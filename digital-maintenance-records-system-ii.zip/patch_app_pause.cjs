const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

const oldCode = `  // ACTION: Start Work (Technician transition Pending -> In Progress)
  const handleStartWork = async (id: string) => {`;

const newCode = `  // ACTION: Pause Work
  const handlePauseWork = async (id: string) => {
    if (import.meta.env.VITE_SUPABASE_URL) {
      await supabase.from('work_orders').update({ status: 'Paused' }).eq('id', id);
    }
    
    setWorkOrders(prev => prev.map(o => {
      if (o.id === id) {
        return { ...o, status: 'Paused' };
      }
      return o;
    }));

    const newLog = {
      id: \`LOG-\${Math.floor(Math.random() * 90000) + 10000}\`,
      timestamp: new Date().toISOString(),
      ticketId: id,
      user: authorizedUser || 'Technician',
      action: 'Paused Work',
      details: \`Status updated to Paused.\`
    };
    
    if (import.meta.env.VITE_SUPABASE_URL) {
      await supabase.from('activity_logs').insert({
        id: newLog.id,
        timestamp: newLog.timestamp,
        ticket_id: newLog.ticketId,
        user_name: newLog.user,
        action: newLog.action,
        details: newLog.details
      });
    }
    
    setActivityLogs(prev => [newLog, ...prev]);
  };

  // ACTION: Start Work (Technician transition Pending -> In Progress)
  const handleStartWork = async (id: string) => {`;

if (code.includes('handlePauseWork')) {
  console.log("Already has handlePauseWork");
} else {
  code = code.replace(oldCode, newCode);
  fs.writeFileSync('src/App.tsx', code);
  console.log("Patched App.tsx for handlePauseWork");
}
