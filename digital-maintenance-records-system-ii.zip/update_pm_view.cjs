const fs = require('fs');
let code = fs.readFileSync('src/components/PreventiveMaintenanceView.tsx', 'utf-8');

// 1. Add to Props
code = code.replace(
    "interface PreventiveMaintenanceViewProps {\n  onAddWorkOrder: (order: Omit<WorkOrder, 'id' | 'timestamp' | 'status'>) => void;\n  staffList: import('../types').Personnel[];\n  technicians?: import('../types').Technician[];\n  authorizedUser: string | null;\n}",
    "interface PreventiveMaintenanceViewProps {\n  onAddWorkOrder: (order: Omit<WorkOrder, 'id' | 'timestamp' | 'status'>) => void;\n  onAddPMTask?: (pm: any) => void;\n  staffList: import('../types').Personnel[];\n  technicians?: import('../types').Technician[];\n  authorizedUser: string | null;\n}"
);

// 2. Add to destructuring
code = code.replace(
    "export const PreventiveMaintenanceView: React.FC<PreventiveMaintenanceViewProps> = ({ onAddWorkOrder, technicians, authorizedUser, staffList }) => {",
    "export const PreventiveMaintenanceView: React.FC<PreventiveMaintenanceViewProps> = ({ onAddWorkOrder, onAddPMTask, technicians, authorizedUser, staffList }) => {"
);

// 3. Add to the newPM insert
const oldInsert = `              if (import.meta.env.VITE_SUPABASE_URL) {
                const { error } = await supabase.from('preventive_maintenance').insert([newPM]);
                if (error) console.error('Error saving PM', error);
              }
              
              // update local state
              setSchedules(prev => [newPM as any, ...prev]);`;

const newInsert = `              if (import.meta.env.VITE_SUPABASE_URL) {
                const { error } = await supabase.from('preventive_maintenance').insert([newPM]);
                if (error) console.error('Error saving PM', error);
              }
              
              if (onAddPMTask) {
                onAddPMTask(newPM);
              }
              
              // update local state
              setSchedules(prev => [newPM as any, ...prev]);`;

code = code.replace(oldInsert, newInsert);

fs.writeFileSync('src/components/PreventiveMaintenanceView.tsx', code);
console.log("PreventiveMaintenanceView updated");
