const fs = require('fs');
let code = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

const UI_OLD = `                <div>
                  <label className="block text-xs font-medium text-slate-700 uppercase tracking-wider mb-1">
                    Total Machine Downtime (Hours)
                  </label>
                  <div className="flex items-center space-x-3">
                    <input
                      type="range"
                      min="0.25"
                      max="24"
                      step="0.25"
                      className="w-full accent-slate-800 h-2 bg-slate-200 rounded-lg cursor-pointer"
                      value={downtimeHours}
                      onChange={(e) => setDowntimeHours(parseFloat(e.target.value))}
                    />
                    <span className="text-sm font-bold text-slate-800 font-mono shrink-0 bg-slate-100 border border-slate-200 px-2.5 py-1 rounded">
                      {downtimeHours} hr{downtimeHours !== 1 ? 's' : ''}
                    </span>
                  </div>
                  <p className="mt-1 text-[10px] text-slate-400">Used to compute accurate MTTR performance metrics.</p>
                </div>`;

const UI_NEW = `                <div>
                  <label className="block text-xs font-medium text-slate-700 uppercase tracking-wider mb-1 flex items-center gap-1">
                    <Clock className="w-3 h-3" /> Total Machine Downtime (Auto-Calculated)
                  </label>
                  <div className="flex items-center space-x-3">
                    <div className="w-full h-10 bg-slate-100 border border-slate-200 rounded-lg flex items-center px-3 cursor-not-allowed overflow-hidden">
                      <div className="h-full bg-slate-200/50 absolute left-0 top-0 pointer-events-none" style={{ width: '100%' }}></div>
                      <span className="text-sm font-bold text-slate-500 font-mono relative z-10 flex items-center gap-2">
                        {downtimeHours} hr{downtimeHours !== 1 ? 's' : ''}
                        <span className="text-[10px] bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded uppercase tracking-widest font-sans font-bold">Auto</span>
                      </span>
                    </div>
                  </div>
                  <p className="mt-1 text-[10px] text-slate-400">Calculated automatically from ticket creation to completion time.</p>
                </div>`;

code = code.replace(UI_OLD, UI_NEW);

const LOGIC_OLD = `  const handleOpenCompletionModal = (orderId: string) => {
    setCompletingOrderId(orderId);
    const saved = localStorage.getItem(\`dmr_draft_\${orderId}\`);
    if (saved) {
      try {
        const draft = JSON.parse(saved);
        setActionsTaken(draft.actionsTaken || '');
        setMaterialsUsed(draft.materialsUsed || '');
        setDowntimeHours(draft.downtimeHours || 1);
      } catch(e) {
        setActionsTaken('');
        setMaterialsUsed('');
        setDowntimeHours(1);
      }
    } else {
      setActionsTaken('');
      setMaterialsUsed('');
      setDowntimeHours(1);
    }
  };`;

const LOGIC_NEW = `  const handleOpenCompletionModal = (orderId: string) => {
    setCompletingOrderId(orderId);
    
    // Auto-calculate downtime
    const order = allTickets.find(t => t.id === orderId);
    let autoHrs = 1;
    if (order?.timestamp) {
      const diffMs = Date.now() - new Date(order.timestamp).getTime();
      // Calculate hours and round to nearest 0.25 (15 mins), minimum 0.25
      const diffHrs = Math.max(0.25, Math.round((diffMs / (1000 * 60 * 60)) * 4) / 4);
      autoHrs = (order as any).isPM ? (order.downtimeHours || diffHrs) : diffHrs;
    }
    setDowntimeHours(autoHrs);

    const saved = localStorage.getItem(\`dmr_draft_\${orderId}\`);
    if (saved) {
      try {
        const draft = JSON.parse(saved);
        setActionsTaken(draft.actionsTaken || '');
        setMaterialsUsed(draft.materialsUsed || '');
      } catch(e) {
        setActionsTaken('');
        setMaterialsUsed('');
      }
    } else {
      setActionsTaken('');
      setMaterialsUsed('');
    }
  };`;

code = code.replace(LOGIC_OLD, LOGIC_NEW);
fs.writeFileSync('src/components/TechnicianView.tsx', code);
