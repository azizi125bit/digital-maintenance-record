import express from "express";
import http from "http";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import { readDb, writeDb, type LocalDbData } from "./src/server/localDb.ts";
import { startPMScheduler, getPMSchedulerStatus, checkAndGeneratePMWorkOrders } from "./src/server/pmScheduler.ts";

dotenv.config();

async function startServer() {
  const app = express();
  const server = http.createServer(app);
  // AI Studio requires port 3000. Check --port CLI argument, env var, or default to 3000
  const portArgIdx = process.argv.indexOf("--port");
  const cliPort = portArgIdx !== -1 && process.argv[portArgIdx + 1] ? Number(process.argv[portArgIdx + 1]) : undefined;
  const envPort = process.env.PORT && process.env.PORT !== "8080" ? Number(process.env.PORT) : undefined;
  const PORT = cliPort || envPort || Number(process.env.DEFAULT_APP_PORT) || 3000;

  app.use(express.json({ limit: "15mb" }));
  app.use(express.urlencoded({ extended: true, limit: "15mb" }));

  // Storage directory for uploaded assets (asset-images bucket and breakdown-images bucket)
  const UPLOADS_DIR = path.join(process.cwd(), "uploads");
  const ASSET_BUCKET_DIR = path.join(UPLOADS_DIR, "asset-images");
  const BREAKDOWN_BUCKET_DIR = path.join(UPLOADS_DIR, "breakdown-images");
  if (!fs.existsSync(ASSET_BUCKET_DIR)) {
    fs.mkdirSync(ASSET_BUCKET_DIR, { recursive: true });
  }
  if (!fs.existsSync(BREAKDOWN_BUCKET_DIR)) {
    fs.mkdirSync(BREAKDOWN_BUCKET_DIR, { recursive: true });
  }

  // Serve storage files publicly under /storage/v1/object/public/:bucket/:fileName and /uploads
  app.use("/storage/v1/object/public/asset-images", express.static(ASSET_BUCKET_DIR));
  app.use("/storage/v1/object/public/breakdown-images", express.static(BREAKDOWN_BUCKET_DIR));
  app.use("/uploads", express.static(UPLOADS_DIR));

  // Storage Upload endpoint compatible with Supabase Storage upload
  app.post("/api/storage/:bucket/upload", (req, res) => {
    try {
      const { bucket } = req.params;
      const { path: filePath, fileBase64, contentType } = req.body;

      if (!filePath || !fileBase64) {
        return res.status(400).json({ error: "Missing filePath or fileBase64" });
      }

      const bucketDir = path.join(UPLOADS_DIR, bucket);
      if (!fs.existsSync(bucketDir)) {
        fs.mkdirSync(bucketDir, { recursive: true });
      }

      const safeFileName = path.basename(filePath);
      const targetFilePath = path.join(bucketDir, safeFileName);

      const base64Data = fileBase64.replace(/^data:image\/[a-z]+;base64,/, "");
      fs.writeFileSync(targetFilePath, Buffer.from(base64Data, "base64"));

      const publicUrl = `/storage/v1/object/public/${bucket}/${safeFileName}`;
      res.json({
        data: {
          path: `${bucket}/${safeFileName}`,
          fullPath: `${bucket}/${safeFileName}`,
          publicUrl
        },
        error: null
      });
    } catch (err: any) {
      console.error("Storage upload error:", err);
      res.status(500).json({ error: err.message || "Failed to upload file" });
    }
  });

  // Storage Delete endpoint
  app.delete("/api/storage/:bucket/remove", (req, res) => {
    try {
      const { bucket } = req.params;
      const { paths } = req.body;
      const bucketDir = path.join(UPLOADS_DIR, bucket);

      if (Array.isArray(paths)) {
        for (const p of paths) {
          const safeName = path.basename(p);
          const fullPath = path.join(bucketDir, safeName);
          if (fs.existsSync(fullPath)) {
            fs.unlinkSync(fullPath);
          }
        }
      }
      res.json({ data: { success: true }, error: null });
    } catch (err: any) {
      console.error("Storage delete error:", err);
      res.status(500).json({ error: err.message || "Failed to delete file" });
    }
  });

  // API routes FIRST
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", mode: "local-server" });
  });

  // InfinityFree api.php compatibility router for development environment
  const TABLE_ALIAS_MAP: Record<string, string> = {
    assets: 'assets',
    staff: 'profiles',
    profiles: 'profiles',
    users: 'profiles',
    workorders: 'work_orders',
    work_orders: 'work_orders',
    pmschedules: 'preventive_maintenance',
    pm_schedules: 'preventive_maintenance',
    preventive_maintenance: 'preventive_maintenance',
    maintenancerecords: 'machine_breakdowns',
    machine_breakdowns: 'machine_breakdowns',
    breakdowns: 'machine_breakdowns',
    safetydocuments: 'safety_documents',
    safety_documents: 'safety_documents',
    requiredocuments: 'safety_documents',
    require_documents: 'safety_documents',
    activitylogs: 'activity_logs',
    activity_logs: 'activity_logs',
    inventory: 'inventory'
  };

  app.get("/api.php", (req, res) => {
    try {
      const resource = String(req.query.resource || req.query.table || '').toLowerCase();
      if (!resource) {
        return res.json({ success: true, status: "online", service: "DMR API (Dev Mirror)" });
      }

      const tableKey = TABLE_ALIAS_MAP[resource] || resource;
      const db = readDb();
      let records = (db as any)[tableKey] || [];

      // Filter by id or field
      const queryId = req.query.id;
      const filterField = req.query.filterField as string;
      const filterVal = req.query.filterValue;

      if (queryId) {
        records = records.filter((r: any) => r.id === queryId || r.userId === queryId);
      }
      if (filterField && filterVal !== undefined) {
        records = records.filter((r: any) => String(r[filterField]) === String(filterVal));
      }

      res.json({ success: true, data: records, count: records.length });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.post("/api.php", (req, res) => {
    try {
      const body = req.body || {};
      const action = body.action || req.query.action || 'create';
      const resource = String(body.resource || body.table || req.query.resource || '').toLowerCase();

      // Action: Upload image
      if (action === 'upload_image' || action === 'upload') {
        const bucket = (body.bucket || 'asset-images').replace(/[^a-zA-Z0-9_-]/g, '');
        const fileBase64 = body.fileBase64 || '';
        const filePath = body.path || `img_${Date.now()}.jpg`;

        if (!fileBase64) {
          return res.status(400).json({ success: false, error: 'Missing image data' });
        }

        const bucketDir = path.join(UPLOADS_DIR, bucket);
        if (!fs.existsSync(bucketDir)) {
          fs.mkdirSync(bucketDir, { recursive: true });
        }

        const safeFileName = `${Date.now()}_${path.basename(filePath)}`;
        const targetPath = path.join(bucketDir, safeFileName);
        const cleanBase64 = fileBase64.replace(/^data:image\/[a-zA-Z0-9.+-]+;base64,/, '');
        fs.writeFileSync(targetPath, Buffer.from(cleanBase64, 'base64'));

        const publicUrl = `/uploads/${bucket}/${safeFileName}`;
        return res.json({
          success: true,
          publicUrl,
          path: `${bucket}/${safeFileName}`,
          url: publicUrl
        });
      }

      // Action: Login
      if (action === 'login') {
        const { username, pin } = body;
        const db = readDb();
        const user = db.profiles.find((p: any) => 
          (p.username === username || p.email === username || p.fullName === username) && 
          String(p.pin) === String(pin)
        );
        if (!user) {
          return res.status(401).json({ success: false, error: 'Invalid username or PIN' });
        }
        return res.json({ success: true, user });
      }

      // CRUD Operations
      const tableKey = TABLE_ALIAS_MAP[resource] || resource;
      const db = readDb();
      if (!(tableKey in db)) {
        (db as any)[tableKey] = [];
      }

      if (action === 'create' || action === 'insert') {
        const payload = Array.isArray(body.data) ? body.data : [body.data];
        for (const item of payload) {
          const idx = (db as any)[tableKey].findIndex((existing: any) => 
            (item.id && existing.id === item.id) || 
            (item.userId && existing.userId === item.userId)
          );
          if (idx >= 0) {
            (db as any)[tableKey][idx] = { ...(db as any)[tableKey][idx], ...item };
          } else {
            (db as any)[tableKey].unshift(item);
          }
        }
        writeDb(db);
        return res.json({ success: true, data: { count: payload.length }, error: null });
      }

      if (action === 'update') {
        const idField = body.idField || 'id';
        const idValue = body.idValue;
        const updates = body.data || {};
        let updated = false;

        (db as any)[tableKey] = (db as any)[tableKey].map((item: any) => {
          if (item[idField] === idValue || (idField === 'id' && item.userId === idValue)) {
            updated = true;
            return { ...item, ...updates };
          }
          return item;
        });

        if (updated) writeDb(db);
        return res.json({ success: true, data: { updated }, error: null });
      }

      if (action === 'delete') {
        const idField = body.idField || 'id';
        const idValue = body.idValue;
        const prevLen = (db as any)[tableKey].length;

        (db as any)[tableKey] = (db as any)[tableKey].filter((item: any) => 
          !(item[idField] === idValue || (idField === 'id' && item.userId === idValue))
        );

        writeDb(db);
        return res.json({ success: true, data: { deleted: (db as any)[tableKey].length < prevLen }, error: null });
      }

      return res.status(400).json({ success: false, error: `Unsupported action '${action}'` });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Local Database API (replaces Supabase completely)
  const validTables = ['work_orders', 'activity_logs', 'assets', 'preventive_maintenance', 'profiles', 'machine_breakdowns', 'safety_documents'] as const;
  type TableName = typeof validTables[number];

  // GET Table Data
  app.get("/api/local/:table", (req, res) => {
    const table = req.params.table as TableName;
    const db = readDb();
    if (!validTables.includes(table)) {
      return res.status(404).json({ error: `Table ${table} not found` });
    }
    res.json(db[table] || []);
  });

  // POST Insert Item(s)
  app.post("/api/local/:table", (req, res) => {
    const table = req.params.table as TableName;
    if (!validTables.includes(table)) {
      return res.status(404).json({ error: `Table ${table} not found` });
    }

    const db = readDb();
    const payload = Array.isArray(req.body) ? req.body : [req.body];
    
    // Add items (uniquely by id if exists, or append)
    for (const item of payload) {
      const existingIdx = (db[table] as any[]).findIndex((existing: any) => 
        (item.id && existing.id === item.id) || 
        (item.userId && existing.userId === item.userId)
      );

      if (existingIdx >= 0) {
        db[table][existingIdx] = { ...db[table][existingIdx], ...item };
      } else {
        db[table].unshift(item);
      }
    }

    writeDb(db);
    res.json({ success: true, count: payload.length });
  });

  // PUT Update Item
  app.put("/api/local/:table", (req, res) => {
    const table = req.params.table as TableName;
    if (!validTables.includes(table)) {
      return res.status(404).json({ error: `Table ${table} not found` });
    }

    const { idField = 'id', idValue, updates } = req.body;
    const db = readDb();
    let updated = false;

    db[table] = (db[table] as any[]).map((item: any) => {
      if (item[idField] === idValue || (idField === 'id' && item.userId === idValue)) {
        updated = true;
        return { ...item, ...updates };
      }
      return item;
    });

    if (updated) {
      writeDb(db);
    }

    res.json({ success: updated });
  });

  // DELETE Item
  app.delete("/api/local/:table", (req, res) => {
    const table = req.params.table as TableName;
    if (!validTables.includes(table)) {
      return res.status(404).json({ error: `Table ${table} not found` });
    }

    const { idField = 'id', idValue } = req.body;
    const db = readDb();
    const initialLen = db[table].length;

    db[table] = (db[table] as any[]).filter((item: any) => {
      return !(item[idField] === idValue || (idField === 'id' && item.userId === idValue));
    });

    writeDb(db);
    res.json({ success: db[table].length < initialLen });
  });

  // Local Create User (Replaces Supabase Auth)
  app.post("/api/supabase/create-user", (req, res) => {
    try {
      const { full_name, role, username, email } = req.body;
      const db = readDb();
      const newUserId = `USR-${Math.floor(Math.random() * 90000) + 10000}`;
      
      const newProfile = {
        id: newUserId,
        userId: newUserId,
        employeeId: `EMP-${Math.floor(Math.random() * 9000 + 1000)}`,
        fullName: full_name,
        full_name,
        username,
        email: email || `${username}@dmr.com`,
        phone: 'N/A',
        department: 'Maintenance',
        position: role,
        role,
        accountStatus: 'Active',
        account_status: 'Active',
        dateJoined: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        pin: '1234'
      };

      db.profiles.push(newProfile);
      writeDb(db);

      res.json({ success: true, user: { id: newUserId, email: newProfile.email } });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Gemini AI Helpers
  app.post("/api/generate-checklist", async (req, res) => {
    try {
      const { issue, category } = req.body;
      const key = process.env.GEMINI_API_KEY;
      if (!key) {
        return res.status(500).json({ error: "GEMINI_API_KEY is missing." });
      }

      const ai = new GoogleGenAI({ apiKey: key });
      const prompt = `You are an expert maintenance technician. Given a failure diagnostic description and a system category, generate a strict JSON array of checklist items (strings) for the technician to perform. Generate exactly 3 to 6 practical tasks.
      
System Category: ${category}
Diagnostic Description: ${issue}

Return ONLY a JSON array of strings, e.g. ["Task 1", "Task 2"]. No markdown formatting, no backticks.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt
      });

      let responseText = response.text || "[]";
      responseText = responseText.replace(/```json/g, '').replace(/```/g, '').trim();

      const items = JSON.parse(responseText);
      const checklist = items.map((item: string) => ({ task: item, completed: false }));
      
      res.json({ checklist });
    } catch (err: any) {
      console.error("Gemini API Error in /api/generate-checklist:", err.message);
      res.json({
        checklist: [
          { task: "Inspect system thoroughly", completed: false },
          { task: "Identify primary fault", completed: false },
          { task: "Perform required maintenance", completed: false }
        ]
      });
    }
  });

  app.post("/api/auto-generate-pm", async (req, res) => {
    try {
      const { machine, condition, recommendations } = req.body;
      const key = process.env.GEMINI_API_KEY;
      if (!key) {
        return res.status(500).json({ error: "GEMINI_API_KEY is missing." });
      }

      const ai = new GoogleGenAI({ apiKey: key });
      const prompt = `You are an expert maintenance planner. A preventive maintenance alert was triggered:
Machine: ${machine}
Condition: ${condition}
Initial Recommendations: ${recommendations.join(', ')}

Generate a structured Preventive Maintenance Work Order.
Return ONLY a valid JSON object with the following keys:
- "issue": (string) A clear, professional description of the work to be done.
- "category": (string) One of: "Mechanical", "Electrical", "Pneumatic", "General"
- "priority": (string) One of: "Low", "Medium", "High"
- "checklist": (array of objects) Each object must have { "task": "string", "completed": false }. Make it 3-6 tasks based on the recommendations and standard practices.

Do not include markdown formatting or backticks.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt
      });

      let responseText = response.text || "{}";
      responseText = responseText.replace(/```json/g, '').replace(/```/g, '').trim();

      const data = JSON.parse(responseText);
      res.json(data);
    } catch (err: any) {
      console.error("Gemini API Error in /api/auto-generate-pm:", err.message);
      res.json({
        issue: "Scheduled Preventive Maintenance",
        category: "General",
        priority: "Medium",
        checklist: [
          { task: "Visual inspection of equipment", completed: false },
          { task: "Clean and lubricate required components", completed: false },
          { task: "Test system operation and record metrics", completed: false }
        ]
      });
    }
  });

  // Automated PM Work Order Generation Endpoints
  app.get("/api/pm-scheduler/status", (req, res) => {
    try {
      res.json(getPMSchedulerStatus());
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/pm-scheduler/trigger", async (req, res) => {
    try {
      const result = await checkAndGeneratePMWorkOrders();
      res.json({
        success: true,
        result,
        status: getPMSchedulerStatus()
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Vite middleware for development
  let viteDevServer: any = null;
  if (process.env.NODE_ENV !== "production") {
    viteDevServer = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR === 'true' ? false : { server },
      },
      appType: "spa",
    });
    app.use(viteDevServer.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`\n  VITE v6.2.3  ready in 150 ms\n`);
    console.log(`  ➜  Local:   http://localhost:${PORT}/`);
    console.log(`  ➜  Network: http://0.0.0.0:${PORT}/`);
    console.log(`Server running on http://0.0.0.0:${PORT} (Localhost mode)`);
    // Start automated PM work order generation background scheduler
    try {
      startPMScheduler(60000);
    } catch (schedErr) {
      console.error('[PM Scheduler] Failed to initialize scheduler:', schedErr);
    }
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
