const fs = require('fs');
let code = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

const oldProps = `interface TechnicianViewProps {
  workOrders: any[];
  pmTasks?: any[];
  onStartWork: (id: string) => void;
  onCompleteWork: (id: string, actionsTaken: string, materialsUsed: string, downtimeHours: number) => void;`;
  
const newProps = `interface TechnicianViewProps {
  workOrders: any[];
  pmTasks?: any[];
  onStartWork: (id: string) => void;
  onPauseWork: (id: string) => void;
  onCompleteWork: (id: string, actionsTaken: string, materialsUsed: string, downtimeHours: number) => void;`;

if (code.includes('onPauseWork: (id: string) => void;') && !code.includes(oldProps)) {
  console.log("Already added");
} else {
  code = code.replace(oldProps, newProps);
  fs.writeFileSync('src/components/TechnicianView.tsx', code);
  console.log("Patched TechnicianViewProps");
}
