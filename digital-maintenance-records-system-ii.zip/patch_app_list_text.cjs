const fs = require('fs');
let code = fs.readFileSync('src/components/AssetListView.tsx', 'utf-8');

const target1 = `                      'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400'
                    }\`}>
                      {asset.status}
                    </span>`;

const new1 = `                      'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400'
                    }\`}>
                      {asset.status === 'Decommissioned' ? 'Scraped' : asset.status}
                    </span>`;

const target2 = `                      'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400'
                    }\`}>
                    {viewingAsset.status}
                  </span>`;

const new2 = `                      'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400'
                    }\`}>
                    {viewingAsset.status === 'Decommissioned' ? 'Scraped' : viewingAsset.status}
                  </span>`;

code = code.replace(target1, new1);
code = code.replace(target2, new2);

fs.writeFileSync('src/components/AssetListView.tsx', code);
console.log("Patched AssetListView text to Scraped");
