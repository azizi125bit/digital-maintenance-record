const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const returnStart = code.indexOf('if (!isAuthorized) {');
const endOfReturn = code.indexOf('  return (\n    <div className={`flex flex-col md:flex-row min-h-screen', returnStart);

const restoredLoginJsx = `  if (!isAuthorized) {
    return (
      <div className="min-h-screen bg-[#050b14] flex flex-col justify-center items-center p-4 font-sans selection:bg-sky-500/30 relative overflow-hidden">
        
        <div className="w-full max-w-sm z-10">
          <div className="mb-8 text-center flex flex-col items-center">
            <div className="w-12 h-12 bg-sky-500 rounded-lg flex items-center justify-center text-white shadow-lg shadow-sky-500/20 mb-4">
              <Wrench className="w-6 h-6" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white block font-display">DMR System</h1>
            <p className="text-xs text-sky-400 font-semibold uppercase tracking-widest block mt-1">TVET Workshop</p>
          </div>

          <div className="bg-slate-800/50 backdrop-blur-md border border-slate-700 rounded-xl p-6 shadow-2xl">
            <form onSubmit={handleLogin} className="space-y-4">
              {loginError && (
                <div className="p-3 bg-rose-950/60 border border-rose-800 text-rose-300 rounded-lg text-xs font-medium text-center">
                  ⚠️ {loginError}
                </div>
              )}

              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  Username
                </label>
                <input
                  type="text"
                  required
                  placeholder="Enter username"
                  className="block w-full rounded-lg border border-slate-700 bg-slate-900 text-slate-200 px-3 py-2 text-sm focus:border-sky-500 focus:ring-1 focus:ring-sky-500 outline-none placeholder:text-slate-500 transition-all"
                  value={loginUsername}
                  onChange={(e) => {
                    setLoginUsername(e.target.value);
                    setLoginError('');
                  }}
                />
              </div>

              <div className="space-y-1 relative">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    placeholder="••••••••"
                    className="block w-full text-center rounded-lg border border-slate-700 bg-slate-900 text-slate-200 px-3 py-2 text-sm tracking-widest font-mono focus:border-sky-500 focus:ring-1 focus:ring-sky-500 outline-none placeholder:text-slate-600 placeholder:tracking-normal transition-all"
                    value={loginPassword}
                    onChange={(e) => {
                      setLoginPassword(e.target.value);
                      setLoginError('');
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 text-xs font-medium focus:outline-none bg-slate-900 pl-2"
                  >
                    {showPassword ? "Hide" : "Show"}
                  </button>
                </div>
              </div>

              <div className="flex justify-end pt-1">
                <button type="button" className="text-[10px] text-sky-400 hover:text-sky-300 transition-colors font-medium cursor-pointer uppercase tracking-wider">
                  Forgot Password?
                </button>
              </div>

              <button
                type="submit"
                className="w-full inline-flex justify-center items-center px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-slate-900 bg-sky-400 hover:bg-sky-300 rounded-lg cursor-pointer transition-all shadow-md shadow-sky-500/10 hover:shadow-lg font-sans mt-2"
              >
                Verify Identity & Gain Access
              </button>
            </form>
          </div>
        </div>

        <p className="text-[10px] text-slate-500 mt-8 font-mono select-none z-10">
          DMR TVET SECURITY SUBSYSTEM • VERSION 1.0.0 • ENCRYPTED SESSION
        </p>
      </div>
    );
  }

`;

if (returnStart !== -1 && endOfReturn !== -1) {
  code = code.substring(0, returnStart) + restoredLoginJsx + code.substring(endOfReturn);
  fs.writeFileSync('src/App.tsx', code);
} else {
  console.log("Could not find bounds");
}
