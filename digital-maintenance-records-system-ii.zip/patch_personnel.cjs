const fs = require('fs');
let content = fs.readFileSync('src/components/PersonnelManagementView.tsx', 'utf-8');

// 1. Add onRemovePersonnel to props
content = content.replace(
  "onAddPersonnel: (personnel: Personnel) => void;",
  "onAddPersonnel: (personnel: Personnel) => void;\n  onRemovePersonnel: (userId: string) => void;"
);

// 2. Destructure it
content = content.replace(
  "  onAddPersonnel,\n  currentRole \n}) => {",
  "  onAddPersonnel,\n  onRemovePersonnel,\n  currentRole \n}) => {"
);

// 3. Add state
content = content.replace(
  "const [deactivateConfirmId, setDeactivateConfirmId] = useState<string | null>(null);",
  "const [deactivateConfirmId, setDeactivateConfirmId] = useState<string | null>(null);\n  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);"
);

// 4. Add handleDelete
const handleDeleteCode = `
  const handleDelete = (userId: string) => {
    onRemovePersonnel(userId);
    setDeleteConfirmId(null);
  };
`;
content = content.replace(
  "  const handleActivate = (userId: string) => {",
  handleDeleteCode + "\n  const handleActivate = (userId: string) => {"
);

// 5. Add button
const oldButtons = `                        </button>
                      )}
                    </td>`;

const newButtons = `                        </button>
                      )}
                      
                      <button 
                        onClick={() => setDeleteConfirmId(person.userId)}
                        className="text-[10px] font-bold px-2 py-1 bg-rose-50 hover:bg-rose-100 dark:bg-rose-900/20 dark:hover:bg-rose-900/40 text-rose-600 dark:text-rose-400 rounded transition-colors cursor-pointer flex items-center gap-1"
                        title="Delete User"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </td>`;
content = content.replace(oldButtons, newButtons);

// 6. Add Modal
const oldModalTarget = `      {/* Deactivate Confirmation Modal */}`;
const deleteModalCode = `      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl max-w-md w-full border border-slate-200 dark:border-slate-800 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-rose-50 dark:bg-rose-900/20">
              <h3 className="font-bold text-rose-600 dark:text-rose-400 flex items-center gap-2">
                <Trash2 className="w-5 h-5" /> Confirm Deletion
              </h3>
              <button 
                onClick={() => setDeleteConfirmId(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6">
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                Are you sure you want to permanently delete this user account?<br/><br/>
                This action cannot be undone. Historical records associated with this user might lose their reference.
              </p>
              <div className="flex items-center gap-3 justify-end mt-6">
                <button 
                  onClick={() => setDeleteConfirmId(null)}
                  className="px-4 py-2 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => handleDelete(deleteConfirmId)}
                  className="px-4 py-2 text-sm font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-sm transition-colors cursor-pointer"
                >
                  Delete User
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

`;
content = content.replace(oldModalTarget, deleteModalCode + oldModalTarget);

fs.writeFileSync('src/components/PersonnelManagementView.tsx', content);
