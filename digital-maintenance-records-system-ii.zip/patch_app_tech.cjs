const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf-8');

content = content.replace(
  "staffList={staffList}",
  "staffList={staffList}\n                  authorizedUser={authorizedUser}"
);

fs.writeFileSync('src/App.tsx', content);
