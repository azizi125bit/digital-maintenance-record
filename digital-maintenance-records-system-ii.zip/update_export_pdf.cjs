const fs = require('fs');

let content = fs.readFileSync('src/components/PreventiveMaintenanceView.tsx', 'utf-8');

// Replace the alert with fallback to the first schedule
content = content.replace(
  `    if (!selectedScheduleId) {
      alert("Please select a PM Schedule from the table first.");
      return;
    }

    const schedule = schedules.find(s => s.id === selectedScheduleId);
    if (!schedule) return;`,
  `    // Fallback to the first schedule if none is selected
    const scheduleToExport = selectedScheduleId 
      ? schedules.find(s => s.id === selectedScheduleId) 
      : schedules[0];
      
    if (!scheduleToExport) return;
    const schedule = scheduleToExport;`
);

fs.writeFileSync('src/components/PreventiveMaintenanceView.tsx', content);
