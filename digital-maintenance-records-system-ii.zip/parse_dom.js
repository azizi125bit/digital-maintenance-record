const fs = require('fs');

const appTsx = fs.readFileSync('src/App.tsx', 'utf-8');
const lines = appTsx.split('\n');

let mainStart = -1;
for (let i=0; i<lines.length; i++) {
  if (lines[i].includes('<main')) {
    mainStart = i;
    break;
  }
}

console.log("Lines starting from <main>:");
console.log(lines.slice(mainStart, mainStart + 150).join('\n'));
