const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf-8');

// 1. Remove dbConfig usages from top
content = content.replace(/const \[dbConfig, setDbConfig\] = useState<DatabaseConfig>\(\(\) => \{[\s\S]*?\}\);\n/g, '');
content = content.replace(/useEffect\(\(\) => \{\n    localStorage\.setItem\('dmr_db_config', JSON\.stringify\(dbConfig\)\);\n  \}, \[dbConfig\]\);\n/g, '');

// 2. Remove handleFetchFromSheets
const fetchStart = content.indexOf('const handleFetchFromSheets');
if(fetchStart !== -1) {
  let depth = 0;
  let end = -1;
  let started = false;
  for(let i = fetchStart; i < content.length; i++) {
    if(content[i] === '{') {
      depth++;
      started = true;
    }
    if(content[i] === '}') {
      depth--;
      if(started && depth === 0) {
        end = i;
        break;
      }
    }
  }
  if(end !== -1) {
    const before = content.substring(0, fetchStart);
    const after = content.substring(end + 1);
    content = before + after;
  }
}

// 3. Remove all fetch calls conditionally using dbConfig
content = content.replace(/if\s*\(dbConfig\.isRealSyncEnabled\s*&&\s*dbConfig\.appsScriptUrl\)\s*\{[\s\S]*?catch\s*\([^)]*\)\s*\{[\s\S]*?\}\s*\}\s*finally\s*\{[\s\S]*?\}\s*\}/g, '');
content = content.replace(/if\s*\(dbConfig\.isRealSyncEnabled\s*&&\s*dbConfig\.appsScriptUrl\)\s*\{[\s\S]*?catch\s*\([^)]*\)\s*\{[\s\S]*?\}\s*\}/g, '');
content = content.replace(/if\s*\(dbConfig\.isRealSyncEnabled\s*&&\s*dbConfig\.appsScriptUrl\)\s*\{[\s\S]*?catch\s*\([^)]*\)\s*\{[\s\S]*?\}\s*setIsSyncing\(false\);\s*\}/g, '');

content = content.replace(/<div className="bg-slate-800\/40 p-3 rounded-lg border border-slate-800 text-\[10px\] text-slate-400 space-y-1">[\s\S]*?<\/div>/g, '');

fs.writeFileSync('src/App.tsx', content);
