const fs = require('fs');
let code = fs.readFileSync('src/components/PreventiveMaintenanceView.tsx', 'utf-8');

code = code.replace(
  "onClick={() => setIsCreateModalOpen(true); setSelectedAssetForForm(null); setSelectedAssetForForm(null);}",
  "onClick={() => { setIsCreateModalOpen(true); setSelectedAssetForForm(null); }}"
);
code = code.replace(
  "onClick={() => setIsCreateModalOpen(false); setSelectedAssetForForm(null); setSelectedAssetForForm(null);}",
  "onClick={() => { setIsCreateModalOpen(false); setSelectedAssetForForm(null); }}"
);
code = code.replace(
  "onClick={() => setIsCreateModalOpen(false); setSelectedAssetForForm(null);}",
  "onClick={() => { setIsCreateModalOpen(false); setSelectedAssetForForm(null); }}"
);

fs.writeFileSync('src/components/PreventiveMaintenanceView.tsx', code);
