const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// Remove Users from ./types
code = code.replace('import { Users, WorkOrder', 'import { WorkOrder');

// Add Users to lucide-react import
code = code.replace("import { \n  ShieldCheck,", "import { \n  Users,\n  ShieldCheck,");

fs.writeFileSync('src/App.tsx', code);
