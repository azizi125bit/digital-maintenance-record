const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

if (!code.includes("const [pmTasks, setPmTasks]")) {
    code = code.replace(
        "const [staffList, setStaffList] = useState<import('./types').Personnel[]>([]);",
        "const [staffList, setStaffList] = useState<import('./types').Personnel[]>([]);\n  const [pmTasks, setPmTasks] = useState<any[]>([]);"
    );
    
    // Check if it was replaced, if not try another pattern
    if (!code.includes("const [pmTasks, setPmTasks]")) {
         // Just insert it after setActivityLogs
         code = code.replace(
             "const [activityLogs, setActivityLogs] = useState<ActivityLog[]>(() => {",
             "const [pmTasks, setPmTasks] = useState<any[]>([]);\n  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>(() => {"
         );
    }
}

fs.writeFileSync('src/App.tsx', code);
