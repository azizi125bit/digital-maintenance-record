const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf-8');

// The problematic block:
// // Sync completed ticket row fields to Google Sheets
// catch (err: any) {
//     console.error('GAS ticket resolution update failed:', err);
//     showFeedback('error', `Cloud Sync Failed: ${err.message || 'CORS/Network error'}. Saved locally.`);
//   }
// } else {
//   showFeedback('success', `Ticket ${id} marked completed locally.`);
// }

const toRemove = `// Sync completed ticket row fields to Google Sheets
    catch (err: any) {
        console.error('GAS ticket resolution update failed:', err);
        showFeedback('error', \`Cloud Sync Failed: \${err.message || 'CORS/Network error'}. Saved locally.\`);
      }
    } else {
      showFeedback('success', \`Ticket \${id} marked completed locally.\`);
    }`;

content = content.replace(toRemove, `showFeedback('success', \`Ticket \${id} marked completed locally.\`);`);
fs.writeFileSync('src/App.tsx', content);
