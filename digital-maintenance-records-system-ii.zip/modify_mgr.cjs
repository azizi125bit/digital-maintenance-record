const fs = require('fs');
let code = fs.readFileSync('src/components/ManagerView.tsx', 'utf-8');

if (!code.includes("pmTasks?: any[];")) {
    code = code.replace(
        "workOrders: WorkOrder[];",
        "workOrders: WorkOrder[];\n  pmTasks?: any[];"
    );
}

code = code.replace(
    "export default function ManagerView({ workOrders, onAddWorkOrder, onUpdatePriority, onReassignTechnician, technicians, staffList, authorizedUser, authorizedUserRole }: ManagerViewProps) {",
    "export default function ManagerView({ workOrders, pmTasks = [], onAddWorkOrder, onUpdatePriority, onReassignTechnician, technicians, staffList, authorizedUser, authorizedUserRole }: ManagerViewProps) {"
);

// We should merge workOrders and pmTasks inside ManagerView just like in App
const normalizationCode = `
  const normalizedPMTasks = pmTasks.map(pm => ({
    id: pm.id,
    timestamp: pm.scheduled_date,
    assetId: pm.asset_id,
    assetName: pm.asset_name,
    category: pm.category || 'General',
    issue: \`[\${pm.maintenance_type || 'PM'}] \${pm.maintenance_task}\`,
    priority: pm.priority,
    assignedToId: pm.assigned_to_id || 'unassigned',
    assignedToName: pm.assigned_to_name,
    status: pm.status,
    loggedBy: pm.supervisor || pm.logged_by || 'System',
    isPM: true,
    downtimeHours: pm.estimated_duration || 2
  }));

  const allTickets = [...workOrders, ...normalizedPMTasks];
`;

if (!code.includes('const allTickets = [...workOrders, ...normalizedPMTasks];')) {
    code = code.replace(
        "const activeOrders = workOrders.filter(order => order.status !== 'Completed');",
        normalizationCode + "\n  const activeOrders = allTickets.filter(order => order.status !== 'Completed');"
    );
    
    // update techWorkload
    code = code.replace(
        "const techOrders = workOrders.filter(o => o.assignedToId === tech.id);",
        "const techOrders = allTickets.filter(o => o.assignedToId === tech.id);"
    );
    
    // update completedOrdersPerTech
    code = code.replace(
        "const totalCompleted = workOrders.filter(",
        "const totalCompleted = allTickets.filter("
    );
    
    // update assetMaintenanceData
    code = code.replace(
        "const completedCount = workOrders.filter(",
        "const completedCount = allTickets.filter("
    );
    code = code.replace(
        "const totalCount = workOrders.filter(o => o.assetId === asset.id).length;",
        "const totalCount = allTickets.filter(o => o.assetId === asset.id).length;"
    );
    
    // update downtimeTrendData
    code = code.replace(
        "const downtimeHours = workOrders",
        "const downtimeHours = allTickets"
    );
}

fs.writeFileSync('src/components/ManagerView.tsx', code);
console.log("ManagerView modified");
