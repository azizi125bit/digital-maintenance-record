const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf-8');

const newFunc = `
  // ACTION: Start Work (Technician transition Pending -> In Progress)
  const handleStartWork = (id: string) => {
    setWorkOrders(prev => prev.map(o => {
      if (o.id === id) {
        return { ...o, status: 'In Progress' };
      }
      return o;
    }));

    const newLog = {
      id: \`LOG-\${Math.floor(Math.random() * 90000) + 10000}\`,
      timestamp: new Date().toISOString(),
      ticketId: id,
      user: 'Technician',
      action: 'Started Work',
      details: \`Status updated to In Progress.\`
    };
    // @ts-ignore
    setActivityLogs(prev => [newLog, ...prev]);
  };

  // ACTION: Complete Work`;

content = content.replace('  // ACTION: Complete Work', newFunc);
fs.writeFileSync('src/App.tsx', content);
