const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf-8');

// Fix ManagerView duplicate
content = content.replace(
`                <ManagerView
                  staffList={staffList}
                  authorizedUser={authorizedUser}
                  workOrders={workOrders}`,
`                <ManagerView
                  staffList={staffList}
                  workOrders={workOrders}`
);

// Add authorizedUser to TechnicianView
content = content.replace(
`                <TechnicianView
                  workOrders={workOrders}
                  onStartWork={handleStartWork}
                  onCompleteWork={handleCompleteWork}
                  technicians={technicians}
                  staffList={staffList}
                />`,
`                <TechnicianView
                  workOrders={workOrders}
                  onStartWork={handleStartWork}
                  onCompleteWork={handleCompleteWork}
                  technicians={technicians}
                  staffList={staffList}
                  authorizedUser={authorizedUser}
                />`
);

fs.writeFileSync('src/App.tsx', content);
