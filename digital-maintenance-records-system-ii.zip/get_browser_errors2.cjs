const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', msg => {
    if (msg.type() === 'error') {
      errors.push(msg.text());
    }
  });

  await page.goto('http://localhost:3000', { waitUntil: 'networkidle0' });
  await new Promise(r => setTimeout(r, 1000));
  
  // Try to login as John Doe
  await page.evaluate(() => {
     const inputs = Array.from(document.querySelectorAll('input'));
     if (inputs[0]) inputs[0].value = 'john.d';
     if (inputs[1]) inputs[1].value = '1234';
     const btn = document.querySelector('button[type="submit"]');
     if (btn) btn.click();
  });

  await new Promise(r => setTimeout(r, 2000));
  
  console.log("Browser Errors after login:", errors);
  await browser.close();
})();
