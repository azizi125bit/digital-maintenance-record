const fs = require('fs');
let code = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

const OLD_MODAL = `  const handleOpenCompletionModal = (orderId: string) => {
    setCompletingOrderId(orderId);
    
    // Auto-calculate downtime
    const order = allTickets.find(t => t.id === orderId);
    let autoHrs = 1;
    if (order?.timestamp) {
      const diffMs = Date.now() - new Date(order.timestamp).getTime();
      // Calculate hours and round to nearest 0.25 (15 mins), minimum 0.25
      const diffHrs = Math.max(0.25, Math.round((diffMs / (1000 * 60 * 60)) * 4) / 4);
      autoHrs = (order as any).isPM ? (order.downtimeHours || diffHrs) : diffHrs;
    }
    setDowntimeHours(autoHrs);

    const saved = localStorage.getItem(\`dmr_draft_\${orderId}\`);
    if (saved) {
      try {
        const draft = JSON.parse(saved);
        setActionsTaken(draft.actionsTaken || '');
        setMaterialsUsed(draft.materialsUsed || '');
      } catch(e) {
        setActionsTaken('');
        setMaterialsUsed('');
      }
    } else {
      setActionsTaken('');
      setMaterialsUsed('');
    }
  };`;

const NEW_MODAL = `  const handleOpenCompletionModal = (orderId: string) => {
    setCompletingOrderId(orderId);
    
    // Auto-calculate downtime
    const order = allTickets.find(t => t.id === orderId);
    let autoHrs = 1;
    if (order?.status === 'Completed' && (order as any).downtimeHours) {
      autoHrs = (order as any).downtimeHours;
    } else if (order?.timestamp) {
      const diffMs = Date.now() - new Date(order.timestamp).getTime();
      // Calculate hours and round to nearest 0.25 (15 mins), minimum 0.25
      const diffHrs = Math.max(0.25, Math.round((diffMs / (1000 * 60 * 60)) * 4) / 4);
      autoHrs = (order as any).isPM ? (order.downtimeHours || diffHrs) : diffHrs;
    }
    setDowntimeHours(autoHrs);

    if (order?.status === 'Completed') {
      setActionsTaken(order.actionsTaken || '');
      setMaterialsUsed(order.materialsUsed || '');
    } else {
      const saved = localStorage.getItem(\`dmr_draft_\${orderId}\`);
      if (saved) {
        try {
          const draft = JSON.parse(saved);
          setActionsTaken(draft.actionsTaken || '');
          setMaterialsUsed(draft.materialsUsed || '');
        } catch(e) {
          setActionsTaken('');
          setMaterialsUsed('');
        }
      } else {
        setActionsTaken('');
        setMaterialsUsed('');
      }
    }
  };`;

code = code.replace(OLD_MODAL, NEW_MODAL);

const OLD_CARD = `              completedTickets.map(order => (
                <div key={order.id} className="p-3 bg-emerald-50 border border-emerald-100 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-emerald-800">{order.id}</span>
                    <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1 bg-white border border-emerald-100 px-2 py-0.5 rounded-full">
                      <Check className="w-3 h-3 text-emerald-500" /> Complete
                    </span>
                  </div>
                  <h4 className="font-display font-bold text-xs text-slate-800 mt-1.5 truncate">{order.assetName}</h4>
                  <p className="text-[11px] text-slate-500 mt-1">Actions: {order.actionsTaken}</p>
                </div>
              ))`;

const NEW_CARD = `              completedTickets.map(order => (
                <button 
                  key={order.id}
                  onClick={() => handleOpenCompletionModal(order.id)}
                  className="w-full text-left p-3 bg-emerald-50 border border-emerald-100 rounded-lg hover:bg-emerald-100/60 hover:border-emerald-200 hover:shadow-sm transition-all cursor-pointer group"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-emerald-800 group-hover:text-emerald-900 transition-colors">{order.id}</span>
                    <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1 bg-white border border-emerald-100 px-2 py-0.5 rounded-full shadow-sm">
                      <Check className="w-3 h-3 text-emerald-500" /> Complete
                    </span>
                  </div>
                  <h4 className="font-display font-bold text-xs text-slate-800 mt-1.5 truncate group-hover:text-emerald-950 transition-colors">{order.assetName}</h4>
                  <p className="text-[11px] text-slate-600 mt-1 line-clamp-2">Actions: {order.actionsTaken}</p>
                </button>
              ))`;

code = code.replace(OLD_CARD, NEW_CARD);

fs.writeFileSync('src/components/TechnicianView.tsx', code);
