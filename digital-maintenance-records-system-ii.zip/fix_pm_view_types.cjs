const fs = require('fs');

let content = fs.readFileSync('src/components/PreventiveMaintenanceView.tsx', 'utf-8');

content = content.replace("const primaryColor = [14, 165, 233]; // sky-500", "const primaryColor: [number, number, number] = [14, 165, 233]; // sky-500");
content = content.replace("const textColor = [51, 65, 85]; // slate-700", "const textColor: [number, number, number] = [51, 65, 85]; // slate-700");
content = content.replace("const lightGray = [241, 245, 249]; // slate-100", "const lightGray: [number, number, number] = [241, 245, 249]; // slate-100");

fs.writeFileSync('src/components/PreventiveMaintenanceView.tsx', content);
