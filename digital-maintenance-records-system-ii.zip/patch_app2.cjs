const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf-8');

const target = `                    setTechnicians([...technicians, {
                      id: 'TECH-' + newUser.userId.split('-')[1],
                      name: newUser.fullName,
                      specialty: newUser.department as any || 'General',
                      activeTicketsCount: 0
                    }]);`;

const replacement = `                    setTechnicians([...technicians, {
                      id: newUser.userId,
                      name: newUser.fullName,
                      specialty: newUser.department as any || 'General',
                      activeTicketsCount: 0
                    }]);`;

content = content.replace(target, replacement);
fs.writeFileSync('src/App.tsx', content);
