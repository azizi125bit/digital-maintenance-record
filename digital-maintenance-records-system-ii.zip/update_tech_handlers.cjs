const fs = require('fs');
let code = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

const completeFunc = `  const handleCompleteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!completingOrderId || !actionsTaken) {
      alert('Please fill in the actions taken during repair.');
      return;
    }
    
    onCompleteWork(completingOrderId, actionsTaken, materialsUsed, downtimeHours);
    localStorage.removeItem(\`dmr_draft_\${completingOrderId}\`);
    setCompletingOrderId(null);
  };`;

const newCompleteFunc = `  const handleCompleteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!completingOrderId || !actionsTaken) {
      alert('Please fill in the actions taken during repair.');
      return;
    }
    
    if (completingOrderId.startsWith('PM-')) {
      if (import.meta.env.VITE_SUPABASE_URL) {
        await supabase.from('preventive_maintenance').update({ status: 'Completed', remarks: actionsTaken }).eq('id', completingOrderId);
        setPmTasks(prev => prev.map(t => t.id === completingOrderId ? { ...t, status: 'Completed', remarks: actionsTaken } : t));
      }
    } else {
      onCompleteWork(completingOrderId, actionsTaken, materialsUsed, downtimeHours);
    }
    
    localStorage.removeItem(\`dmr_draft_\${completingOrderId}\`);
    setCompletingOrderId(null);
  };

  const handleStartTask = async (orderId: string) => {
    if (orderId.startsWith('PM-')) {
      if (import.meta.env.VITE_SUPABASE_URL) {
        await supabase.from('preventive_maintenance').update({ status: 'In Progress' }).eq('id', orderId);
        setPmTasks(prev => prev.map(t => t.id === orderId ? { ...t, status: 'In Progress' } : t));
      }
    } else {
      onStartWork(orderId);
    }
  };`;

code = code.replace(completeFunc, newCompleteFunc);

code = code.replace(
  "onClick={() => onStartWork(order.id)}",
  "onClick={() => handleStartTask(order.id)}"
);

fs.writeFileSync('src/components/TechnicianView.tsx', code);
