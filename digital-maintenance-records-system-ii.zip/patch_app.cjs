const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf-8');

const target = `                onAddPersonnel={(newUser) => {
                  setStaffList([...staffList, newUser]);
                  if (newUser.role === 'Technician') {
                    setTechnicians([...technicians, {
                      id: 'TECH-' + newUser.userId.split('-')[1],
                      name: newUser.fullName,
                      specialty: newUser.department as any || 'General',
                      activeTicketsCount: 0
                    }]);
                  }
                }}
              />`;

const newCode = `                onAddPersonnel={(newUser) => {
                  setStaffList([...staffList, newUser]);
                  if (newUser.role === 'Technician') {
                    setTechnicians([...technicians, {
                      id: 'TECH-' + newUser.userId.split('-')[1],
                      name: newUser.fullName,
                      specialty: newUser.department as any || 'General',
                      activeTicketsCount: 0
                    }]);
                  }
                }}
                onRemovePersonnel={async (userId) => {
                  if (import.meta.env.VITE_SUPABASE_URL) {
                    await supabase.from('profiles').delete().eq('id', userId);
                  }
                  setStaffList(staffList.filter(p => p.userId !== userId));
                }}
              />`;

content = content.replace(target, newCode);
fs.writeFileSync('src/App.tsx', content);
