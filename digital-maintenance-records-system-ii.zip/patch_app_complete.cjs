const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

const targetStr = `  // ACTION: Complete Work
  const handleCompleteWork = async (id: string, actions: string, materials: string, downtime: number) => {
    if (import.meta.env.VITE_SUPABASE_URL) {
      if (id.startsWith('PM-')) {
        await supabase.from('preventive_maintenance').update({
          status: 'Completed',
          completed_time: new Date().toISOString(),
          actions_taken: actions,
          materials_used: materials,
          downtime_hours: downtime
        }).eq('id', id);
      } else {
        await supabase.from('work_orders').update({
          status: 'Completed',
          completed_time: new Date().toISOString(),
          actions_taken: actions,
          materials_used: materials,
          downtime_hours: downtime
        }).eq('id', id);
      }
    }
    
    let completedOrderObj: any = null;`;

const replacementStr = `  // ACTION: Complete Work
  const handleCompleteWork = async (id: string, actions: string, materials: string, downtime: number) => {
    const isPM = id.startsWith('PM-');
    
    // Find the current order to get its checklist
    const currentList = isPM ? pmTasks : workOrders;
    const currentOrder = currentList.find(o => o.id === id);
    let updatedChecklist = currentOrder?.checklist || [];
    
    // Mark all checklist items as completed
    if (Array.isArray(updatedChecklist)) {
      updatedChecklist = updatedChecklist.map(item => ({ ...item, completed: true }));
    }

    if (import.meta.env.VITE_SUPABASE_URL) {
      if (isPM) {
        await supabase.from('preventive_maintenance').update({
          status: 'Completed',
          completed_time: new Date().toISOString(),
          actions_taken: actions,
          materials_used: materials,
          downtime_hours: downtime,
          checklist: updatedChecklist
        }).eq('id', id);
      } else {
        await supabase.from('work_orders').update({
          status: 'Completed',
          completed_time: new Date().toISOString(),
          actions_taken: actions,
          materials_used: materials,
          downtime_hours: downtime,
          checklist: updatedChecklist
        }).eq('id', id);
      }
    }
    
    let completedOrderObj: any = null;`;

if (code.includes('checklist: updatedChecklist')) {
  console.log('Already patched');
} else if (code.includes('const handleCompleteWork = async')) {
  code = code.replace(targetStr, replacementStr);
  
  // also need to update local state mapping for checklist
  const localTarget = `    if (id.startsWith('PM-')) {
      setPmTasks(prev => prev.map(o => {
        if (o.id === id) {
          completedOrderObj = { ...o, status: 'Completed', actionsTaken: actions, materialsUsed: materials, downtimeHours: downtime };
          return completedOrderObj;
        }
        return o;
      }));
    } else {
      setWorkOrders(prev => prev.map(o => {
        if (o.id === id) {
          completedOrderObj = { ...o, status: 'Completed', actionsTaken: actions, materialsUsed: materials, downtimeHours: downtime };
          return completedOrderObj;
        }
        return o;
      }));
    }`;

  const localReplacement = `    if (id.startsWith('PM-')) {
      setPmTasks(prev => prev.map(o => {
        if (o.id === id) {
          completedOrderObj = { ...o, status: 'Completed', actionsTaken: actions, materialsUsed: materials, downtimeHours: downtime, checklist: updatedChecklist };
          return completedOrderObj;
        }
        return o;
      }));
    } else {
      setWorkOrders(prev => prev.map(o => {
        if (o.id === id) {
          completedOrderObj = { ...o, status: 'Completed', actionsTaken: actions, materialsUsed: materials, downtimeHours: downtime, checklist: updatedChecklist };
          return completedOrderObj;
        }
        return o;
      }));
    }`;
    
  code = code.replace(localTarget, localReplacement);
  fs.writeFileSync('src/App.tsx', code);
  console.log('Patched App.tsx handleCompleteWork');
} else {
  console.log('Target not found');
}
