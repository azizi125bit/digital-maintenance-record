const fs = require('fs');
let code = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

const stateInsertTarget = `  // Active technician data
  const currentTech = activeStaff.find(t => t.userId === activeTechId);`;

const stateInsertNew = `  // Active technician data
  const currentTech = activeStaff.find(t => t.userId === activeTechId);

  const [checklistStates, setChecklistStates] = useState<Record<string, Record<number, boolean>>>({});

  const handleToggleChecklist = (orderId: string, idx: number) => {
    setChecklistStates(prev => ({
      ...prev,
      [orderId]: {
        ...(prev[orderId] || {}),
        [idx]: !prev[orderId]?.[idx]
      }
    }));
  };

  const isChecklistIncomplete = (order: any) => {
    if (!order.checklist || order.checklist.length === 0) return false;
    for (let i = 0; i < order.checklist.length; i++) {
      if (!checklistStates[order.id]?.[i]) return true;
    }
    return false;
  };`;

const checklistTarget = `                              <li key={idx} className="flex items-start gap-2">
                                <input type="checkbox" className="mt-0.5 w-3.5 h-3.5 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500" />
                                <span className="text-xs text-slate-700">{item.task}</span>
                              </li>`;

const checklistNew = `                              <li key={idx} className="flex items-start gap-2">
                                <input 
                                  type="checkbox" 
                                  checked={!!checklistStates[order.id]?.[idx]}
                                  onChange={() => handleToggleChecklist(order.id, idx)}
                                  className="mt-0.5 w-3.5 h-3.5 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer" 
                                />
                                <span className={\`text-xs \${checklistStates[order.id]?.[idx] ? 'text-slate-400 line-through' : 'text-slate-700'}\`}>{item.task}</span>
                              </li>`;

const buttonTarget = `                          <button
                            onClick={() => handleOpenCompletionModal(order.id)}
                            className="w-full md:w-36 inline-flex justify-center items-center px-4 py-2 text-xs font-bold uppercase tracking-wider text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow transition-all cursor-pointer border border-emerald-500"
                          >
                            <Check className="w-3.5 h-3.5 mr-1.5" /> Complete Job
                          </button>`;

const buttonNew = `                          <button
                            onClick={() => handleOpenCompletionModal(order.id)}
                            disabled={isChecklistIncomplete(order)}
                            className={\`w-full md:w-36 inline-flex justify-center items-center px-4 py-2 text-xs font-bold uppercase tracking-wider text-white rounded-lg shadow transition-all border \${isChecklistIncomplete(order) ? 'bg-slate-300 border-slate-300 cursor-not-allowed opacity-75' : 'bg-emerald-600 hover:bg-emerald-700 cursor-pointer border-emerald-500'}\`}
                          >
                            <Check className="w-3.5 h-3.5 mr-1.5" /> Complete Job
                          </button>`;

if (!code.includes('handleToggleChecklist')) {
  code = code.replace(stateInsertTarget, stateInsertNew);
  code = code.replace(checklistTarget, checklistNew);
  code = code.replace(buttonTarget, buttonNew);
  fs.writeFileSync('src/components/TechnicianView.tsx', code);
  console.log('Patched checklist functionality');
} else {
  console.log('Already patched');
}
