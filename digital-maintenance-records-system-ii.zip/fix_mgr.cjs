const fs = require('fs');
let code = fs.readFileSync('src/components/ManagerView.tsx', 'utf-8');

// The function signature likely didn't update correctly if there was a line break.
if (code.includes("pmTasks = [],")) {
    console.log("pmTasks is defined in signature?");
    // Let's check where it failed.
} else {
    // try finding the exact signature
    // export default function ManagerView({
    code = code.replace(
        "export default function ManagerView({ workOrders, onAddWorkOrder, onUpdatePriority, onReassignTechnician, technicians, staffList, authorizedUser, authorizedUserRole }: ManagerViewProps) {",
        "export default function ManagerView({ workOrders, pmTasks = [], onAddWorkOrder, onUpdatePriority, onReassignTechnician, technicians, staffList, authorizedUser, authorizedUserRole }: ManagerViewProps) {"
    );
    // what if it was multiline?
    code = code.replace(
        /export default function ManagerView\(\{\s*workOrders,\s*onAddWorkOrder/g,
        "export default function ManagerView({\n  workOrders,\n  pmTasks = [],\n  onAddWorkOrder"
    );
}

fs.writeFileSync('src/components/ManagerView.tsx', code);
