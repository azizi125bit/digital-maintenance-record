const fs = require('fs');
let code = fs.readFileSync('src/components/PMCalendar.tsx', 'utf-8');

// Add states
code = code.replace(
  "const [techFilter, setTechFilter] = useState('All');",
  "const [techFilter, setTechFilter] = useState('All');\n  const [assetFilter, setAssetFilter] = useState('All');\n  const [priorityFilter, setPriorityFilter] = useState('All');"
);

// Apply filtering
const originalFilter = `if (techFilter !== 'All') {
        if (pm.assigned_technician !== techFilter) return false;
      }
      return true;`;
const newFilter = `if (techFilter !== 'All') {
        if (pm.assigned_technician !== techFilter) return false;
      }
      if (assetFilter !== 'All') {
        if (pm.asset_id !== assetFilter) return false;
      }
      if (priorityFilter !== 'All') {
        if (pm.priority !== priorityFilter) return false;
      }
      return true;`;
code = code.replace(originalFilter, newFilter);

// Add select dropdowns
const origSelects = `</select>
        </div>
      </div>`;
const newSelects = `</select>
          <select 
            value={assetFilter} 
            onChange={e => setAssetFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 text-slate-700 text-sm rounded-lg px-3 py-2 outline-none focus:border-sky-500"
          >
            <option value="All">All Assets</option>
            {Array.from(new Set(schedules.map(s => s.asset_id))).filter(Boolean).map(a => (
              <option key={a} value={a}>{a}</option>
            ))}
          </select>
          <select 
            value={priorityFilter} 
            onChange={e => setPriorityFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 text-slate-700 text-sm rounded-lg px-3 py-2 outline-none focus:border-sky-500"
          >
            <option value="All">All Priorities</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>
      </div>`;
code = code.replace(origSelects, newSelects);

fs.writeFileSync('src/components/PMCalendar.tsx', code);
