const fs = require('fs');
let code = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

const buttonTarget = `                          <button
                            onClick={() => handleOpenCompletionModal(order.id)}
                            disabled={isChecklistIncomplete(order)}
                            className={\`w-full md:w-36 inline-flex justify-center items-center px-4 py-2 text-xs font-bold uppercase tracking-wider text-white rounded-lg shadow transition-all border \${isChecklistIncomplete(order) ? 'bg-slate-300 border-slate-300 cursor-not-allowed opacity-75' : 'bg-emerald-600 hover:bg-emerald-700 cursor-pointer border-emerald-500'}\`}
                          >
                            <Check className="w-3.5 h-3.5 mr-1.5" /> Complete Job
                          </button>`;

const buttonNew = `                          <button
                            onClick={() => handleOpenCompletionModal(order.id)}
                            className="w-full md:w-36 inline-flex justify-center items-center px-4 py-2 text-xs font-bold uppercase tracking-wider text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow transition-all cursor-pointer border border-emerald-500"
                          >
                            <Check className="w-3.5 h-3.5 mr-1.5" /> Complete Job
                          </button>`;

if (code.includes('disabled={isChecklistIncomplete(order)}')) {
  code = code.replace(buttonTarget, buttonNew);
  fs.writeFileSync('src/components/TechnicianView.tsx', code);
  console.log('Removed disabled constraint');
} else {
  console.log('Not found');
}
