const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle0' });
  
  // Login if necessary
  // Wait, is there a login screen?
  if (await page.$('form')) {
     const inputs = await page.$$('input');
     if (inputs.length >= 2) {
       await inputs[0].type('admin');
       await inputs[1].type('password'); // whatever the login is
       await page.click('button[type="submit"]');
       await page.waitForNavigation({ waitUntil: 'networkidle0' }).catch(e => {});
     }
  }

  // evaluate selector
  const html = await page.evaluate(() => {
     const el = document.querySelector('div#root:nth-of-type(1) > div:nth-of-type(1) > main:nth-of-type(1) > div:nth-of-type(3) > div:nth-of-type(2) > div:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(2) > div:nth-of-type(2)');
     return el ? el.outerHTML : 'Element not found';
  });

  console.log("Found Element HTML:", html);
  await browser.close();
})();
