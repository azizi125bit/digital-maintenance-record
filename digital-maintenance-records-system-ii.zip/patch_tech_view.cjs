const fs = require('fs');
let code = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

const propReplace = `  onStartWork: (id: string) => void;
  onCompleteWork: (id: string, actionsTaken: string, materialsUsed: string, downtimeHours: number) => void;`;
const propNew = `  onStartWork: (id: string) => void;
  onPauseWork: (id: string) => void;
  onCompleteWork: (id: string, actionsTaken: string, materialsUsed: string, downtimeHours: number) => void;`;

const paramReplace = `export default function TechnicianView({ workOrders, pmTasks = [], onStartWork, onCompleteWork, technicians, staffList, authorizedUser }: TechnicianViewProps) {`;
const paramNew = `export default function TechnicianView({ workOrders, pmTasks = [], onStartWork, onPauseWork, onCompleteWork, technicians, staffList, authorizedUser }: TechnicianViewProps) {`;

const startTaskReplace = `  const handleStartTask = async (orderId: string) => {
    if (orderId.startsWith('PM-')) {
      if (import.meta.env.VITE_SUPABASE_URL) {
        await supabase.from('preventive_maintenance').update({ status: 'In Progress' }).eq('id', orderId);
        setPmTasks(prev => prev.map(t => t.id === orderId ? { ...t, status: 'In Progress' } : t));
      }
    } else {
      onStartWork(orderId);
    }
  };`;
const startTaskNew = `  const handleStartTask = async (orderId: string) => {
    if (orderId.startsWith('PM-')) {
      if (import.meta.env.VITE_SUPABASE_URL) {
        await supabase.from('preventive_maintenance').update({ status: 'In Progress' }).eq('id', orderId);
        setPmTasks(prev => prev.map(t => t.id === orderId ? { ...t, status: 'In Progress' } : t));
      }
    } else {
      onStartWork(orderId);
    }
  };

  const handlePauseTask = async (orderId: string) => {
    if (orderId.startsWith('PM-')) {
      if (import.meta.env.VITE_SUPABASE_URL) {
        await supabase.from('preventive_maintenance').update({ status: 'Paused' }).eq('id', orderId);
        setPmTasks(prev => prev.map(t => t.id === orderId ? { ...t, status: 'Paused' } : t));
      }
    } else {
      onPauseWork(orderId);
    }
  };`;

const btnReplace = `                    {/* Operational Actions */}
                    <div className="flex sm:flex-col items-end gap-2 shrink-0 justify-end pt-3 md:pt-0 border-t border-slate-100 md:border-0">
                      {order.status !== 'In Progress' ? (
                        <button
                          onClick={() => handleStartTask(order.id)}
                          className="w-full md:w-36 inline-flex justify-center items-center px-4 py-2 text-xs font-bold uppercase tracking-wider text-white bg-slate-800 hover:bg-slate-950 rounded-lg shadow transition-all cursor-pointer"
                        >
                          <Play className="w-3.5 h-3.5 mr-1.5" /> Start Repair
                        </button>
                      ) : (
                        <button
                          onClick={() => handleOpenCompletionModal(order.id)}
                          className="w-full md:w-36 inline-flex justify-center items-center px-4 py-2 text-xs font-bold uppercase tracking-wider text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow transition-all cursor-pointer border border-emerald-500"
                        >
                          <Check className="w-3.5 h-3.5 mr-1.5" /> Complete Job
                        </button>
                      )}`;
const btnNew = `                    {/* Operational Actions */}
                    <div className="flex sm:flex-col items-end gap-2 shrink-0 justify-end pt-3 md:pt-0 border-t border-slate-100 md:border-0">
                      {order.status !== 'In Progress' ? (
                        <button
                          onClick={() => handleStartTask(order.id)}
                          className="w-full md:w-36 inline-flex justify-center items-center px-4 py-2 text-xs font-bold uppercase tracking-wider text-white bg-slate-800 hover:bg-slate-950 rounded-lg shadow transition-all cursor-pointer"
                        >
                          <Play className="w-3.5 h-3.5 mr-1.5" /> {order.status === 'Paused' ? 'Resume Repair' : 'Start Repair'}
                        </button>
                      ) : (
                        <>
                          <button
                            onClick={() => handlePauseTask(order.id)}
                            className="w-full md:w-36 inline-flex justify-center items-center px-4 py-2 text-xs font-bold uppercase tracking-wider text-slate-700 bg-amber-100 hover:bg-amber-200 rounded-lg shadow transition-all cursor-pointer border border-amber-300"
                          >
                            <svg className="w-3.5 h-3.5 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                              <path strokeLinecap="round" strokeLinejoin="round" d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            Pause Job
                          </button>
                          <button
                            onClick={() => handleOpenCompletionModal(order.id)}
                            className="w-full md:w-36 inline-flex justify-center items-center px-4 py-2 text-xs font-bold uppercase tracking-wider text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow transition-all cursor-pointer border border-emerald-500"
                          >
                            <Check className="w-3.5 h-3.5 mr-1.5" /> Complete Job
                          </button>
                        </>
                      )}`;

code = code.replace(propReplace, propNew);
code = code.replace(paramReplace, paramNew);
code = code.replace(startTaskReplace, startTaskNew);
code = code.replace(btnReplace, btnNew);

fs.writeFileSync('src/components/TechnicianView.tsx', code);
console.log("Patched TechnicianView.tsx");
