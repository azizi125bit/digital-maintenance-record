const fs = require('fs');
let code = fs.readFileSync('src/components/PreventiveMaintenanceView.tsx', 'utf-8');

// 1. Add Asset import
code = code.replace(
  "import { WorkOrder, Technician } from '../types';",
  "import { WorkOrder, Technician, Asset } from '../types';"
);

// 2. Add asset state
code = code.replace(
  "const [selectedMachine, setSelectedMachine] = useState<string | null>(null);",
  "const [selectedMachine, setSelectedMachine] = useState<string | null>(null);\n  const [assets, setAssets] = useState<Asset[]>([]);\n  const [assetSearchQuery, setAssetSearchQuery] = useState('');\n  const [showAssetDropdown, setShowAssetDropdown] = useState(false);\n  const [selectedAssetForForm, setSelectedAssetForForm] = useState<Asset | null>(null);"
);

// 3. Update useEffect to fetch assets
const origUseEffect = `    if (import.meta.env.VITE_SUPABASE_URL) {
      const fetchPM = async () => {
        const { data, error } = await supabase.from('preventive_maintenance').select('*');`;
const newUseEffect = `    if (import.meta.env.VITE_SUPABASE_URL) {
      const fetchData = async () => {
        const { data: assetsData } = await supabase.from('assets').select('*');
        if (assetsData) setAssets(assetsData as any[]);
        
        const { data, error } = await supabase.from('preventive_maintenance').select('*');`;
code = code.replace(origUseEffect, newUseEffect);

code = code.replace(
  "      fetchPM();",
  "      fetchData();"
);

// 4. Update the select field
const selectCode = `<div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Asset Selection</label>
                    <select required name="machine" className="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm text-slate-700 focus:border-sky-500 focus:outline-none">
                      <option value="">Select Asset...</option>
                      <option value="CNC Lathe M-01">CNC Lathe M-01</option>
                      <option value="Industrial Boiler">Industrial Boiler</option>
                      <option value="Air Compressor A-3">Air Compressor A-3</option>
                      <option value="Hydraulic Press H-1">Hydraulic Press H-1</option>
                    </select>
                  </div>`;

const searchCode = `<div className="relative">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Asset Selection</label>
                    <div className="relative">
                      <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                      <input 
                        type="text" 
                        required={!selectedAssetForForm}
                        value={showAssetDropdown ? assetSearchQuery : (selectedAssetForForm ? selectedAssetForForm.name : '')}
                        onChange={(e) => {
                          setAssetSearchQuery(e.target.value);
                          setShowAssetDropdown(true);
                          if (!e.target.value) setSelectedAssetForForm(null);
                        }}
                        onFocus={() => setShowAssetDropdown(true)}
                        onBlur={() => setTimeout(() => setShowAssetDropdown(false), 200)}
                        placeholder="Search by asset name or ID..." 
                        className="w-full pl-9 bg-white border border-slate-200 rounded-lg p-2 text-sm text-slate-700 focus:border-sky-500 focus:outline-none" 
                      />
                      <input type="hidden" name="machine" value={selectedAssetForForm?.name || ''} />
                      <input type="hidden" name="asset_id" value={selectedAssetForForm?.id || ''} />
                    </div>
                    {showAssetDropdown && (
                      <div className="absolute z-10 w-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg max-h-48 overflow-y-auto">
                        {assets.filter(a => a.name.toLowerCase().includes(assetSearchQuery.toLowerCase()) || a.id.toLowerCase().includes(assetSearchQuery.toLowerCase())).map(asset => (
                          <div 
                            key={asset.id}
                            className="px-4 py-2 hover:bg-slate-50 cursor-pointer text-sm"
                            onClick={() => {
                              setSelectedAssetForForm(asset);
                              setAssetSearchQuery('');
                              setShowAssetDropdown(false);
                            }}
                          >
                            <div className="font-bold text-slate-700">{asset.name}</div>
                            <div className="text-xs text-slate-500 font-mono">{asset.id}</div>
                          </div>
                        ))}
                        {assets.length > 0 && assets.filter(a => a.name.toLowerCase().includes(assetSearchQuery.toLowerCase()) || a.id.toLowerCase().includes(assetSearchQuery.toLowerCase())).length === 0 && (
                          <div className="px-4 py-2 text-sm text-slate-500">No assets found</div>
                        )}
                      </div>
                    )}
                  </div>`;
                  
code = code.replace(selectCode, searchCode);

// 5. Update submission parsing
const origSubmit = `const machine = form.machine.value;
              const tech = form.tech.value;
              
              const newPM = {
                id: 'PM-' + Math.floor(Math.random() * 10000),
                asset_id: machine === 'CNC Lathe M-01' ? 'M-01' : machine === 'Industrial Boiler' ? 'B-01' : 'A-01',
                asset_name: machine,`;

const newSubmit = `const machine = form.machine.value;
              const asset_id = form.asset_id?.value || 'A-01';
              const tech = form.tech.value;
              
              const newPM = {
                id: 'PM-' + Math.floor(Math.random() * 10000),
                asset_id: asset_id,
                asset_name: machine,`;

code = code.replace(origSubmit, newSubmit);

// 6. Reset selected asset when modal opens/closes
code = code.replace(
  "setIsCreateModalOpen(false)",
  "setIsCreateModalOpen(false); setSelectedAssetForForm(null);"
);
code = code.replace(
  "setIsCreateModalOpen(true)",
  "setIsCreateModalOpen(true); setSelectedAssetForForm(null);"
);

fs.writeFileSync('src/components/PreventiveMaintenanceView.tsx', code);
