const fs = require('fs');
let code = fs.readFileSync('src/components/PreventiveMaintenanceView.tsx', 'utf-8');

// We need to find the onSubmit handler
const onSubmitStr = `<form onSubmit={(e) => {
              e.preventDefault();
              // Calculate next due date simply (mock logic)`;
const newOnSubmit = `<form onSubmit={async (e) => {
              e.preventDefault();
              const form = e.target as any;
              const type = form.maintType.value;
              const freq = form.frequency.value;
              const machine = form.machine.value;
              const tech = form.tech.value;
              
              const newPM = {
                id: 'PM-' + Math.floor(Math.random() * 10000),
                asset_id: machine === 'CNC Lathe M-01' ? 'M-01' : machine === 'Industrial Boiler' ? 'B-01' : 'A-01',
                asset_name: machine,
                category: type,
                frequency: freq,
                next_due_date: form.startDate.value,
                scheduled_date: form.startDate.value,
                assigned_to_name: tech,
                status: 'Pending',
                priority: form.priority.value,
                downtime_hours: parseFloat(form.estimatedDuration?.value || '2')
              };
              
              if (import.meta.env.VITE_SUPABASE_URL) {
                const { error } = await supabase.from('preventive_maintenance').insert([newPM]);
                if (error) console.error('Error saving PM', error);
              }
              
              // update local state
              setSchedules(prev => [newPM as any, ...prev]);
              setUpcomingMaint(prev => [{
                id: newPM.id,
                machine: newPM.asset_name,
                type: newPM.category,
                freq: newPM.frequency,
                due: newPM.next_due_date,
                tech: newPM.assigned_to_name,
                priority: newPM.priority,
                status: 'Pending'
              }, ...prev]);
                 
              alert(\`PM Schedule created successfully for \${newPM.scheduled_date}.\`);
              setIsCreateModalOpen(false);
              // Trigger a re-render/refresh if possible
              // window.location.reload(); 
            }} className="flex flex-col">`;

code = code.replace(
  code.substring(code.indexOf(onSubmitStr), code.indexOf(`className="flex flex-col">`)),
  newOnSubmit
).replace(`className="flex flex-col">`, "");

fs.writeFileSync('src/components/PreventiveMaintenanceView.tsx', code);
