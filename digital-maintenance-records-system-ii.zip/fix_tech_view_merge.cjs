const fs = require('fs');
let code = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

const filterCode = `  // Filter tickets for this technician
  const techTickets = workOrders.filter(order => order.assignedToId === activeTechId);
  const pendingTickets = techTickets.filter(order => order.status !== 'Completed');
  const completedTickets = techTickets.filter(order => order.status === 'Completed');`;

const newFilterCode = `  // Filter tickets for this technician
  const techTickets = workOrders.filter(order => order.assignedToId === activeTechId);
  
  // Normalize PM Tasks to match WorkOrder shape for the UI
  const normalizedPMTasks = pmTasks.map(pm => ({
    id: pm.id,
    timestamp: pm.scheduled_date,
    assetId: pm.asset_id,
    assetName: pm.asset_name,
    category: pm.category || 'General',
    issue: \`[\${pm.maintenance_type || 'PM'}] \${pm.maintenance_task}\`,
    priority: pm.priority,
    assignedToId: activeTechId,
    assignedToName: pm.assigned_to_name,
    status: pm.status,
    loggedBy: pm.supervisor || pm.logged_by || 'System',
    isPM: true, // Custom flag to distinguish
    downtimeHours: pm.estimated_duration || 2
  }));

  const allTickets = [...techTickets, ...normalizedPMTasks];
  const pendingTickets = allTickets.filter(order => order.status !== 'Completed');
  const completedTickets = allTickets.filter(order => order.status === 'Completed');`;

code = code.replace(filterCode, newFilterCode);

fs.writeFileSync('src/components/TechnicianView.tsx', code);
