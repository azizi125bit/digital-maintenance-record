const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle0' });
  
  // They are in technician role, wait we don't know the role.
  // They clicked something.
  const html = await page.evaluate(() => {
     // try to find any "Active Maintenance" text
     const els = Array.from(document.querySelectorAll('*')).filter(el => el.textContent && el.textContent.includes('Active Maintenance') && el.children.length === 0);
     return els.map(e => e.outerHTML);
  });

  console.log("Found Active Maintenance elements:", html);
  await browser.close();
})();
