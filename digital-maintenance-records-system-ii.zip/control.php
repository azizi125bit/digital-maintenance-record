<?php
/**
 * Digital Maintenance Records (DMR) - Backend Controller
 * Handles business logic, CRUD, sanitization, and database operations.
 */

require_once __DIR__ . '/config.php';

// Canonical table names
const TABLE_MAP = [
    'assets'                 => 'assets',
    'staff'                  => 'staff',
    'profiles'               => 'staff',
    'users'                  => 'staff',
    'workorders'             => 'work_orders',
    'work_orders'            => 'work_orders',
    'pmschedules'            => 'pm_schedules',
    'pm_schedules'           => 'pm_schedules',
    'preventive_maintenance' => 'pm_schedules',
    'maintenancerecords'     => 'machine_breakdowns',
    'machine_breakdowns'     => 'machine_breakdowns',
    'breakdowns'             => 'machine_breakdowns',
    'safetydocuments'        => 'safety_documents',
    'safety_documents'       => 'safety_documents',
    'requiredocuments'       => 'safety_documents',
    'require_documents'      => 'safety_documents',
    'documents'              => 'safety_documents',
    'activitylogs'           => 'activity_logs',
    'activity_logs'          => 'activity_logs',
    'inventory'              => 'inventory',
    'inventory_items'        => 'inventory'
];

/**
 * Resolve client table name to database table
 */
function resolveTableName($name) {
    $clean = strtolower(trim($name));
    return TABLE_MAP[$clean] ?? null;
}

/**
 * Convert snake_case to camelCase
 */
function snakeToCamel($str) {
    return lcfirst(str_replace(' ', '', ucwords(str_replace('_', ' ', $str))));
}

/**
 * Convert camelCase to snake_case
 */
function camelToSnake($str) {
    return strtolower(preg_replace('/[A-Z]/', '_$0', $str));
}

/**
 * Format a database row into a standardized response matching TypeScript interfaces
 */
function formatDbRow($table, $row) {
    if (!$row || !is_array($row)) return $row;
    $formatted = [];

    // JSON fields to decode for each table
    $jsonFields = [
        'assets' => ['custom_specifications'],
        'staff' => ['skills'],
        'work_orders' => ['checklist'],
        'pm_schedules' => ['safety_requirements'],
        'safety_documents' => ['job_steps', 'identified_hazards', 'required_ppe', 'safety_precautions', 'isolations', 'gas_testing', 'safety_checklist'],
        'inventory' => ['compatible_assets']
    ];

    $targetJsonFields = $jsonFields[$table] ?? [];

    foreach ($row as $col => $val) {
        $camelCol = snakeToCamel($col);

        // Decode JSON fields if applicable
        if (in_array($col, $targetJsonFields) && is_string($val)) {
            $decoded = json_decode($val, true);
            $parsedVal = ($decoded !== null) ? $decoded : $val;
            $formatted[$col] = $parsedVal;
            $formatted[$camelCol] = $parsedVal;
            continue;
        }

        // Cast boolean flags
        if (in_array($col, ['machine_isolated', 'requires_permit', 'auto_generated', 'isolation_required', 'gas_testing_required', 'fire_watch_assigned', 'handback_housekeeping_done', 'handback_isolations_restored'])) {
            $boolVal = (bool)$val;
            $formatted[$col] = $boolVal;
            $formatted[$camelCol] = $boolVal;
            continue;
        }

        // Default: provide both snake_case and camelCase for seamless frontend binding
        $formatted[$col] = $val;
        $formatted[$camelCol] = $val;
    }

    // Special primary key aliases
    if ($table === 'staff') {
        $formatted['id'] = $row['user_id'] ?? '';
        $formatted['userId'] = $row['user_id'] ?? '';
    }
    if ($table === 'assets') {
        if (!empty($row['photo_url'])) {
            $formatted['photoUrl'] = $row['photo_url'];
            $formatted['machine_photo'] = $row['photo_url'];
        }
    }

    return $formatted;
}

/**
 * Prepare a data payload for insertion/update into MySQL
 */
function prepareDataForTable($table, $data) {
    $pdo = getDbConnection();
    // Get table columns
    $stmt = $pdo->prepare("SHOW COLUMNS FROM `{$table}`");
    $stmt->execute();
    $validColumns = $stmt->fetchAll(PDO::FETCH_COLUMN);

    $prepared = [];
    foreach ($validColumns as $col) {
        $camelCol = snakeToCamel($col);

        // Find value from incoming data in either format
        $val = null;
        if (array_key_exists($col, $data)) {
            $val = $data[$col];
        } elseif (array_key_exists($camelCol, $data)) {
            $val = $data[$camelCol];
        } else {
            continue;
        }

        // Special handling for staff primary key
        if ($table === 'staff' && $col === 'user_id' && empty($val)) {
            $val = $data['id'] ?? $data['userId'] ?? ('USR-' . time());
        }

        // Serialize arrays/objects to JSON
        if (is_array($val) || is_object($val)) {
            $val = json_encode($val, JSON_UNESCAPED_UNICODE);
        } elseif (is_bool($val)) {
            $val = $val ? 1 : 0;
        }

        $prepared[$col] = $val;
    }

    return $prepared;
}

/**
 * Handle listing records
 */
function handleListRecords($table, $params = []) {
    $pdo = getDbConnection();
    $sql = "SELECT * FROM `{$table}`";
    $where = [];
    $bindings = [];

    // Filter by field
    if (!empty($params['filterField']) && isset($params['filterValue'])) {
        $field = camelToSnake($params['filterField']);
        $where[] = "`{$field}` = :filterVal";
        $bindings[':filterVal'] = $params['filterValue'];
    }

    // Direct id query
    if (!empty($params['id'])) {
        $idCol = ($table === 'staff') ? 'user_id' : 'id';
        $where[] = "(`{$idCol}` = :queryId OR `id` = :queryId)";
        $bindings[':queryId'] = $params['id'];
    }

    if (!empty($where)) {
        $sql .= " WHERE " . implode(' AND ', $where);
    }

    // Order
    $orderField = !empty($params['orderField']) ? camelToSnake($params['orderField']) : null;
    if ($orderField) {
        $asc = (!isset($params['ascending']) || $params['ascending'] === 'true' || $params['ascending'] === true) ? 'ASC' : 'DESC';
        $sql .= " ORDER BY `{$orderField}` {$asc}";
    } else {
        // Default ordering
        if ($table === 'work_orders' || $table === 'activity_logs' || $table === 'machine_breakdowns') {
            $sql .= " ORDER BY `created_at` DESC";
        }
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($bindings);
    $rows = $stmt->fetchAll();

    $result = [];
    foreach ($rows as $row) {
        $result[] = formatDbRow($table, $row);
    }
    return $result;
}

/**
 * Handle insert/create record(s)
 */
function handleCreateRecord($table, $data) {
    $pdo = getDbConnection();
    $items = is_array($data) && isset($data[0]) ? $data : [$data];
    $insertedCount = 0;

    foreach ($items as $item) {
        $prepared = prepareDataForTable($table, $item);
        if (empty($prepared)) continue;

        // Ensure primary key exists
        $pk = ($table === 'staff') ? 'user_id' : 'id';
        if (empty($prepared[$pk])) {
            $prefix = strtoupper(substr($table, 0, 3));
            $prepared[$pk] = $prefix . '-' . time() . '-' . rand(100, 999);
        }

        $cols = array_keys($prepared);
        $colNames = implode('`, `', $cols);
        $placeholders = ':' . implode(', :', $cols);

        // ON DUPLICATE KEY UPDATE clause
        $updates = [];
        foreach ($cols as $c) {
            if ($c !== $pk) {
                $updates[] = "`{$c}` = VALUES(`{$c}`)";
            }
        }
        $updateClause = !empty($updates) ? " ON DUPLICATE KEY UPDATE " . implode(', ', $updates) : "";

        $sql = "INSERT INTO `{$table}` (`{$colNames}`) VALUES ({$placeholders}){$updateClause}";
        $stmt = $pdo->prepare($sql);

        $params = [];
        foreach ($prepared as $k => $v) {
            $params[':' . $k] = $v;
        }
        $stmt->execute($params);
        $insertedCount++;
    }

    return ['success' => true, 'count' => $insertedCount];
}

/**
 * Handle update record
 */
function handleUpdateRecord($table, $idField, $idValue, $updates) {
    $pdo = getDbConnection();
    $prepared = prepareDataForTable($table, $updates);
    if (empty($prepared)) {
        return ['success' => true, 'updated' => 0];
    }

    $idCol = camelToSnake($idField);
    // Fallback if staff user_id
    if ($table === 'staff' && $idCol === 'id') {
        $idCol = 'user_id';
    }

    $setParts = [];
    $params = [':idVal' => $idValue];
    foreach ($prepared as $col => $val) {
        $paramKey = ':set_' . $col;
        $setParts[] = "`{$col}` = {$paramKey}";
        $params[$paramKey] = $val;
    }

    $sql = "UPDATE `{$table}` SET " . implode(', ', $setParts) . " WHERE `{$idCol}` = :idVal";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    return ['success' => true, 'updated' => $stmt->rowCount()];
}

/**
 * Handle delete record
 */
function handleDeleteRecord($table, $idField, $idValue) {
    $pdo = getDbConnection();
    $idCol = camelToSnake($idField);
    if ($table === 'staff' && $idCol === 'id') {
        $idCol = 'user_id';
    }

    $sql = "DELETE FROM `{$table}` WHERE `{$idCol}` = :idVal";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':idVal' => $idValue]);

    return ['success' => true, 'deleted' => $stmt->rowCount()];
}

/**
 * Handle image file upload (saves into uploads/ directory and returns public URL)
 */
function handleImageUpload($data) {
    $bucket = preg_replace('/[^a-zA-Z0-9_-]/', '', $data['bucket'] ?? 'asset-images');
    $fileBase64 = $data['fileBase64'] ?? $data['file_base64'] ?? '';
    $filePath = $data['path'] ?? ('img_' . time() . '.jpg');

    if (empty($fileBase64)) {
        throw new Exception('Missing image data (fileBase64)');
    }

    $baseDir = __DIR__ . '/uploads/' . $bucket;
    if (!is_dir($baseDir)) {
        mkdir($baseDir, 0755, true);
    }

    $safeFileName = basename($filePath);
    // Ensure file extension
    if (!preg_match('/\.(jpg|jpeg|png|gif|webp|svg)$/i', $safeFileName)) {
        $safeFileName .= '.jpg';
    }
    // Prepend timestamp to avoid collision
    $targetFileName = time() . '_' . $safeFileName;
    $targetPath = $baseDir . '/' . $targetFileName;

    // Remove data URI scheme header if present
    $cleanBase64 = preg_replace('/^data:image\/[a-zA-Z0-9.+-]+;base64,/', '', $fileBase64);
    $decodedData = base64_decode($cleanBase64);

    if ($decodedData === false) {
        throw new Exception('Failed to decode base64 image data');
    }

    if (file_put_contents($targetPath, $decodedData) === false) {
        throw new Exception('Failed to write uploaded image to disk');
    }

    // Public URL relative to website root
    $publicUrl = '/uploads/' . $bucket . '/' . $targetFileName;

    return [
        'success'   => true,
        'publicUrl' => $publicUrl,
        'path'      => $bucket . '/' . $targetFileName,
        'url'       => $publicUrl
    ];
}

/**
 * Handle authentication / login verification
 */
function handleLogin($data) {
    $pdo = getDbConnection();
    $username = trim($data['username'] ?? '');
    $pin = trim($data['pin'] ?? '');

    if (empty($username) || empty($pin)) {
        throw new Exception('Username and PIN are required');
    }

    $stmt = $pdo->prepare("SELECT * FROM `staff` WHERE (`username` = :u OR `email` = :u OR `full_name` = :u) AND `pin` = :p LIMIT 1");
    $stmt->execute([':u' => $username, ':p' => $pin]);
    $user = $stmt->fetch();

    if (!$user) {
        throw new Exception('Invalid credentials. Please check your username and PIN.');
    }

    // Update last login
    $nowIso = date('c');
    $upd = $pdo->prepare("UPDATE `staff` SET `last_login` = :now WHERE `user_id` = :uid");
    $upd->execute([':now' => $nowIso, ':uid' => $user['user_id']]);

    return [
        'success' => true,
        'user'    => formatDbRow('staff', $user)
    ];
}
