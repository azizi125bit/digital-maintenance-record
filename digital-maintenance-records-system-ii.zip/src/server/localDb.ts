import fs from 'fs';
import path from 'path';

export interface LocalDbData {
  work_orders: any[];
  activity_logs: any[];
  assets: any[];
  preventive_maintenance: any[];
  profiles: any[];
  machine_breakdowns: any[];
  safety_documents: any[];
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

// Ensure directory and db.json exist
function ensureDb() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  if (!fs.existsSync(DB_FILE)) {
    const initialData: LocalDbData = {
      work_orders: [],
      activity_logs: [],
      assets: [],
      preventive_maintenance: [],
      machine_breakdowns: [],
      safety_documents: [],
      profiles: [
        {
          userId: 'USR-001',
          id: 'USR-001',
          employeeId: 'EMP-1001',
          fullName: 'Ahmad',
          full_name: 'Ahmad',
          username: 'Ahmad',
          email: 'ahmad@dmr.com',
          phone: '',
          department: 'Management',
          position: 'Manager',
          role: 'Management',
          accountStatus: 'Active',
          account_status: 'Active',
          dateJoined: '2026-01-01T00:00:00Z',
          lastLogin: new Date().toISOString(),
          pin: '1111'
        }
      ]
    };

    fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2), 'utf-8');
  }
}

export function readDb(): LocalDbData {
  ensureDb();
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    if (!parsed.machine_breakdowns) {
      parsed.machine_breakdowns = [];
    }
    if (!parsed.work_orders) parsed.work_orders = [];
    if (!parsed.activity_logs) parsed.activity_logs = [];
    if (!parsed.assets) parsed.assets = [];
    if (!parsed.preventive_maintenance) parsed.preventive_maintenance = [];
    if (!parsed.profiles) parsed.profiles = [];
    if (!parsed.safety_documents) parsed.safety_documents = [];
    return parsed;
  } catch (e) {
    console.error('Error reading local db:', e);
    return {
      work_orders: [],
      activity_logs: [],
      assets: [],
      preventive_maintenance: [],
      profiles: [],
      machine_breakdowns: [],
      safety_documents: []
    };
  }
}

export function writeDb(data: LocalDbData): void {
  ensureDb();
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (e) {
    console.error('Error writing local db:', e);
  }
}
