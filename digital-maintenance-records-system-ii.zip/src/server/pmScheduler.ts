import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  initializeFirestore, 
  getFirestore, 
  collection, 
  getDocs, 
  setDoc, 
  doc, 
  query, 
  orderBy,
  limit
} from 'firebase/firestore';
import fs from 'fs';
import path from 'path';
import { readDb, writeDb, type LocalDbData } from './localDb.ts';

// Load Firebase configuration
const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
let fileConfig: any = {};
try {
  if (fs.existsSync(configPath)) {
    fileConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  }
} catch (e) {
  console.error('[PM Scheduler] Could not load firebase-applet-config.json:', e);
}

// Initialize Firebase for server-side processing
let firebaseApp: any = null;
let firestoreDb: any = null;

try {
  if (getApps().length === 0) {
    firebaseApp = initializeApp(fileConfig);
  } else {
    firebaseApp = getApp();
  }
  firestoreDb = initializeFirestore(firebaseApp, {
    ignoreUndefinedProperties: true
  }, fileConfig.firestoreDatabaseId || undefined);
} catch (e: any) {
  try {
    firestoreDb = getFirestore(firebaseApp, fileConfig.firestoreDatabaseId || undefined);
  } catch (err: any) {
    console.error('[PM Scheduler] Firestore init fallback error:', err.message);
  }
}

export interface PMSchedulerStatus {
  active: boolean;
  intervalSeconds: number;
  timezone: string;
  currentTimeInKL: string;
  currentDateInKL: string;
  lastRunTimestamp: string | null;
  lastRunResult: {
    processedCount: number;
    generatedCount: number;
    generatedWorkOrderIds: string[];
    errors: string[];
  } | null;
  totalGeneratedSinceStart: number;
  recentLogs: Array<{ timestamp: string; message: string; type: 'info' | 'success' | 'warn' | 'error' }>;
}

const schedulerStatus: PMSchedulerStatus = {
  active: true,
  intervalSeconds: 60,
  timezone: 'Asia/Kuala_Lumpur',
  currentTimeInKL: '',
  currentDateInKL: '',
  lastRunTimestamp: null,
  lastRunResult: null,
  totalGeneratedSinceStart: 0,
  recentLogs: []
};

function addLog(type: 'info' | 'success' | 'warn' | 'error', message: string) {
  const ts = new Date().toISOString();
  console.log(`[PM Scheduler ${type.toUpperCase()}] ${ts}: ${message}`);
  schedulerStatus.recentLogs.unshift({ timestamp: ts, message, type });
  if (schedulerStatus.recentLogs.length > 50) {
    schedulerStatus.recentLogs.pop();
  }
}

/**
 * Returns current Date and Time strictly in Asia/Kuala_Lumpur timezone
 */
export function getKualaLumpurTime() {
  const now = new Date();
  
  // Format YYYY-MM-DD
  const dateFormatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Kuala_Lumpur',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  });
  const dateString = dateFormatter.format(now);

  // Format HH:mm:ss
  const timeFormatter = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Kuala_Lumpur',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  });
  const timeString = timeFormatter.format(now);

  return {
    dateString, // e.g. "2026-10-15"
    timeString, // e.g. "22:15:00"
    isoTimestamp: now.toISOString()
  };
}

/**
 * Helper to determine the next sequential Work Order ID (e.g. DMR-1015)
 */
function calculateNextWorkOrderId(existingWorkOrders: any[]): string {
  let maxNum = 1000;
  for (const wo of existingWorkOrders) {
    const id = wo.id || wo.ticket_id || '';
    const match = String(id).match(/DMR-(\d+)/i);
    if (match) {
      const num = parseInt(match[1], 10);
      if (!isNaN(num) && num > maxNum) {
        maxNum = num;
      }
    }
  }
  return `DMR-${maxNum + 1}`;
}

/**
 * Standard default checklist items for PM tasks if none provided
 */
function getDefaultChecklist(category: string, taskDesc: string) {
  return [
    { task: 'Inspect and clean physical equipment housing', completed: false },
    { task: 'Inspect electrical and mechanical wiring/connections', completed: false },
    { task: `Perform ${taskDesc || category} verification and functional testing`, completed: false },
    { task: 'Verify safety guards and emergency shut-off controls', completed: false },
    { task: 'Record post-maintenance operating metrics & sign off', completed: false }
  ];
}

/**
 * Main scheduled routine:
 * 1. Checks all PM schedules in the database.
 * 2. Compares due dates using Asia/Kuala_Lumpur timezone.
 * 3. Safely generates Work Orders for due schedules.
 * 4. Strictly avoids duplicate generation for the same occurrence.
 * 5. Links Work Order to the PM schedule and Machine.
 */
export async function checkAndGeneratePMWorkOrders(): Promise<{
  processedCount: number;
  generatedCount: number;
  generatedWorkOrderIds: string[];
  errors: string[];
}> {
  const klTime = getKualaLumpurTime();
  schedulerStatus.currentTimeInKL = `${klTime.dateString} ${klTime.timeString}`;
  schedulerStatus.currentDateInKL = klTime.dateString;
  schedulerStatus.lastRunTimestamp = klTime.isoTimestamp;

  const result = {
    processedCount: 0,
    generatedCount: 0,
    generatedWorkOrderIds: [] as string[],
    errors: [] as string[]
  };

  try {
    // 1. Fetch PM Schedules, Work Orders, Assets, Profiles from Firestore (primary) and localDb (secondary)
    let pmList: any[] = [];
    let woList: any[] = [];
    let assetList: any[] = [];
    let profileList: any[] = [];

    // Read local DB
    const localDb = readDb();
    const localPms = localDb.preventive_maintenance || [];
    const localWos = localDb.work_orders || [];
    const localAssets = localDb.assets || [];
    const localProfiles = localDb.profiles || [];

    if (firestoreDb) {
      try {
        const pmSnap = await getDocs(collection(firestoreDb, 'pmSchedules'));
        pmList = pmSnap.docs.map(d => ({ id: d.id, ...d.data() }));

        const woSnap = await getDocs(collection(firestoreDb, 'workOrders'));
        woList = woSnap.docs.map(d => ({ id: d.id, ...d.data() }));

        const assetSnap = await getDocs(collection(firestoreDb, 'assets'));
        assetList = assetSnap.docs.map(d => ({ id: d.id, ...d.data() }));

        const profSnap = await getDocs(collection(firestoreDb, 'staff'));
        profileList = profSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      } catch (fErr: any) {
        addLog('warn', `Firestore fetch issue (${fErr.message}). Merging with local DB.`);
      }
    }

    // Merge Firestore + localDb (unique by id)
    const pmMap = new Map<string, any>();
    [...localPms, ...pmList].forEach(p => { if (p && p.id) pmMap.set(p.id, p); });
    const allPms = Array.from(pmMap.values());

    const woMap = new Map<string, any>();
    [...localWos, ...woList].forEach(w => { if (w && w.id) woMap.set(w.id, w); });
    let allWos = Array.from(woMap.values());

    const assetMap = new Map<string, any>();
    [...localAssets, ...assetList].forEach(a => { if (a && a.id) assetMap.set(a.id, a); });
    const allAssets = Array.from(assetMap.values());

    const profMap = new Map<string, any>();
    [...localProfiles, ...profileList].forEach(p => {
      const pid = p.id || p.userId;
      if (pid) profMap.set(pid, p);
    });
    const allProfiles = Array.from(profMap.values());

    result.processedCount = allPms.length;

    // 2. Identify PM schedules whose due dates have arrived
    for (const pm of allPms) {
      // Determine effective due date string (YYYY-MM-DD)
      const dueDate = pm.scheduled_date || pm.next_due_date || pm.startDate || '';
      if (!dueDate) continue;

      // Check status: ignore cancelled or explicitly deactivated
      const statusLower = (pm.status || '').toLowerCase();
      if (statusLower === 'cancelled' || statusLower === 'deactivated') {
        continue;
      }

      // Check if scheduled date has arrived in Asia/Kuala_Lumpur
      // Due if dueDate <= klTime.dateString
      const isDue = dueDate <= klTime.dateString;
      if (!isDue) {
        // Not yet due
        continue;
      }

      // 3. Strict De-Duplication Verification:
      // Has a Work Order already been generated for this PM schedule occurrence?
      const alreadyHasWorkOrder = allWos.some(w => {
        const matchesPmId = 
          (w.pm_schedule_id && w.pm_schedule_id === pm.id) ||
          (w.pmScheduleId && w.pmScheduleId === pm.id) ||
          (pm.linked_work_order_id && (w.id === pm.linked_work_order_id || w.id === pm.linkedWorkOrderId));

        if (!matchesPmId) return false;

        // Check if it belongs to this occurrence date
        const woDate = w.scheduled_date || w.scheduledDate || (w.timestamp ? w.timestamp.split('T')[0] : '');
        const matchesDate = woDate === dueDate || w.pm_occurrence_date === dueDate;
        
        // If matched PM ID and date, or if linked_work_order_id is already set for this PM
        return matchesDate || (pm.linked_work_order_id && w.id === pm.linked_work_order_id);
      });

      if (alreadyHasWorkOrder) {
        // Already generated for this occurrence, skip to avoid duplicates
        continue;
      }

      // Check if PM record itself records this occurrence as already generated
      if (pm.last_generated_occurrence_date === dueDate && pm.linked_work_order_id) {
        continue;
      }

      // 4. Retrieve Machine / Asset Information
      const assetId = pm.asset_id || pm.assetId || '';
      const matchedAsset = allAssets.find(a => 
        (assetId && a.id === assetId) || 
        (pm.machine_name && a.name && a.name.toLowerCase() === pm.machine_name.toLowerCase()) ||
        (pm.asset_name && a.name && a.name.toLowerCase() === pm.asset_name.toLowerCase())
      );

      const machineName = matchedAsset?.name || pm.machine_name || pm.asset_name || assetId || 'Machine';
      const serialNumber = matchedAsset?.serialNumber || matchedAsset?.serial_number || pm.serial_number || 'N/A';
      const location = matchedAsset?.location || pm.location || 'Workshop';
      const category = pm.category || matchedAsset?.category || 'General';
      const taskDescription = pm.maintenance_task || pm.schedule_name || pm.issue || `Preventive Maintenance - ${category}`;
      const priority = pm.priority || 'Medium';
      const downtimeHours = parseFloat(pm.downtime_hours || pm.estimated_duration || '2');

      // 5. Match or Determine Technician Assignment
      const techName = pm.assigned_to_name || pm.assigned_technician || '';
      let techId = pm.assigned_to_id || pm.assigned_technician_id || '';
      if (!techId && techName) {
        const foundTech = allProfiles.find(p => 
          (p.fullName && p.fullName.toLowerCase() === techName.toLowerCase()) ||
          (p.full_name && p.full_name.toLowerCase() === techName.toLowerCase()) ||
          (p.username && p.username.toLowerCase() === techName.toLowerCase())
        );
        if (foundTech) {
          techId = foundTech.id || foundTech.userId || '';
        }
      }

      // 6. Build Checklist
      let checklistItems: Array<{ task: string; completed: boolean }> = [];
      if (Array.isArray(pm.checklist) && pm.checklist.length > 0) {
        checklistItems = pm.checklist.map((item: any) => ({
          task: typeof item === 'string' ? item : (item.task || item.label || 'PM Check'),
          completed: false
        }));
      } else if (pm.checklist_instructions && typeof pm.checklist_instructions === 'string') {
        const lines = pm.checklist_instructions.split('\n').map((l: string) => l.replace(/^[-*•0-9.]+\s*/, '').trim()).filter(Boolean);
        if (lines.length > 0) {
          checklistItems = lines.map((line: string) => ({ task: line, completed: false }));
        }
      }
      if (checklistItems.length === 0) {
        checklistItems = getDefaultChecklist(category, taskDescription);
      }

      // 7. Calculate Next Unique Work Order ID (DMR-XXXX)
      const nextId = calculateNextWorkOrderId(allWos);

      // 8. Construct New Work Order Object matching database schema
      const newWorkOrder = {
        id: nextId,
        timestamp: klTime.isoTimestamp,
        asset_id: assetId || matchedAsset?.id || 'EQ-AUTO',
        assetId: assetId || matchedAsset?.id || 'EQ-AUTO',
        asset_name: machineName,
        assetName: machineName,
        serial_number: serialNumber,
        serialNumber: serialNumber,
        location: location,
        machine_location: location,
        category: category,
        maintenance_type: 'Preventive Maintenance (PM)',
        maintenanceType: 'Preventive Maintenance (PM)',
        issue: `[PM ${pm.id}] ${taskDescription}`,
        pm_task_description: taskDescription,
        priority: priority,
        assigned_to_id: techId || 'USR-UNASSIGNED',
        assignedToId: techId || 'USR-UNASSIGNED',
        assigned_to_name: techName || 'Pending Technician Assignment',
        assignedToName: techName || 'Pending Technician Assignment',
        status: techName ? 'Pending' : 'Pending Technician Assignment',
        logged_by: pm.logged_by || pm.supervisor || 'System PM Scheduler',
        loggedBy: pm.logged_by || pm.supervisor || 'System PM Scheduler',
        scheduled_date: dueDate,
        scheduledDate: dueDate,
        due_date: dueDate,
        dueDate: dueDate,
        downtime_hours: downtimeHours,
        downtimeHours: downtimeHours,
        estimated_duration: downtimeHours,
        estimatedDuration: downtimeHours,
        checklist: checklistItems,
        tools_and_materials: pm.tools_and_materials || pm.tools || pm.materials || '',
        materials_used: '',
        actions_taken: '',
        pm_schedule_id: pm.id,
        pmScheduleId: pm.id,
        pm_occurrence_date: dueDate,
        auto_generated: true,
        autoGenerated: true,
        generated_at: klTime.isoTimestamp,
        generatedAt: klTime.isoTimestamp,
        generation_timezone: 'Asia/Kuala_Lumpur'
      };

      // 9. Construct Activity Log
      const newLog = {
        id: `LOG-PM-${Date.now()}-${Math.floor(Math.random() * 9000 + 1000)}`,
        timestamp: klTime.isoTimestamp,
        ticket_id: nextId,
        ticketId: nextId,
        user_name: 'PM Automated Scheduler',
        user: 'PM Automated Scheduler',
        action: 'Auto-Generated Work Order',
        details: `Automatic Work Order [${nextId}] generated from PM Schedule [${pm.id}] for ${machineName} (${assetId}). Scheduled Due Date: ${dueDate} (Asia/Kuala_Lumpur).`
      };

      // 10. Update PM Schedule to link the generated Work Order
      const pmUpdates = {
        linked_work_order_id: nextId,
        linkedWorkOrderId: nextId,
        last_work_order_generated_at: klTime.isoTimestamp,
        last_generated_occurrence_date: dueDate,
        status: pm.status === 'Completed' ? 'Scheduled' : (pm.status || 'Scheduled')
      };

      // 11. Save Work Order to Firestore
      if (firestoreDb) {
        try {
          await setDoc(doc(firestoreDb, 'workOrders', nextId), newWorkOrder, { merge: true });
          await setDoc(doc(firestoreDb, 'activityLogs', newLog.id), newLog, { merge: true });
          await setDoc(doc(firestoreDb, 'pmSchedules', pm.id), pmUpdates, { merge: true });
          addLog('success', `Saved Work Order ${nextId} to Firestore workOrders collection.`);
        } catch (saveErr: any) {
          addLog('error', `Firestore save error for ${nextId}: ${saveErr.message}`);
          result.errors.push(`Firestore save error for ${nextId}: ${saveErr.message}`);
        }
      }

      // 12. Save to localDb (data/db.json) as dual-persistence
      try {
        const freshDb = readDb();
        if (!freshDb.work_orders) freshDb.work_orders = [];
        if (!freshDb.activity_logs) freshDb.activity_logs = [];
        if (!freshDb.preventive_maintenance) freshDb.preventive_maintenance = [];

        freshDb.work_orders.unshift(newWorkOrder);
        freshDb.activity_logs.unshift(newLog);

        const pmIdx = freshDb.preventive_maintenance.findIndex((p: any) => p.id === pm.id);
        if (pmIdx >= 0) {
          freshDb.preventive_maintenance[pmIdx] = {
            ...freshDb.preventive_maintenance[pmIdx],
            ...pmUpdates
          };
        } else {
          freshDb.preventive_maintenance.unshift({ ...pm, ...pmUpdates });
        }

        writeDb(freshDb);
        addLog('success', `Saved Work Order ${nextId} to local db.json.`);
      } catch (dbErr: any) {
        addLog('error', `localDb save error for ${nextId}: ${dbErr.message}`);
        result.errors.push(`localDb save error for ${nextId}: ${dbErr.message}`);
      }

      // Add to in-memory list for next iterations
      allWos.unshift(newWorkOrder);
      result.generatedCount++;
      result.generatedWorkOrderIds.push(nextId);
      schedulerStatus.totalGeneratedSinceStart++;

      addLog('success', `Auto-generated Work Order ${nextId} for PM ${pm.id} on machine ${machineName} (due ${dueDate}).`);
    }

  } catch (err: any) {
    addLog('error', `Scheduler run failed: ${err.message}`);
    result.errors.push(err.message);
  }

  schedulerStatus.lastRunResult = result;
  return result;
}

let schedulerTimer: NodeJS.Timeout | null = null;

/**
 * Initializes and starts the background server-side PM Scheduler
 */
export function startPMScheduler(intervalMs = 60000) {
  if (schedulerTimer) {
    clearInterval(schedulerTimer);
  }

  schedulerStatus.intervalSeconds = Math.round(intervalMs / 1000);
  schedulerStatus.active = true;

  addLog('info', `Background PM Scheduler started (Interval: ${schedulerStatus.intervalSeconds}s, Timezone: ${schedulerStatus.timezone}). Running initial check...`);

  // Run immediate first check
  checkAndGeneratePMWorkOrders()
    .then(res => {
      if (res.generatedCount > 0) {
        addLog('info', `Initial check completed: generated ${res.generatedCount} work order(s): ${res.generatedWorkOrderIds.join(', ')}`);
      } else {
        addLog('info', `Initial check completed: ${res.processedCount} PM schedule(s) checked, 0 due for generation.`);
      }
    })
    .catch(err => {
      addLog('error', `Initial check error: ${err.message}`);
    });

  // Recurring interval
  schedulerTimer = setInterval(() => {
    checkAndGeneratePMWorkOrders().catch(err => {
      addLog('error', `Recurring check error: ${err.message}`);
    });
  }, intervalMs);
}

/**
 * Stops the scheduler
 */
export function stopPMScheduler() {
  if (schedulerTimer) {
    clearInterval(schedulerTimer);
    schedulerTimer = null;
  }
  schedulerStatus.active = false;
  addLog('warn', 'Background PM Scheduler stopped.');
}

/**
 * Get current scheduler telemetry
 */
export function getPMSchedulerStatus(): PMSchedulerStatus {
  const kl = getKualaLumpurTime();
  schedulerStatus.currentTimeInKL = `${kl.dateString} ${kl.timeString}`;
  schedulerStatus.currentDateInKL = kl.dateString;
  return { ...schedulerStatus };
}
