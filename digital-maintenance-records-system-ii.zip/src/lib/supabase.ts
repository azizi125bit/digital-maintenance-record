/**
 * Firebase Firestore Client
 * Connected to Firebase Firestore Database: ai-studio-dmrdigitalmainte-a087a991-08fe-4327-abd1-fb4139bb5023
 */
export { firebaseDbClient as supabase, firebaseDbClient, db, auth } from './firebase';
