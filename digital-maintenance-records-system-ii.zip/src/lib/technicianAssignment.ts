/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Asset, Personnel, WorkOrder, MaintenanceCategory, PriorityLevel } from '../types';

export interface AssignmentCriteria {
  asset: Asset | null;
  maintenanceType: MaintenanceCategory;
  priority: PriorityLevel;
  issueDescription: string;
  scheduledDate?: string;
  estimatedDuration?: number;
  maxWorkloadLimit?: number;
}

export interface CandidateEvaluation {
  technician: Personnel;
  isEligible: boolean;
  departmentMatch: boolean;
  skillMatchScore: number;
  matchedSkills: string[];
  primarySkill: string;
  currentActiveWorkload: number;
  maxWorkload: number;
  isAtMaxWorkload: boolean;
  isAccountActive: boolean;
  hasScheduleConflict: boolean;
  rejectionReasons: string[];
  totalScore: number;
}

export interface AssignmentResult {
  success: boolean;
  technician: Personnel | null;
  technicianId: string;
  technicianName: string;
  department: string;
  primarySkill: string;
  currentActiveWorkOrders: number;
  availability: 'Available' | 'Immediate Dispatch' | 'Scheduled';
  assignmentReason: string;
  candidateEvaluations: CandidateEvaluation[];
  rejectionSummary: string[];
  suggestedStatus: 'Pending' | 'Pending Technician Assignment';
}

export const DEFAULT_MAX_WORKLOAD = 5;

/**
 * Normalizes strings for lenient department and skill comparisons
 */
const normalize = (str?: string) => (str || '').trim().toLowerCase();

/**
 * Calculates current active workload for a technician across work orders and PM tasks
 */
export function getActiveWorkload(
  staff: Personnel,
  workOrders: WorkOrder[],
  pmTasks: any[] = []
): number {
  const activeOrders = workOrders.filter(
    (wo) => wo.status !== 'Completed' && wo.status !== 'Closed' as any
  );
  const activePMs = (pmTasks || []).filter(
    (pm) => pm.status !== 'Completed' && pm.status !== 'Closed'
  );

  const matchingOrders = activeOrders.filter((wo) => {
    return (
      wo.assignedToId === staff.userId ||
      wo.assignedToId === staff.employeeId ||
      wo.assignedToName === staff.fullName ||
      (wo.assignedToName && staff.fullName && wo.assignedToName.includes(staff.fullName))
    );
  });

  const matchingPMs = activePMs.filter((pm) => {
    return (
      pm.assigned_technician === staff.fullName ||
      pm.assigned_technician === staff.userId ||
      pm.assigned_technician === staff.employeeId
    );
  });

  return matchingOrders.length + matchingPMs.length;
}

/**
 * Checks if the technician has a schedule conflict on the given date
 */
export function hasScheduleConflict(
  staff: Personnel,
  scheduledDate: string | undefined,
  workOrders: WorkOrder[]
): boolean {
  if (!scheduledDate) return false;
  const targetDate = scheduledDate.split('T')[0];

  return workOrders.some((wo) => {
    if (wo.status === 'Completed' || (wo.status as string) === 'Closed') return false;
    const woDate = wo.scheduledDate ? wo.scheduledDate.split('T')[0] : wo.timestamp?.split('T')[0];
    const isAssigned =
      wo.assignedToId === staff.userId ||
      wo.assignedToId === staff.employeeId ||
      wo.assignedToName === staff.fullName;
    // If technician already has 3 or more tickets on that exact date, treat as schedule conflict
    return isAssigned && woDate === targetDate;
  });
}

/**
 * Checks if Technician Department matches Asset Department
 * Only technicians assigned to matching department are considered.
 * Do NOT assign a technician from an unrelated department.
 */
export function matchDepartment(assetDept?: string, techDept?: string): boolean {
  const aDept = normalize(assetDept);
  const tDept = normalize(techDept);

  if (!aDept || !tDept) return true; // fallback if data is unspecified
  if (aDept === tDept) return true;

  // Department aliases and groupings
  if (tDept === 'plant maintenance' || tDept === 'maintenance') {
    return true; // Central Plant Maintenance can service general assets
  }

  if (aDept === 'machining' || aDept.includes('workshop') || aDept.includes('cnc')) {
    return tDept === 'machining' || tDept === 'mechanical';
  }

  if (aDept === 'electrical' || aDept.includes('automation') || aDept.includes('plc')) {
    return tDept === 'electrical' || tDept === 'automation & electrical';
  }

  if (aDept === 'pneumatics' || aDept.includes('pneumatic')) {
    return tDept === 'pneumatics' || tDept === 'hydraulic';
  }

  return false;
}

/**
 * Evaluates skill match between Work Order maintenance type/issue and technician skills
 */
export function evaluateSkills(
  staff: Personnel,
  maintenanceType: MaintenanceCategory,
  issueDescription: string
): { score: number; matchedSkills: string[]; primarySkill: string } {
  const staffSkills = staff.skills || [];
  const primarySkill = staff.primarySkill || staffSkills[0] || staff.position || 'General Maintenance';
  const matchedSkills: string[] = [];
  let score = 0;

  const targetCategory = normalize(maintenanceType);
  const issueText = normalize(issueDescription);

  // 1. Primary Skill Match (+15 pts)
  if (normalize(primarySkill) === targetCategory || normalize(primarySkill).includes(targetCategory)) {
    score += 15;
    matchedSkills.push(primarySkill);
  }

  // 2. Secondary Skills Match (+10 pts each)
  staffSkills.forEach((skill) => {
    const sNorm = normalize(skill);
    if (sNorm === targetCategory || sNorm.includes(targetCategory) || targetCategory.includes(sNorm)) {
      if (!matchedSkills.includes(skill)) {
        matchedSkills.push(skill);
        score += 10;
      }
    }
  });

  // 3. Keyword matching in problem description (+3 pts each)
  staffSkills.forEach((skill) => {
    const sNorm = normalize(skill);
    if (issueText.length > 0 && issueText.includes(sNorm)) {
      if (!matchedSkills.includes(skill)) {
        matchedSkills.push(skill);
      }
      score += 5;
    }
  });

  // Special domain synonyms
  if (targetCategory === 'mechanical') {
    const mechKeywords = ['lathe', 'milling', 'drill', 'gear', 'motor', 'pump', 'spindle', 'bearing', 'lubrication'];
    staffSkills.forEach((skill) => {
      if (mechKeywords.some((kw) => normalize(skill).includes(kw))) {
        score += 4;
        if (!matchedSkills.includes(skill)) matchedSkills.push(skill);
      }
    });
  } else if (targetCategory === 'electrical') {
    const elecKeywords = ['plc', 'control panel', 'wiring', 'fuse', 'breaker', 'sensor', 'voltage', 'circuit'];
    staffSkills.forEach((skill) => {
      if (elecKeywords.some((kw) => normalize(skill).includes(kw))) {
        score += 4;
        if (!matchedSkills.includes(skill)) matchedSkills.push(skill);
      }
    });
  } else if (targetCategory === 'pneumatic') {
    const pneuKeywords = ['compressor', 'valve', 'pressure', 'cylinder', 'regulator', 'hydraulic', 'leak'];
    staffSkills.forEach((skill) => {
      if (pneuKeywords.some((kw) => normalize(skill).includes(kw))) {
        score += 4;
        if (!matchedSkills.includes(skill)) matchedSkills.push(skill);
      }
    });
  }

  return { score, matchedSkills, primarySkill };
}

/**
 * AUTOMATIC TECHNICIAN ASSIGNMENT ENGINE
 * 
 * Rules executed in strict order of priority:
 * 1. Technician Department
 * 2. Technician Skill / Maintenance Type
 * 3. Technician Availability
 * 4. Current Workload Balancing
 * 5. Technician Account Status
 */
export function autoAssignTechnician(
  criteria: AssignmentCriteria,
  staffList: Personnel[],
  workOrders: WorkOrder[],
  pmTasks: any[] = []
): AssignmentResult {
  const maxLimit = criteria.maxWorkloadLimit || DEFAULT_MAX_WORKLOAD;
  const isEmergency = criteria.priority === 'Critical' || criteria.priority === 'High';

  // Filter staff: consider personnel with role Technician or with technician in position
  const techPool = staffList.filter((s) => s.role === 'Technician' || normalize(s.position).includes('tech'));
  const candidatePool = techPool.length > 0 ? techPool : staffList.filter((s) => s.role !== 'Auditor');

  const evaluations: CandidateEvaluation[] = [];
  const rejectionReasonsCollector: Set<string> = new Set();

  for (const tech of candidatePool) {
    const reasons: string[] = [];

    // 1. Account Status Check (Priority 5 & Rule 5)
    const isAccountActive = tech.accountStatus === 'Active';
    if (!isAccountActive) {
      reasons.push(`Technician unavailable (Account is ${tech.accountStatus || 'Inactive'})`);
      rejectionReasonsCollector.add('Technician unavailable');
    }

    // 2. Department Matching (Rule 3 & Priority 1)
    const assetDept = criteria.asset?.department || criteria.asset?.location || 'Plant Maintenance';
    const techDept = tech.department || 'Plant Maintenance';
    const departmentMatch = matchDepartment(assetDept, techDept);
    if (!departmentMatch) {
      reasons.push(`Department mismatch: Asset in '${assetDept}', Technician in '${techDept}'`);
      rejectionReasonsCollector.add('Department mismatch');
    }

    // 3. Skill Matching (Rule 4 & Priority 2)
    const { score: skillScore, matchedSkills, primarySkill } = evaluateSkills(
      tech,
      criteria.maintenanceType,
      criteria.issueDescription
    );
    const hasMatchingSkill = skillScore > 0;
    if (!hasMatchingSkill) {
      reasons.push(`No matching skill for '${criteria.maintenanceType}' maintenance`);
      rejectionReasonsCollector.add('No matching skill');
    }

    // 4. Current Workload & Maximum Workload (Rule 6, Rule 10 & Priority 4)
    const currentActiveWorkload = getActiveWorkload(tech, workOrders, pmTasks);
    const techMax = tech.maxWorkload || maxLimit;
    const isAtMaxWorkload = currentActiveWorkload >= techMax;
    if (isAtMaxWorkload) {
      reasons.push(`Maximum workload capacity reached (${currentActiveWorkload}/${techMax} active orders)`);
      rejectionReasonsCollector.add('All suitable technicians have maximum workload');
    }

    // 5. Schedule Availability (Rule 5 & Priority 3)
    const conflict = hasScheduleConflict(tech, criteria.scheduledDate, workOrders);
    if (conflict) {
      reasons.push(`Technician unavailable due to existing scheduled active orders on ${criteria.scheduledDate}`);
      rejectionReasonsCollector.add('Technician unavailable on requested schedule');
    }

    const isEligible = isAccountActive && departmentMatch && hasMatchingSkill && !isAtMaxWorkload && !conflict;

    // Calculate total ranking score
    // Higher skill score = better
    // Lower workload = better (inverted penalty)
    // Emergency orders reward immediate availability heavily
    let totalScore = skillScore * 10;
    totalScore -= currentActiveWorkload * 15; // Fair workload balancing weight

    if (isEmergency) {
      // Prioritize immediate availability and lowest active workload
      if (currentActiveWorkload === 0) totalScore += 50;
      else if (currentActiveWorkload === 1) totalScore += 25;
      totalScore += skillScore * 5;
    }

    evaluations.push({
      technician: tech,
      isEligible,
      departmentMatch,
      skillMatchScore: skillScore,
      matchedSkills,
      primarySkill,
      currentActiveWorkload,
      maxWorkload: techMax,
      isAtMaxWorkload,
      isAccountActive,
      hasScheduleConflict: conflict,
      rejectionReasons: reasons,
      totalScore,
    });
  }

  // Filter strictly eligible candidates
  const eligible = evaluations.filter((e) => e.isEligible);

  if (eligible.length === 0) {
    return {
      success: false,
      technician: null,
      technicianId: '',
      technicianName: '',
      department: criteria.asset?.department || 'Plant Maintenance',
      primarySkill: criteria.maintenanceType,
      currentActiveWorkOrders: 0,
      availability: 'Available',
      assignmentReason: 'No suitable technician is currently available for this maintenance task.',
      candidateEvaluations: evaluations,
      rejectionSummary: Array.from(rejectionReasonsCollector),
      suggestedStatus: 'Pending Technician Assignment',
    };
  }

  // Sort eligible candidates:
  // 1. Lowest workload (Fair Balancing - Rule 6)
  // 2. Highest skill match score (Skill Matching - Rule 4)
  // 3. Higher total composite score
  eligible.sort((a, b) => {
    // Primary: lowest active workload
    if (a.currentActiveWorkload !== b.currentActiveWorkload) {
      return a.currentActiveWorkload - b.currentActiveWorkload;
    }
    // Secondary: skill match score
    if (b.skillMatchScore !== a.skillMatchScore) {
      return b.skillMatchScore - a.skillMatchScore;
    }
    // Tertiary: total composite score
    return b.totalScore - a.totalScore;
  });

  const best = eligible[0];
  const chosenTech = best.technician;

  // Build the assignment reason string according to prompt specs
  const reasons: string[] = ['Matched department'];
  if (best.matchedSkills.length > 0) {
    reasons.push(`required skill (${best.primarySkill})`);
  }
  reasons.push('availability');
  reasons.push(`lowest active workload (${best.currentActiveWorkload} active orders)`);
  if (isEmergency) {
    reasons.push('emergency dispatch readiness');
  }

  const assignmentReason = `Matched department, required skill, availability and lowest workload.`;

  return {
    success: true,
    technician: chosenTech,
    technicianId: chosenTech.userId || chosenTech.employeeId,
    technicianName: chosenTech.fullName,
    department: chosenTech.department || criteria.asset?.department || 'Plant Maintenance',
    primarySkill: best.primarySkill,
    currentActiveWorkOrders: best.currentActiveWorkload,
    availability: isEmergency && best.currentActiveWorkload === 0 ? 'Immediate Dispatch' : 'Available',
    assignmentReason,
    candidateEvaluations: evaluations,
    rejectionSummary: [],
    suggestedStatus: 'Pending',
  };
}
