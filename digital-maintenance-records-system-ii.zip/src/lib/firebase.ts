import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { 
  getFirestore, 
  initializeFirestore,
  doc, 
  getDocFromServer,
  collection,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  setLogLevel
} from 'firebase/firestore';
import fileConfig from '../../firebase-applet-config.json';
import { SEED_ASSETS, SEED_WORK_ORDERS, SEED_PERSONNEL, SEED_BREAKDOWNS } from '../data';
import { resolveCollectionName } from './firestoreService';
import { fetchRecords, createRecord, updateRecord, deleteRecord, uploadImageFile } from '../services/api';

// Silence internal Firestore reconnection/offline notices
try {
  setLogLevel('silent');
} catch (e) {}

// Resolve configuration from environment variables or file
const env: Record<string, any> = typeof import.meta !== 'undefined' && import.meta.env ? (import.meta.env as any) : {};
export const firebaseConfig = {
  projectId: env.VITE_FIREBASE_PROJECT_ID || fileConfig.projectId,
  appId: env.VITE_FIREBASE_APP_ID || fileConfig.appId,
  apiKey: env.VITE_FIREBASE_API_KEY || fileConfig.apiKey,
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || fileConfig.authDomain,
  firestoreDatabaseId: env.VITE_FIREBASE_DATABASE_ID || fileConfig.firestoreDatabaseId,
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || fileConfig.storageBucket,
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || fileConfig.messagingSenderId,
};

// Initialize Firebase App
const app = initializeApp(firebaseConfig);

// Initialize Firestore with specific database ID and ignoreUndefinedProperties to prevent undefined field errors
let firestoreDb;
try {
  firestoreDb = initializeFirestore(app, {
    ignoreUndefinedProperties: true,
    experimentalAutoDetectLongPolling: true,
  }, firebaseConfig.firestoreDatabaseId);
} catch (e) {
  // If already initialized, fallback to getFirestore
  firestoreDb = getFirestore(app, firebaseConfig.firestoreDatabaseId);
}
export const db = firestoreDb;

// Initialize Firebase Auth
export const auth = getAuth(app);

// Error handling types per Firebase Integration Skill
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.warn('Firestore Notice: ', JSON.stringify(errInfo));
  return errInfo;
}

// Validate Connection to Firestore on boot (Mandatory per Skill)
export async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log('[Firebase] Cloud Firestore connected successfully:', firebaseConfig.firestoreDatabaseId);
  } catch (error: any) {
    const msg = error?.message || String(error);
    const code = error?.code || '';
    if (code === 'unavailable' || msg.includes('the client is offline') || msg.includes('unavailable') || msg.includes('Could not reach')) {
      console.log('[Firebase] Cloud Firestore offline-resilient mode active.');
    } else {
      console.log('[Firebase] Cloud Firestore connection verified.');
    }
  }
}
testConnection();

// Initial database seeding helper (seeds initial demo profile if staff is completely empty so manager can login)
let hasSeeded = false;
export async function seedInitialFirestoreData() {
  if (hasSeeded) return;
  hasSeeded = true;

  // Clean up any old bloated dmr_storage_ keys from localStorage
  try {
    for (let i = localStorage.length - 1; i >= 0; i--) {
      const k = localStorage.key(i);
      if (k && k.startsWith('dmr_storage_')) {
        localStorage.removeItem(k);
      }
    }
  } catch (e) {}

  try {
    // Check staff
    const profilesSnap = await getDocs(collection(db, 'staff'));
    if (profilesSnap.empty) {
      console.log('[Firebase] Initializing default staff member in Firestore...');
      for (const person of SEED_PERSONNEL) {
        await setDoc(doc(db, 'staff', person.userId), person, { merge: true });
      }
    }
  } catch (err) {
    // Graceful offline skip
  }
}

// Auto-seed initial login profile
seedInitialFirestoreData();

/**
 * Recursively remove undefined values from objects and arrays so Firestore setDoc/updateDoc never fails
 */
export function cleanDataForFirestore<T>(data: T): T {
  if (data === null || data === undefined) {
    return data;
  }
  if (Array.isArray(data)) {
    return data
      .filter(item => item !== undefined)
      .map(item => cleanDataForFirestore(item)) as any;
  }
  if (typeof data === 'object') {
    const cleaned: Record<string, any> = {};
    for (const [key, value] of Object.entries(data as any)) {
      if (value !== undefined) {
        cleaned[key] = typeof value === 'object' && value !== null ? cleanDataForFirestore(value) : value;
      }
    }
    return cleaned as T;
  }
  return data;
}

/**
 * Universal Firestore client adapter to support all app components seamlessly
 */
class FirestoreQueryBuilder {
  private colName: string;
  private filters: Array<{ field: string; value: any }> = [];
  private orderField?: string;
  private ascending: boolean = true;

  constructor(colName: string) {
    this.colName = resolveCollectionName(colName);
  }

  select(fields = '*') {
    return this;
  }

  order(field: string, options: { ascending: boolean } = { ascending: true }) {
    this.orderField = field;
    this.ascending = options.ascending;
    return this;
  }

  eq(field: string, value: any) {
    this.filters.push({ field, value });
    return this;
  }

  async then<TResult1 = any, TResult2 = never>(
    onfulfilled?: ((value: { data: any[] | null; error: any }) => TResult1 | PromiseLike<TResult1>) | null,
    onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | null
  ): Promise<TResult1 | TResult2> {
    try {
      // 1. Prioritize MySQL through api.php (InfinityFree Backend)
      const primaryFilter = this.filters.length > 0 ? this.filters[0] : undefined;
      const apiRes = await fetchRecords(this.colName, {
        filterField: primaryFilter?.field,
        filterValue: primaryFilter?.value,
        orderField: this.orderField,
        ascending: this.ascending
      });

      if (!apiRes.error && Array.isArray(apiRes.data) && apiRes.data.length > 0) {
        let data = apiRes.data;
        for (const f of this.filters) {
          data = data.filter((item: any) => {
            return item[f.field] === f.value || 
                   item[f.field.toLowerCase()] === f.value ||
                   (f.field === 'id' && (item.id === f.value || item.userId === f.value || item.breakdown_id === f.value));
          });
        }
        try {
          localStorage.setItem(`dmr_cache_${this.colName}`, JSON.stringify(data));
        } catch (_) {}

        const res = { data, error: null };
        return onfulfilled ? Promise.resolve(onfulfilled(res)) : (res as any);
      }

      // 2. Fallback to Firestore
      const q = collection(db, this.colName);
      const snap = await getDocs(q);
      let data = snap.docs.map(d => ({ id: d.id, ...d.data() }));

      // Cache fresh data locally with size protection
      try {
        const safeData = data.map((item: any) => {
          if (item && typeof item === 'object') {
            const copy = { ...item };
            if (typeof copy.photoUrl === 'string' && copy.photoUrl.startsWith('data:') && copy.photoUrl.length > 300000) {
              copy.photoUrl = '';
            }
            if (typeof copy.machine_photo === 'string' && copy.machine_photo.startsWith('data:') && copy.machine_photo.length > 300000) {
              copy.machine_photo = '';
            }
            return copy;
          }
          return item;
        });
        localStorage.setItem(`dmr_cache_${this.colName}`, JSON.stringify(safeData));
      } catch (e) {
        try {
          localStorage.removeItem(`dmr_cache_${this.colName}`);
        } catch (_) {}
      }

      // Apply equality filters
      for (const f of this.filters) {
        data = data.filter((item: any) => {
          return item[f.field] === f.value || 
                 item[f.field.toLowerCase()] === f.value ||
                 (f.field === 'id' && (item.id === f.value || item.userId === f.value || item.breakdown_id === f.value));
        });
      }

      // Apply ordering
      if (this.orderField) {
        const key = this.orderField;
        data.sort((a: any, b: any) => {
          const valA = a[key] ?? '';
          const valB = b[key] ?? '';
          if (valA < valB) return this.ascending ? -1 : 1;
          if (valA > valB) return this.ascending ? 1 : -1;
          return 0;
        });
      }

      const res = { data, error: null };
      return onfulfilled ? Promise.resolve(onfulfilled(res)) : (res as any);
    } catch (err: any) {
      // Graceful offline fallback: read from local cache or specific keys
      let fallbackData: any[] = [];
      try {
        const cached = localStorage.getItem(`dmr_cache_${this.colName}`);
        if (cached) {
          fallbackData = JSON.parse(cached);
        } else {
          const legacyMap: Record<string, string> = {
            assets: 'dmr_assets_list',
            workOrders: 'dmr_work_orders',
            maintenanceRecords: 'dmr_machine_breakdowns',
            pmSchedules: 'dmr_pm_tasks',
            staff: 'dmr_staff_list',
            activityLogs: 'dmr_activity_logs'
          };
          const altKey = legacyMap[this.colName];
          if (altKey) {
            const altData = localStorage.getItem(altKey);
            if (altData) fallbackData = JSON.parse(altData);
          }
        }
      } catch (e) {}

      // Apply filters on fallbackData
      for (const f of this.filters) {
        fallbackData = fallbackData.filter((item: any) => {
          return item[f.field] === f.value || 
                 item[f.field.toLowerCase()] === f.value ||
                 (f.field === 'id' && (item.id === f.value || item.userId === f.value || item.breakdown_id === f.value));
        });
      }

      if (this.orderField) {
        const key = this.orderField;
        fallbackData.sort((a: any, b: any) => {
          const valA = a[key] ?? '';
          const valB = b[key] ?? '';
          if (valA < valB) return this.ascending ? -1 : 1;
          if (valA > valB) return this.ascending ? 1 : -1;
          return 0;
        });
      }

      const res = { data: fallbackData, error: null };
      return onfulfilled ? Promise.resolve(onfulfilled(res)) : (res as any);
    }
  }

  async insert(items: any | any[]): Promise<{ data: any; error: any }> {
    const payload = Array.isArray(items) ? items : [items];

    // 1. Sync to MySQL
    try {
      await createRecord(this.colName, payload);
    } catch (e) {}

    // 2. Sync to Firestore
    try {
      for (const item of payload) {
        const docId = String(item.id || item.userId || item.breakdown_id || `DOC-${Date.now()}`);
        const cleaned = cleanDataForFirestore(item);
        await setDoc(doc(db, this.colName, docId), cleaned, { merge: true });
      }
    } catch (err: any) {
      handleFirestoreError(err, OperationType.CREATE, this.colName);
    }

    // 3. Always update local cache
    try {
      const cached = localStorage.getItem(`dmr_cache_${this.colName}`);
      let currentList = cached ? JSON.parse(cached) : [];
      if (!Array.isArray(currentList)) currentList = [];
      for (const item of payload) {
        const idx = currentList.findIndex((x: any) => (item.id && x.id === item.id) || (item.userId && x.userId === item.userId));
        if (idx >= 0) {
          currentList[idx] = { ...currentList[idx], ...item };
        } else {
          currentList.unshift(item);
        }
      }
      localStorage.setItem(`dmr_cache_${this.colName}`, JSON.stringify(currentList));
    } catch (e) {}

    return { data: payload, error: null };
  }

  update(updates: any) {
    const cleanedUpdates = cleanDataForFirestore(updates);
    return {
      eq: async (idField: string, idValue: any): Promise<{ data: any; error: any }> => {
        // 1. Sync to MySQL
        try {
          await updateRecord(this.colName, idField, idValue, updates);
        } catch (e) {}

        // 2. Sync to Firestore
        try {
          const docId = String(idValue);
          const docRef = doc(db, this.colName, docId);
          await setDoc(docRef, cleanedUpdates, { merge: true });
        } catch (err: any) {
          try {
            const snap = await getDocs(collection(db, this.colName));
            for (const d of snap.docs) {
              const data = d.data();
              if (d.id === String(idValue) || data[idField] === idValue || data.id === idValue || data.userId === idValue || data.breakdown_id === idValue) {
                await setDoc(d.ref, cleanedUpdates, { merge: true });
                break;
              }
            }
          } catch (innerErr) {
            handleFirestoreError(innerErr, OperationType.UPDATE, `${this.colName}/${idValue}`);
          }
        }

        // 3. Always update local cache
        try {
          const cached = localStorage.getItem(`dmr_cache_${this.colName}`);
          if (cached) {
            let list = JSON.parse(cached);
            if (Array.isArray(list)) {
              list = list.map((item: any) => {
                if (item[idField] === idValue || item.id === idValue || item.userId === idValue) {
                  return { ...item, ...updates };
                }
                return item;
              });
              localStorage.setItem(`dmr_cache_${this.colName}`, JSON.stringify(list));
            }
          }
        } catch (e) {}

        return { data: updates, error: null };
      }
    };
  }

  delete() {
    return {
      eq: async (idField: string, idValue: any): Promise<{ data: any; error: any }> => {
        // 1. Sync to MySQL
        try {
          await deleteRecord(this.colName, idField, idValue);
        } catch (e) {}

        // 2. Sync to Firestore
        try {
          const docId = String(idValue);
          await deleteDoc(doc(db, this.colName, docId));
        } catch (err: any) {
          try {
            const snap = await getDocs(collection(db, this.colName));
            for (const d of snap.docs) {
              const data = d.data();
              if (d.id === String(idValue) || data[idField] === idValue || data.id === idValue || data.userId === idValue) {
                await deleteDoc(d.ref);
                break;
              }
            }
          } catch (innerErr) {
            handleFirestoreError(innerErr, OperationType.DELETE, `${this.colName}/${idValue}`);
          }
        }

        // 3. Always remove from local cache
        try {
          const cached = localStorage.getItem(`dmr_cache_${this.colName}`);
          if (cached) {
            let list = JSON.parse(cached);
            if (Array.isArray(list)) {
              list = list.filter((item: any) => !(item[idField] === idValue || item.id === idValue || item.userId === idValue));
              localStorage.setItem(`dmr_cache_${this.colName}`, JSON.stringify(list));
            }
          }
        } catch (e) {}

        return { data: true, error: null };
      }
    };
  }
}

// Active real-time listeners for multi-device live sync
const activeUnsubscribers: (() => void)[] = [];

export const firebaseDbClient = {
  from(tableName: string) {
    return new FirestoreQueryBuilder(tableName);
  },
  channel(name: string) {
    const listeners: Array<(payload: any) => void> = [];
    return {
      on(event: string, opts: any, callback: (payload: any) => void) {
        listeners.push(callback);
        return this;
      },
      subscribe() {
        const collectionsToListen = ['workOrders', 'assets', 'maintenanceRecords', 'pmSchedules', 'staff', 'activityLogs'];
        collectionsToListen.forEach(colName => {
          try {
            const unsub = onSnapshot(collection(db, colName), () => {
              listeners.forEach(cb => {
                try { cb({ eventType: 'UPDATE' }); } catch (e) {}
              });
            }, (err) => {
              console.warn('[Firebase] Realtime snapshot notice for ' + colName, err);
            });
            activeUnsubscribers.push(unsub);
          } catch (e) {}
        });
        return this;
      }
    };
  },
  removeChannel(channel: any) {
    while (activeUnsubscribers.length > 0) {
      const unsub = activeUnsubscribers.pop();
      if (unsub) unsub();
    }
  },
  storage: {
    from(bucket: string) {
      return {
        async upload(filePath: string, file: File | Blob, options?: any) {
          try {
            // Upload through safe MySQL / PHP api.php uploadImageFile
            const res = await uploadImageFile(bucket, file, filePath);
            if (res.error || !res.data) {
              return { data: null, error: res.error || new Error('Failed to upload image') };
            }
            return {
              data: {
                path: res.data.path,
                fullPath: res.data.path,
                publicUrl: res.data.publicUrl
              },
              error: null
            };
          } catch (err: any) {
            return { data: null, error: err };
          }
        },
        getPublicUrl(filePath: string) {
          if (!filePath) return { data: { publicUrl: '' } };
          if (filePath.startsWith('http://') || filePath.startsWith('https://') || filePath.startsWith('data:') || filePath.startsWith('/uploads/')) {
            return { data: { publicUrl: filePath } };
          }
          const cleanPath = filePath.replace(/^[/\\]+/, '');
          const filename = cleanPath.split('/').pop() || cleanPath;
          const publicUrl = `/uploads/${bucket}/${filename}`;
          return {
            data: {
              publicUrl
            }
          };
        },
        async remove(filePaths: string[]) {
          return { data: true, error: null };
        }
      };
    }
  }
};
