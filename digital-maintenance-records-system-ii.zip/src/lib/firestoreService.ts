import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  orderBy, 
  onSnapshot 
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType, cleanDataForFirestore } from './firebase';
import { Asset, WorkOrder, Personnel, MachineBreakdown, PMSchedule, ActivityLog, SafetyDocument } from '../types';
import { fetchRecords, createRecord, deleteRecord } from '../services/api';

/**
 * Standardized Firestore collection mappings
 */
export const COLLECTIONS = {
  STAFF: 'staff',
  ASSETS: 'assets',
  WORK_ORDERS: 'workOrders',
  MAINTENANCE_RECORDS: 'maintenanceRecords',
  PM_SCHEDULES: 'pmSchedules',
  INVENTORY: 'inventory',
  ACTIVITY_LOGS: 'activityLogs',
  SAFETY_DOCUMENTS: 'safetyDocuments',
} as const;

// Resolve aliases so both modern clean names and legacy names point to the same primary Firestore collections
export function resolveCollectionName(name: string): string {
  switch (name) {
    case 'profiles':
    case 'staff':
      return COLLECTIONS.STAFF;
    case 'assets':
      return COLLECTIONS.ASSETS;
    case 'work_orders':
    case 'workOrders':
      return COLLECTIONS.WORK_ORDERS;
    case 'machine_breakdowns':
    case 'maintenanceRecords':
    case 'maintenance_history':
      return COLLECTIONS.MAINTENANCE_RECORDS;
    case 'preventive_maintenance':
    case 'pmSchedules':
      return COLLECTIONS.PM_SCHEDULES;
    case 'inventory':
      return COLLECTIONS.INVENTORY;
    case 'activity_logs':
    case 'activityLogs':
      return COLLECTIONS.ACTIVITY_LOGS;
    case 'safety_documents':
    case 'safetyDocuments':
    case 'require_documents':
    case 'requireDocuments':
    case 'documents':
      return COLLECTIONS.SAFETY_DOCUMENTS;
    default:
      return name;
  }
}

// ============================================================================
// 1. STAFF / PERSONNEL
// ============================================================================
export async function getStaffFromFirestore(): Promise<Personnel[]> {
  try {
    const mysqlRes = await fetchRecords<Personnel>('staff');
    if (!mysqlRes.error && Array.isArray(mysqlRes.data) && mysqlRes.data.length > 0) {
      return mysqlRes.data;
    }
  } catch (e) {}

  try {
    const colRef = collection(db, COLLECTIONS.STAFF);
    const snap = await getDocs(colRef);
    return snap.docs.map(d => ({ userId: d.id, ...d.data() } as Personnel));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, COLLECTIONS.STAFF);
    return [];
  }
}

export async function saveStaffToFirestore(person: Personnel): Promise<Personnel> {
  const id = person.userId || `USR-${Date.now()}`;
  const personWithId = cleanDataForFirestore({ ...person, userId: id });

  try {
    await createRecord('staff', personWithId);
  } catch (e) {}

  try {
    await setDoc(doc(db, COLLECTIONS.STAFF, id), personWithId, { merge: true });
    return personWithId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `${COLLECTIONS.STAFF}/${id}`);
    return personWithId;
  }
}

export async function deleteStaffFromFirestore(userId: string): Promise<boolean> {
  try {
    await deleteRecord('staff', 'user_id', userId);
  } catch (e) {}

  try {
    await deleteDoc(doc(db, COLLECTIONS.STAFF, userId));
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `${COLLECTIONS.STAFF}/${userId}`);
    return true;
  }
}

// ============================================================================
// 2. ASSETS / MACHINES
// ============================================================================
export async function getAssetsFromFirestore(): Promise<Asset[]> {
  try {
    const mysqlRes = await fetchRecords<Asset>('assets');
    if (!mysqlRes.error && Array.isArray(mysqlRes.data) && mysqlRes.data.length > 0) {
      return mysqlRes.data;
    }
  } catch (e) {}

  try {
    const colRef = collection(db, COLLECTIONS.ASSETS);
    const snap = await getDocs(colRef);
    return snap.docs.map(d => ({ id: d.id, ...d.data() } as Asset));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, COLLECTIONS.ASSETS);
    return [];
  }
}

export async function saveAssetToFirestore(asset: Asset): Promise<Asset> {
  const id = asset.id || `MCH-${Date.now()}`;
  const assetWithId = cleanDataForFirestore({ 
    ...asset, 
    id,
    criticality: asset.criticality || 'Medium',
    status: asset.status || 'Operational',
    category: asset.category || 'General'
  });

  try {
    await createRecord('assets', assetWithId);
  } catch (e) {}

  try {
    await setDoc(doc(db, COLLECTIONS.ASSETS, id), assetWithId, { merge: true });
    return assetWithId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `${COLLECTIONS.ASSETS}/${id}`);
    return assetWithId;
  }
}

export async function deleteAssetFromFirestore(assetId: string): Promise<boolean> {
  try {
    await deleteRecord('assets', 'id', assetId);
  } catch (e) {}

  try {
    await deleteDoc(doc(db, COLLECTIONS.ASSETS, assetId));
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `${COLLECTIONS.ASSETS}/${assetId}`);
    return true;
  }
}

// ============================================================================
// 3. WORK ORDERS
// ============================================================================
export async function getWorkOrdersFromFirestore(): Promise<WorkOrder[]> {
  try {
    const mysqlRes = await fetchRecords<WorkOrder>('work_orders', { orderField: 'timestamp', ascending: false });
    if (!mysqlRes.error && Array.isArray(mysqlRes.data) && mysqlRes.data.length > 0) {
      return mysqlRes.data;
    }
  } catch (e) {}

  try {
    const colRef = collection(db, COLLECTIONS.WORK_ORDERS);
    const q = query(colRef, orderBy('timestamp', 'desc'));
    const snap = await getDocs(q);
    return snap.docs.map(d => ({ id: d.id, ...d.data() } as WorkOrder));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, COLLECTIONS.WORK_ORDERS);
    return [];
  }
}

export async function saveWorkOrderToFirestore(wo: WorkOrder): Promise<WorkOrder> {
  const id = wo.id || `DMR-${Date.now()}`;
  const woWithId = cleanDataForFirestore({ ...wo, id });

  try {
    await createRecord('work_orders', woWithId);
  } catch (e) {}

  try {
    await setDoc(doc(db, COLLECTIONS.WORK_ORDERS, id), woWithId, { merge: true });
    return woWithId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `${COLLECTIONS.WORK_ORDERS}/${id}`);
    return woWithId;
  }
}

export async function deleteWorkOrderFromFirestore(woId: string): Promise<boolean> {
  try {
    await deleteRecord('work_orders', 'id', woId);
  } catch (e) {}

  try {
    await deleteDoc(doc(db, COLLECTIONS.WORK_ORDERS, woId));
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `${COLLECTIONS.WORK_ORDERS}/${woId}`);
    return true;
  }
}

// ============================================================================
// 4. MAINTENANCE RECORDS / BREAKDOWNS
// ============================================================================
export async function getMaintenanceRecordsFromFirestore(): Promise<MachineBreakdown[]> {
  try {
    const mysqlRes = await fetchRecords<MachineBreakdown>('machine_breakdowns');
    if (!mysqlRes.error && Array.isArray(mysqlRes.data) && mysqlRes.data.length > 0) {
      return mysqlRes.data;
    }
  } catch (e) {}

  try {
    const colRef = collection(db, COLLECTIONS.MAINTENANCE_RECORDS);
    const snap = await getDocs(colRef);
    return snap.docs.map(d => ({ id: d.id, ...d.data() } as MachineBreakdown));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, COLLECTIONS.MAINTENANCE_RECORDS);
    return [];
  }
}

export async function saveMaintenanceRecordToFirestore(record: MachineBreakdown): Promise<MachineBreakdown> {
  const id = record.id || record.breakdown_id || `BRK-${Date.now()}`;
  const recordWithId = cleanDataForFirestore({ ...record, id });

  try {
    await createRecord('machine_breakdowns', recordWithId);
  } catch (e) {}

  try {
    await setDoc(doc(db, COLLECTIONS.MAINTENANCE_RECORDS, id), recordWithId, { merge: true });
    return recordWithId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `${COLLECTIONS.MAINTENANCE_RECORDS}/${id}`);
    return recordWithId;
  }
}

export async function deleteMaintenanceRecordFromFirestore(recordId: string): Promise<boolean> {
  try {
    await deleteRecord('machine_breakdowns', 'id', recordId);
  } catch (e) {}

  try {
    await deleteDoc(doc(db, COLLECTIONS.MAINTENANCE_RECORDS, recordId));
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `${COLLECTIONS.MAINTENANCE_RECORDS}/${recordId}`);
    return true;
  }
}

// ============================================================================
// 5. PM SCHEDULES
// ============================================================================
export async function getPMSchedulesFromFirestore(): Promise<PMSchedule[]> {
  try {
    const mysqlRes = await fetchRecords<PMSchedule>('pm_schedules');
    if (!mysqlRes.error && Array.isArray(mysqlRes.data) && mysqlRes.data.length > 0) {
      return mysqlRes.data;
    }
  } catch (e) {}

  try {
    const colRef = collection(db, COLLECTIONS.PM_SCHEDULES);
    const snap = await getDocs(colRef);
    return snap.docs.map(d => ({ id: d.id, ...d.data() } as PMSchedule));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, COLLECTIONS.PM_SCHEDULES);
    return [];
  }
}

export async function savePMScheduleToFirestore(pm: PMSchedule): Promise<PMSchedule> {
  const id = pm.id || `PM-${Date.now()}`;
  const pmWithId = cleanDataForFirestore({ ...pm, id });

  try {
    await createRecord('pm_schedules', pmWithId);
  } catch (e) {}

  try {
    await setDoc(doc(db, COLLECTIONS.PM_SCHEDULES, id), pmWithId, { merge: true });
    return pmWithId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `${COLLECTIONS.PM_SCHEDULES}/${id}`);
    return pmWithId;
  }
}

export async function deletePMScheduleFromFirestore(pmId: string): Promise<boolean> {
  try {
    await deleteRecord('pm_schedules', 'id', pmId);
  } catch (e) {}

  try {
    await deleteDoc(doc(db, COLLECTIONS.PM_SCHEDULES, pmId));
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `${COLLECTIONS.PM_SCHEDULES}/${pmId}`);
    return true;
  }
}

// ============================================================================
// 6. ACTIVITY LOGS
// ============================================================================
export async function getActivityLogsFromFirestore(): Promise<ActivityLog[]> {
  try {
    const mysqlRes = await fetchRecords<ActivityLog>('activity_logs', { orderField: 'timestamp', ascending: false });
    if (!mysqlRes.error && Array.isArray(mysqlRes.data) && mysqlRes.data.length > 0) {
      return mysqlRes.data;
    }
  } catch (e) {}

  try {
    const colRef = collection(db, COLLECTIONS.ACTIVITY_LOGS);
    const q = query(colRef, orderBy('timestamp', 'desc'));
    const snap = await getDocs(q);
    return snap.docs.map(d => ({ id: d.id, ...d.data() } as ActivityLog));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, COLLECTIONS.ACTIVITY_LOGS);
    return [];
  }
}

export async function saveActivityLogToFirestore(log: ActivityLog): Promise<ActivityLog> {
  const id = log.id || `LOG-${Date.now()}`;
  const logWithId = cleanDataForFirestore({ ...log, id });

  try {
    await createRecord('activity_logs', logWithId);
  } catch (e) {}

  try {
    await setDoc(doc(db, COLLECTIONS.ACTIVITY_LOGS, id), logWithId);
    return logWithId;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `${COLLECTIONS.ACTIVITY_LOGS}/${id}`);
    return logWithId;
  }
}

// ============================================================================
// 7. SAFETY DOCUMENTS (JSA & PTW)
// ============================================================================
export async function getSafetyDocumentsFromFirestore(): Promise<SafetyDocument[]> {
  try {
    const mysqlRes = await fetchRecords<SafetyDocument>('safety_documents');
    if (!mysqlRes.error && Array.isArray(mysqlRes.data) && mysqlRes.data.length > 0) {
      return (mysqlRes.data as SafetyDocument[]).sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
    }
  } catch (e) {}

  try {
    const colRef = collection(db, COLLECTIONS.SAFETY_DOCUMENTS);
    const snap = await getDocs(colRef);
    const docs = snap.docs.map(d => ({ id: d.id, ...d.data() } as SafetyDocument));
    return docs.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, COLLECTIONS.SAFETY_DOCUMENTS);
    return [];
  }
}

export async function saveSafetyDocumentToFirestore(docData: SafetyDocument): Promise<SafetyDocument> {
  const id = docData.id || docData.documentNumber || `${docData.documentType || 'DOC'}-${Date.now()}`;
  const docWithId = cleanDataForFirestore({ 
    ...docData, 
    id, 
    documentNumber: docData.documentNumber || id,
    updatedAt: new Date().toISOString() 
  });

  try {
    await createRecord('safety_documents', docWithId);
  } catch (e) {}

  try {
    await setDoc(doc(db, COLLECTIONS.SAFETY_DOCUMENTS, id), docWithId, { merge: true });
    return docWithId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `${COLLECTIONS.SAFETY_DOCUMENTS}/${id}`);
    return docWithId;
  }
}

export async function deleteSafetyDocumentFromFirestore(docId: string): Promise<boolean> {
  try {
    await deleteRecord('safety_documents', 'id', docId);
  } catch (e) {}

  try {
    await deleteDoc(doc(db, COLLECTIONS.SAFETY_DOCUMENTS, docId));
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `${COLLECTIONS.SAFETY_DOCUMENTS}/${docId}`);
    return true;
  }
}

