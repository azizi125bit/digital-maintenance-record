/**
 * Local & MySQL API Client
 * Seamlessly interfaces with api.php and local fallback to avoid HTML JSON parse crashes.
 */

import { fetchRecords, createRecord, updateRecord, deleteRecord, uploadImageFile } from '../services/api';

export interface ApiResponse<T> {
  data: T | null;
  error: Error | null;
}

class LocalQueryBuilder {
  private tableName: string;
  private filters: Array<{ field: string; value: any }> = [];
  private orderField?: string;
  private ascending: boolean = true;

  constructor(tableName: string) {
    this.tableName = tableName;
  }

  select(fields = '*') {
    return this;
  }

  order(field: string, options: { ascending: boolean } = { ascending: true }) {
    this.orderField = field;
    this.ascending = options.ascending;
    return this;
  }

  eq(field: string, value: any) {
    this.filters.push({ field, value });
    return this;
  }

  async then<TResult1 = any, TResult2 = never>(
    onfulfilled?: ((value: ApiResponse<any[]>) => TResult1 | PromiseLike<TResult1>) | null,
    onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | null
  ): Promise<TResult1 | TResult2> {
    try {
      const primaryFilter = this.filters.length > 0 ? this.filters[0] : undefined;
      const res = await fetchRecords(this.tableName, {
        filterField: primaryFilter?.field,
        filterValue: primaryFilter?.value,
        orderField: this.orderField,
        ascending: this.ascending
      });

      let data = res.data || [];
      for (const f of this.filters) {
        data = data.filter((item: any) => {
          return item[f.field] === f.value || 
                 item[f.field.toLowerCase()] === f.value ||
                 (f.field === 'id' && (item.id === f.value || item.userId === f.value));
        });
      }

      const result: ApiResponse<any[]> = { data, error: res.error };
      return onfulfilled ? Promise.resolve(onfulfilled(result)) : (result as any);
    } catch (err: any) {
      const result: ApiResponse<any[]> = { data: null, error: err };
      return onfulfilled ? Promise.resolve(onfulfilled(result)) : (result as any);
    }
  }

  async insert(items: any | any[]): Promise<ApiResponse<any>> {
    try {
      const res = await createRecord(this.tableName, items);
      return { data: res.data, error: res.error };
    } catch (err: any) {
      return { data: null, error: err };
    }
  }

  update(updates: any) {
    return {
      eq: async (idField: string, idValue: any): Promise<ApiResponse<any>> => {
        try {
          const res = await updateRecord(this.tableName, idField, idValue, updates);
          return { data: res.data, error: res.error };
        } catch (err: any) {
          return { data: null, error: err };
        }
      }
    };
  }

  delete() {
    return {
      eq: async (idField: string, idValue: any): Promise<ApiResponse<any>> => {
        try {
          const res = await deleteRecord(this.tableName, idField, idValue);
          return { data: res.success, error: res.error };
        } catch (err: any) {
          return { data: null, error: err };
        }
      }
    };
  }
}

export const storageClient = {
  from(bucket: string) {
    return {
      async upload(filePath: string, file: File | Blob, options?: { upsert?: boolean; contentType?: string }) {
        try {
          const res = await uploadImageFile(bucket, file, filePath);
          if (res.error || !res.data) {
            return { data: null, error: res.error || new Error('Upload failed') };
          }
          return {
            data: {
              path: res.data.path,
              fullPath: res.data.path,
              publicUrl: res.data.publicUrl
            },
            error: null
          };
        } catch (err: any) {
          return { data: null, error: err };
        }
      },

      getPublicUrl(filePath: string) {
        if (!filePath) return { data: { publicUrl: '' } };
        if (filePath.startsWith('http://') || filePath.startsWith('https://') || filePath.startsWith('data:') || filePath.startsWith('/uploads/')) {
          return { data: { publicUrl: filePath } };
        }
        const cleanPath = filePath.replace(/^[/\\]+/, '');
        const filename = cleanPath.split('/').pop() || cleanPath;
        const publicUrl = `/uploads/${bucket}/${filename}`;
        return {
          data: {
            publicUrl
          }
        };
      },

      async remove(paths: string[]) {
        return { data: true, error: null };
      }
    };
  }
};

export const localDbClient = {
  from(tableName: string) {
    return new LocalQueryBuilder(tableName);
  },
  storage: storageClient,
  channel(name: string) {
    return {
      on(event: string, opts: any, callback: () => void) {
        return this;
      },
      subscribe() {
        return this;
      }
    };
  },
  removeChannel(ch: any) {}
};

export const supabase = localDbClient;
