/**
 * Digital Maintenance Records (DMR) - MySQL & PHP API Service
 * 
 * Provides robust communication with InfinityFree PHP backend (api.php)
 * Handles responses safely to prevent "Unexpected token '<', '<html>...' is not valid JSON" errors.
 */

// Base endpoint for InfinityFree PHP API
const API_URL = '/api.php';

/**
 * Safely parse JSON from a fetch Response, protecting against HTML 404/500 error pages
 */
async function safeParseResponse(res: Response): Promise<{ data: any; error: string | null }> {
  const contentType = res.headers.get('content-type') || '';
  const isJson = contentType.includes('application/json');

  if (!isJson) {
    const text = await res.text();
    // Detect HTML response (e.g., Apache 404/500 default error page)
    if (text.trim().startsWith('<') || text.includes('<html') || text.includes('<!DOCTYPE')) {
      return {
        data: null,
        error: `Server returned HTML (${res.status} ${res.statusText}) instead of JSON. Ensure api.php and MySQL are configured in config.php.`
      };
    }
    try {
      const parsed = JSON.parse(text);
      return { data: parsed, error: null };
    } catch {
      return { data: null, error: text || `HTTP ${res.status} ${res.statusText}` };
    }
  }

  try {
    const json = await res.json();
    return { data: json, error: json.error || null };
  } catch (err: any) {
    return { data: null, error: err?.message || 'Failed to parse JSON response' };
  }
}

/**
 * Perform safe HTTP GET or POST request to api.php
 */
async function requestApi(endpoint: string, options: RequestInit = {}): Promise<{ success: boolean; data: any; error: any }> {
  try {
    const headers: Record<string, string> = {
      'Accept': 'application/json',
      ...(options.headers as Record<string, string> || {})
    };

    const res = await fetch(endpoint, {
      ...options,
      headers
    });

    const parsed = await safeParseResponse(res);

    if (!res.ok || parsed.error) {
      return {
        success: false,
        data: parsed.data?.data || null,
        error: new Error(parsed.error || `HTTP ${res.status} error from API`)
      };
    }

    return {
      success: true,
      data: parsed.data?.data !== undefined ? parsed.data.data : parsed.data,
      error: null
    };
  } catch (err: any) {
    return {
      success: false,
      data: null,
      error: err instanceof Error ? err : new Error(String(err))
    };
  }
}

/**
 * Fetch records from MySQL via api.php (GET)
 */
export async function fetchRecords<T = any>(
  resource: string, 
  params: { id?: string; filterField?: string; filterValue?: any; orderField?: string; ascending?: boolean } = {}
): Promise<{ data: T[]; error: any }> {
  const query = new URLSearchParams();
  query.set('resource', resource);
  query.set('action', 'list');

  if (params.id) query.set('id', params.id);
  if (params.filterField) query.set('filterField', params.filterField);
  if (params.filterValue !== undefined && params.filterValue !== null) query.set('filterValue', String(params.filterValue));
  if (params.orderField) query.set('orderField', params.orderField);
  if (params.ascending !== undefined) query.set('ascending', String(params.ascending));

  const result = await requestApi(`${API_URL}?${query.toString()}`, { method: 'GET' });

  if (!result.success || !Array.isArray(result.data)) {
    return { data: [], error: result.error };
  }

  return { data: result.data as T[], error: null };
}

/**
 * Create or insert record into MySQL via api.php (POST)
 */
export async function createRecord<T = any>(resource: string, data: any): Promise<{ data: T | null; error: any }> {
  const result = await requestApi(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      resource,
      action: 'create',
      data
    })
  });

  return { data: result.data as T, error: result.error };
}

/**
 * Update record in MySQL via api.php (POST with action: "update")
 */
export async function updateRecord<T = any>(
  resource: string, 
  idField: string, 
  idValue: any, 
  updates: any
): Promise<{ data: T | null; error: any }> {
  const result = await requestApi(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      resource,
      action: 'update',
      idField,
      idValue,
      data: updates
    })
  });

  return { data: result.data as T, error: result.error };
}

/**
 * Delete record from MySQL via api.php (POST with action: "delete")
 */
export async function deleteRecord(
  resource: string, 
  idField: string, 
  idValue: any
): Promise<{ success: boolean; error: any }> {
  const result = await requestApi(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      resource,
      action: 'delete',
      idField,
      idValue
    })
  });

  return { success: result.success, error: result.error };
}

/**
 * Upload image file to server (POST to api.php with action: "upload_image")
 * Encodes file as Base64 to ensure seamless upload without multipart mime issues on shared hosts
 */
export async function uploadImageFile(
  bucket: string, 
  file: File | Blob, 
  path?: string
): Promise<{ data: { publicUrl: string; path: string } | null; error: any }> {
  let base64Data = '';
  const fileName = path || (file instanceof File ? file.name : `img_${Date.now()}.jpg`);
  
  try {
    base64Data = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });

    const result = await requestApi(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'upload_image',
        bucket,
        fileBase64: base64Data,
        path: fileName
      })
    });

    if (result.success && result.data?.publicUrl) {
      return {
        data: {
          publicUrl: result.data.publicUrl,
          path: result.data.path || fileName
        },
        error: null
      };
    }

    // Seamless fallback to base64 data URL if server upload returned HTML / not configured
    return {
      data: {
        publicUrl: base64Data,
        path: fileName
      },
      error: null
    };
  } catch (err: any) {
    if (base64Data) {
      return {
        data: {
          publicUrl: base64Data,
          path: fileName
        },
        error: null
      };
    }
    return { data: null, error: err };
  }
}

/**
 * Authenticate staff user via api.php
 */
export async function loginStaff(username: string, pin: string): Promise<{ user: any | null; error: any }> {
  const result = await requestApi(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'login',
      username,
      pin
    })
  });

  if (!result.success || !result.data?.user) {
    return { user: null, error: result.error || new Error('Authentication failed') };
  }

  return { user: result.data.user, error: null };
}

/**
 * Ping backend to check if PHP & MySQL are responsive
 */
export async function checkBackendStatus(): Promise<{ online: boolean; message: string }> {
  try {
    const res = await fetch(`${API_URL}?action=status`, { headers: { Accept: 'application/json' } });
    const parsed = await safeParseResponse(res);
    if (res.ok && parsed.data?.success) {
      return { online: true, message: 'MySQL backend connected' };
    }
    return { online: false, message: parsed.error || 'Backend unreachable' };
  } catch (e: any) {
    return { online: false, message: e.message || 'Offline' };
  }
}
