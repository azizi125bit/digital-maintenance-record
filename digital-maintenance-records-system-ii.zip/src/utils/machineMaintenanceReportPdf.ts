import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Asset } from '../types';
import { UnifiedMaintenanceRecord } from '../components/MaintenanceRecordsView';

export interface MachineReportSectionOptions {
  machineInfo: boolean;
  maintenanceSummary: boolean;
  maintenanceHistory: boolean;
  preventiveMaintenance: boolean;
  correctiveMaintenance: boolean;
  checklist: boolean;
  measurements: boolean;
  technicianTools: boolean;
  findingsActions: boolean;
  downtimeSummary: boolean;
  verification: boolean;
}

export interface GenerateMachineReportPdfOptions {
  asset: Asset;
  records: UnifiedMaintenanceRecord[];
  periodLabel: string;
  dateFrom?: string;
  dateTo?: string;
  sections: MachineReportSectionOptions;
  companyName?: string;
  printMode?: boolean;
}

/**
 * Format date nicely for physical documentation (e.g. 2026-10-15)
 */
function formatDate(d?: string | Date | null): string {
  if (!d) return 'N/A';
  try {
    const dateObj = typeof d === 'string' ? new Date(d) : d;
    if (isNaN(dateObj.getTime())) return String(d).split('T')[0];
    return dateObj.toISOString().split('T')[0];
  } catch {
    return String(d);
  }
}

/**
 * Safely load an image URL into a base64 Data URL with width/height
 */
async function loadBase64Image(url?: string): Promise<{ dataUrl: string; width: number; height: number } | null> {
  if (!url || typeof window === 'undefined') return null;
  return new Promise((resolve) => {
    try {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = img.naturalWidth || img.width;
          canvas.height = img.naturalHeight || img.height;
          const ctx = canvas.getContext('2d');
          if (!ctx) { resolve(null); return; }
          ctx.drawImage(img, 0, 0);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
          resolve({ dataUrl, width: img.naturalWidth || img.width, height: img.naturalHeight || img.height });
        } catch {
          resolve(null);
        }
      };
      img.onerror = () => resolve(null);
      img.src = url;
    } catch {
      resolve(null);
    }
  });
}

/**
 * Clean plain text for PDF export, stripping HTML entities and unprintable symbols
 */
function cleanPdfText(text: any, fallback: string = ''): string {
  if (text === undefined || text === null) return fallback;
  let str = String(text);
  str = str.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
  str = str.replace(/&[#a-zA-Z0-9]+;/g, ' ');
  str = str.replace(/[\u25A0-\u26FF\u2700-\u27BF]/g, '').trim();
  return str || fallback;
}

export async function generateMachineMaintenanceReportPDF(options: GenerateMachineReportPdfOptions): Promise<void> {
  const {
    asset,
    records = [],
    periodLabel,
    sections,
    companyName = 'DIGITAL MAINTENANCE RECORDS SYSTEM (DMR)',
    printMode = false
  } = options;

  // Initialize jsPDF A4 portrait
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210 mm
  const pageHeight = doc.internal.pageSize.getHeight(); // 297 mm
  const marginX = 12;
  const contentWidth = pageWidth - marginX * 2; // 186 mm
  const bottomMargin = 16;

  // Industrial Color Palette (inspired by professional technical documentation)
  const cSlate950: [number, number, number] = [2, 6, 23];
  const cSlate900: [number, number, number] = [15, 23, 42];
  const cSlate800: [number, number, number] = [30, 41, 59];
  const cSlate700: [number, number, number] = [51, 65, 85];
  const cSlate500: [number, number, number] = [100, 116, 139];
  const cSlate300: [number, number, number] = [203, 213, 225];
  const cSlate100: [number, number, number] = [241, 245, 249];
  const cSlate50: [number, number, number] = [248, 250, 252];
  const cPrimaryBlue: [number, number, number] = [2, 132, 199];
  const cEmerald: [number, number, number] = [16, 185, 129];
  const cAmber: [number, number, number] = [217, 119, 6];

  const now = new Date();
  const dateGenerated = `${formatDate(now)} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  const reportRef = `MMR-${asset.id || 'ASSET'}-${Date.now().toString().slice(-6)}`;

  // Pre-load asset photo if available
  const photoUrl = asset.photoUrl || asset.machine_photo;
  const loadedImage = await loadBase64Image(photoUrl);

  let currentY = 10;

  // =========================================================================
  // 1. TOP HEADER ACCENT BARS & TITLES
  // =========================================================================
  doc.setFillColor(...cSlate900);
  doc.rect(marginX, currentY, contentWidth, 3, 'F');
  doc.setFillColor(...cPrimaryBlue);
  doc.rect(marginX, currentY + 3, contentWidth, 1, 'F');
  currentY += 6;

  // Header Title Area
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(...cSlate900);
  doc.text(companyName.toUpperCase(), marginX, currentY + 2);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(...cSlate500);
  doc.text('Industrial Plant CMMS • Technical Equipment Maintenance & Condition Report', marginX, currentY + 6);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(...cSlate900);
  doc.text('MACHINE MAINTENANCE REPORT', marginX, currentY + 14);

  // Metadata Box on Right Side
  const metaBoxX = 126;
  const metaBoxY = currentY - 2;
  const metaBoxW = contentWidth - (metaBoxX - marginX);
  const metaBoxH = 18;

  doc.setFillColor(...cSlate50);
  doc.setDrawColor(...cSlate300);
  doc.setLineWidth(0.2);
  doc.rect(metaBoxX, metaBoxY, metaBoxW, metaBoxH, 'FD');

  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...cSlate500);
  doc.text('REPORT REFERENCE:', metaBoxX + 2.5, metaBoxY + 4);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...cSlate900);
  doc.text(reportRef, metaBoxX + 30, metaBoxY + 4);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...cSlate500);
  doc.text('DATE GENERATED:', metaBoxX + 2.5, metaBoxY + 8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...cSlate900);
  doc.text(dateGenerated, metaBoxX + 30, metaBoxY + 8);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...cSlate500);
  doc.text('REPORTING PERIOD:', metaBoxX + 2.5, metaBoxY + 12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...cPrimaryBlue);
  doc.text(periodLabel, metaBoxX + 30, metaBoxY + 12);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...cSlate500);
  doc.text('ASSET ID / NAME:', metaBoxX + 2.5, metaBoxY + 16);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...cSlate900);
  const truncatedMachineStr = `${asset.id} • ${asset.name}`.slice(0, 32);
  doc.text(truncatedMachineStr, metaBoxX + 30, metaBoxY + 16);

  currentY += 21;

  // Thin separator line
  doc.setDrawColor(...cSlate300);
  doc.setLineWidth(0.25);
  doc.line(marginX, currentY, marginX + contentWidth, currentY);
  currentY += 4;

  // =========================================================================
  // 2. SECTION: MACHINE INFORMATION (FLIR-style side-by-side Technical Box)
  // =========================================================================
  if (sections.machineInfo) {
    // Section Header
    doc.setFillColor(...cSlate100);
    doc.rect(marginX, currentY, contentWidth, 5.5, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(...cSlate900);
    doc.text('1.0 MACHINE SPECIFICATIONS & ASSET IDENTIFICATION', marginX + 3, currentY + 3.8);
    currentY += 7;

    const infoBoxW = loadedImage ? 122 : contentWidth;
    const photoBoxW = loadedImage ? 60 : 0;
    const photoBoxX = marginX + infoBoxW + 4;
    const infoBoxH = 44;

    // Technical Specs Grid (Bordered table style)
    const specRows = [
      ['Machine Name', asset.name || 'N/A', 'Asset ID', asset.id || 'N/A'],
      ['Serial Number', asset.serialNumber || 'Not Available', 'Current Status', asset.status || 'Operational'],
      ['Manufacturer', asset.manufacturer || 'Not Available', 'Model', asset.model || 'Not Available'],
      ['Machine Type', asset.machineType || asset.category || 'Production Asset', 'Criticality', asset.criticality || 'Medium'],
      ['Department', asset.department || 'Not Available', 'Location', asset.location || 'Workshop'],
      ['Installation Date', formatDate(asset.installationDate), 'Next PM Date', formatDate(asset.nextMaintenanceDate)]
    ];

    autoTable(doc, {
      startY: currentY,
      margin: { left: marginX, right: loadedImage ? pageWidth - (marginX + infoBoxW) : marginX },
      tableWidth: infoBoxW,
      body: specRows,
      theme: 'grid',
      styles: {
        fontSize: 7,
        cellPadding: 1.5,
        textColor: cSlate900,
        lineColor: cSlate300,
        lineWidth: 0.15
      },
      columnStyles: loadedImage ? {
        0: { fontStyle: 'bold', fillColor: cSlate50, textColor: cSlate700, cellWidth: 26 },
        1: { cellWidth: 34 },
        2: { fontStyle: 'bold', fillColor: cSlate50, textColor: cSlate700, cellWidth: 26 },
        3: { cellWidth: 34 }
      } : {
        0: { fontStyle: 'bold', fillColor: cSlate50, textColor: cSlate700, cellWidth: 32 },
        1: { cellWidth: 61 },
        2: { fontStyle: 'bold', fillColor: cSlate50, textColor: cSlate700, cellWidth: 32 },
        3: { cellWidth: 61 }
      }
    });

    // Machine Photo on Right Side
    if (loadedImage) {
      doc.setDrawColor(...cSlate300);
      doc.setLineWidth(0.2);
      doc.setFillColor(...cSlate50);
      doc.rect(photoBoxX, currentY, photoBoxW, infoBoxH, 'FD');

      // Center and scale image properly without stretching
      const maxW = photoBoxW - 4;
      const maxH = infoBoxH - 8;
      const imgRatio = loadedImage.width / loadedImage.height;
      let renderW = maxW;
      let renderH = maxW / imgRatio;

      if (renderH > maxH) {
        renderH = maxH;
        renderW = maxH * imgRatio;
      }

      const imgX = photoBoxX + (photoBoxW - renderW) / 2;
      const imgY = currentY + 2;

      try {
        doc.addImage(loadedImage.dataUrl, 'JPEG', imgX, imgY, renderW, renderH);
      } catch (err) {
        console.warn('Failed rendering asset image in PDF:', err);
      }

      // Photo caption bar
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6);
      doc.setTextColor(...cSlate500);
      doc.text(`FIG 1.0: ${asset.id} VISUAL RECORD`, photoBoxX + 3, currentY + infoBoxH - 2);
    }

    currentY += infoBoxH + 3;
  }

  // =========================================================================
  // 3. SECTION: MAINTENANCE EXECUTIVE SUMMARY & DOWNTIME METRICS
  // =========================================================================
  if (sections.maintenanceSummary) {
    // Check page space
    if (currentY > pageHeight - 50) {
      doc.addPage();
      currentY = 16;
    }

    doc.setFillColor(...cSlate100);
    doc.rect(marginX, currentY, contentWidth, 5.5, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(...cSlate900);
    doc.text('2.0 MAINTENANCE EXECUTIVE SUMMARY & DOWNTIME METRICS', marginX + 3, currentY + 3.8);
    currentY += 7;

    // Calculate real stats without double counting
    const totalRecords = records.length;
    const pmRecords = records.filter(r => r.recordType === 'Preventive Maintenance');
    const cmRecords = records.filter(r => r.recordType === 'Corrective Maintenance' || r.recordType === 'General');
    const breakdownRecords = records.filter(r => r.recordType === 'Breakdown Repair');
    
    // Machine downtime (distinguished from labour hours)
    const totalDowntime = records.reduce((acc, r) => acc + (Number(r.downtimeHours) || 0), 0);
    const completedBreakdowns = breakdownRecords.filter(r => 
      r.status.toLowerCase() === 'completed' || r.status.toLowerCase() === 'closed' || r.status.toLowerCase() === 'resolved'
    );
    const completedBreakdownDowntime = completedBreakdowns.reduce((acc, r) => acc + (Number(r.downtimeHours) || 0), 0);
    const avgDowntime = completedBreakdowns.length > 0 
      ? (completedBreakdownDowntime / completedBreakdowns.length).toFixed(1)
      : '0.0';

    const completedJobs = records.filter(r => 
      r.status.toLowerCase() === 'completed' || r.status.toLowerCase() === 'closed' || r.status.toLowerCase() === 'verified'
    ).length;
    const pendingJobs = totalRecords - completedJobs;

    // 8 KPI Summary Box
    const kpiData = [
      [
        'Total Maintenance Records', `${totalRecords}`,
        'Preventive Maintenance (PM)', `${pmRecords.length}`,
        'Corrective Maintenance (CM)', `${cmRecords.length}`,
        'Breakdown Incidents', `${breakdownRecords.length}`
      ],
      [
        'Total Machine Downtime', `${totalDowntime.toFixed(1)} Hours`,
        'Avg Downtime / Completed Breakdown', `${avgDowntime} Hours`,
        'Completed Interventions', `${completedJobs}`,
        'Pending / Open Tasks', `${pendingJobs}`
      ]
    ];

    autoTable(doc, {
      startY: currentY,
      margin: { left: marginX, right: marginX },
      body: kpiData,
      theme: 'grid',
      styles: {
        fontSize: 7,
        cellPadding: 2,
        textColor: cSlate900,
        lineColor: cSlate300,
        lineWidth: 0.15
      },
      columnStyles: {
        0: { fontStyle: 'bold', fillColor: cSlate50, textColor: cSlate700, cellWidth: 32 },
        1: { fontStyle: 'bold', textColor: cPrimaryBlue, cellWidth: 14.5 },
        2: { fontStyle: 'bold', fillColor: cSlate50, textColor: cSlate700, cellWidth: 32 },
        3: { fontStyle: 'bold', textColor: cEmerald, cellWidth: 14.5 },
        4: { fontStyle: 'bold', fillColor: cSlate50, textColor: cSlate700, cellWidth: 32 },
        5: { fontStyle: 'bold', textColor: cAmber, cellWidth: 14.5 },
        6: { fontStyle: 'bold', fillColor: cSlate50, textColor: cSlate700, cellWidth: 32 },
        7: { fontStyle: 'bold', textColor: cSlate900, cellWidth: 14.5 }
      }
    });

    const lastTable: any = (doc as any).lastAutoTable;
    currentY = (lastTable?.finalY || currentY + 16) + 2;

    // Technical distinction notice
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(6);
    doc.setTextColor(...cSlate500);
    doc.text('* Machine Downtime reflects cumulative physical equipment availability interruption, calculated distinct from technician labour hours.', marginX, currentY);
    currentY += 4;
  }

  // =========================================================================
  // 4. SECTION: MAINTENANCE HISTORY LOG TABLE
  // =========================================================================
  if (sections.maintenanceHistory) {
    if (currentY > pageHeight - 50) {
      doc.addPage();
      currentY = 16;
    }

    doc.setFillColor(...cSlate100);
    doc.rect(marginX, currentY, contentWidth, 5.5, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(...cSlate900);
    doc.text('3.0 MAINTENANCE HISTORY LOG', marginX + 3, currentY + 3.8);
    currentY += 7;

    const tableHeaders = [
      ['No.', 'Date', 'WO ID', 'Type', 'Technician', 'Problem / Job Description', 'Findings', 'Action Taken', 'Downtime', 'Status']
    ];

    const tableRows = records.length > 0 ? records.map((rec, idx) => {
      const formattedDate = formatDate(rec.date);
      const woId = rec.workOrderId || rec.id || 'N/A';
      const desc = cleanPdfText(rec.maintenanceDescription || 'Maintenance routine', 'Maintenance routine');
      const findings = cleanPdfText(rec.findings || 'No anomalies found', 'No anomalies found');
      const action = cleanPdfText(rec.actionTaken || 'Inspected and serviced', 'Inspected and serviced');
      const downtimeStr = rec.downtimeHours ? `${rec.downtimeHours}h` : '0h';
      
      return [
        String(idx + 1),
        formattedDate,
        woId,
        rec.recordType,
        cleanPdfText(rec.technician, 'Technician'),
        desc.length > 50 ? `${desc.slice(0, 48)}...` : desc,
        findings.length > 50 ? `${findings.slice(0, 48)}...` : findings,
        action.length > 50 ? `${action.slice(0, 48)}...` : action,
        downtimeStr,
        rec.status
      ];
    }) : [
      ['-', '-', '-', '-', '-', 'No maintenance records found for the selected reporting period.', '-', '-', '-', '-']
    ];

    autoTable(doc, {
      startY: currentY,
      head: tableHeaders,
      body: tableRows,
      theme: 'grid',
      margin: { left: marginX, right: marginX, bottom: bottomMargin },
      tableWidth: contentWidth,
      headStyles: {
        fillColor: cSlate900,
        textColor: [255, 255, 255],
        fontSize: 6.5,
        fontStyle: 'bold',
        cellPadding: 1.5,
        halign: 'left'
      },
      styles: {
        fontSize: 6,
        cellPadding: 1.5,
        textColor: cSlate900,
        lineColor: cSlate300,
        lineWidth: 0.15,
        overflow: 'linebreak'
      },
      columnStyles: {
        0: { cellWidth: 7, halign: 'center' },
        1: { cellWidth: 16 },
        2: { cellWidth: 18, fontStyle: 'bold', textColor: cPrimaryBlue },
        3: { cellWidth: 22 },
        4: { cellWidth: 18 },
        8: { cellWidth: 12, halign: 'center' },
        9: { cellWidth: 14, halign: 'center', fontStyle: 'bold' }
      },
      alternateRowStyles: {
        fillColor: cSlate50
      }
    });

    const lastTable: any = (doc as any).lastAutoTable;
    currentY = (lastTable?.finalY || currentY + 20) + 5;
  }

  // =========================================================================
  // 5. SECTION: DETAILED PM & CM RECORDS (Checklists, Measurements, Tools)
  // =========================================================================
  if (sections.preventiveMaintenance || sections.correctiveMaintenance || sections.checklist || sections.measurements) {
    const pmItemsWithChecklists = records.filter(r => r.recordType === 'Preventive Maintenance' && Array.isArray(r.checklist) && r.checklist.length > 0);
    const pmItemsWithMeasurements = records.filter(r => r.recordType === 'Preventive Maintenance' && Array.isArray(r.measurements) && r.measurements.length > 0);
    const breakdownDetails = records.filter(r => r.recordType === 'Breakdown Repair' || r.recordType === 'Corrective Maintenance');

    if (pmItemsWithChecklists.length > 0 || pmItemsWithMeasurements.length > 0 || breakdownDetails.length > 0) {
      if (currentY > pageHeight - 60) {
        doc.addPage();
        currentY = 16;
      }

      doc.setFillColor(...cSlate100);
      doc.rect(marginX, currentY, contentWidth, 5.5, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(...cSlate900);
      doc.text('4.0 DETAILED MAINTENANCE INSPECTION, CHECKLIST & INTERVENTIONS', marginX + 3, currentY + 3.8);
      currentY += 8;

      // 4.1 Preventive Maintenance Checklists
      if (sections.checklist && pmItemsWithChecklists.length > 0) {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7.5);
        doc.setTextColor(...cSlate700);
        doc.text('4.1 PREVENTIVE MAINTENANCE CHECKLIST VERIFICATION', marginX, currentY);
        currentY += 3;

        const latestPmWithChecklist = pmItemsWithChecklists[0];
        const clRows = (latestPmWithChecklist.checklist || []).map((c, i) => [
          String(i + 1),
          cleanPdfText(c.task, `Task ${i + 1}`),
          c.status || (c.completed ? 'OK' : 'Not OK'),
          cleanPdfText(c.remarks || 'Standard verified', 'Standard verified')
        ]);

        autoTable(doc, {
          startY: currentY,
          head: [['Item #', 'Inspection Task / Verification Item', 'Result', 'Technician Remarks']],
          body: clRows,
          theme: 'grid',
          margin: { left: marginX, right: marginX, bottom: bottomMargin },
          headStyles: {
            fillColor: cSlate800,
            textColor: [255, 255, 255],
            fontSize: 6.5,
            cellPadding: 1.5
          },
          styles: {
            fontSize: 6,
            cellPadding: 1.5,
            textColor: cSlate900,
            lineColor: cSlate300,
            lineWidth: 0.15
          },
          columnStyles: {
            0: { cellWidth: 12, halign: 'center' },
            1: { cellWidth: 95 },
            2: { cellWidth: 20, halign: 'center', fontStyle: 'bold' },
            3: { cellWidth: 59 }
          }
        });

        const lastTable: any = (doc as any).lastAutoTable;
        currentY = (lastTable?.finalY || currentY + 20) + 5;
      }

      // 4.2 Technical Measurements
      if (sections.measurements && pmItemsWithMeasurements.length > 0) {
        if (currentY > pageHeight - 45) {
          doc.addPage();
          currentY = 16;
        }

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7.5);
        doc.setTextColor(...cSlate700);
        doc.text('4.2 RECORDED PARAMETER MEASUREMENTS', marginX, currentY);
        currentY += 3;

        const latestPmWithMeasurements = pmItemsWithMeasurements[0];
        const mRows = (latestPmWithMeasurements.measurements || []).map(m => [
          cleanPdfText(m.parameter, 'Parameter'),
          cleanPdfText(m.standard, 'Standard Limit'),
          cleanPdfText(m.reading, 'N/A'),
          cleanPdfText(m.unit, '-'),
          cleanPdfText(m.status, 'Normal')
        ]);

        autoTable(doc, {
          startY: currentY,
          head: [['Parameter', 'Standard Limit', 'Actual Reading', 'Unit', 'Status']],
          body: mRows,
          theme: 'grid',
          margin: { left: marginX, right: marginX, bottom: bottomMargin },
          headStyles: {
            fillColor: cSlate800,
            textColor: [255, 255, 255],
            fontSize: 6.5,
            cellPadding: 1.5
          },
          styles: {
            fontSize: 6,
            cellPadding: 1.5,
            textColor: cSlate900,
            lineColor: cSlate300,
            lineWidth: 0.15
          },
          columnStyles: {
            0: { cellWidth: 50 },
            1: { cellWidth: 40 },
            2: { cellWidth: 35, fontStyle: 'bold' },
            3: { cellWidth: 25 },
            4: { cellWidth: 36, fontStyle: 'bold', halign: 'center' }
          }
        });

        const lastTable: any = (doc as any).lastAutoTable;
        currentY = (lastTable?.finalY || currentY + 20) + 5;
      }

      // 4.3 Corrective Maintenance & Breakdown Interventions
      if (sections.correctiveMaintenance && breakdownDetails.length > 0) {
        if (currentY > pageHeight - 45) {
          doc.addPage();
          currentY = 16;
        }

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7.5);
        doc.setTextColor(...cSlate700);
        doc.text('4.3 CORRECTIVE REPAIR & BREAKDOWN RESTORATION DETAILS', marginX, currentY);
        currentY += 3;

        const bdRows = breakdownDetails.slice(0, 5).map(b => [
          b.workOrderId || b.id,
          formatDate(b.date),
          cleanPdfText(b.findings, 'Breakdown reported'),
          cleanPdfText(b.actionTaken, 'Restored to service'),
          cleanPdfText(b.partsUsed, 'None recorded'),
          b.downtimeHours ? `${b.downtimeHours}h` : '0h'
        ]);

        autoTable(doc, {
          startY: currentY,
          head: [['Ref / WO ID', 'Incident Date', 'Root Cause / Findings', 'Repair Action Taken', 'Parts / Materials', 'Downtime']],
          body: bdRows,
          theme: 'grid',
          margin: { left: marginX, right: marginX, bottom: bottomMargin },
          headStyles: {
            fillColor: cSlate800,
            textColor: [255, 255, 255],
            fontSize: 6.5,
            cellPadding: 1.5
          },
          styles: {
            fontSize: 6,
            cellPadding: 1.5,
            textColor: cSlate900,
            lineColor: cSlate300,
            lineWidth: 0.15
          },
          columnStyles: {
            0: { cellWidth: 20, fontStyle: 'bold', textColor: cPrimaryBlue },
            1: { cellWidth: 20 },
            2: { cellWidth: 45 },
            3: { cellWidth: 50 },
            4: { cellWidth: 35 },
            5: { cellWidth: 16, halign: 'center' }
          }
        });

        const lastTable: any = (doc as any).lastAutoTable;
        currentY = (lastTable?.finalY || currentY + 20) + 5;
      }
    }
  }

  // =========================================================================
  // 6. SECTION: VERIFICATION, QUALITY AUDIT & APPROVAL
  // =========================================================================
  if (sections.verification) {
    if (currentY > pageHeight - 45) {
      doc.addPage();
      currentY = 16;
    }

    doc.setFillColor(...cSlate100);
    doc.rect(marginX, currentY, contentWidth, 5.5, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(...cSlate900);
    doc.text('5.0 VERIFICATION, QUALITY AUDIT & SIGN-OFF', marginX + 3, currentY + 3.8);
    currentY += 7;

    const signoffW = contentWidth;
    const signoffH = 28;

    doc.setFillColor(...cSlate50);
    doc.setDrawColor(...cSlate300);
    doc.setLineWidth(0.2);
    doc.rect(marginX, currentY, signoffW, signoffH, 'FD');

    // Split sign-off box into two columns
    const colMid = marginX + signoffW / 2;
    doc.line(colMid, currentY, colMid, currentY + signoffH);

    // Left Column: Verifier Information
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.setTextColor(...cSlate700);
    doc.text('TECHNICAL VERIFICATION & INSPECTION AUDIT', marginX + 3, currentY + 5);

    const firstVerifiedRecord = records.find(r => r.supervisor && r.verificationStatus === 'Verified') || records[0];
    const supervisorName = firstVerifiedRecord?.supervisor || 'Maintenance Supervisor';
    const verificationDateStr = formatDate(firstVerifiedRecord?.verificationDate || now);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(...cSlate500);
    doc.text('VERIFIED BY:', marginX + 3, currentY + 10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...cSlate900);
    doc.text(supervisorName, marginX + 28, currentY + 10);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...cSlate500);
    doc.text('VERIFICATION DATE:', marginX + 3, currentY + 14);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...cSlate900);
    doc.text(verificationDateStr, marginX + 28, currentY + 14);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...cSlate500);
    doc.text('AUDIT REMARKS:', marginX + 3, currentY + 18);
    doc.setFont('helvetica', 'italic');
    doc.setTextColor(...cSlate700);
    doc.text('All scheduled and corrective interventions confirmed according to engineering standards.', marginX + 28, currentY + 18, { maxWidth: (signoffW / 2) - 32 });

    // Right Column: Official Authorization Sign-off
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.setTextColor(...cSlate700);
    doc.text('FORMAL MANAGEMENT / SAFETY AUTHORIZATION', colMid + 3, currentY + 5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(...cSlate500);
    doc.text('AUTHORIZATION STATUS:', colMid + 3, currentY + 10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...cEmerald);
    doc.text('APPROVED & RECORDED IN CMMS DATABASE', colMid + 36, currentY + 10);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...cSlate500);
    doc.text('AUTHORIZED SIGNATURE:', colMid + 3, currentY + 16);
    
    // Dotted Signature Line
    doc.setDrawColor(...cSlate300);
    doc.setLineDashPattern([1, 1], 0);
    doc.line(colMid + 36, currentY + 22, colMid + (signoffW / 2) - 5, currentY + 22);
    doc.setLineDashPattern([], 0); // reset

    doc.setFontSize(5.5);
    doc.setTextColor(...cSlate500);
    doc.text('(Authorized Plant Engineer / Maintenance Manager)', colMid + 36, currentY + 25);

    currentY += signoffH + 6;
  }

  // =========================================================================
  // 7. RUNNING FOOTER & PAGE NUMBERING (Page X of Y)
  // =========================================================================
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);

    // Top running header on pages 2+
    if (i > 1) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(6.5);
      doc.setTextColor(...cSlate500);
      doc.text(`MACHINE MAINTENANCE REPORT • ${asset.id} - ${asset.name}`, marginX, 8);
      doc.text(`REF: ${reportRef}`, marginX + contentWidth - 25, 8);
      doc.setDrawColor(...cSlate300);
      doc.setLineWidth(0.15);
      doc.line(marginX, 9.5, marginX + contentWidth, 9.5);
    }

    // Bottom running footer
    doc.setDrawColor(...cSlate300);
    doc.setLineWidth(0.15);
    doc.line(marginX, pageHeight - bottomMargin + 4, marginX + contentWidth, pageHeight - bottomMargin + 4);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6);
    doc.setTextColor(...cSlate500);
    doc.text('CONFIDENTIAL • DIGITAL MAINTENANCE RECORDS SYSTEM (DMR) • ALL RIGHTS RESERVED', marginX, pageHeight - bottomMargin + 8);
    
    doc.setFont('helvetica', 'bold');
    doc.text(`PAGE ${i} OF ${totalPages}`, marginX + contentWidth - 18, pageHeight - bottomMargin + 8);
  }

  // Download or Launch Print
  if (printMode) {
    // Open in print-friendly tab or trigger print
    doc.autoPrint();
    const pdfBlob = doc.output('blob');
    const blobUrl = URL.createObjectURL(pdfBlob);
    const printWindow = window.open(blobUrl);
    if (printWindow) {
      printWindow.onload = () => {
        printWindow.print();
      };
    }
  } else {
    // Download PDF directly
    const filename = `DMR_Machine_Report_${asset.id || 'ASSET'}_${formatDate(now)}.pdf`;
    doc.save(filename);
  }
}
