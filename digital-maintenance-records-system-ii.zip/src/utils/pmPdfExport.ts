import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { supabase } from '../lib/supabase';
import { Asset, PMSchedule, Personnel, WorkOrder } from '../types';

export interface GeneratePMPdfOptions {
  pmSchedule?: any;
  scheduleId?: string;
  printMode?: boolean;
  asset?: Asset | null;
  technician?: Personnel | null;
  workOrder?: WorkOrder | null;
  staffList?: Personnel[];
  companyName?: string;
}

/**
 * Format date nicely for physical documentation (e.g. 2026-10-04)
 */
function formatDate(d?: string | Date | null): string {
  if (!d) return 'N/A';
  try {
    const dateObj = typeof d === 'string' ? new Date(d) : d;
    if (isNaN(dateObj.getTime())) return String(d).split('T')[0];
    return dateObj.toISOString().split('T')[0];
  } catch {
    return String(d);
  }
}

/**
 * Calculate total downtime string between start and end timestamps or fallback
 */
function calculateDowntime(start?: string | null, end?: string | null, fallbackHours?: number | string | null): string {
  if (start && end) {
    const s = new Date(start).getTime();
    const e = new Date(end).getTime();
    if (!isNaN(s) && !isNaN(e) && e >= s) {
      const diffHrs = (e - s) / (1000 * 60 * 60);
      return `${diffHrs.toFixed(1)} Hours`;
    }
  }
  if (fallbackHours !== undefined && fallbackHours !== null && fallbackHours !== '') {
    const num = Number(fallbackHours);
    if (!isNaN(num) && num > 0) {
      return `${num.toFixed(1)} Hours`;
    }
  }
  return 'No downtime recorded.';
}

/**
 * Clean & normalize checklist status to Option A (Recommended): OK, Not OK, N/A
 * Strips HTML entities (&nbsp;, &amp;, etc.) and unprintable unicode glyphs (☐, ☑, etc.)
 */
export function normalizeChecklistStatus(raw: any, defaultStatus: string = 'OK'): string {
  if (raw === undefined || raw === null) return defaultStatus;
  let str = String(raw).trim();
  // Strip HTML entities (&nbsp;, &#9744;, &amp;, etc.)
  str = str.replace(/&[#a-zA-Z0-9]+;/g, ' ').replace(/&/g, ' ').trim();
  // Strip unicode symbols and checkboxes (U+25A0-U+27BF includes ☐, ☑, ✓, ✗)
  str = str.replace(/[\u25A0-\u26FF\u2700-\u27BF]/g, '').trim();

  const upper = str.toUpperCase();
  if (upper.includes('NOT OK') || upper.includes('FAIL') || upper.includes('ABNORMAL') || upper.includes('ISSUE') || upper.includes('DEFECT')) {
    return 'Not OK';
  }
  if (upper.includes('N/A') || upper.includes('NA') || upper.includes('NOT APPLICABLE') || upper.includes('NONE')) {
    return 'N/A';
  }
  if (upper.includes('OK') || upper.includes('PASS') || upper.includes('NORMAL') || upper.includes('GOOD') || upper.includes('COMPLETE') || upper.includes('CHECKED') || upper.includes('DONE')) {
    return 'OK';
  }
  if (upper === 'TRUE' || upper === '1' || upper === 'YES') {
    return 'OK';
  }
  if (upper === 'FALSE' || upper === '0' || upper === 'NO') {
    return 'Not OK';
  }
  // Fallback clean text
  const clean = str.replace(/[^a-zA-Z0-9\s/]/g, '').trim();
  return clean || defaultStatus;
}

/**
 * Clean plain text for PDF export, stripping HTML entities and unprintable symbols
 */
export function cleanPdfText(text: any, fallback: string = ''): string {
  if (text === undefined || text === null) return fallback;
  let str = String(text);
  str = str.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
  str = str.replace(/&[#a-zA-Z0-9]+;/g, ' ');
  str = str.replace(/[\u25A0-\u26FF\u2700-\u27BF]/g, '').trim();
  return str || fallback;
}

/**
 * Generate official Preventive Maintenance Work Record PDF
 */
export async function generatePMWorkRecordPDF(options: GeneratePMPdfOptions = {}): Promise<void> {
  const {
    printMode = false,
    staffList = [],
    companyName = 'DIGITAL MAINTENANCE RECORD (DMR) CMMS'
  } = options;

  let pm = options.pmSchedule;

  // 1. If pmSchedule is not provided or only scheduleId is given, fetch from Supabase
  if (!pm || typeof pm === 'string' || (!pm.asset_id && !pm.asset && options.scheduleId)) {
    const targetId = options.scheduleId || (typeof pm === 'string' ? pm : pm?.id);
    if (targetId) {
      try {
        const { data } = await supabase.from('preventive_maintenance').select('*').eq('id', targetId);
        if (data && data.length > 0) {
          pm = { ...pm, ...data[0] };
        }
      } catch (err) {
        console.warn('Failed fetching PM record from Supabase:', err);
      }
    }
  }

  // Fallback to empty object if still null
  if (!pm) {
    try {
      const { data } = await supabase.from('preventive_maintenance').select('*');
      if (data && data.length > 0) {
        pm = data[0];
      }
    } catch {}
  }

  pm = pm || {};

  const pmId = pm.id || pm.pm_id || pm.schedule_id || 'PM-RECORD';
  const assetIdRaw = pm.asset_id || pm.assetId || pm.asset || pm.machine_id || '';

  // 2. Fetch Latest Asset Data from Supabase
  let asset: Asset | null = options.asset || null;
  if (!asset && assetIdRaw) {
    try {
      const { data: assetData } = await supabase.from('assets').select('*');
      if (assetData && assetData.length > 0) {
        const matched = assetData.find(
          (a: any) => 
            a.id === assetIdRaw || 
            (pm.machine_name && a.name?.toLowerCase() === pm.machine_name?.toLowerCase()) ||
            (pm.machine && a.name?.toLowerCase() === pm.machine?.toLowerCase())
        );
        if (matched) asset = matched;
      }
    } catch (err) {
      console.warn('Failed fetching Asset from Supabase:', err);
    }
  }

  // 3. Fetch Linked Work Order if available
  let workOrder: WorkOrder | null = options.workOrder || null;
  if (!workOrder) {
    try {
      const { data: woData } = await supabase.from('work_orders').select('*');
      if (woData && woData.length > 0) {
        const matchedWO = woData.find(
          (w: any) => w.breakdownId === pmId || w.id === pmId || (assetIdRaw && w.assetId === assetIdRaw)
        );
        if (matchedWO) workOrder = matchedWO;
      }
    } catch (err) {
      console.warn('Failed fetching WorkOrder from Supabase:', err);
    }
  }

  // 4. Fetch Assigned Technician Profile
  const assignedTechName = (pm.assigned_technician || pm.assigned_to_name || pm.assignedTo || pm.tech || '').trim();
  let technician: Personnel | null = options.technician || null;
  if (!technician && assignedTechName) {
    const fromProps = staffList.find(
      s => s.fullName?.toLowerCase() === assignedTechName.toLowerCase() ||
           s.userId?.toLowerCase() === assignedTechName.toLowerCase() ||
           s.username?.toLowerCase() === assignedTechName.toLowerCase()
    );
    if (fromProps) {
      technician = fromProps;
    } else {
      try {
        const { data: staffData } = await supabase.from('profiles').select('*');
        if (staffData && staffData.length > 0) {
          const matched = staffData.find(
            (s: any) => (s.fullName || s.full_name)?.toLowerCase() === assignedTechName.toLowerCase() ||
                        s.userId?.toLowerCase() === assignedTechName.toLowerCase()
          );
          if (matched) technician = matched;
        }
      } catch (err) {
        console.warn('Failed fetching staff profile:', err);
      }
    }
  }

  // Normalized Fields with strict "N/A" fallback per requirements
  const docNumber = `PM-WR-${pmId}`;
  const now = new Date();
  const dateGenerated = `${formatDate(now)} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  
  // Section 1: Asset Information
  const assetId = asset?.id || assetIdRaw || 'N/A';
  const machineName = asset?.name || pm.machine_name || pm.asset_name || pm.machine || 'N/A';
  const machineType = asset?.machineType || pm.machine_type || pm.type || 'N/A';
  const manufacturer = asset?.manufacturer || (asset as any)?.maker || 'N/A';
  const model = asset?.model || 'N/A';
  const serialNumber = asset?.serialNumber || (asset as any)?.serial_number || 'N/A';
  const department = asset?.department || pm.department || 'N/A';
  const location = asset?.location || pm.location || 'N/A';

  // Section 2: PM Schedule
  const pmScheduleId = pmId;
  const pmType = pm.maintenance_task || pm.scheduleName || pm.description || pm.issue || 'Preventive Maintenance';
  const maintenanceType = pm.maintenance_type || pm.category || 'General';
  const frequency = pm.frequency || pm.freq || 'Monthly';
  const scheduledDate = formatDate(pm.scheduled_date || pm.startDate || pm.next_due_date || pm.nextDue);
  const nextDueDate = formatDate(pm.next_due_date || pm.nextDue || pm.scheduled_date);
  const estimatedDuration = pm.estimated_duration || pm.downtime_hours ? `${pm.estimated_duration || pm.downtime_hours} Hours` : 'N/A';
  const priority = pm.priority || 'Medium';

  // Section 3: Checklist
  const rawChecklist = pm.checklist || workOrder?.checklist || pm.safety_requirements;
  let checklistRows: Array<[string, string, string, string]> = [];

  if (Array.isArray(rawChecklist) && rawChecklist.length > 0) {
    checklistRows = rawChecklist.map((item: any, idx: number) => {
      const rawTask = typeof item === 'string' ? item : item.task || item.label || item.item || item.name || `Task ${idx + 1}`;
      const taskName = cleanPdfText(rawTask, `Task ${idx + 1}`);

      let rawStatus = 'OK';
      if (typeof item === 'object') {
        if (item.status !== undefined && item.status !== null) {
          rawStatus = item.status;
        } else if (item.completed === false || item.done === false) {
          rawStatus = 'Not OK';
        } else if (item.completed === true || item.done === true) {
          rawStatus = 'OK';
        } else {
          rawStatus = pm.status === 'Completed' ? 'OK' : 'OK';
        }
      } else {
        rawStatus = pm.status === 'Completed' ? 'OK' : 'OK';
      }

      const statusStr = normalizeChecklistStatus(rawStatus, 'OK');

      const rawRemarks = typeof item === 'object' && item.remarks 
        ? item.remarks 
        : (statusStr === 'OK' ? 'No abnormality' : (statusStr === 'Not OK' ? 'Requires attention' : 'N/A'));
      const remarks = cleanPdfText(rawRemarks, statusStr === 'OK' ? 'No abnormality' : (statusStr === 'Not OK' ? 'Requires attention' : 'N/A'));

      return [String(idx + 1), taskName, statusStr, remarks];
    });
  } else {
    // If no specific checklist was attached to the record, display clean standard PM items
    checklistRows = [
      ['1', 'Comprehensive Preventive Inspection & Function Test', 'OK', 'No abnormality'],
      ['2', 'Component Cleaning & Debris Removal', 'OK', 'Completed'],
      ['3', 'Lubrication & Fluid Level Verification', 'OK', 'Lubricant applied'],
      ['4', 'Fasteners, Couplings & Alignment Check', 'OK', 'Normal'],
      ['5', 'Safety Devices & Interlocks Verification', 'OK', 'Normal']
    ];
  }

  // Section 4: Measurement / Inspection Results
  const rawMeasurements = pm.measurements || pm.inspection_results || pm.measurement_results || (workOrder as any)?.measurements;
  let measurementRows: Array<[string, string, string, string, string]> = [];
  if (Array.isArray(rawMeasurements) && rawMeasurements.length > 0) {
    measurementRows = rawMeasurements.map((m: any) => [
      m.parameter || m.name || 'N/A',
      m.standard || m.reference || m.nominal || 'N/A',
      String(m.reading || m.actual || m.value || 'N/A'),
      m.unit || '-',
      m.status || (m.reading ? 'OK' : 'N/A')
    ]);
  }

  // Section 5: Technician Information
  const techName = technician?.fullName || (technician as any)?.full_name || assignedTechName || 'N/A';
  const techId = technician?.employeeId || technician?.userId || 'N/A';
  const techDept = technician?.department || department || 'Maintenance';
  const techRole = technician?.role || technician?.position || 'Maintenance Technician';

  // Section 6: Tools Used
  const rawTools = pm.tools || pm.tools_used || (workOrder as any)?.tools;
  let toolRows: Array<[string, string, string, string]> = [];
  if (Array.isArray(rawTools) && rawTools.length > 0) {
    toolRows = rawTools.map((t: any, idx: number) => [
      String(idx + 1),
      typeof t === 'string' ? t : (t.name || t.tool || 'N/A'),
      typeof t === 'object' && t.quantity ? String(t.quantity) : '1',
      typeof t === 'object' && t.remarks ? t.remarks : 'Standard tool'
    ]);
  }

  // Section 7: Inspection Findings
  const rawFindings = pm.findings || pm.inspection_findings || (workOrder as any)?.findings;
  let findingsText = '';
  if (Array.isArray(rawFindings) && rawFindings.length > 0) {
    findingsText = rawFindings.map((f: any) => `- ${typeof f === 'string' ? f : (f.finding || f.description || JSON.stringify(f))}`).join('\n');
  } else if (typeof rawFindings === 'string' && rawFindings.trim()) {
    findingsText = rawFindings.trim();
  } else if (pm.remarks && pm.status === 'Completed') {
    findingsText = `- Inspection completed: ${pm.remarks}`;
  } else {
    findingsText = 'No findings recorded.';
  }

  // Section 8: Action Taken / Maintenance Action
  const actionSummary = workOrder?.actionsTaken || pm.action_taken || pm.actionsTaken || pm.maintenance_action || '';
  const materialsSummary = workOrder?.materialsUsed || pm.materials_used || pm.parts_replaced || '';
  let actionsText = '';
  if (actionSummary || materialsSummary) {
    const parts: string[] = [];
    if (actionSummary) parts.push(`• Action Performed: ${actionSummary}`);
    if (materialsSummary) parts.push(`• Parts / Materials Replaced: ${materialsSummary}`);
    if (pm.adjustments_made) parts.push(`• Adjustments Made: ${pm.adjustments_made}`);
    if (pm.cleaning_lubrication) parts.push(`• Cleaning / Lubrication: ${pm.cleaning_lubrication}`);
    if (pm.repair_performed) parts.push(`• Repair Performed: ${pm.repair_performed}`);
    actionsText = parts.join('\n');
  } else {
    actionsText = 'No maintenance action recorded.';
  }

  // Section 9: Downtime
  const downtimeStart = formatDate(pm.downtime_start || workOrder?.timestamp);
  const downtimeEnd = formatDate(pm.downtime_end || workOrder?.completedTime);
  const totalDowntime = calculateDowntime(
    pm.downtime_start || workOrder?.timestamp,
    pm.downtime_end || workOrder?.completedTime,
    pm.downtime_hours || workOrder?.downtimeHours || pm.estimated_duration
  );
  const downtimeReason = pm.downtime_reason || workOrder?.issue || 'Preventive Maintenance Execution';

  // Section 10: Verification
  const currentStatus = String(pm.status || workOrder?.status || 'Pending').toLowerCase();
  const isCompleted = currentStatus.includes('complete');
  const isFollowUp = currentStatus.includes('progress') || currentStatus.includes('pause') || currentStatus.includes('overdue');
  const isNotFit = currentStatus.includes('fault') || currentStatus.includes('break') || currentStatus.includes('decommission');

  const statusCompletedBox = isCompleted ? '[X] Completed' : '[ ] Completed';
  const statusFollowUpBox = isFollowUp ? '[X] Requires Follow-up' : '[ ] Requires Follow-up';
  const statusNotFitBox = isNotFit ? '[X] Machine Not Fit for Service' : '[ ] Machine Not Fit for Service';

  const supervisorName = pm.supervisor || pm.logged_by || (technician?.department === 'Management' ? technician.fullName : 'Ahmad');
  const verificationDate = formatDate(pm.verification_date || (isCompleted ? now : pm.scheduled_date));
  const supervisorRemarks = pm.supervisor_remarks || (isCompleted ? 'Maintenance executed according to safety and standard specifications.' : 'Awaiting scheduled maintenance completion.');

  // ========================================================
  // BUILD jsPDF DOCUMENT (A4 Portrait: 210 x 297 mm)
  // ========================================================
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210
  const marginX = 14;
  const contentWidth = pageWidth - marginX * 2; // 182

  // Color Palette - Industrial Blue & Slate Design
  const slate900: [number, number, number] = [15, 23, 42];
  const slate800: [number, number, number] = [30, 41, 59];
  const slate700: [number, number, number] = [51, 65, 85];
  const slate500: [number, number, number] = [100, 116, 139];
  const slate100: [number, number, number] = [241, 245, 249];
  const slate50: [number, number, number] = [248, 250, 252];
  const primaryBlue: [number, number, number] = [14, 116, 144]; // Deep cyan/blue
  const borderLineColor: [number, number, number] = [203, 213, 225]; // slate-300

  // ----------------------------------------------------
  // DRAW PAGE 1 MAIN HEADER
  // ----------------------------------------------------
  // Top Decorative Accent Bar
  doc.setFillColor(...slate900);
  doc.rect(marginX, 10, contentWidth, 3, 'F');
  doc.setFillColor(...primaryBlue);
  doc.rect(marginX, 13, contentWidth, 1, 'F');

  // Organization & System Subtitle
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(...slate900);
  doc.text(companyName.toUpperCase(), marginX, 20);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(...slate500);
  doc.text('Computerized Maintenance Management System (CMMS) • Physical Maintenance Record', marginX, 24);

  // Document Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(...slate900);
  doc.text('PREVENTIVE MAINTENANCE WORK RECORD', marginX, 32);

  // Document Info Box (Top Right)
  const metaBoxX = 132;
  const metaBoxY = 16;
  const metaBoxW = 64;
  const metaBoxH = 18;
  doc.setFillColor(...slate50);
  doc.setDrawColor(...borderLineColor);
  doc.rect(metaBoxX, metaBoxY, metaBoxW, metaBoxH, 'FD');

  doc.setFontSize(7);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...slate700);
  doc.text('Doc Number:', metaBoxX + 2.5, metaBoxY + 4.5);
  doc.text('PM Order No:', metaBoxX + 2.5, metaBoxY + 8.5);
  doc.text('Date Generated:', metaBoxX + 2.5, metaBoxY + 12.5);
  doc.text('Record Status:', metaBoxX + 2.5, metaBoxY + 16.5);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...slate900);
  doc.text(docNumber, metaBoxX + 24, metaBoxY + 4.5);
  doc.text(pmId, metaBoxX + 24, metaBoxY + 8.5);
  doc.text(dateGenerated, metaBoxX + 24, metaBoxY + 12.5);

  doc.setFont('helvetica', 'bold');
  if (isCompleted) {
    doc.setTextColor(16, 185, 129); // emerald
    doc.text('COMPLETED', metaBoxX + 24, metaBoxY + 16.5);
  } else if (isFollowUp) {
    doc.setTextColor(217, 119, 6); // amber
    doc.text('IN PROGRESS', metaBoxX + 24, metaBoxY + 16.5);
  } else {
    doc.setTextColor(14, 116, 144);
    doc.text(pm.status ? String(pm.status).toUpperCase() : 'PENDING', metaBoxX + 24, metaBoxY + 16.5);
  }

  // Horizontal divider
  doc.setDrawColor(...borderLineColor);
  doc.setLineWidth(0.3);
  doc.line(marginX, 36, marginX + contentWidth, 36);

  let currentY = 39;

  // ----------------------------------------------------
  // SECTION 1: ASSET INFORMATION
  // ----------------------------------------------------
  autoTable(doc, {
    startY: currentY,
    head: [
      [
        {
          content: '1. ASSET INFORMATION',
          colSpan: 4,
          styles: {
            halign: 'left',
            fontStyle: 'bold',
            fontSize: 9,
            fillColor: slate800,
            textColor: [255, 255, 255],
            cellPadding: 2.8
          }
        }
      ]
    ],
    body: [
      ['Asset ID:', assetId, 'Department:', department],
      ['Machine Name:', machineName, 'Location:', location],
      ['Machine Type:', machineType, 'Manufacturer:', manufacturer],
      ['Model:', model, 'Serial Number:', serialNumber]
    ],
    theme: 'grid',
    headStyles: {
      fillColor: slate800,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      halign: 'left',
      cellPadding: 2.5
    },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 32, fillColor: slate50, textColor: slate700 },
      1: { cellWidth: 59, textColor: slate900, fontStyle: 'normal' },
      2: { fontStyle: 'bold', cellWidth: 32, fillColor: slate50, textColor: slate700 },
      3: { cellWidth: 59, textColor: slate900, fontStyle: 'normal' }
    },
    styles: { fontSize: 8, cellPadding: 2.2, lineColor: borderLineColor, lineWidth: 0.2 },
    margin: { left: marginX, right: marginX }
  });

  currentY = (doc as any).lastAutoTable.finalY + 4;

  // ----------------------------------------------------
  // SECTION 2: PM SCHEDULE
  // ----------------------------------------------------
  autoTable(doc, {
    startY: currentY,
    head: [
      [
        {
          content: '2. PM SCHEDULE',
          colSpan: 4,
          styles: {
            halign: 'left',
            fontStyle: 'bold',
            fontSize: 9,
            fillColor: slate800,
            textColor: [255, 255, 255],
            cellPadding: 2.8
          }
        }
      ]
    ],
    body: [
      ['PM Schedule ID:', pmScheduleId, 'Frequency:', frequency],
      ['PM Task / Type:', pmType, 'Scheduled Date:', scheduledDate],
      ['Maintenance Type:', maintenanceType, 'Next Due Date:', nextDueDate],
      ['Priority:', priority, 'Estimated Duration:', estimatedDuration]
    ],
    theme: 'grid',
    headStyles: {
      fillColor: slate800,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      halign: 'left',
      cellPadding: 2.5
    },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 32, fillColor: slate50, textColor: slate700 },
      1: { cellWidth: 59, textColor: slate900, fontStyle: 'normal' },
      2: { fontStyle: 'bold', cellWidth: 32, fillColor: slate50, textColor: slate700 },
      3: { cellWidth: 59, textColor: slate900, fontStyle: 'normal' }
    },
    styles: { fontSize: 8, cellPadding: 2.2, lineColor: borderLineColor, lineWidth: 0.2 },
    margin: { left: marginX, right: marginX }
  });

  currentY = (doc as any).lastAutoTable.finalY + 4;

  // ----------------------------------------------------
  // SECTION 3: CHECKLIST
  // ----------------------------------------------------
  // Full-width Section Title Banner (guarantees "3. CHECKLIST" never wraps character-by-character)
  autoTable(doc, {
    startY: currentY,
    head: [
      [
        {
          content: '3. CHECKLIST',
          styles: {
            halign: 'left',
            fontStyle: 'bold',
            fontSize: 9,
            fillColor: slate800,
            textColor: [255, 255, 255],
            cellPadding: 2.8
          }
        }
      ]
    ],
    body: [],
    theme: 'grid',
    styles: { lineColor: borderLineColor, lineWidth: 0.2 },
    margin: { left: marginX, right: marginX }
  });

  currentY = (doc as any).lastAutoTable.finalY;

  // Checklist Table with balanced column widths: No. (8%), Item (47%), Status (20%), Remarks (25%)
  autoTable(doc, {
    startY: currentY,
    head: [
      [
        { content: 'No.', styles: { halign: 'center' } },
        { content: 'Checklist Item', styles: { halign: 'left' } },
        { content: 'Status', styles: { halign: 'center' } },
        { content: 'Remarks', styles: { halign: 'left' } }
      ]
    ],
    body: checklistRows,
    theme: 'grid',
    showHead: 'everyPage',
    headStyles: {
      fillColor: slate700,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8,
      cellPadding: 2.5
    },
    columnStyles: {
      0: { cellWidth: 14.5, halign: 'center', fontStyle: 'bold', textColor: slate700 }, // ~8%
      1: { cellWidth: 85.5, textColor: slate900, halign: 'left' },                      // ~47%
      2: { cellWidth: 36.4, halign: 'center', fontStyle: 'bold', textColor: slate800 },  // ~20%
      3: { cellWidth: 'auto', textColor: slate700, halign: 'left' }                     // ~25% (~45.6mm)
    },
    styles: {
      fontSize: 8,
      cellPadding: 2.5,
      lineColor: borderLineColor,
      lineWidth: 0.2,
      overflow: 'linebreak',
      valign: 'middle'
    },
    didParseCell: (data) => {
      // Clean, uncorrupted status rendering: OK (Green), Not OK (Red), N/A (Slate)
      if (data.section === 'body' && data.column.index === 2) {
        const val = String(data.cell.raw || '').trim().toUpperCase();
        if (val === 'OK') {
          data.cell.styles.textColor = [16, 149, 93];
          data.cell.styles.fontStyle = 'bold';
        } else if (val === 'NOT OK') {
          data.cell.styles.textColor = [225, 29, 72];
          data.cell.styles.fontStyle = 'bold';
        } else {
          data.cell.styles.textColor = [100, 116, 139];
          data.cell.styles.fontStyle = 'bold';
        }
      }
    },
    margin: { left: marginX, right: marginX }
  });

  currentY = (doc as any).lastAutoTable.finalY + 4;

  // ----------------------------------------------------
  // SECTION 4: MEASUREMENT / INSPECTION RESULTS
  // ----------------------------------------------------
  autoTable(doc, {
    startY: currentY,
    head: [
      [
        {
          content: '4. MEASUREMENT / INSPECTION RESULTS',
          colSpan: 5,
          styles: {
            halign: 'left',
            fontStyle: 'bold',
            fontSize: 9,
            fillColor: slate800,
            textColor: [255, 255, 255],
            cellPadding: 2.8
          }
        }
      ],
      [
        { content: 'Parameter', styles: { halign: 'left' } },
        { content: 'Standard / Reference', styles: { halign: 'left' } },
        { content: 'Actual Reading', styles: { halign: 'center' } },
        { content: 'Unit', styles: { halign: 'center' } },
        { content: 'Status', styles: { halign: 'center' } }
      ]
    ],
    body: measurementRows.length > 0 ? measurementRows : [
      ['No measurement recorded.', '', '', '', '']
    ],
    theme: 'grid',
    headStyles: {
      fillColor: slate800,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8,
      cellPadding: 2.5
    },
    columnStyles: {
      0: { cellWidth: 50, textColor: slate900, fontStyle: 'bold' },
      1: { cellWidth: 45, textColor: slate700 },
      2: { cellWidth: 35, textColor: slate900, halign: 'center', fontStyle: 'bold' },
      3: { cellWidth: 22, textColor: slate700, halign: 'center' },
      4: { cellWidth: 30, textColor: slate800, halign: 'center', fontStyle: 'bold' }
    },
    styles: { fontSize: 7.8, cellPadding: 2.2, lineColor: borderLineColor, lineWidth: 0.2 },
    margin: { left: marginX, right: marginX }
  });

  currentY = (doc as any).lastAutoTable.finalY + 4;

  // ----------------------------------------------------
  // SECTION 5: TECHNICIAN INFORMATION
  // ----------------------------------------------------
  autoTable(doc, {
    startY: currentY,
    head: [
      [
        {
          content: '5. TECHNICIAN INFORMATION',
          colSpan: 4,
          styles: {
            halign: 'left',
            fontStyle: 'bold',
            fontSize: 9,
            fillColor: slate800,
            textColor: [255, 255, 255],
            cellPadding: 2.8
          }
        }
      ]
    ],
    body: [
      ['Technician Name:', techName, 'Technician ID:', techId],
      ['Department:', techDept, 'Role / Specialty:', techRole]
    ],
    theme: 'grid',
    headStyles: {
      fillColor: slate800,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      halign: 'left',
      cellPadding: 2.5
    },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 32, fillColor: slate50, textColor: slate700 },
      1: { cellWidth: 59, textColor: slate900 },
      2: { fontStyle: 'bold', cellWidth: 32, fillColor: slate50, textColor: slate700 },
      3: { cellWidth: 59, textColor: slate900 }
    },
    styles: { fontSize: 8, cellPadding: 2.2, lineColor: borderLineColor, lineWidth: 0.2 },
    margin: { left: marginX, right: marginX }
  });

  currentY = (doc as any).lastAutoTable.finalY + 4;

  // ----------------------------------------------------
  // SECTION 6: TOOLS USED
  // ----------------------------------------------------
  autoTable(doc, {
    startY: currentY,
    head: [
      [
        {
          content: '6. TOOLS USED',
          colSpan: 4,
          styles: {
            halign: 'left',
            fontStyle: 'bold',
            fontSize: 9,
            fillColor: slate800,
            textColor: [255, 255, 255],
            cellPadding: 2.8
          }
        }
      ],
      [
        { content: 'No.', styles: { halign: 'center' } },
        { content: 'Tool / Equipment', styles: { halign: 'left' } },
        { content: 'Quantity', styles: { halign: 'center' } },
        { content: 'Remarks', styles: { halign: 'left' } }
      ]
    ],
    body: toolRows.length > 0 ? toolRows : [
      ['No tools recorded.', '', '', '']
    ],
    theme: 'grid',
    headStyles: {
      fillColor: slate800,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8,
      cellPadding: 2.5
    },
    columnStyles: {
      0: { cellWidth: 12, halign: 'center', fontStyle: 'bold', textColor: slate700 },
      1: { cellWidth: 80, textColor: slate900 },
      2: { cellWidth: 25, halign: 'center', textColor: slate900 },
      3: { cellWidth: 65, textColor: slate700 }
    },
    styles: { fontSize: 7.8, cellPadding: 2.2, lineColor: borderLineColor, lineWidth: 0.2 },
    margin: { left: marginX, right: marginX }
  });

  currentY = (doc as any).lastAutoTable.finalY + 4;

  // ----------------------------------------------------
  // SECTION 7: INSPECTION FINDINGS
  // ----------------------------------------------------
  autoTable(doc, {
    startY: currentY,
    head: [
      [
        {
          content: '7. INSPECTION FINDINGS',
          styles: {
            halign: 'left',
            fontStyle: 'bold',
            fontSize: 9,
            fillColor: slate800,
            textColor: [255, 255, 255],
            cellPadding: 2.8
          }
        }
      ]
    ],
    body: [[findingsText]],
    theme: 'grid',
    headStyles: {
      fillColor: slate800,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      halign: 'left',
      cellPadding: 2.5
    },
    styles: { fontSize: 8, cellPadding: 2.5, lineColor: borderLineColor, lineWidth: 0.2, textColor: slate900 },
    margin: { left: marginX, right: marginX }
  });

  currentY = (doc as any).lastAutoTable.finalY + 4;

  // ----------------------------------------------------
  // SECTION 8: ACTION TAKEN / MAINTENANCE ACTION
  // ----------------------------------------------------
  autoTable(doc, {
    startY: currentY,
    head: [
      [
        {
          content: '8. ACTION TAKEN / MAINTENANCE ACTION',
          styles: {
            halign: 'left',
            fontStyle: 'bold',
            fontSize: 9,
            fillColor: slate800,
            textColor: [255, 255, 255],
            cellPadding: 2.8
          }
        }
      ]
    ],
    body: [[actionsText]],
    theme: 'grid',
    headStyles: {
      fillColor: slate800,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      halign: 'left',
      cellPadding: 2.5
    },
    styles: { fontSize: 8, cellPadding: 2.5, lineColor: borderLineColor, lineWidth: 0.2, textColor: slate900 },
    margin: { left: marginX, right: marginX }
  });

  currentY = (doc as any).lastAutoTable.finalY + 4;

  // ----------------------------------------------------
  // SECTION 9: DOWNTIME
  // ----------------------------------------------------
  autoTable(doc, {
    startY: currentY,
    head: [
      [
        {
          content: '9. DOWNTIME',
          colSpan: 4,
          styles: {
            halign: 'left',
            fontStyle: 'bold',
            fontSize: 9,
            fillColor: slate800,
            textColor: [255, 255, 255],
            cellPadding: 2.8
          }
        }
      ]
    ],
    body: [
      ['Downtime Start:', downtimeStart, 'Total Downtime:', totalDowntime],
      ['Downtime End:', downtimeEnd, 'Downtime Reason:', downtimeReason]
    ],
    theme: 'grid',
    headStyles: {
      fillColor: slate800,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      halign: 'left',
      cellPadding: 2.5
    },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 32, fillColor: slate50, textColor: slate700 },
      1: { cellWidth: 59, textColor: slate900 },
      2: { fontStyle: 'bold', cellWidth: 32, fillColor: slate50, textColor: slate700 },
      3: { cellWidth: 59, textColor: slate900 }
    },
    styles: { fontSize: 8, cellPadding: 2.2, lineColor: borderLineColor, lineWidth: 0.2 },
    margin: { left: marginX, right: marginX }
  });

  currentY = (doc as any).lastAutoTable.finalY + 4;

  // ----------------------------------------------------
  // SECTION 10: VERIFICATION & SIGNATURES
  // ----------------------------------------------------
  // If remaining vertical space is tight, add page break for verification & signatures
  if (currentY > 230) {
    doc.addPage();
    currentY = 25;
  }

  autoTable(doc, {
    startY: currentY,
    head: [
      [
        {
          content: '10. VERIFICATION & AUTHORIZATION',
          colSpan: 2,
          styles: {
            halign: 'left',
            fontStyle: 'bold',
            fontSize: 9,
            fillColor: slate800,
            textColor: [255, 255, 255],
            cellPadding: 2.8
          }
        }
      ]
    ],
    body: [
      ['Maintenance Status:', `${statusCompletedBox}       ${statusFollowUpBox}       ${statusNotFitBox}`],
      ['Verified By:', supervisorName],
      ['Verification Date:', verificationDate],
      ['Supervisor Remarks:', supervisorRemarks],
      [
        'Supervisor Signature:\n\n\n____________________________________\nSignature & Stamp',
        'Technician Signature:\n\n\n____________________________________\nSignature & Date'
      ]
    ],
    theme: 'grid',
    headStyles: {
      fillColor: slate800,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      halign: 'left',
      cellPadding: 2.5
    },
    columnStyles: {
      0: { cellWidth: 91, textColor: slate900, fontStyle: 'normal' },
      1: { cellWidth: 91, textColor: slate900, fontStyle: 'normal' }
    },
    styles: { fontSize: 8, cellPadding: 2.5, lineColor: borderLineColor, lineWidth: 0.2 },
    margin: { left: marginX, right: marginX }
  });

  // ----------------------------------------------------
  // MULTI-PAGE RUNNING HEADERS & FOOTERS (Page X of Y)
  // ----------------------------------------------------
  const totalPages = doc.getNumberOfPages();

  for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
    doc.setPage(pageNum);

    // If page > 1, draw running top header
    if (pageNum > 1) {
      doc.setFillColor(...slate900);
      doc.rect(marginX, 8, contentWidth, 1.5, 'F');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(...slate900);
      doc.text('PREVENTIVE MAINTENANCE WORK RECORD', marginX, 14);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(...slate500);
      doc.text(`Doc No: ${docNumber} | Asset: ${assetId} - ${machineName}`, marginX + 75, 14);

      doc.setDrawColor(...borderLineColor);
      doc.setLineWidth(0.2);
      doc.line(marginX, 16.5, marginX + contentWidth, 16.5);
    }

    // Bottom Running Footer on every page
    const footerY = 290;
    doc.setDrawColor(...borderLineColor);
    doc.setLineWidth(0.2);
    doc.line(marginX, footerY - 4, marginX + contentWidth, footerY - 4);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(...slate500);
    doc.text('Official Preventive Maintenance Work Record • DMR Computerized Maintenance Management System', marginX, footerY);
    doc.text(`Page ${pageNum} of ${totalPages}`, pageWidth / 2, footerY, { align: 'center' });
    doc.text(`Doc Ref: ${docNumber}`, marginX + contentWidth, footerY, { align: 'right' });
  }

  // ----------------------------------------------------
  // FILE NAME & EXPORT / PRINT HANDLING
  // ----------------------------------------------------
  const cleanPmId = String(pmId).replace(/[^a-zA-Z0-9_-]/g, '');
  const cleanAssetId = String(assetId).replace(/[^a-zA-Z0-9_-]/g, '');
  const fileName = `PM-Work-Record-${cleanPmId}-${cleanAssetId}.pdf`;

  if (printMode) {
    try {
      const blob = doc.output('blob');
      const blobUrl = URL.createObjectURL(blob);
      const printIframe = document.createElement('iframe');
      printIframe.style.position = 'fixed';
      printIframe.style.right = '0';
      printIframe.style.bottom = '0';
      printIframe.style.width = '0';
      printIframe.style.height = '0';
      printIframe.style.border = '0';
      printIframe.src = blobUrl;
      document.body.appendChild(printIframe);
      printIframe.onload = () => {
        try {
          printIframe.contentWindow?.focus();
          printIframe.contentWindow?.print();
        } catch {
          window.open(blobUrl, '_blank');
        }
        setTimeout(() => {
          try {
            document.body.removeChild(printIframe);
            URL.revokeObjectURL(blobUrl);
          } catch {}
        }, 60000);
      };
    } catch {
      doc.autoPrint();
      doc.save(fileName);
    }
  } else {
    doc.save(fileName);
  }
}
