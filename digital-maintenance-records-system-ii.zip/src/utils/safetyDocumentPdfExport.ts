import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { SafetyDocument } from '../types';

export interface GenerateSafetyDocumentPdfOptions {
  document: SafetyDocument;
  printMode?: boolean;
  companyName?: string;
}

function formatDate(d?: string | Date | null): string {
  if (!d) return 'N/A';
  try {
    const dateObj = typeof d === 'string' ? new Date(d) : d;
    if (isNaN(dateObj.getTime())) return String(d).replace('T', ' ');
    return dateObj.toISOString().replace('T', ' ').substring(0, 16);
  } catch {
    return String(d);
  }
}

export async function generateSafetyDocumentPDF(options: GenerateSafetyDocumentPdfOptions): Promise<void> {
  const { document: docData, printMode = false, companyName = 'DIGITAL MAINTENANCE RECORD (DMR) CMMS' } = options;

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210 mm
  const pageHeight = doc.internal.pageSize.getHeight(); // 297 mm
  const marginX = 14;
  const contentWidth = pageWidth - marginX * 2; // 182 mm

  // Palette
  const slate900: [number, number, number] = [15, 23, 42];
  const slate800: [number, number, number] = [30, 41, 59];
  const slate700: [number, number, number] = [51, 65, 85];
  const slate500: [number, number, number] = [100, 116, 139];
  const slate200: [number, number, number] = [226, 232, 240];
  const slate50: [number, number, number] = [248, 250, 252];
  const amber700: [number, number, number] = [180, 83, 9];
  const emerald700: [number, number, number] = [4, 120, 87];
  const rose700: [number, number, number] = [190, 18, 60];
  const blue700: [number, number, number] = [29, 78, 216];

  let currentY = 14;

  const checkPageBreak = (neededHeight: number) => {
    if (currentY + neededHeight > pageHeight - 18) {
      doc.addPage();
      currentY = 14;
      return true;
    }
    return false;
  };

  const isIntegrated = docData.documentType === 'JSA + PTW' || 
    (Boolean(docData.jobSteps && docData.jobSteps.length > 0) && Boolean(docData.permitType || (docData.safetyPrecautions && docData.safetyPrecautions.length > 0)));

  // 1. TOP HEADER BRANDING
  doc.setFillColor(...slate900);
  doc.rect(marginX, currentY, contentWidth, 18, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(255, 255, 255);
  doc.text(companyName, marginX + 4, currentY + 7);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(203, 213, 225);
  const subTitle = isIntegrated
    ? `INTEGRATED SAFETY DOCUMENT (JSA + PTW) - ${docData.permitType?.toUpperCase() || 'HIGH RISK OPERATIONAL PERMIT'}`
    : docData.documentType === 'JSA' 
    ? 'JOB SAFETY ANALYSIS (JSA) - SAFE WORK METHOD STATEMENT'
    : `PERMIT TO WORK (PTW) - ${docData.permitType?.toUpperCase() || 'HIGH RISK WORK PERMIT'}`;
  doc.text(subTitle, marginX + 4, currentY + 13);

  // Status Badge on Header Right
  const isApproved = docData.status === 'Approved' || docData.status === 'Active';
  const statusColor = isApproved ? emerald700 : (docData.status === 'Pending Approval' ? amber700 : (docData.status === 'Rejected' ? rose700 : slate700));
  
  doc.setFillColor(...statusColor);
  doc.roundedRect(pageWidth - marginX - 44, currentY + 3.5, 40, 11, 2, 2, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text(docData.status.toUpperCase(), pageWidth - marginX - 24, currentY + 10.5, { align: 'center' });

  currentY += 22;

  // 2. SECTION A: GENERAL JOB INFORMATION
  doc.setFillColor(...slate800);
  doc.rect(marginX, currentY, contentWidth, 6, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text('SECTION A: GENERAL JOB INFORMATION', marginX + 3, currentY + 4.2);

  currentY += 7;

  // Panel 1: Metadata Grid
  doc.setFillColor(...slate50);
  doc.setDrawColor(...slate200);
  doc.setLineWidth(0.3);
  doc.rect(marginX, currentY, contentWidth, 38, 'FD');

  doc.setFontSize(7.5);
  
  // Row 1
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...slate500);
  doc.text('SAFETY REF NUMBER:', marginX + 4, currentY + 6);
  doc.setTextColor(...blue700);
  doc.text(docData.documentNumber || docData.id, marginX + 42, currentY + 6);

  const col2X = marginX + 94;
  doc.setTextColor(...slate500);
  doc.text('WORK ORDER ID:', col2X, currentY + 6);
  doc.setTextColor(...blue700);
  doc.text(docData.workOrderId || 'Standalone (No Work Order)', col2X + 38, currentY + 6);

  // Row 2
  doc.setTextColor(...slate500);
  doc.text('MACHINE / ASSET NAME:', marginX + 4, currentY + 13);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...slate900);
  doc.text(`${docData.machineName || 'General Equipment'} (${docData.assetId || 'N/A'})`, marginX + 42, currentY + 13);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...slate500);
  doc.text('SERIAL NUMBER:', col2X, currentY + 13);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...slate900);
  doc.text(docData.machineSerialNumber || 'N/A', col2X + 38, currentY + 13);

  // Row 3
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...slate500);
  doc.text('WORK LOCATION:', marginX + 4, currentY + 20);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...slate900);
  doc.text((docData.machineLocation || docData.workLocationDetail || 'Workshop Site').substring(0, 36), marginX + 42, currentY + 20);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...slate500);
  doc.text('DEPARTMENT:', col2X, currentY + 20);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...slate900);
  doc.text(docData.department || 'Mechanical & Electrical', col2X + 38, currentY + 20);

  // Row 4
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...slate500);
  doc.text('MAINTENANCE TYPE:', marginX + 4, currentY + 27);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...slate900);
  doc.text(docData.maintenanceType || 'Corrective Maintenance', marginX + 42, currentY + 27);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...slate500);
  doc.text('PLANNED PERIOD:', col2X, currentY + 27);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...emerald700);
  const startStr = formatDate(docData.plannedStartTime || docData.validityStart);
  const endStr = formatDate(docData.plannedEndTime || docData.validityEnd);
  doc.text(`${startStr} to ${endStr}`, col2X + 38, currentY + 27);

  // Row 5
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...slate500);
  doc.text('REQUESTED BY:', marginX + 4, currentY + 34);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...slate900);
  doc.text(docData.requestedBy || docData.createdBy || 'Engineering Management', marginX + 42, currentY + 34);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...slate500);
  doc.text('ASSIGNED / PIC:', col2X, currentY + 34);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...slate900);
  const techPic = `Tech: ${docData.assignedTechnicianName || 'Technician'} | PIC: ${docData.personInCharge || 'Supervisor'}`;
  doc.text(techPic.substring(0, 48), col2X + 38, currentY + 34);

  currentY += 41;

  // Panel 2: Job Title & Description
  doc.setFillColor(...slate50);
  doc.rect(marginX, currentY, contentWidth, 14, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(...slate500);
  doc.text('JOB TITLE & SCOPE:', marginX + 4, currentY + 5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...slate900);
  const fullDesc = `${docData.jobTitle ? docData.jobTitle + ' - ' : ''}${docData.jobDescription || 'Standard maintenance task'}`;
  const splitJob = doc.splitTextToSize(fullDesc, contentWidth - 40);
  doc.text(splitJob, marginX + 36, currentY + 5);

  currentY += 18;

  // 3. SECTION B: JOB SAFETY ANALYSIS (JSA)
  if (isIntegrated || docData.documentType === 'JSA') {
    checkPageBreak(50);
    doc.setFillColor(...slate800);
    doc.rect(marginX, currentY, contentWidth, 6, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(255, 255, 255);
    doc.text('SECTION B: JOB SAFETY ANALYSIS (JSA) & RISK ASSESSMENT', marginX + 3, currentY + 4.2);

    currentY += 8;

    const ppeList = (docData.requiredPPE && docData.requiredPPE.length > 0)
      ? docData.requiredPPE.join(', ')
      : 'Standard Workshop PPE (Safety Helmet, Safety Boots, Safety Glasses)';

    const hazardsList = (docData.identifiedHazards && docData.identifiedHazards.length > 0)
      ? docData.identifiedHazards.join(', ')
      : 'Mechanical Pinch Points, Stored Energy, Tripping Hazards';

    doc.setFillColor(...slate50);
    doc.rect(marginX, currentY, contentWidth, 16, 'FD');

    doc.setFontSize(7.5);
    doc.setTextColor(...slate500);
    doc.setFont('helvetica', 'bold');
    doc.text('Mandatory PPE:', marginX + 3, currentY + 5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...slate900);
    const splitPPE = doc.splitTextToSize(ppeList, contentWidth - 30);
    doc.text(splitPPE, marginX + 28, currentY + 5);

    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...slate500);
    doc.text('Hazards Identified:', marginX + 3, currentY + 12);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...rose700);
    const splitHazards = doc.splitTextToSize(hazardsList, contentWidth - 30);
    doc.text(splitHazards, marginX + 28, currentY + 12);

    currentY += 19;

    // Step-by-step Job Safety Analysis table
    const steps = (docData.jobSteps && docData.jobSteps.length > 0)
      ? docData.jobSteps.map((s, idx) => [
          String(s.stepNumber || idx + 1),
          s.stepDescription || 'Task Step',
          s.hazards || 'Potential Risk',
          s.controlMeasures || 'Control Precaution'
        ])
      : [
          ['1', 'Pre-work briefing and boundary barricading', 'Unauthorized personnel entry', 'Set warning signage and barricade tape'],
          ['2', 'Equipment lockout (LOTO) & verify zero energy', 'Unexpected start, electrical shock', 'Apply padlock, bleed valves, test zero voltage'],
          ['3', 'Execute mechanical repair and inspection', 'Pinch points, sharp edges, tool slips', 'Use cut-resistant gloves and inspected tools'],
          ['4', 'Site cleanup and barrier removal', 'Trip hazards, misplaced tools', 'Housekeeping 5S, verify area clean']
        ];

    autoTable(doc, {
      startY: currentY,
      margin: { left: marginX, right: marginX },
      head: [['Step #', 'Job Sequence / Steps', 'Identified Hazards', 'Control Measures / Precaution']],
      body: steps,
      theme: 'grid',
      headStyles: {
        fillColor: slate800,
        textColor: [255, 255, 255],
        fontSize: 7.5,
        fontStyle: 'bold',
        halign: 'left'
      },
      styles: {
        fontSize: 7.5,
        textColor: slate900,
        cellPadding: 2,
        lineColor: slate200,
        lineWidth: 0.2
      },
      columnStyles: {
        0: { cellWidth: 14, halign: 'center' },
        1: { cellWidth: 54 },
        2: { cellWidth: 54 },
        3: { cellWidth: 60 }
      }
    });

    currentY = (doc as any).lastAutoTable ? (doc as any).lastAutoTable.finalY + 5 : currentY + 30;

    if (docData.emergencyProcedures) {
      checkPageBreak(12);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(...slate700);
      const emerg = `Emergency Response: ${docData.emergencyProcedures}`;
      const splitEmerg = doc.splitTextToSize(emerg, contentWidth - 4);
      doc.text(splitEmerg, marginX + 2, currentY);
      currentY += (splitEmerg.length * 4) + 2;
    }
  }

  // 4. SECTION C: PERMIT TO WORK (PTW)
  if (isIntegrated || docData.documentType === 'PTW') {
    checkPageBreak(50);
    doc.setFillColor(...slate800);
    doc.rect(marginX, currentY, contentWidth, 6, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(255, 255, 255);
    doc.text(`SECTION C: PERMIT TO WORK (PTW) - ${docData.permitType?.toUpperCase() || 'HIGH RISK AUTHORIZATION'}`, marginX + 3, currentY + 4.2);

    currentY += 8;

    // Permit validity and details
    doc.setFillColor(...slate50);
    doc.rect(marginX, currentY, contentWidth, 14, 'FD');

    doc.setFontSize(7.5);
    doc.setTextColor(...slate500);
    doc.setFont('helvetica', 'bold');
    doc.text('Permit Category:', marginX + 3, currentY + 5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...blue700);
    doc.text(docData.permitType || 'Hot Work', marginX + 28, currentY + 5);

    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...slate500);
    doc.text('Specific Location:', col2X, currentY + 5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...slate900);
    doc.text((docData.workLocationDetail || docData.machineLocation || 'Workshop Bay').substring(0, 42), col2X + 28, currentY + 5);

    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...slate500);
    doc.text('Permit Validity:', marginX + 3, currentY + 10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...emerald700);
    doc.text(`Start: ${formatDate(docData.validityStart || docData.plannedStartTime)}  |  End: ${formatDate(docData.validityEnd || docData.plannedEndTime)}`, marginX + 28, currentY + 10);

    currentY += 17;

    // Energy Isolation / LOTO Table
    const isolationRows = (docData.isolations && docData.isolations.length > 0)
      ? docData.isolations.map(iso => [
          iso.type,
          iso.applied ? 'VERIFIED LOCKED [YES]' : 'NOT APPLIED [NO]',
          iso.isolationPoint || 'Main Isolator',
          iso.tagOrLockNumber || 'TAG-01',
          iso.verifiedBy || 'Authorized Officer'
        ])
      : [
          ['Electrical Isolation (LOTO)', docData.isolationRequired ? 'REQUIRED / VERIFIED' : 'NOT REQUIRED', 'Main Distribution Board', 'TAG-EL-01', 'Electrical Lead'],
          ['Mechanical Energy Block', docData.isolationRequired ? 'REQUIRED / VERIFIED' : 'NOT REQUIRED', 'Machine Drive Lock Pin', 'TAG-MC-01', 'Mechanical Tech'],
          ['Pressure Bleed / Depressurization', docData.isolationRequired ? 'REQUIRED / VERIFIED' : 'NOT REQUIRED', 'Pneumatic Dump Valve', 'TAG-PR-01', 'Technician']
        ];

    autoTable(doc, {
      startY: currentY,
      margin: { left: marginX, right: marginX },
      head: [['Isolation Method', 'Applied Status', 'Isolation Point', 'Tag / Lock ID', 'Verified By']],
      body: isolationRows,
      theme: 'grid',
      headStyles: {
        fillColor: slate800,
        textColor: [255, 255, 255],
        fontSize: 7.5,
        fontStyle: 'bold'
      },
      styles: {
        fontSize: 7.5,
        textColor: slate900,
        cellPadding: 2,
        lineColor: slate200,
        lineWidth: 0.2
      },
      columnStyles: {
        0: { cellWidth: 50 },
        1: { cellWidth: 38, halign: 'center' },
        2: { cellWidth: 38 },
        3: { cellWidth: 26 },
        4: { cellWidth: 30 }
      }
    });

    currentY = (doc as any).lastAutoTable ? (doc as any).lastAutoTable.finalY + 5 : currentY + 30;

    // Gas test results or Standby person if applicable
    if (docData.gasTestingRequired || docData.gasTesting || docData.standbyPersonName) {
      checkPageBreak(14);
      doc.setFillColor(...slate50);
      doc.rect(marginX, currentY, contentWidth, 12, 'FD');
      doc.setFontSize(7.5);
      doc.setTextColor(...slate700);
      doc.setFont('helvetica', 'bold');
      doc.text('Gas Test / Safety Sentry:', marginX + 3, currentY + 5);
      doc.setFont('helvetica', 'normal');
      const gasStr = docData.gasTestingRequired
        ? `O2: ${docData.gasTesting?.oxygenPercent || '20.9%'} | LEL: ${docData.gasTesting?.flammableLEL || '<1%'} | Toxic: ${docData.gasTesting?.toxicPPM || '0 ppm'}`
        : 'Atmospheric Gas Testing: Not mandatory for this task';
      const sentryStr = `Standby Person (Sentry): ${docData.standbyPersonName || 'Workshop Supervisor'}`;
      doc.text(`${gasStr}  |  ${sentryStr}`, marginX + 36, currentY + 5);
      currentY += 15;
    }
  }

  // 5. SECTION D: SAFETY CHECKLIST
  checkPageBreak(40);
  doc.setFillColor(...slate800);
  doc.rect(marginX, currentY, contentWidth, 6, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text('SECTION D: PRE-WORK SAFETY CHECKLIST & VERIFICATION', marginX + 3, currentY + 4.2);

  currentY += 8;

  const standardChecklist = [
    'Area Barricaded & Warning Signboards Posted',
    'ABC Dry Powder Fire Extinguisher on Standby (Min 9kg)',
    'Combustible Materials Cleared within 10m Radius',
    'Ventilation Fan / Exhaust Duct Operating Safely',
    'Emergency Evacuation Route Verified Clear & Unobstructed',
    'Emergency Stop Buttons Tested and Tagged',
    'Tools & Portable Power Equipment Inspected and Tested Safe',
    'All Workers Briefed on JSA Risk Assessment & Controls'
  ];

  const precautions = (docData.safetyPrecautions && docData.safetyPrecautions.length > 0)
    ? docData.safetyPrecautions
    : standardChecklist.slice(0, 5);

  doc.setFillColor(...slate50);
  doc.rect(marginX, currentY, contentWidth, 18, 'FD');
  doc.setFontSize(7.5);

  const half = Math.ceil(precautions.length / 2);
  const col1Items = precautions.slice(0, half);
  const col2Items = precautions.slice(half);

  let py = currentY + 4.5;
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...emerald700);
  col1Items.forEach(item => {
    doc.text(`[✓] ${item.substring(0, 50)}`, marginX + 4, py);
    py += 4;
  });

  py = currentY + 4.5;
  col2Items.forEach(item => {
    doc.text(`[✓] ${item.substring(0, 50)}`, col2X, py);
    py += 4;
  });

  currentY += 21;

  // 6. SECTION E: REVIEW, AUTHORIZATION & SIGN-OFF SECTION
  checkPageBreak(45);

  doc.setFillColor(...slate800);
  doc.rect(marginX, currentY, contentWidth, 6, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text('SECTION E: REVIEW, AUTHORIZATION & SIGN-OFF RECORD', marginX + 3, currentY + 4.2);

  currentY += 8;

  const boxWidth = (contentWidth - 4) / 2;
  
  // Box 1: Prepared / Submitted By
  doc.setFillColor(...slate50);
  doc.rect(marginX, currentY, boxWidth, 28, 'FD');

  doc.setFontSize(7.5);
  doc.setTextColor(...slate500);
  doc.setFont('helvetica', 'bold');
  doc.text('PREPARED & SUBMITTED BY (TECHNICIAN):', marginX + 3, currentY + 5);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...slate900);
  doc.text(`Name: ${docData.assignedTechnicianName || docData.createdBy || 'Authorized Technician'}`, marginX + 3, currentY + 11);
  doc.text(`Submission Date: ${formatDate(docData.submittedAt || docData.createdAt)}`, marginX + 3, currentY + 16);
  doc.text(`Designation: Maintenance Specialist`, marginX + 3, currentY + 21);
  doc.text(`PIC Endorsement: ${docData.personInCharge || 'Supervisor Verified'}`, marginX + 3, currentY + 26);

  // Box 2: Management / Safety Approval
  const box2X = marginX + boxWidth + 4;
  doc.setFillColor(...slate50);
  doc.rect(box2X, currentY, boxWidth, 28, 'FD');

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...slate500);
  doc.text('MANAGEMENT / SAFETY APPROVAL:', box2X + 3, currentY + 5);

  if (isApproved && docData.approvedBy) {
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...emerald700);
    doc.text(`APPROVED BY: ${docData.approvedBy}`, box2X + 3, currentY + 11);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...slate900);
    doc.text(`Approval Date: ${formatDate(docData.approvedAt)}`, box2X + 3, currentY + 16);
    doc.text(`Authority: ${docData.approvalRole || 'Plant Engineering Management'}`, box2X + 3, currentY + 21);

    // Official approval stamp graphic
    doc.setDrawColor(...emerald700);
    doc.setLineWidth(0.8);
    doc.roundedRect(box2X + boxWidth - 36, currentY + 6, 32, 16, 1, 1, 'D');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.setTextColor(...emerald700);
    doc.text('OFFICIAL VERIFIED', box2X + boxWidth - 20, currentY + 12, { align: 'center' });
    doc.text('APPROVED', box2X + boxWidth - 20, currentY + 18, { align: 'center' });
  } else if (docData.status === 'Rejected') {
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...rose700);
    doc.text('STATUS: REJECTED FOR REVISION', box2X + 3, currentY + 11);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...slate700);
    doc.text(`Reason: ${docData.rejectionReason || 'Incomplete safety controls'}`, box2X + 3, currentY + 17);
  } else {
    // Unapproved Draft Notice
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...amber700);
    doc.text('STATUS: PENDING MANAGEMENT APPROVAL', box2X + 3, currentY + 11);
    doc.setFont('helvetica', 'italic');
    doc.setTextColor(...slate500);
    doc.text('This document is NOT yet authorized for work.', box2X + 3, currentY + 17);
    doc.text('Work must not commence until signed.', box2X + 3, currentY + 23);
  }

  currentY += 31;

  // 7. FOOTER & DISCLAIMER
  checkPageBreak(12);
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...slate500);
  const disclaimer = 'STATUTORY SAFETY NOTICE: This integrated safety document is an official statutory record within the Digital Maintenance Record (DMR) System. Work execution must strictly adhere to the hazard control measures, energy isolation procedures, and safety checklists specified above. Any alteration without safety re-validation renders this permit null and void.';
  const splitDisc = doc.splitTextToSize(disclaimer, contentWidth);
  doc.text(splitDisc, marginX, currentY);

  const cleanDocNum = String(docData.documentNumber || docData.id).replace(/[^a-zA-Z0-9_-]/g, '');
  const prefix = isIntegrated ? 'SAF-JSA-PTW' : docData.documentType;
  const fileName = `${prefix}-${cleanDocNum}.pdf`;

  // Output: Print or Download
  if (printMode) {
    try {
      const blob = doc.output('blob');
      const blobUrl = URL.createObjectURL(blob);
      const printIframe = document.createElement('iframe');
      printIframe.style.position = 'fixed';
      printIframe.style.right = '0';
      printIframe.style.bottom = '0';
      printIframe.style.width = '0';
      printIframe.style.height = '0';
      printIframe.style.border = '0';
      printIframe.src = blobUrl;
      document.body.appendChild(printIframe);
      printIframe.onload = () => {
        try {
          printIframe.contentWindow?.focus();
          printIframe.contentWindow?.print();
        } catch {
          window.open(blobUrl, '_blank');
        }
        setTimeout(() => {
          try {
            document.body.removeChild(printIframe);
            URL.revokeObjectURL(blobUrl);
          } catch {}
        }, 60000);
      };
    } catch {
      doc.autoPrint();
      doc.save(fileName);
    }
  } else {
    doc.save(fileName);
  }
}
