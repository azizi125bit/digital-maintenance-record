import { WorkOrder, SafetyDocument, SafetyDocumentStatus, SafetyDocumentType } from '../types';
import { supabase } from '../lib/supabase';

export interface SafetyValidationResult {
  canStart: boolean;
  blockingReason?: string;
  specificMessage?: string;
  requiredDocuments: Array<'JSA' | 'PTW' | 'JSA + PTW'>;
  linkedJSA?: SafetyDocument | null;
  linkedPTW?: SafetyDocument | null;
  jsaStatus?: SafetyDocumentStatus;
  ptwStatus?: SafetyDocumentStatus;
}

/**
 * Standardize ticket/asset ID comparison (removes leading #, trims, lowercases)
 */
export const normalizeDocId = (id?: string | null): string => {
  if (!id) return '';
  return String(id).toLowerCase().trim().replace(/^#/, '');
};

/**
 * Fetch latest safety documents from the database with reliable fallback/cache synchronization.
 */
export async function fetchLatestSafetyDocuments(workOrderId?: string): Promise<SafetyDocument[]> {
  let docs: SafetyDocument[] = [];

  try {
    const { data, error } = await supabase.from('safety_documents').select('*');
    if (!error && Array.isArray(data) && data.length > 0) {
      docs = data as SafetyDocument[];
    }
  } catch (err) {
    console.warn('Could not query safety_documents from database:', err);
  }

  // Merge with localStorage for resilience
  try {
    const stored = localStorage.getItem('dmr_safety_documents');
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed)) {
        const seen = new Set(docs.map(d => normalizeDocId(d.id)));
        for (const item of parsed) {
          const normId = normalizeDocId(item.id);
          if (!seen.has(normId)) {
            docs.push(item);
            seen.add(normId);
          } else {
            // Update with newer status if localStorage has recent edit
            const idx = docs.findIndex(d => normalizeDocId(d.id) === normId);
            if (idx >= 0) {
              const remoteTime = docs[idx].updatedAt ? new Date(docs[idx].updatedAt).getTime() : 0;
              const localTime = item.updatedAt ? new Date(item.updatedAt).getTime() : 0;
              if (localTime >= remoteTime) {
                docs[idx] = { ...docs[idx], ...item };
              }
            }
          }
        }
      }
    }
  } catch (_) {}

  // Filter by workOrderId if specified
  if (workOrderId) {
    const cleanId = normalizeDocId(workOrderId);
    return docs.filter(d => 
      normalizeDocId(d.workOrderId) === cleanId || 
      normalizeDocId(d.id) === cleanId ||
      normalizeDocId(d.documentNumber) === cleanId
    );
  }

  return docs;
}

/**
 * Persist approved / updated safety document to database, localStorage, and linked Work Order.
 */
export async function syncSafetyDocumentToDb(
  doc: SafetyDocument,
  linkedWorkOrderId?: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const now = new Date().toISOString();
    const updatedDoc: SafetyDocument = {
      ...doc,
      updatedAt: now
    };

    // 1. Update / Insert safety document in database
    try {
      const { data: existing } = await supabase.from('safety_documents').select('*').eq('id', updatedDoc.id);
      if (Array.isArray(existing) && existing.length > 0) {
        await supabase.from('safety_documents').update(updatedDoc).eq('id', updatedDoc.id);
      } else {
        await supabase.from('safety_documents').insert([updatedDoc]);
      }
    } catch (e) {
      console.warn('Database safety_documents update warning:', e);
    }

    // 2. Persist to localStorage dmr_safety_documents
    try {
      let currentDocs: SafetyDocument[] = [];
      const stored = localStorage.getItem('dmr_safety_documents');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) currentDocs = parsed;
      }
      const existingIdx = currentDocs.findIndex(d => normalizeDocId(d.id) === normalizeDocId(updatedDoc.id));
      if (existingIdx >= 0) {
        currentDocs[existingIdx] = updatedDoc;
      } else {
        currentDocs.unshift(updatedDoc);
      }
      localStorage.setItem('dmr_safety_documents', JSON.stringify(currentDocs));
    } catch (_) {}

    // 3. Update linked Work Order in database and cache
    const woId = linkedWorkOrderId || doc.workOrderId;
    if (woId) {
      const cleanWoId = normalizeDocId(woId);
      const isApproved = updatedDoc.status === 'Approved' || updatedDoc.status === 'Active';
      const woUpdates: Partial<WorkOrder> = {
        safetyDocumentId: updatedDoc.id,
        safetyDocumentType: updatedDoc.documentType,
        safetyDocumentStatus: updatedDoc.status,
        requiresPermit: updatedDoc.documentType === 'PTW' || doc.permitType !== undefined,
        requiredPermitType: updatedDoc.permitType
      };

      try {
        await supabase.from('work_orders').update(woUpdates).eq('id', woId);
      } catch (e) {
        console.warn('Database work_orders safety update warning:', e);
      }

      try {
        const storedWo = localStorage.getItem('dmr_work_orders');
        if (storedWo) {
          const wos: WorkOrder[] = JSON.parse(storedWo);
          const updatedWos = wos.map(w => normalizeDocId(w.id) === cleanWoId ? { ...w, ...woUpdates } : w);
          localStorage.setItem('dmr_work_orders', JSON.stringify(updatedWos));
        }
      } catch (_) {}
    }

    // Dispatch custom event for cross-component reactive updates
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('dmr_safety_updated', { detail: { doc: updatedDoc, workOrderId: woId } }));
    }

    return { success: true };
  } catch (err: any) {
    console.error('syncSafetyDocumentToDb error:', err);
    return { success: false, error: err.message || 'Failed saving safety document.' };
  }
}

/**
 * Validate whether a Work Order has satisfied all required safety documents and approvals.
 */
export function validateWorkOrderSafety(
  order: WorkOrder,
  safetyDocs: SafetyDocument[]
): SafetyValidationResult {
  const cleanWoId = normalizeDocId(order.id);
  const cleanAssetId = normalizeDocId(order.assetId);

  // Find all documents linked strictly to this Work Order and Asset
  const linkedDocs = safetyDocs.filter(d => {
    const docWoId = normalizeDocId(d.workOrderId);
    if (docWoId && docWoId === cleanWoId) {
      if (cleanAssetId && d.assetId) {
        return normalizeDocId(d.assetId) === cleanAssetId;
      }
      return true;
    }
    if (order.safetyDocumentId && (normalizeDocId(d.id) === normalizeDocId(order.safetyDocumentId) || normalizeDocId(d.documentNumber) === normalizeDocId(order.safetyDocumentId))) {
      if (cleanAssetId && d.assetId) {
        return normalizeDocId(d.assetId) === cleanAssetId;
      }
      return true;
    }
    return false;
  });

  const linkedIntegrated = linkedDocs.find(d => d.documentType === 'JSA + PTW') || null;
  const linkedJSA = linkedDocs.find(d => d.documentType === 'JSA') || linkedIntegrated || null;
  const linkedPTW = linkedDocs.find(d => d.documentType === 'PTW') || linkedIntegrated || null;

  // Determine what safety documents are mandatory for this task
  const isHighPriority = (order.priority || '').toLowerCase() === 'high';
  const isElectrical = (order.category || '').toLowerCase() === 'electrical';
  const isHighRisk = isHighPriority || isElectrical;
  const isExplicitPermit = order.requiresPermit === true || !!order.requiredPermitType;
  const hasLinkedJSA = !!linkedJSA;
  const hasLinkedPTW = !!linkedPTW;

  const requiredDocuments: Array<'JSA' | 'PTW' | 'JSA + PTW'> = [];

  // 1. If an integrated doc or PTW is linked to this order, or explicitly demanded by requiresPermit
  if (hasLinkedPTW || (isExplicitPermit && !hasLinkedJSA)) {
    requiredDocuments.push('PTW');
  }

  // 2. If a JSA is linked to this order
  if (hasLinkedJSA && !requiredDocuments.includes('JSA')) {
    requiredDocuments.push('JSA');
  }

  // 3. If order explicitly specifies safetyDocumentType
  if (order.safetyDocumentType && !requiredDocuments.includes(order.safetyDocumentType)) {
    requiredDocuments.push(order.safetyDocumentType);
  }

  const isApprovedStatus = (status: string | undefined): boolean => {
    if (!status) return false;
    const s = status.toLowerCase().trim();
    return s === 'approved' || s === 'active';
  };

  // 4. If neither document is linked yet:
  if (requiredDocuments.length === 0) {
    if (isHighRisk || isExplicitPermit) {
      // Check direct work order attributes in case safetyDocumentStatus is stored directly on work_order
      const orderDirectStatus = (order.safetyDocumentStatus || '').toLowerCase().trim();
      const isDirectApproved = isApprovedStatus(orderDirectStatus);

      if (isDirectApproved) {
        return {
          canStart: true,
          requiredDocuments: order.safetyDocumentType ? [order.safetyDocumentType] : ['JSA'],
          linkedJSA,
          linkedPTW,
          jsaStatus: order.safetyDocumentType === 'JSA' ? order.safetyDocumentStatus : undefined,
          ptwStatus: order.safetyDocumentType === 'PTW' ? order.safetyDocumentStatus : undefined
        };
      }

      // Neither document is linked or approved yet -> Safety Hold is active
      return {
        canStart: false,
        blockingReason: 'High Risk Safety Hold',
        specificMessage: 'Work cannot be marked as authorized to start. This maintenance task involves high-risk hazards (High Priority or Electrical scope) that mandate an approved Job Safety Analysis (JSA) or Permit to Work (PTW).',
        requiredDocuments: isExplicitPermit ? ['PTW'] : ['JSA'],
        linkedJSA: null,
        linkedPTW: null
      };
    }

    // Standard low-risk job without safety document requirements
    return {
      canStart: true,
      requiredDocuments: [],
      linkedJSA: null,
      linkedPTW: null
    };
  }

  // Evaluate JSA requirement if applicable
  if (requiredDocuments.includes('JSA')) {
    if (!linkedJSA) {
      // Check if order itself has approved JSA status
      const directApproved = order.safetyDocumentType === 'JSA' && isApprovedStatus(order.safetyDocumentStatus);
      if (!directApproved) {
        return {
          canStart: false,
          blockingReason: 'Missing JSA',
          specificMessage: isElectrical 
            ? 'Electrical work mandates an approved Job Safety Analysis (JSA) before work can start.'
            : isHighPriority 
            ? 'High Priority maintenance tasks mandate an approved Job Safety Analysis (JSA) before work can start.'
            : 'JSA approval is required before work can start.',
          requiredDocuments,
          linkedJSA,
          linkedPTW,
          jsaStatus: order.safetyDocumentType === 'JSA' ? order.safetyDocumentStatus : undefined,
          ptwStatus: linkedPTW?.status || (order.safetyDocumentType === 'PTW' ? order.safetyDocumentStatus : undefined)
        };
      }
    } else {
      const s = (linkedJSA.status || '').toLowerCase().trim();
      if (!isApprovedStatus(s)) {
        let msg = 'JSA approval is required before work can start.';
        if (s === 'draft') {
          msg = 'The linked Job Safety Analysis (JSA) is still in Draft. Please submit the JSA for approval before work can start.';
        } else if (s === 'pending approval') {
          msg = 'JSA approval is required before work can start. The document is currently pending Management review.';
        } else if (s === 'rejected') {
          msg = `The linked Job Safety Analysis (JSA) has been rejected${linkedJSA.rejectionReason ? `: "${linkedJSA.rejectionReason}"` : ''}. Safety revisions must be approved before work can start.`;
        } else if (s === 'closed') {
          msg = 'The linked Job Safety Analysis is closed.';
        }

        return {
          canStart: false,
          blockingReason: `JSA [${linkedJSA.status}]`,
          specificMessage: msg,
          requiredDocuments,
          linkedJSA,
          linkedPTW,
          jsaStatus: linkedJSA.status,
          ptwStatus: linkedPTW?.status
        };
      }
    }
  }

  // Evaluate PTW requirement if applicable
  if (requiredDocuments.includes('PTW')) {
    if (!linkedPTW) {
      // Check if order itself has approved PTW status
      const directApproved = order.safetyDocumentType === 'PTW' && isApprovedStatus(order.safetyDocumentStatus);
      if (!directApproved) {
        return {
          canStart: false,
          blockingReason: 'Missing PTW',
          specificMessage: 'PTW approval is required before work can start. Please ensure a Permit to Work has been reviewed and authorized.',
          requiredDocuments,
          linkedJSA,
          linkedPTW,
          jsaStatus: linkedJSA?.status,
          ptwStatus: order.safetyDocumentType === 'PTW' ? order.safetyDocumentStatus : undefined
        };
      }
    } else {
      const s = (linkedPTW.status || '').toLowerCase().trim();

      // Check validity period
      let isExpired = s === 'expired';
      if (!isExpired && linkedPTW.validityEnd) {
        try {
          const endDate = new Date(linkedPTW.validityEnd);
          if (!isNaN(endDate.getTime()) && endDate < new Date()) {
            isExpired = true;
          }
        } catch (_) {}
      }

      if (isExpired) {
        return {
          canStart: false,
          blockingReason: 'PTW Expired',
          specificMessage: 'The permit has expired. An active, valid Permit to Work is required to start work.',
          requiredDocuments,
          linkedJSA,
          linkedPTW,
          jsaStatus: linkedJSA?.status,
          ptwStatus: 'Expired'
        };
      }

      if (s === 'suspended') {
        return {
          canStart: false,
          blockingReason: 'PTW Suspended',
          specificMessage: 'The permit is currently suspended. Work cannot proceed until the safety suspension is lifted.',
          requiredDocuments,
          linkedJSA,
          linkedPTW,
          jsaStatus: linkedJSA?.status,
          ptwStatus: 'Suspended'
        };
      }

      if (s === 'closed') {
        return {
          canStart: false,
          blockingReason: 'PTW Closed',
          specificMessage: 'The permit has been closed. A new permit is required for further maintenance.',
          requiredDocuments,
          linkedJSA,
          linkedPTW,
          jsaStatus: linkedJSA?.status,
          ptwStatus: 'Closed'
        };
      }

      if (!isApprovedStatus(s)) {
        let msg = 'PTW approval is required before work can start.';
        if (s === 'draft') {
          msg = 'The Permit to Work (PTW) is still in Draft. Please submit the permit for approval before work can start.';
        } else if (s === 'pending approval') {
          msg = 'PTW approval is required before work can start. The permit is currently pending Management authorization.';
        } else if (s === 'rejected') {
          msg = `The Permit to Work (PTW) has been rejected${linkedPTW.rejectionReason ? `: "${linkedPTW.rejectionReason}"` : ''}. Required safety revisions must be approved before work can start.`;
        }

        return {
          canStart: false,
          blockingReason: `PTW [${linkedPTW.status}]`,
          specificMessage: msg,
          requiredDocuments,
          linkedJSA,
          linkedPTW,
          jsaStatus: linkedJSA?.status,
          ptwStatus: linkedPTW.status
        };
      }
    }
  }

  // All applicable safety requirements are satisfied!
  return {
    canStart: true,
    requiredDocuments,
    linkedJSA,
    linkedPTW,
    jsaStatus: linkedJSA?.status || (order.safetyDocumentType === 'JSA' ? order.safetyDocumentStatus : undefined),
    ptwStatus: linkedPTW?.status || (order.safetyDocumentType === 'PTW' ? order.safetyDocumentStatus : undefined)
  };
}
