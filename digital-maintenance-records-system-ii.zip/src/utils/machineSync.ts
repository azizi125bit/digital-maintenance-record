/**
 * Utility for bidirectional synchronization between Machine Breakdowns and Asset statuses.
 * Enforces rule:
 * - Active breakdown reported -> Machine status switches to BREAKDOWN (🔴 Red)
 * - All breakdowns completed/resolved -> Machine status switches back to OPERATIONAL (🟢 Green)
 * Synchronized across Asset Directory, Maintenance Records, and Dashboard.
 */

import { supabase } from '../lib/supabase';
import { Asset, MachineBreakdown } from '../types';

export const RESOLVED_BREAKDOWN_STATUSES: string[] = [
  'completed',
  'resolved',
  'closed',
  'repaired',
  'cancelled',
  'canceled',
  'done',
  'selesai',
  'siap',
  'fixed',
  'ok'
];

/**
 * Checks if a breakdown status is considered active (unresolved).
 */
export function isBreakdownActive(status: string | undefined | null): boolean {
  if (!status) return true;
  const normalized = status.trim().toLowerCase();
  return !RESOLVED_BREAKDOWN_STATUSES.includes(normalized);
}

/**
 * Checks if a breakdown status is considered completed/resolved.
 */
export function isBreakdownCompleted(status: string | undefined | null): boolean {
  return !isBreakdownActive(status);
}

/**
 * Checks if an asset has at least one active breakdown incident.
 */
export function checkAssetHasActiveBreakdown(
  assetId: string, 
  breakdownsList?: MachineBreakdown[]
): boolean {
  if (!assetId) return false;
  const targetId = assetId.trim().toLowerCase();

  let list: MachineBreakdown[] = (breakdownsList && breakdownsList.length > 0) ? breakdownsList : [];
  if (list.length === 0) {
    try {
      const saved = localStorage.getItem('dmr_machine_breakdowns');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          list = parsed;
        }
      }
    } catch (_) {}
  }

  return list.some(b => {
    const bAssetId = (b.asset_id || (b as any).assetId || '').trim().toLowerCase();
    const bMachineName = (b.machine_name || '').trim().toLowerCase();
    const matchesAsset = bAssetId === targetId || (bMachineName && bMachineName === targetId);
    return matchesAsset && isBreakdownActive(b.status);
  });
}

/**
 * Derives the effective real-time status of an asset, prioritizing active breakdowns.
 * If there is NO active breakdown for this asset, it returns 'Operational' if previously marked 'Breakdown'.
 */
export function getEffectiveMachineStatus(
  asset: { id: string; name?: string; status?: string } | null | undefined,
  breakdownsList?: MachineBreakdown[]
): 'Breakdown' | 'Operational' | 'Under Maintenance' | 'Faulty' | 'Decommissioned' {
  if (!asset) return 'Operational';

  // 1. If any active breakdown exists for this asset, it is unequivocally in BREAKDOWN (🔴 Red)
  if (checkAssetHasActiveBreakdown(asset.id, breakdownsList)) {
    return 'Breakdown';
  }

  // 2. If no active breakdown exists:
  // If the asset status was recorded as Breakdown, it has returned to OPERATIONAL (🟢 Green)
  if (asset.status === 'Breakdown') {
    return 'Operational';
  }

  return (asset.status as any) || 'Operational';
}

/**
 * Broadcasts an update event so all listening components synchronize instantly.
 */
export function broadcastMachineSync(assetId: string, status: string, detailData?: any) {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('dmr_machine_sync', {
        detail: { assetId, status, timestamp: Date.now(), ...detailData }
      })
    );
    // Also trigger standard storage event for cross-component awareness
    window.dispatchEvent(new Event('storage'));
  }
}

/**
 * Updates asset status across Firestore, localStorage, and application event bus.
 */
export async function syncAssetBreakdownStatus(
  assetId: string, 
  isBreakdown: boolean, 
  reason?: string
): Promise<void> {
  if (!assetId) return;

  const targetId = assetId.trim();
  const newStatus: Asset['status'] = isBreakdown ? 'Breakdown' : 'Operational';

  // 1. Update localStorage assets cache
  try {
    const saved = localStorage.getItem('dmr_assets_list');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        const updated = parsed.map((a: Asset) => 
          (a.id || '').trim().toLowerCase() === targetId.toLowerCase() ? { ...a, status: newStatus } : a
        );
        localStorage.setItem('dmr_assets_list', JSON.stringify(updated));
      }
    }
  } catch (err) {
    console.warn('Failed to update localStorage dmr_assets_list in sync:', err);
  }

  // 2. Update Firestore database table
  try {
    await supabase.from('assets').update({ 
      status: newStatus,
      updated_at: new Date().toISOString()
    }).eq('id', targetId);
  } catch (err) {
    console.warn('Failed to update asset in Firestore:', err);
  }

  // 3. Broadcast synchronization event
  broadcastMachineSync(targetId, newStatus, { reason });
}

/**
 * Self-healing reconciliation: inspects all assets against all machine breakdowns.
 * If any machine was left as Breakdown but all of its breakdowns are Completed,
 * it automatically heals the machine back to Operational (🟢 Green).
 */
export async function healAndSyncAllAssets(
  assetsList?: Asset[], 
  breakdownsList?: MachineBreakdown[]
): Promise<Asset[]> {
  let assets: Asset[] = assetsList && assetsList.length > 0 ? assetsList : [];
  if (assets.length === 0) {
    try {
      const saved = localStorage.getItem('dmr_assets_list');
      if (saved) assets = JSON.parse(saved) || [];
    } catch (_) {}
  }

  let breakdowns: MachineBreakdown[] = breakdownsList && breakdownsList.length > 0 ? breakdownsList : [];
  if (breakdowns.length === 0) {
    try {
      const savedBrk = localStorage.getItem('dmr_machine_breakdowns');
      if (savedBrk) breakdowns = JSON.parse(savedBrk) || [];
    } catch (_) {}
  }

  if (!assets || assets.length === 0) return [];

  let changed = false;
  const healedAssets = assets.map(asset => {
    const hasActive = checkAssetHasActiveBreakdown(asset.id, breakdowns);
    if (!hasActive && asset.status === 'Breakdown') {
      changed = true;
      syncAssetBreakdownStatus(asset.id, false, 'Auto-healing: no active breakdowns remain');
      return { ...asset, status: 'Operational' as const };
    } else if (hasActive && asset.status !== 'Breakdown') {
      changed = true;
      syncAssetBreakdownStatus(asset.id, true, 'Auto-healing: active breakdown detected');
      return { ...asset, status: 'Breakdown' as const };
    }
    return asset;
  });

  if (changed) {
    try {
      localStorage.setItem('dmr_assets_list', JSON.stringify(healedAssets));
    } catch (_) {}
    broadcastMachineSync('ALL', 'HEALED');
  }

  return healedAssets;
}
