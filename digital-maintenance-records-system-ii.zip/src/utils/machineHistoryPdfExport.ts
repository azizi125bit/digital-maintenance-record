import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Asset } from '../types';

export interface MachineHistoryPdfRecord {
  id: string;
  date: string;
  recordType: string;
  workOrderId?: string;
  technician: string;
  findings: string;
  actionTaken: string;
  partsUsed: string;
  downtimeHours?: number;
  verificationStatus: string;
  supervisor?: string;
  verificationDate?: string;
}

export interface GenerateMachineHistoryPdfOptions {
  asset: Asset;
  records: MachineHistoryPdfRecord[];
  summary: {
    totalRecords: number;
    lastMaintenanceDate: string;
    lastMaintenanceType: string;
    totalDowntimeHours: number;
    numberOfBreakdowns: number;
    nextPmDate: string;
  };
  companyName?: string;
}

function formatDate(d?: string | Date | null): string {
  if (!d) return 'N/A';
  try {
    const dateObj = typeof d === 'string' ? new Date(d) : d;
    if (isNaN(dateObj.getTime())) return String(d).split('T')[0];
    return dateObj.toISOString().split('T')[0];
  } catch {
    return String(d);
  }
}

export async function generateMachineHistoryPDF(options: GenerateMachineHistoryPdfOptions): Promise<void> {
  const {
    asset,
    records = [],
    summary,
    companyName = 'DIGITAL MAINTENANCE RECORD (DMR) CMMS'
  } = options;

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210 mm
  const marginX = 14;
  const contentWidth = pageWidth - marginX * 2; // 182 mm

  // Colors
  const slate900: [number, number, number] = [15, 23, 42];
  const slate800: [number, number, number] = [30, 41, 59];
  const slate700: [number, number, number] = [51, 65, 85];
  const slate500: [number, number, number] = [100, 116, 139];
  const slate50: [number, number, number] = [248, 250, 252];
  const primaryCyan: [number, number, number] = [8, 145, 178];
  const borderLineColor: [number, number, number] = [203, 213, 225];

  const now = new Date();
  const dateGenerated = `${formatDate(now)} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  const docNumber = `MHR-${asset.id || 'ASSET'}-${Date.now().toString().slice(-4)}`;

  // Header Banner
  doc.setFillColor(...slate900);
  doc.rect(marginX, 10, contentWidth, 3, 'F');
  doc.setFillColor(...primaryCyan);
  doc.rect(marginX, 13, contentWidth, 1, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(...slate900);
  doc.text(companyName.toUpperCase(), marginX, 20);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(...slate500);
  doc.text('Computerized Maintenance Management System • Historical Machine Records & Audit Log', marginX, 24);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(...slate900);
  doc.text('MACHINE MAINTENANCE HISTORY RECORD', marginX, 32);

  // Doc info box
  const metaBoxX = 132;
  const metaBoxY = 16;
  const metaBoxW = 64;
  const metaBoxH = 17;
  doc.setFillColor(...slate50);
  doc.setDrawColor(...borderLineColor);
  doc.rect(metaBoxX, metaBoxY, metaBoxW, metaBoxH, 'FD');

  doc.setFontSize(7);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...slate700);
  doc.text('Doc Number:', metaBoxX + 2.5, metaBoxY + 4.5);
  doc.text('Asset ID:', metaBoxX + 2.5, metaBoxY + 8.5);
  doc.text('Date Generated:', metaBoxX + 2.5, metaBoxY + 12.5);
  doc.text('Audit Status:', metaBoxX + 2.5, metaBoxY + 16);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...slate900);
  doc.text(docNumber, metaBoxX + 24, metaBoxY + 4.5);
  doc.text(asset.id || 'N/A', metaBoxX + 24, metaBoxY + 8.5);
  doc.text(dateGenerated, metaBoxX + 24, metaBoxY + 12.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...primaryCyan);
  doc.text('READ-ONLY AUDIT', metaBoxX + 24, metaBoxY + 16);

  doc.setDrawColor(...borderLineColor);
  doc.setLineWidth(0.3);
  doc.line(marginX, 36, marginX + contentWidth, 36);

  let currentY = 39;

  // 1. Machine Information
  autoTable(doc, {
    startY: currentY,
    head: [
      [
        {
          content: '1. MACHINE INFORMATION',
          colSpan: 4,
          styles: {
            halign: 'left',
            fontStyle: 'bold',
            fontSize: 9,
            fillColor: slate800,
            textColor: [255, 255, 255],
            cellPadding: 2.8
          }
        }
      ]
    ],
    body: [
      ['Asset ID:', asset.id || 'N/A', 'Department:', asset.department || 'N/A'],
      ['Machine Name:', asset.name || 'N/A', 'Location:', asset.location || 'N/A'],
      ['Machine Type:', asset.machineType || asset.category || 'N/A', 'Manufacturer:', asset.manufacturer || 'N/A'],
      ['Model:', asset.model || 'N/A', 'Serial Number:', asset.serialNumber || 'N/A'],
      ['Current Status:', asset.status || 'Operational', 'Criticality:', asset.criticality || 'Medium']
    ],
    theme: 'grid',
    headStyles: {
      fillColor: slate800,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      halign: 'left',
      cellPadding: 2.5
    },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 32, fillColor: slate50, textColor: slate700 },
      1: { cellWidth: 59, textColor: slate900, fontStyle: 'normal' },
      2: { fontStyle: 'bold', cellWidth: 32, fillColor: slate50, textColor: slate700 },
      3: { cellWidth: 59, textColor: slate900, fontStyle: 'normal' }
    },
    styles: { fontSize: 8, cellPadding: 2.2, lineColor: borderLineColor, lineWidth: 0.2 },
    margin: { left: marginX, right: marginX }
  });

  currentY = (doc as any).lastAutoTable.finalY + 4;

  // 2. Maintenance Summary Statistics
  autoTable(doc, {
    startY: currentY,
    head: [
      [
        {
          content: '2. MAINTENANCE SUMMARY & METRICS',
          colSpan: 4,
          styles: {
            halign: 'left',
            fontStyle: 'bold',
            fontSize: 9,
            fillColor: slate800,
            textColor: [255, 255, 255],
            cellPadding: 2.8
          }
        }
      ]
    ],
    body: [
      ['Total Maintenance Records:', String(summary.totalRecords), 'Total Downtime:', `${summary.totalDowntimeHours.toFixed(1)} Hours`],
      ['Last Maintenance Date:', summary.lastMaintenanceDate || 'N/A', 'Last Maintenance Type:', summary.lastMaintenanceType || 'N/A'],
      ['Breakdown Incidents:', String(summary.numberOfBreakdowns), 'Next Scheduled PM:', summary.nextPmDate || 'N/A']
    ],
    theme: 'grid',
    headStyles: {
      fillColor: slate800,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      halign: 'left',
      cellPadding: 2.5
    },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 42, fillColor: slate50, textColor: slate700 },
      1: { cellWidth: 49, textColor: slate900, fontStyle: 'bold' },
      2: { fontStyle: 'bold', cellWidth: 42, fillColor: slate50, textColor: slate700 },
      3: { cellWidth: 49, textColor: slate900, fontStyle: 'bold' }
    },
    styles: { fontSize: 8, cellPadding: 2.2, lineColor: borderLineColor, lineWidth: 0.2 },
    margin: { left: marginX, right: marginX }
  });

  currentY = (doc as any).lastAutoTable.finalY + 4;

  // 3. Complete Maintenance History Table
  // Dedicated Full-Width Section Header
  autoTable(doc, {
    startY: currentY,
    head: [
      [
        {
          content: '3. HISTORICAL MAINTENANCE SERVICE RECORDS',
          styles: {
            halign: 'left',
            fontStyle: 'bold',
            fontSize: 9,
            fillColor: slate800,
            textColor: [255, 255, 255],
            cellPadding: 2.8
          }
        }
      ]
    ],
    body: [],
    theme: 'grid',
    styles: { lineColor: borderLineColor, lineWidth: 0.2 },
    margin: { left: marginX, right: marginX }
  });

  currentY = (doc as any).lastAutoTable.finalY;

  const tableBody = records.length > 0
    ? records.map((r, idx) => [
        String(idx + 1),
        r.date ? r.date.split('T')[0] : 'N/A',
        r.recordType || 'General',
        r.workOrderId || r.id || 'N/A',
        r.technician || 'Unassigned',
        r.findings || 'No findings recorded',
        r.actionTaken || 'No action recorded',
        r.partsUsed || 'None',
        r.downtimeHours !== undefined ? `${r.downtimeHours}h` : '0h',
        r.verificationStatus || 'Completed'
      ])
    : [['-', '-', 'No maintenance records available for this machine.', '', '', '', '', '', '', '']];

  autoTable(doc, {
    startY: currentY,
    head: [
      [
        { content: 'No.', styles: { halign: 'center' } },
        { content: 'Date', styles: { halign: 'center' } },
        { content: 'Type', styles: { halign: 'left' } },
        { content: 'Ref ID', styles: { halign: 'center' } },
        { content: 'Technician', styles: { halign: 'left' } },
        { content: 'Findings', styles: { halign: 'left' } },
        { content: 'Action Taken', styles: { halign: 'left' } },
        { content: 'Parts Used', styles: { halign: 'left' } },
        { content: 'Down', styles: { halign: 'center' } },
        { content: 'Status', styles: { halign: 'center' } }
      ]
    ],
    body: tableBody,
    theme: 'grid',
    showHead: 'everyPage',
    headStyles: {
      fillColor: slate700,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 7.5,
      cellPadding: 2
    },
    columnStyles: {
      0: { cellWidth: 8, halign: 'center', fontStyle: 'bold', textColor: slate700 },
      1: { cellWidth: 16, halign: 'center', textColor: slate900 },
      2: { cellWidth: 20, textColor: slate900, fontStyle: 'bold' },
      3: { cellWidth: 16, halign: 'center', textColor: slate700 },
      4: { cellWidth: 20, textColor: slate900 },
      5: { cellWidth: 32, textColor: slate700 },
      6: { cellWidth: 32, textColor: slate700 },
      7: { cellWidth: 16, textColor: slate700 },
      8: { cellWidth: 10, halign: 'center', textColor: slate900 },
      9: { cellWidth: 'auto', halign: 'center', fontStyle: 'bold' }
    },
    styles: {
      fontSize: 7.2,
      cellPadding: 2,
      lineColor: borderLineColor,
      lineWidth: 0.2,
      overflow: 'linebreak',
      valign: 'middle'
    },
    didParseCell: (data) => {
      if (data.section === 'body' && data.column.index === 9) {
        const val = String(data.cell.raw || '').trim().toLowerCase();
        if (val.includes('complete') || val.includes('verif') || val.includes('ok')) {
          data.cell.styles.textColor = [16, 149, 93];
        } else if (val.includes('progress') || val.includes('repair')) {
          data.cell.styles.textColor = [217, 119, 6];
        } else {
          data.cell.styles.textColor = [100, 116, 139];
        }
      }
    },
    margin: { left: marginX, right: marginX }
  });

  // Running footers & page numbers
  const totalPages = doc.getNumberOfPages();
  for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
    doc.setPage(pageNum);

    if (pageNum > 1) {
      doc.setFillColor(...slate900);
      doc.rect(marginX, 8, contentWidth, 1.5, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(...slate900);
      doc.text('MACHINE MAINTENANCE HISTORY RECORD', marginX, 14);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(...slate500);
      doc.text(`Asset: ${asset.id} - ${asset.name}`, marginX + 80, 14);
      doc.setDrawColor(...borderLineColor);
      doc.setLineWidth(0.2);
      doc.line(marginX, 16.5, marginX + contentWidth, 16.5);
    }

    const footerY = 290;
    doc.setDrawColor(...borderLineColor);
    doc.setLineWidth(0.2);
    doc.line(marginX, footerY - 4, marginX + contentWidth, footerY - 4);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(...slate500);
    doc.text('Official Maintenance History Record • DMR CMMS System', marginX, footerY);
    doc.text(`Page ${pageNum} of ${totalPages}`, pageWidth / 2, footerY, { align: 'center' });
    doc.text(`Doc Ref: ${docNumber}`, marginX + contentWidth, footerY, { align: 'right' });
  }

  const cleanAssetId = String(asset.id || 'MACHINE').replace(/[^a-zA-Z0-9_-]/g, '');
  const fileName = `Maintenance-History-${cleanAssetId}.pdf`;
  doc.save(fileName);
}
