import { UserRole } from '../types';

export interface AuthSession {
  userId: string;
  username: string;
  fullName: string;
  role: UserRole;
  createdAt: number;
  expiresAt: number;
}

// 8 hours session duration
export const SESSION_DURATION_MS = 8 * 60 * 60 * 1000;

export const SESSION_KEYS = {
  AUTH_FLAG: 'dmr_authorized',
  AUTH_USER: 'dmr_authorized_user',
  AUTH_USER_ID: 'dmr_auth_user_id',
  AUTH_ROLE: 'dmr_auth_role',
  AUTH_SESSION: 'dmr_auth_session',
  CURRENT_ROLE: 'dmr_current_role'
} as const;

/**
 * Returns the exact and only dashboard a role is authorized to access
 */
export function getAuthorizedDashboardForRole(role: UserRole): UserRole {
  switch (role) {
    case 'Management':
      return 'Management';
    case 'Technician':
      return 'Technician';
    case 'Supervisor':
      return 'Supervisor';
    case 'Auditor':
      return 'Auditor';
    default:
      return 'Technician';
  }
}

/**
 * Validates if a user's verified role can view a specific dashboard.
 * STRICT ENFORCEMENT:
 * - Management can NEVER access Technician Dashboard.
 * - Technician can NEVER access Management Dashboard.
 * - Supervisor cannot access Technician execution dashboard.
 */
export function isRoleAuthorizedForDashboard(userRole: UserRole, targetDashboard: UserRole): boolean {
  if (userRole === 'Management') {
    return targetDashboard === 'Management';
  }
  if (userRole === 'Technician') {
    return targetDashboard === 'Technician';
  }
  if (userRole === 'Supervisor') {
    return targetDashboard === 'Supervisor';
  }
  if (userRole === 'Auditor') {
    return targetDashboard === 'Auditor';
  }
  return false;
}

/**
 * Validates if a user's role can access a specific application module
 */
export function isRoleAuthorizedForModule(userRole: UserRole, module: string): boolean {
  switch (module) {
    case 'Dashboard':
      return true; // Dashboard is permitted, but the specific view is strictly guarded
    case 'PreventiveMaintenance':
      return userRole === 'Management'; // Management only
    case 'PersonnelManagement':
      return userRole === 'Management'; // Management only
    case 'AssetList':
    case 'MachineBreakdown':
    case 'MaintenanceRecords':
    case 'RequireDocument':
    case 'ProfileSettings':
      return true; // Universal operational modules
    default:
      return false;
  }
}

/**
 * Generates an informative, standardized security denial message
 */
export function getAccessDeniedMessage(target: 'Management' | 'Technician' | 'Supervisor' | 'Auditor' | string): string {
  if (target === 'Technician' || target === 'technician') {
    return 'Access Denied: You are not authorized to access the Technician Dashboard.';
  }
  if (target === 'Management' || target === 'management') {
    return 'Access Denied: You are not authorized to access the Management Dashboard.';
  }
  if (target === 'PersonnelManagement' || target === 'personnel') {
    return 'Access Denied: Personnel Management is restricted to Management users only.';
  }
  if (target === 'PreventiveMaintenance' || target === 'pm') {
    return 'Access Denied: Preventive Maintenance configuration is restricted to Management users only.';
  }
  return `Access Denied: Your assigned role is not authorized to access ${target}.`;
}

/**
 * Inspects URL search params, pathname, and hash to identify direct URL access attempts
 */
export function parseRouteFromUrl(): {
  requestedDashboard?: UserRole;
  requestedModule?: string;
} {
  try {
    const searchParams = new URLSearchParams(window.location.search);
    const hash = window.location.hash.toLowerCase().replace(/^#\/?/, '');
    const pathname = window.location.pathname.toLowerCase().replace(/^\//, '');

    // Check dashboard queries: ?dashboard=technician | ?role=technician
    const dashboardQuery = searchParams.get('dashboard') || searchParams.get('role');
    const moduleQuery = searchParams.get('module');

    let requestedDashboard: UserRole | undefined;

    const testStr = `${dashboardQuery || ''} ${hash} ${pathname}`.toLowerCase();

    if (testStr.includes('technician')) {
      requestedDashboard = 'Technician';
    } else if (testStr.includes('management') || testStr.includes('manager')) {
      requestedDashboard = 'Management';
    } else if (testStr.includes('supervisor')) {
      requestedDashboard = 'Supervisor';
    } else if (testStr.includes('auditor')) {
      requestedDashboard = 'Auditor';
    }

    let requestedModule: string | undefined = moduleQuery || undefined;
    if (!requestedModule) {
      if (testStr.includes('pm') || testStr.includes('preventive')) {
        requestedModule = 'PreventiveMaintenance';
      } else if (testStr.includes('personnel') || testStr.includes('staff')) {
        requestedModule = 'PersonnelManagement';
      } else if (testStr.includes('asset')) {
        requestedModule = 'AssetList';
      } else if (testStr.includes('breakdown')) {
        requestedModule = 'MachineBreakdown';
      } else if (testStr.includes('records') || testStr.includes('history')) {
        requestedModule = 'MaintenanceRecords';
      } else if (testStr.includes('document') || testStr.includes('permit') || testStr.includes('jsa')) {
        requestedModule = 'RequireDocument';
      } else if (testStr.includes('profile') || testStr.includes('settings')) {
        requestedModule = 'ProfileSettings';
      }
    }

    return { requestedDashboard, requestedModule };
  } catch (err) {
    return {};
  }
}

/**
 * Updates the browser URL without page reload to reflect current authorized location
 */
export function syncUrlForRoute(module: string, role?: UserRole) {
  try {
    const url = new URL(window.location.href);
    if (module === 'Dashboard') {
      url.searchParams.delete('module');
      if (role) {
        url.searchParams.set('dashboard', role.toLowerCase());
      }
    } else {
      url.searchParams.delete('dashboard');
      url.searchParams.delete('role');
      url.searchParams.set('module', module);
    }
    window.history.replaceState({ module, role }, '', url.toString());
  } catch (err) {
    // Non-critical in constrained iframe contexts
  }
}

/**
 * Saves authenticated session with expiry timestamp
 */
export function saveAuthenticatedSession(user: { userId: string; username: string; fullName: string; role: UserRole }) {
  const now = Date.now();
  const session: AuthSession = {
    userId: user.userId,
    username: user.username,
    fullName: user.fullName,
    role: user.role,
    createdAt: now,
    expiresAt: now + SESSION_DURATION_MS
  };

  try {
    localStorage.setItem(SESSION_KEYS.AUTH_FLAG, 'true');
    localStorage.setItem(SESSION_KEYS.AUTH_USER, user.fullName);
    localStorage.setItem(SESSION_KEYS.AUTH_USER_ID, user.userId);
    localStorage.setItem(SESSION_KEYS.AUTH_ROLE, user.role);
    localStorage.setItem(SESSION_KEYS.CURRENT_ROLE, user.role);
    localStorage.setItem(SESSION_KEYS.AUTH_SESSION, JSON.stringify(session));
  } catch (err) {
    console.error('Failed to store session in localStorage:', err);
  }
}

/**
 * Retrieves and validates the stored session from localStorage
 */
export function getStoredSession(): AuthSession | null {
  try {
    const isAuth = localStorage.getItem(SESSION_KEYS.AUTH_FLAG) === 'true';
    if (!isAuth) return null;

    const raw = localStorage.getItem(SESSION_KEYS.AUTH_SESSION);
    if (!raw) {
      // Fallback to legacy keys if present
      const userId = localStorage.getItem(SESSION_KEYS.AUTH_USER_ID);
      const fullName = localStorage.getItem(SESSION_KEYS.AUTH_USER);
      const role = localStorage.getItem(SESSION_KEYS.AUTH_ROLE) as UserRole;
      if (fullName && role) {
        return {
          userId: userId || 'USR-001',
          username: fullName,
          fullName,
          role,
          createdAt: Date.now(),
          expiresAt: Date.now() + SESSION_DURATION_MS
        };
      }
      return null;
    }

    const session: AuthSession = JSON.parse(raw);
    if (Date.now() > session.expiresAt) {
      clearAuthenticatedSession();
      return null;
    }
    return session;
  } catch (e) {
    return null;
  }
}

/**
 * Completely purges all authenticated session tokens, preventing role leakage
 */
export function clearAuthenticatedSession() {
  try {
    localStorage.removeItem(SESSION_KEYS.AUTH_FLAG);
    localStorage.removeItem(SESSION_KEYS.AUTH_USER);
    localStorage.removeItem(SESSION_KEYS.AUTH_USER_ID);
    localStorage.removeItem(SESSION_KEYS.AUTH_ROLE);
    localStorage.removeItem(SESSION_KEYS.CURRENT_ROLE);
    localStorage.removeItem(SESSION_KEYS.AUTH_SESSION);

    // Also clean URL query params if present
    const url = new URL(window.location.href);
    url.searchParams.delete('dashboard');
    url.searchParams.delete('role');
    url.searchParams.delete('module');
    window.history.replaceState({}, '', url.toString());
  } catch (e) {
    // Ignore
  }
}
const SESSION_KEYS_EXT = SESSION_KEYS as Record<string, string>;
SESSION_KEYS_EXT.AUTH_USER_PREV = 'dmr_authorized_user';
