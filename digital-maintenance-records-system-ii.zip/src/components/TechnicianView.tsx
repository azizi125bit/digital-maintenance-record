/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { WorkOrder, Technician } from '../types';
import { SEED_TECHNICIANS } from '../data';
import { motion, AnimatePresence } from 'motion/react';
import { supabase } from '../lib/supabase';
import { fetchLatestSafetyDocuments, validateWorkOrderSafety, normalizeDocId } from '../utils/safetyValidation';
import { 
  Wrench, 
  CheckCircle, 
  Play, 
  Check, 
  Clipboard, 
  Clock, 
  Tag, 
  Sparkles,
  AlertTriangle,
  FolderLock,
  CheckSquare,
  ShieldCheck,
  ShieldAlert,
  FileText,
  Flame,
  Eye,
  RefreshCw,
  MapPin
} from 'lucide-react';

interface TechnicianViewProps {
  workOrders: WorkOrder[];
  pmTasks?: any[];
  onStartWork: (id: string) => void;
  onPauseWork: (id: string) => void;
  onCompleteWork: (id: string, actions: string, materials: string, downtime: number) => void;
  onOpenRequireDocument?: (workOrderId?: string, defaultType?: 'JSA' | 'PTW' | 'JSA + PTW') => void;
  technicians?: Technician[];
  staffList?: import('../types').Personnel[];
  authorizedUser?: string;
}

export default function TechnicianView({ 
  workOrders, 
  pmTasks = [], 
  onStartWork, 
  onPauseWork, 
  onCompleteWork, 
  onOpenRequireDocument,
  technicians, 
  staffList, 
  authorizedUser 
}: TechnicianViewProps) {
  const techniciansList = technicians || [];
  const activeStaff = staffList ? staffList.filter(s => s.accountStatus === 'Active') : [];
  const activeTechStaff = activeStaff.filter(s => s.role === 'Technician');
  // Select active technician profile to simulate login
  const loggedInStaff = activeStaff.find(s => s.fullName === authorizedUser);
  const defaultTech = (loggedInStaff && loggedInStaff.role === 'Technician') ? loggedInStaff : (activeTechStaff[0] || activeStaff[0]);
  const [activeTechId, setActiveTechId] = useState<string>(defaultTech?.userId || '');
  
  useEffect(() => {
    if (loggedInStaff && loggedInStaff.role === 'Technician') {
      setActiveTechId(loggedInStaff.userId);
    }
  }, [loggedInStaff]);
  
  // Completion form modal states
  const [completingOrderId, setCompletingOrderId] = useState<string | null>(null);
  const [actionsTaken, setActionsTaken] = useState('');
  const [materialsUsed, setMaterialsUsed] = useState('');
  const [downtimeHours, setDowntimeHours] = useState<number>(1);

  // Auto-save mechanism
  useEffect(() => {
    if (completingOrderId) {
      const draft = { actionsTaken, materialsUsed, downtimeHours };
      localStorage.setItem(`dmr_draft_${completingOrderId}`, JSON.stringify(draft));
    }
  }, [actionsTaken, materialsUsed, downtimeHours, completingOrderId]);

  // Safety Hold modal state for unapproved PTW/JSA
  const [safetyHoldOrder, setSafetyHoldOrder] = useState<any | null>(null);

  // Active technician data
  const currentTech = activeStaff.find(t => t.userId === activeTechId);

  const [checklistStates, setChecklistStates] = useState<Record<string, Record<number, boolean>>>({});

  const handleToggleChecklist = (orderId: string, idx: number) => {
    setChecklistStates(prev => ({
      ...prev,
      [orderId]: {
        ...(prev[orderId] || {}),
        [idx]: !prev[orderId]?.[idx]
      }
    }));
  };

  const isChecklistIncomplete = (order: any) => {
    if (!order.checklist || order.checklist.length === 0) return false;
    for (let i = 0; i < order.checklist.length; i++) {
      if (!checklistStates[order.id]?.[i]) return true;
    }
    return false;
  };

  const [localPmTasks, setPmTasks] = useState<any[]>([]);

  useEffect(() => {
    if (currentTech) {
      const cleanFull = (currentTech.fullName || '').toLowerCase().trim();
      const cleanUser = (currentTech.username || '').toLowerCase().trim();
      const filtered = pmTasks.filter(pm => {
        if (pm.assigned_to_id && (pm.assigned_to_id === currentTech.userId || pm.assigned_to_id === currentTech.employeeId)) return true;
        const assignedName = (pm.assigned_to_name || '').toLowerCase().trim();
        const assignedTech = (pm.assigned_technician || '').toLowerCase().trim();
        if (assignedName && (assignedName === cleanFull || cleanFull.includes(assignedName) || assignedName.includes(cleanFull))) return true;
        if (assignedTech && (assignedTech === cleanUser || cleanFull.includes(assignedTech) || cleanUser.includes(assignedTech))) return true;
        return false;
      });
      setPmTasks(filtered);
    } else {
      setPmTasks([]);
    }
  }, [pmTasks, currentTech]);

  // Filter tickets for this technician
  const techTickets = workOrders.filter(order => {
    if (order.assignedToId === activeTechId) return true;
    if (currentTech) {
      if (order.assignedToId === currentTech.employeeId) return true;
      const cleanAssigned = (order.assignedToName || '').toLowerCase().trim();
      const cleanFull = (currentTech.fullName || '').toLowerCase().trim();
      const cleanUser = (currentTech.username || '').toLowerCase().trim();
      if (cleanAssigned && (cleanAssigned === cleanFull || cleanAssigned === cleanUser)) return true;
      if (cleanAssigned && (cleanFull.includes(cleanAssigned) || cleanAssigned.includes(cleanFull))) return true;
    }
    return false;
  });
  
  // Normalize PM Tasks to match WorkOrder shape for the UI
  const normalizedPMTasks = localPmTasks.map(pm => ({
    id: pm.id,
    timestamp: pm.scheduled_date,
    assetId: pm.asset_id,
    assetName: pm.asset_name,
    category: pm.category || 'General',
    issue: `[${pm.maintenance_type || 'PM'}] ${pm.maintenance_task}`,
    priority: pm.priority,
    assignedToId: activeTechId,
    assignedToName: pm.assigned_to_name || currentTech?.fullName,
    status: pm.status,
    loggedBy: pm.supervisor || pm.logged_by || 'System',
    isPM: true, // Custom flag to distinguish
    downtimeHours: pm.estimated_duration || 2
  }));

  const allTickets = [...techTickets, ...normalizedPMTasks];
  const pendingTickets = allTickets.filter(order => order.status !== 'Completed');
  const completedTickets = allTickets.filter(order => order.status === 'Completed');

  const handleOpenCompletionModal = (orderId: string) => {
    setCompletingOrderId(orderId);
    
    // Auto-calculate downtime
    const order = allTickets.find(t => t.id === orderId);
    let autoHrs = 1;
    if (order?.status === 'Completed' && (order as any).downtimeHours) {
      autoHrs = (order as any).downtimeHours;
    } else if (order?.timestamp) {
      const diffMs = Date.now() - new Date(order.timestamp).getTime();
      // Calculate hours and round to nearest 0.25 (15 mins), minimum 0.25
      const diffHrs = Math.max(0.25, Math.round((diffMs / (1000 * 60 * 60)) * 4) / 4);
      autoHrs = (order as any).isPM ? (order.downtimeHours || diffHrs) : diffHrs;
    }
    setDowntimeHours(autoHrs);

    if (order?.status === 'Completed') {
      setActionsTaken((order as any).actionsTaken || (order as any).remarks || '');
      setMaterialsUsed((order as any).materialsUsed || '');
    } else {
      const saved = localStorage.getItem(`dmr_draft_${orderId}`);
      if (saved) {
        try {
          const draft = JSON.parse(saved);
          setActionsTaken(draft.actionsTaken || '');
          setMaterialsUsed(draft.materialsUsed || '');
        } catch(e) {
          setActionsTaken('');
          setMaterialsUsed('');
        }
      } else {
        setActionsTaken('');
        setMaterialsUsed('');
      }
    }
  };

  const handleCompleteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!completingOrderId || !actionsTaken) {
      alert('Please fill in the actions taken during repair.');
      return;
    }
    
    const targetId = completingOrderId;
    const isPM = targetId.startsWith('PM-') || localPmTasks.some(t => t.id === targetId);

    if (isPM) {
      setPmTasks(prev => prev.map(t => t.id === targetId ? { ...t, status: 'Completed', remarks: actionsTaken, downtime_hours: downtimeHours } : t));
      try {
        await supabase.from('preventive_maintenance').update({ 
          status: 'Completed', 
          remarks: actionsTaken,
          downtime_hours: downtimeHours 
        }).eq('id', targetId);
      } catch (err) {
        console.error('Error completing PM task:', err);
      }
    }

    onCompleteWork(targetId, actionsTaken, materialsUsed, downtimeHours);
    
    localStorage.removeItem(`dmr_draft_${targetId}`);
    setCompletingOrderId(null);
  };

  const handleStartTask = async (orderId: string) => {
    const isPM = orderId.startsWith('PM-') || localPmTasks.some(t => t.id === orderId);
    if (isPM) {
      setPmTasks(prev => prev.map(t => t.id === orderId ? { ...t, status: 'In Progress' } : t));
      try {
        await supabase.from('preventive_maintenance').update({ status: 'In Progress' }).eq('id', orderId);
      } catch (err) {
        console.error('Error starting PM task:', err);
      }
      onStartWork(orderId);
      return;
    }

    // Work Order Safety Validation
    const cleanId = normalizeDocId(orderId);
    const targetOrder = pendingTickets.find(o => normalizeDocId(o.id) === cleanId) || workOrders.find(o => normalizeDocId(o.id) === cleanId);
    if (!targetOrder) return;

    // STEP 1: Fetch latest work order from database or cache to ensure state is fresh
    let latestOrder: WorkOrder = targetOrder;
    try {
      const { data: woData } = await supabase.from('work_orders').select('*').eq('id', targetOrder.id);
      if (Array.isArray(woData) && woData.length > 0) {
        latestOrder = { ...targetOrder, ...woData[0] };
      }
    } catch (_) {}

    // STEP 2: Fetch latest saved safety documents from database / persistence
    const latestDocs = await fetchLatestSafetyDocuments(targetOrder.id);

    // STEP 3: Validate against safety rules
    const validation = validateWorkOrderSafety(latestOrder, latestDocs);

    // STEP 4: If any required condition is not satisfied, show Safety Hold with specific reason
    if (!validation.canStart) {
      setSafetyHoldOrder({
        ...latestOrder,
        blockingReason: validation.blockingReason || 'Safety Hold Active',
        specificMessage: validation.specificMessage || 'Work cannot be marked as authorized to start. Required safety documents must be approved before work can commence.'
      });
      return;
    }

    // STEP 5: All required conditions satisfied! Proceed with work authorization
    setSafetyHoldOrder(null);
    try {
      await supabase.from('work_orders').update({
        status: 'In Progress',
        workAuthorized: true,
        workAuthorizedAt: new Date().toISOString(),
        workAuthorizedBy: authorizedUser || currentTech?.fullName || 'Technician'
      }).eq('id', targetOrder.id);
    } catch (e) {
      console.warn('Failed saving work authorization to database:', e);
    }

    onStartWork(targetOrder.id);
  };

  const handlePauseTask = async (orderId: string) => {
    const isPM = orderId.startsWith('PM-') || localPmTasks.some(t => t.id === orderId);
    if (isPM) {
      setPmTasks(prev => prev.map(t => t.id === orderId ? { ...t, status: 'Paused' } : t));
      try {
        await supabase.from('preventive_maintenance').update({ status: 'Paused' }).eq('id', orderId);
      } catch (err) {
        console.error('Error pausing PM task:', err);
      }
    }
    onPauseWork(orderId);
  };

  return (
    <div className="space-y-6">
      {/* Tech Stats Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 flex items-center justify-between">
          <div>
            <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Queue Priority</span>
            <span className="block font-display font-bold text-slate-800 text-xl mt-1">
              {pendingTickets.length} Jobs Active
            </span>
          </div>
          <div className="p-2 rounded-lg bg-amber-50 text-amber-600 border border-amber-100">
            <Clipboard className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 flex items-center justify-between">
          <div>
            <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">In Progress</span>
            <span className="block font-display font-bold text-slate-800 text-xl mt-1">
              {pendingTickets.filter(o => o.status === 'In Progress').length} Working
            </span>
          </div>
          <div className="p-2 rounded-lg bg-blue-50 text-blue-600 border border-blue-100">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 flex items-center justify-between">
          <div>
            <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">My Completed Log</span>
            <span className="block font-display font-bold text-slate-800 text-xl mt-1">
              {completedTickets.length} Resolved
            </span>
          </div>
          <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-100">
            <CheckCircle className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Queue Lists */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Active Ticket Queue */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden lg:col-span-8">
          <div className="px-5 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="font-display font-bold text-slate-800 text-sm md:text-base flex items-center gap-2">
                <Wrench className="w-5 h-5 text-slate-600" /> Active Workshop Assignment Queue
              </h3>
              <p className="text-xs text-slate-500">Solve pending breakdowns and report actions taken.</p>
            </div>
            <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-200">
              {pendingTickets.length} Tasks Left
            </span>
          </div>

          <div className="p-5 max-h-[500px] overflow-y-auto space-y-4">
            {pendingTickets.length === 0 ? (
              <div className="text-center py-12 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <Sparkles className="w-12 h-12 text-emerald-500 mx-auto mb-3 animate-bounce" />
                <h4 className="font-display font-semibold text-slate-600 text-sm">Workshop Queue Clear!</h4>
                <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                  You have no pending maintenance orders. Great job!
                </p>
              </div>
            ) : (
              pendingTickets.map((order, idx) => (
                <div 
                  key={`${order.id}-${idx}`} 
                  className={`border rounded-lg p-4 transition-all relative overflow-hidden bg-white ${
                    order.status === 'In Progress' ? 'border-amber-400 ring-1 ring-amber-100' : 'border-slate-200'
                  }`}
                >
                  {/* Status Ribbon indicator */}
                  <div className={`absolute top-0 right-0 h-1 w-20 ${
                    order.priority === 'High' ? 'bg-rose-500' :
                    order.priority === 'Medium' ? 'bg-amber-400' : 'bg-slate-300'
                  }`} />

                  <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2.5 py-0.5 rounded border border-slate-200">
                          {order.id}
                        </span>
                        {(order as any).isPM && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded bg-sky-50 text-sky-800 border border-sky-200">
                            <Sparkles className="w-3.5 h-3.5 text-sky-500" /> Planned Maintenance
                          </span>
                        )}
                        {order.pmScheduleId && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded bg-sky-50 text-sky-800 border border-sky-300 font-mono" title={`Linked PM Schedule: ${order.pmScheduleId}`}>
                            <ShieldCheck className="w-3.5 h-3.5 text-sky-600" /> PM: {order.pmScheduleId}
                          </span>
                        )}
                        {order.autoGenerated && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200 font-mono" title="Auto-Generated by PM Scheduler">
                            <RefreshCw className="w-3.5 h-3.5 text-indigo-600" /> Auto PM
                          </span>
                        )}
                        <span className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded ${
                          order.priority === 'High' ? 'bg-rose-50 text-rose-800 border border-rose-100' :
                          order.priority === 'Medium' ? 'bg-amber-50 text-amber-800 border border-amber-100' :
                          'bg-slate-50 text-slate-600 border border-slate-100'
                        }`}>
                          <AlertTriangle className="w-3.5 h-3.5" />
                          {order.priority} Priority
                        </span>
                        {order.status === 'In Progress' && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-200">
                            <Clock className="w-3.5 h-3.5 animate-spin" /> In Progress
                          </span>
                        )}

                        {/* Safety Status Badge */}
                        {order.safetyDocumentStatus ? (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onOpenRequireDocument && onOpenRequireDocument(order.id, order.safetyDocumentType || 'JSA');
                            }}
                            className={`inline-flex items-center gap-1.5 text-[11px] font-mono font-bold px-2 py-0.5 rounded-md border shadow-2xs hover:shadow-xs active:scale-95 active:translate-y-0.5 transition-all cursor-pointer ${
                              order.safetyDocumentStatus === 'Approved' || order.safetyDocumentStatus === 'Active'
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                                : order.safetyDocumentStatus === 'Pending Approval'
                                ? 'bg-yellow-50 text-yellow-800 border-yellow-300 hover:bg-yellow-100 animate-pulse'
                                : order.safetyDocumentStatus === 'Rejected'
                                ? 'bg-rose-50 text-rose-800 border-rose-300 hover:bg-rose-100'
                                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                            }`}
                            title={`Klik untuk lihat rekod keselamatan ${order.safetyDocumentType || 'Dokumen'}: ${order.safetyDocumentStatus}`}
                          >
                            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                            <span>{order.safetyDocumentType || 'Permit'}: {order.safetyDocumentStatus}</span>
                          </button>
                        ) : (order.priority === 'High' || order.category === 'Electrical') ? (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onOpenRequireDocument && onOpenRequireDocument(order.id, 'JSA');
                            }}
                            className="inline-flex items-center gap-1.5 text-[11px] font-semibold px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-300 hover:bg-amber-100 active:scale-95 active:translate-y-0.5 transition-all cursor-pointer shadow-2xs"
                            title="Permit & JSA Diperlukan — Klik untuk buka / lengkapkan"
                          >
                            <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
                            <span>Permit & JSA Required</span>
                          </button>
                        ) : null}

                        {/* Safety Document Quick Action Button */}
                        {onOpenRequireDocument && (
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onOpenRequireDocument(order.id, 'JSA');
                              }}
                              className="inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1 rounded-lg bg-gradient-to-b from-blue-50 to-blue-100 text-blue-900 hover:from-blue-100 hover:to-blue-200 border border-blue-400/80 hover:border-blue-500 shadow-xs hover:shadow active:scale-95 active:translate-y-0.5 transition-all cursor-pointer select-none group"
                              title="Buka / Jana Job Safety Analysis (JSA) untuk tiket ini"
                              aria-label="Job Safety Analysis (JSA)"
                            >
                              <FileText className="w-3.5 h-3.5 text-blue-600 group-hover:scale-110 transition-transform shrink-0" />
                              <span>JSA</span>
                              <span className="text-[9px] px-1.5 py-0.2 rounded font-mono font-bold bg-blue-200/90 text-blue-950 group-hover:bg-blue-300">
                                {order.safetyDocumentStatus && order.safetyDocumentType === 'JSA' ? order.safetyDocumentStatus : '+ Form'}
                              </span>
                            </button>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onOpenRequireDocument(order.id, 'PTW');
                              }}
                              className="inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1 rounded-lg bg-gradient-to-b from-amber-50 to-amber-100 text-amber-950 hover:from-amber-100 hover:to-amber-200 border border-amber-400/80 hover:border-amber-500 shadow-xs hover:shadow active:scale-95 active:translate-y-0.5 transition-all cursor-pointer select-none group"
                              title="Buka / Jana Permit to Work (PTW) untuk tiket ini"
                              aria-label="Permit to Work (PTW)"
                            >
                              <Flame className="w-3.5 h-3.5 text-amber-600 group-hover:scale-110 transition-transform shrink-0" />
                              <span>PTW</span>
                              <span className="text-[9px] px-1.5 py-0.2 rounded font-mono font-bold bg-amber-200/90 text-amber-950 group-hover:bg-amber-300">
                                {order.safetyDocumentStatus && order.safetyDocumentType === 'PTW' ? order.safetyDocumentStatus : '+ Permit'}
                              </span>
                            </button>
                          </div>
                        )}
                      </div>

                      <div>
                        <h4 className="font-display font-bold text-slate-800 text-sm flex items-center gap-2 flex-wrap">
                          <span>{order.assetName}</span>
                          <span className="text-xs font-mono font-medium text-slate-500">({order.assetId})</span>
                          {order.serialNumber && order.serialNumber !== 'N/A' && (
                            <span className="text-[11px] font-mono text-slate-400">
                              S/N: {order.serialNumber}
                            </span>
                          )}
                        </h4>
                        <div className="mt-1 flex items-center gap-1.5 text-xs text-slate-500">
                          <MapPin className="w-3.5 h-3.5 text-slate-400" />
                          <span>Location: <strong className="text-slate-700">{order.location || 'Mechanical/Industrial Lab'}</strong></span>
                        </div>
                      </div>

                      <div className="bg-slate-50 border border-slate-150 rounded-lg p-3 text-xs text-slate-700 leading-relaxed font-sans">
                        <strong className="text-slate-900 font-display block mb-0.5">{(order as any).isPM ? 'Maintenance Task:' : 'Problem Diagnosis:'}</strong>
                        {order.issue}
                      </div>

                      {(order as any).checklist && (order as any).checklist.length > 0 && (
                        <div className="mt-4 pt-3 border-t border-slate-100">
                          <h5 className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1">
                            <CheckSquare className="w-3.5 h-3.5" /> Auto-Generated Task Checklist
                          </h5>
                          <ul className="space-y-2">
                            {(order as any).checklist.map((item, idx) => (
                              <li key={idx} className="flex items-start gap-2">
                                <input 
                                  type="checkbox" 
                                  checked={!!checklistStates[order.id]?.[idx]}
                                  onChange={() => handleToggleChecklist(order.id, idx)}
                                  className="mt-0.5 w-3.5 h-3.5 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer" 
                                />
                                <span className={`text-xs ${checklistStates[order.id]?.[idx] ? 'text-slate-400 line-through' : 'text-slate-700'}`}>{item.task}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>

                    {/* Operational Actions */}
                    <div className="flex flex-col sm:flex-row md:flex-col items-stretch md:items-end gap-2 w-full md:w-auto shrink-0 justify-end pt-3 md:pt-0 border-t border-slate-100 md:border-0">
                      {order.status !== 'In Progress' ? (
                        <button
                          type="button"
                          onClick={() => handleStartTask(order.id)}
                          className="w-full sm:w-auto md:w-36 inline-flex justify-center items-center px-4 py-2.5 sm:py-2 text-xs font-bold uppercase tracking-wider text-white bg-slate-800 hover:bg-slate-950 active:scale-95 rounded-lg shadow transition-all cursor-pointer min-h-[40px]"
                        >
                          <Play className="w-3.5 h-3.5 mr-1.5" /> {order.status === 'Paused' ? 'Resume Repair' : 'Start Repair'}
                        </button>
                      ) : (
                        <>
                          <button
                            type="button"
                            onClick={() => handlePauseTask(order.id)}
                            className="w-full sm:w-auto md:w-36 inline-flex justify-center items-center px-4 py-2.5 sm:py-2 text-xs font-bold uppercase tracking-wider text-slate-700 bg-amber-100 hover:bg-amber-200 active:scale-95 rounded-lg shadow transition-all cursor-pointer border border-amber-300 min-h-[40px]"
                          >
                            <svg className="w-3.5 h-3.5 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                              <path strokeLinecap="round" strokeLinejoin="round" d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            Pause Job
                          </button>
                          <button
                            type="button"
                            onClick={() => handleOpenCompletionModal(order.id)}
                            className="w-full sm:w-auto md:w-36 inline-flex justify-center items-center px-4 py-2.5 sm:py-2 text-xs font-bold uppercase tracking-wider text-white bg-emerald-600 hover:bg-emerald-700 active:scale-95 rounded-lg shadow transition-all cursor-pointer border border-emerald-500 min-h-[40px]"
                          >
                            <Check className="w-3.5 h-3.5 mr-1.5" /> Complete Job
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Tech Resolved Activity Log */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden lg:col-span-4 flex flex-col">
          <div className="px-5 py-4 bg-slate-50 border-b border-slate-100">
            <h3 className="font-display font-bold text-slate-800 text-sm md:text-base flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-600" /> My Resolved Tickets
            </h3>
            <p className="text-xs text-slate-500">Your historical completions for key performance.</p>
          </div>

          <div className="p-5 flex-1 max-h-[500px] overflow-y-auto space-y-3">
            {completedTickets.length === 0 ? (
              <div className="text-center py-10 text-slate-400 text-xs">
                No completed tickets in this session yet. Completing tickets updates this list.
              </div>
            ) : (
              completedTickets.map((order, idx) => (
                <button 
                  key={`${order.id}-${idx}`}
                  onClick={() => handleOpenCompletionModal(order.id)}
                  className="w-full text-left p-3 bg-emerald-50 border border-emerald-100 rounded-lg hover:bg-emerald-100/60 hover:border-emerald-200 hover:shadow-sm transition-all cursor-pointer group"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-emerald-800 group-hover:text-emerald-900 transition-colors">{order.id}</span>
                    <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1 bg-white border border-emerald-100 px-2 py-0.5 rounded-full shadow-sm">
                      <Check className="w-3 h-3 text-emerald-500" /> Complete
                    </span>
                  </div>
                  <h4 className="font-display font-bold text-xs text-black mt-1.5 truncate group-hover:text-emerald-950 transition-colors">{order.assetName}</h4>
                  <p className="text-[11px] text-black mt-1 line-clamp-2">Actions: {(order as any).actionsTaken}</p>
                </button>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Completion Modal Overlay */}
      <AnimatePresence>
        {completingOrderId && (() => {
          const isCompleted = allTickets.find(o => o.id === completingOrderId)?.status === 'Completed';
          return (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50 overflow-y-auto">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-xl border border-slate-200 max-w-md w-full max-h-[90vh] overflow-y-auto shadow-2xl flex flex-col my-auto"
            >
              <div className="px-4 sm:px-5 py-3.5 sm:py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
                <h3 className="font-display font-bold text-sm md:text-base flex items-center gap-1.5">
                  <Wrench className="w-4 h-4 text-sky-400" /> {isCompleted ? 'Review Maintenance Record' : 'Submit Maintenance Record'}
                </h3>
                <span className="font-mono text-xs text-sky-300 font-bold bg-sky-950 border border-sky-800 px-2 py-0.5 rounded">
                  {completingOrderId}
                </span>
              </div>

              <form onSubmit={handleCompleteSubmit} className="p-5 space-y-4">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-150 text-xs text-slate-600 leading-normal">
                    <span className="font-semibold text-slate-800 block mb-0.5">
                    {completingOrderId?.startsWith('PM-') ? 'Maintenance Task:' : 'Diagnosed Problem:'}
                  </span>
                  {allTickets.find(o => o.id === completingOrderId)?.issue}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 uppercase tracking-wider mb-1">
                    Actions Taken / Repairs Performed <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    required
                    readOnly={isCompleted}
                    rows={3}
                    className={`block w-full rounded-lg border px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:outline-none resize-none ${isCompleted ? 'bg-slate-50 border-slate-200 cursor-default' : 'border-slate-300 focus:border-brand-500 focus:ring-1 focus:ring-brand-500'}`}
                    placeholder="e.g. Cleared debris, replaced timing belt, adjusted motor drive alignment..."
                    value={actionsTaken}
                    onChange={(e) => setActionsTaken(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 uppercase tracking-wider mb-1">
                    Spare Parts & Materials Used (Optional)
                  </label>
                  <input
                    type="text"
                    readOnly={isCompleted}
                    className={`block w-full rounded-lg border px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:outline-none ${isCompleted ? 'bg-slate-50 border-slate-200 cursor-default' : 'border-slate-300 focus:border-brand-500 focus:ring-1 focus:ring-brand-500'}`}
                    placeholder="e.g. 1x V-Belt A-42, 2L Hydraulic Oil"
                    value={materialsUsed}
                    onChange={(e) => setMaterialsUsed(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 uppercase tracking-wider mb-1 flex items-center gap-1">
                    <Clock className="w-3 h-3" /> Total Machine Downtime (Auto-Calculated)
                  </label>
                  <div className="flex items-center space-x-3">
                    <div className="relative w-full h-10 bg-slate-100 border border-slate-200 rounded-lg flex items-center px-3 cursor-not-allowed overflow-hidden">
                      <div className="h-full bg-slate-200/50 dark:bg-slate-800/50 absolute left-0 top-0 pointer-events-none" style={{ width: '100%' }}></div>
                      <span className="text-sm font-bold text-slate-500 font-mono relative z-10 flex items-center gap-2">
                        {downtimeHours} hr{downtimeHours !== 1 ? 's' : ''}
                        <span className="text-[10px] bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded uppercase tracking-widest font-sans font-bold">Auto</span>
                      </span>
                    </div>
                  </div>
                  <p className="mt-1 text-[10px] text-slate-400">Calculated automatically from ticket creation to completion time.</p>
                </div>

                <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setCompletingOrderId(null)}
                    className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
                  >
                    {isCompleted ? 'Close' : 'Cancel'}
                  </button>
                  {!isCompleted && (
                    <button
                      type="submit"
                      className="px-4 py-2 text-xs font-bold uppercase tracking-wider text-white bg-emerald-600 hover:bg-emerald-700 border border-emerald-500 rounded-lg cursor-pointer shadow"
                    >
                      Submit Record
                    </button>
                  )}
                </div>
              </form>
            </motion.div>
          </div>
          );
        })()}
      </AnimatePresence>

      {/* Safety Hold Modal for Unapproved PTW / JSA */}
      {safetyHoldOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white border-2 border-rose-500 rounded-2xl w-full max-w-md p-5 sm:p-6 shadow-2xl space-y-4 my-auto">
            <div className="flex items-start sm:items-center gap-3 text-rose-600">
              <div className="p-2.5 rounded-full bg-rose-100 shrink-0 mt-0.5 sm:mt-0">
                <ShieldAlert className="w-6 h-6 text-rose-600" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="font-display font-bold text-base text-slate-900 leading-tight">
                  SAFETY HOLD: Work Start Blocked
                </h3>
                <span className="text-[11px] font-mono font-bold text-rose-600 block mt-0.5 truncate">
                  Ticket #{safetyHoldOrder.id} — {safetyHoldOrder.assetName}
                </span>
              </div>
            </div>

            <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 space-y-2.5 text-xs text-slate-700 leading-relaxed block overflow-hidden break-words relative z-10">
              <p className="font-semibold text-rose-900">
                Work cannot be marked as authorized to start.
              </p>
              <p className="text-slate-700">
                {safetyHoldOrder.specificMessage || (
                  safetyHoldOrder.safetyDocumentStatus 
                    ? `The linked safety document is currently [${safetyHoldOrder.safetyDocumentStatus}]. Plant safety procedures prohibit commencing repair until the permit has been reviewed and approved by Management.`
                    : 'This maintenance task involves high-risk hazards (High Priority or Electrical scope) that mandate an approved Job Safety Analysis (JSA) or Permit to Work (PTW).'
                )}
              </p>
              {safetyHoldOrder.blockingReason && (
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-rose-100/90 border border-rose-300 text-[11px] font-mono font-bold text-rose-900 mt-1">
                  <span>Requirement:</span>
                  <span>{safetyHoldOrder.blockingReason}</span>
                </div>
              )}
            </div>

            <div className="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-2.5 pt-3 border-t border-rose-100">
              <button
                type="button"
                onClick={() => setSafetyHoldOrder(null)}
                className="w-full sm:w-auto px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg cursor-pointer transition-colors shrink-0 text-center"
              >
                Dismiss
              </button>
              {onOpenRequireDocument && (
                <button
                  type="button"
                  onClick={() => {
                    const id = safetyHoldOrder.id;
                    const docType = safetyHoldOrder.requiredPermitType || safetyHoldOrder.safetyDocumentType === 'JSA' ? 'JSA' : 'PTW';
                    setSafetyHoldOrder(null);
                    onOpenRequireDocument(id, docType);
                  }}
                  className="w-full sm:w-auto px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-lg shadow-sm flex items-center justify-center gap-1.5 cursor-pointer transition-all shrink-0"
                >
                  <FileText className="w-3.5 h-3.5" />
                  Open / Complete Safety Document
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
