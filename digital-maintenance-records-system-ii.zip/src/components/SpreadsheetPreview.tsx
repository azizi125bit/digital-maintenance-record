/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { WorkOrder } from '../types';
import { FileSpreadsheet, Info, ChevronDown, CheckCircle2, RefreshCw } from 'lucide-react';
import { motion } from 'motion/react';

interface SpreadsheetPreviewProps {
  workOrders: WorkOrder[];
  isRealSyncEnabled: boolean;
  onRefreshFromSheet?: () => void;
  isSyncing?: boolean;
}

export default function SpreadsheetPreview({ 
  workOrders, 
  isRealSyncEnabled, 
  onRefreshFromSheet,
  isSyncing = false
}: SpreadsheetPreviewProps) {
  const [activeTab, setActiveTab] = useState<'sheet' | 'schema'>('sheet');

  // Excel style columns map
  const columns = [
    { letter: 'A', name: 'id', label: 'id (Ticket ID)' },
    { letter: 'B', name: 'timestamp', label: 'timestamp' },
    { letter: 'C', name: 'assetId', label: 'assetId' },
    { letter: 'D', name: 'assetName', label: 'assetName' },
    { letter: 'E', name: 'category', label: 'category' },
    { letter: 'F', name: 'issue', label: 'issue' },
    { letter: 'G', name: 'priority', label: 'priority' },
    { letter: 'H', name: 'assignedToId', label: 'assignedToId' },
    { letter: 'I', name: 'assignedToName', label: 'assignedToName' },
    { letter: 'J', name: 'status', label: 'status' },
    { letter: 'K', name: 'loggedBy', label: 'loggedBy' },
    { letter: 'L', name: 'actionsTaken', label: 'actionsTaken' },
    { letter: 'M', name: 'materialsUsed', label: 'materialsUsed' },
    { letter: 'N', name: 'completedTime', label: 'completedTime' },
    { letter: 'O', name: 'downtimeHours', label: 'downtimeHours' },
  ];

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden" id="google-sheets-simulator">
      {/* Sheets Style Header */}
      <div className="bg-[#0f9d58] text-white px-4 sm:px-5 py-3 sm:py-3.5 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="bg-white/20 p-2 rounded-lg text-white shrink-0">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-display font-bold text-xs sm:text-sm md:text-base flex items-center gap-2 break-words">
              DMR_Database.xlsx - Google Sheets Preview
            </h3>
            <p className="text-[11px] text-emerald-100 font-medium">
              {isRealSyncEnabled 
                ? 'Sync Active: Streaming values straight to cloud Spreadsheet'
                : 'Offline Emulator: Local Storage active (Safe to develop offline)'
              }
            </p>
          </div>
        </div>

        {/* Refresh button if real sync */}
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {isRealSyncEnabled && onRefreshFromSheet && (
            <button
              onClick={onRefreshFromSheet}
              disabled={isSyncing}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700/50 hover:bg-emerald-700 hover:text-white transition-colors text-xs font-semibold uppercase tracking-wider text-emerald-100 disabled:opacity-50 min-h-[32px] cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              Fetch Latest Sheets Data
            </button>
          )}

          <div className="flex bg-emerald-800 rounded-lg p-0.5 border border-emerald-700">
            <button
              onClick={() => setActiveTab('sheet')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                activeTab === 'sheet' ? 'bg-white text-emerald-800 shadow-sm' : 'text-emerald-100 hover:text-white'
              }`}
            >
              Spreadsheet view
            </button>
            <button
              onClick={() => setActiveTab('schema')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                activeTab === 'schema' ? 'bg-white text-emerald-800 shadow-sm' : 'text-emerald-100 hover:text-white'
              }`}
            >
              ERD / Schema
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'sheet' ? (
        <div className="flex flex-col">
          {/* Legend instructions */}
          <div className="px-5 py-3 bg-slate-50 border-b border-slate-100 flex items-start gap-2.5 text-xs text-slate-600 leading-relaxed">
            <Info className="w-4 h-4 text-[#0f9d58] shrink-0 mt-0.5" />
            <p>
              This is a live database visualizer mimicking the structures of your <strong>Google Sheet</strong>. Whenever you dispatch tickets, assign technicians, or complete breakdowns, rows are immediately appended or cells updated here.
            </p>
          </div>

          {/* Grid Layout */}
          <div className="overflow-auto max-h-72">
            <table className="w-full border-collapse border border-slate-200 text-[11px] font-mono bg-white select-all">
              <thead>
                {/* Excel Column Letters */}
                <tr className="bg-slate-100 text-slate-500 text-center select-none divide-x divide-slate-200 border-b border-slate-200">
                  <th className="w-10 bg-slate-200 border-r border-slate-300"></th>
                  {columns.map((col, idx) => (
                    <th key={idx} className="py-1 px-3 font-semibold text-[10px] bg-slate-100 min-w-36">
                      {col.letter}
                    </th>
                  ))}
                </tr>

                {/* Database Row 1 (Header Row) */}
                <tr className="bg-slate-50 text-slate-700 text-left font-bold divide-x divide-slate-200 border-b border-slate-200 shadow-xs">
                  <td className="w-10 text-center font-bold bg-slate-200 text-slate-500 border-r border-slate-300 py-1.5">1</td>
                  {columns.map((col, idx) => (
                    <td key={idx} className="py-1.5 px-3 text-emerald-800 font-bold bg-emerald-50/40">
                      {col.name}
                    </td>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {workOrders.map((order, rowIdx) => (
                  <tr 
                    key={`${order.id}-${rowIdx}`} 
                    className="hover:bg-slate-50 divide-x divide-slate-200 text-slate-600 font-normal leading-normal text-left"
                  >
                    {/* Row numbers in excel */}
                    <td className="w-10 text-center font-bold bg-slate-200 text-slate-500 border-r border-slate-300 py-1 select-none">
                      {rowIdx + 2}
                    </td>

                    {/* Cel values mapped to column properties */}
                    <td className="py-1 px-3 font-bold text-slate-900 bg-slate-50/30">{order.id}</td>
                    <td className="py-1 px-3 text-slate-400 truncate max-w-40" title={order.timestamp}>
                      {new Date(order.timestamp).toISOString()}
                    </td>
                    <td className="py-1 px-3 text-slate-800 font-semibold">{order.assetId}</td>
                    <td className="py-1 px-3 truncate max-w-44">{order.assetName}</td>
                    <td className="py-1 px-3">{order.category}</td>
                    <td className="py-1 px-3 truncate max-w-48 text-slate-500" title={order.issue}>{order.issue}</td>
                    <td className="py-1 px-3 font-semibold">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                        order.priority === 'High' ? 'bg-rose-50 text-rose-700 font-bold' :
                        order.priority === 'Medium' ? 'bg-amber-50 text-amber-700 font-semibold' :
                        'bg-slate-50 text-slate-600'
                      }`}>
                        {order.priority}
                      </span>
                    </td>
                    <td className="py-1 px-3 text-slate-400 font-mono">{order.assignedToId}</td>
                    <td className="py-1 px-3 text-slate-800 font-semibold truncate max-w-36">{order.assignedToName}</td>
                    <td className="py-1 px-3 font-semibold">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                        order.status === 'Completed' ? 'bg-emerald-50 text-emerald-800' :
                        order.status === 'In Progress' ? 'bg-amber-50 text-amber-800' :
                        'bg-slate-50 text-slate-600'
                      }`}>
                        {order.status}
                      </span>
                    </td>
                    <td className="py-1 px-3 text-slate-500">{order.loggedBy}</td>
                    <td className="py-1 px-3 truncate max-w-48 text-slate-700" title={order.actionsTaken || ''}>
                      {order.actionsTaken || '—'}
                    </td>
                    <td className="py-1 px-3 truncate max-w-44 text-slate-600">{order.materialsUsed || '—'}</td>
                    <td className="py-1 px-3 text-slate-400 truncate max-w-40">
                      {order.completedTime ? new Date(order.completedTime).toISOString() : '—'}
                    </td>
                    <td className="py-1 px-3 text-right font-semibold text-slate-900">{order.downtimeHours || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="p-5 bg-slate-50 space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
            <h4 className="font-display font-bold text-slate-800 text-xs uppercase tracking-wider mb-3">
              Google Sheet Relational Entity Mapping (ERD)
            </h4>
            <div className="text-xs text-slate-600 space-y-3 font-sans leading-relaxed">
              <p>
                A core academic requirement of your TVET FYP project is identifying the underlying data schema mapping. In traditional CMMS, database relations link tables. Using Google Sheets, we map this flat-file schema elegantly where each row represents a complete Maintenance Work Order entry.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                <div className="border border-slate-200 rounded-lg p-3 bg-slate-50">
                  <h5 className="font-bold text-slate-800 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Active Database Keys
                  </h5>
                  <ul className="list-disc list-inside mt-2 space-y-1 text-[11px] text-slate-500">
                    <li><strong>id (Col A):</strong> Primary Key (Unique Identifier format: <code>DMR-XXXX</code>)</li>
                    <li><strong>assetId (Col C):</strong> Foreign Key (Maps to Workshop Asset Inventory)</li>
                    <li><strong>assignedToId (Col H):</strong> Foreign Key (Maps to Technical Staff Profile)</li>
                  </ul>
                </div>
                <div className="border border-slate-200 rounded-lg p-3 bg-slate-50">
                  <h5 className="font-bold text-slate-800 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Resolution Timestamps
                  </h5>
                  <ul className="list-disc list-inside mt-2 space-y-1 text-[11px] text-slate-500">
                    <li><strong>timestamp (Col B):</strong> Ticket initialization date/time signature</li>
                    <li><strong>completedTime (Col N):</strong> Ticket resolution completion date/time</li>
                    <li><strong>downtimeHours (Col O):</strong> Float value measuring total machine repair delay</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
