import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { motion } from 'motion/react';
import { WorkOrder, Technician, Asset } from '../types';
import { PMCalendar } from './PMCalendar';
import { generatePMWorkRecordPDF } from '../utils/pmPdfExport';
import { 
  Calendar, Clock, AlertTriangle, CheckCircle, HeartPulse, ShieldCheck,
  Plus, FileText, Download, CalendarDays, Search, Printer, Filter, Settings, 
  Trash2, Edit, Eye, Activity, CheckSquare, List, RefreshCw, Zap, CheckCircle2
} from 'lucide-react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer,
  PieChart, Pie, Cell, BarChart, Bar, AreaChart, Area
} from 'recharts';

const PM_DATA = {
  monthlyTrend: [] as Array<{ name: string; completed: number; scheduled: number }>,
  healthDist: [] as Array<{ name: string; value: number; color: string }>,
  deptMaint: [] as Array<{ name: string; count: number }>,
  completionRate: [] as Array<{ name: string; rate: number }>,
  upcoming: [] as any[],
  machines: [] as any[],
  schedule: [] as any[],
  activity: [] as Array<{ time: string; action: string; target: string; user: string }>
};

interface PreventiveMaintenanceViewProps {
  onAddWorkOrder: (order: Omit<WorkOrder, 'id' | 'timestamp' | 'status'>) => void;
  onAddPMTask?: (pm: any) => void;
  pmTasks?: any[];
  staffList: import('../types').Personnel[];
  technicians?: import('../types').Technician[];
  authorizedUser: string | null;
}

export const PreventiveMaintenanceView: React.FC<PreventiveMaintenanceViewProps> = ({ 
  onAddWorkOrder, 
  onAddPMTask, 
  pmTasks = [],
  technicians, 
  authorizedUser, 
  staffList 
}) => {
  const [selectedMachine, setSelectedMachine] = useState<string | null>(null);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [assetSearchQuery, setAssetSearchQuery] = useState('');
  const [showAssetDropdown, setShowAssetDropdown] = useState(false);
  const [selectedAssetForForm, setSelectedAssetForForm] = useState<Asset | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [createPmInitialDate, setCreatePmInitialDate] = useState<string | undefined>(undefined);
  const [schedules, setSchedules] = useState<any[]>(() => {
    return pmTasks || [];
  });

  useEffect(() => {
    if (pmTasks && pmTasks.length > 0) {
      setSchedules(prev => {
        const map = new Map<string, any>();
        [...pmTasks, ...prev].forEach(item => {
          if (item && item.id) map.set(item.id, item);
        });
        return Array.from(map.values());
      });
    }
  }, [pmTasks]);

  const defaultChecklist = [
    { label: 'Visual Inspection', done: true },
    { label: 'Cleaning', done: true },
    { label: 'Lubrication', done: true },
    { label: 'Bearing Inspection', done: true },
    { label: 'Motor Inspection', done: false },
    { label: 'Electrical Inspection', done: false },
    { label: 'Belt Inspection', done: false },
    { label: 'Leak Inspection', done: false },
    { label: 'Safety Check', done: false },
    { label: 'Functional Test', done: false },
  ];
  const [machineChecklists, setMachineChecklists] = useState<Record<string, { label: string, done: boolean }[]>>({});

  const currentChecklist = selectedMachine ? (machineChecklists[selectedMachine] || defaultChecklist) : [];
  const completedCount = currentChecklist.filter(i => i.done).length;
  const progressPercent = currentChecklist.length ? Math.round((completedCount / currentChecklist.length) * 100) : 0;

  const toggleChecklistItem = (idx: number) => {
    if (!selectedMachine) return;
    const newChecklist = [...currentChecklist];
    newChecklist[idx] = { ...newChecklist[idx], done: !newChecklist[idx].done };
    setMachineChecklists(prev => ({
      ...prev,
      [selectedMachine]: newChecklist
    }));
  };

  const [schedulerInfo, setSchedulerInfo] = useState<any>(null);
  const [isSyncingScheduler, setIsSyncingScheduler] = useState(false);

  const fetchPMData = async () => {
    try {
      const { data: assetsData } = await supabase.from('assets').select('*');
      if (assetsData) setAssets(assetsData as any[]);
      
      const { data, error } = await supabase.from('preventive_maintenance').select('*');
      if (!error && data) {
        const formatted = data.map(p => ({
          id: p.id,
          asset: p.asset_id,
          asset_id: p.asset_id,
          assetName: p.asset_name,
          asset_name: p.asset_name,
          machine: p.machine_name || p.asset_name || p.asset_id,
          machine_name: p.machine_name || p.asset_name || p.asset_id,
          type: p.category || p.maintenance_type || 'General',
          maintenanceType: p.category || p.maintenance_type || 'General',
          maintenance_type: p.maintenance_type || p.category || 'General',
          description: p.maintenance_task || p.issue || 'Preventive Maintenance',
          maintenance_task: p.maintenance_task || p.issue || 'Preventive Maintenance',
          priority: p.priority || 'Medium',
          frequency: p.frequency || 'Monthly',
          freq: p.frequency || 'Monthly',
          lastCompleted: p.created_at,
          nextDue: p.next_due_date || p.scheduled_date,
          next_due_date: p.next_due_date || p.scheduled_date,
          scheduled_date: p.scheduled_date || p.next_due_date,
          estimatedDuration: p.downtime_hours || p.estimated_duration || 2,
          assignedTo: p.assigned_to_name || p.assigned_technician || 'Unassigned',
          assigned_to_name: p.assigned_to_name || p.assigned_technician || 'Unassigned',
          supervisor: p.logged_by || p.supervisor || 'Management',
          safetyRequirements: p.safety_requirements || [],
          remarks: p.remarks || "",
          status: p.status || 'Pending',
          linked_work_order_id: p.linked_work_order_id || p.linkedWorkOrderId,
          linkedWorkOrderId: p.linked_work_order_id || p.linkedWorkOrderId,
          last_work_order_generated_at: p.last_work_order_generated_at
        }));
        setSchedules(formatted);
        setUpcomingMaint(formatted.filter(f => f.status !== 'Completed'));
      }
    } catch (err) {
      console.error('Failed to fetch PM schedules from Firestore:', err);
    }
  };

  const loadSchedulerStatus = async () => {
    try {
      const res = await fetch('/api/pm-scheduler/status', { headers: { Accept: 'application/json' } });
      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        const data = await res.json();
        setSchedulerInfo(data);
      }
    } catch (e) {
      // Offline fallback
    }
  };

  const handleTriggerSchedulerCheck = async () => {
    setIsSyncingScheduler(true);
    try {
      const res = await fetch('/api/pm-scheduler/trigger', { method: 'POST', headers: { Accept: 'application/json' } });
      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        const json = await res.json();
        if (json && json.status) {
          setSchedulerInfo(json.status);
        }
        await fetchPMData();
        if (json && json.result && json.result.generatedCount > 0) {
          alert(`Auto-Generated ${json.result.generatedCount} Work Order(s): ${json.result.generatedWorkOrderIds.join(', ')} based on due PM schedules!`);
        }
      }
    } catch (err) {
      console.error('Error triggering scheduler:', err);
    } finally {
      setIsSyncingScheduler(false);
    }
  };

  useEffect(() => {
    fetchPMData();
    loadSchedulerStatus();
    const interval = setInterval(() => {
      loadSchedulerStatus();
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  const [selectedScheduleId, setSelectedScheduleId] = useState<string | null>(null);
  const [upcomingMaint, setUpcomingMaint] = useState(PM_DATA.upcoming);
  const [isExportingPdf, setIsExportingPdf] = useState(false);

  const generatePDF = async (printMode = false, targetSchedule?: any) => {
    try {
      setIsExportingPdf(true);
      // Determine schedule to export: targetSchedule, or selectedScheduleId, or first in schedules
      const scheduleToExport = targetSchedule || (
        selectedScheduleId 
          ? schedules.find(s => s.id === selectedScheduleId) 
          : schedules[0]
      );

      if (!scheduleToExport && schedules.length === 0) {
        alert('No preventive maintenance record available to export.');
        return;
      }

      // Find matching asset in local assets state if available
      const targetAssetId = scheduleToExport?.asset_id || scheduleToExport?.asset;
      const matchedAsset = assets.find(a => 
        (targetAssetId && a.id === targetAssetId) || 
        a.name?.toLowerCase() === (scheduleToExport?.machine_name || scheduleToExport?.machine || scheduleToExport?.assetName)?.toLowerCase()
      );

      await generatePMWorkRecordPDF({
        pmSchedule: scheduleToExport,
        scheduleId: scheduleToExport?.id,
        printMode,
        asset: matchedAsset,
        staffList
      });
    } catch (err) {
      console.error('Failed generating PM PDF:', err);
      alert('Failed to generate PM Work Record PDF. Please check console for details.');
    } finally {
      setIsExportingPdf(false);
    }
  };

  const scrollToCalendar = () => {
    document.getElementById('maintenance-calendar')?.scrollIntoView({ behavior: 'smooth' });
  };

  const exportExcel = () => {
    const dataToExport = schedules.length > 0 ? schedules : PM_DATA.schedule;
    const headers = ["PM ID", "Asset / Machine", "Task / Type", "Frequency", "Priority", "Status", "Technician", "Due Date"];
    
    const rows = dataToExport.map(s => [
      s.id || '',
      `"${(s.machine || s.assetName || s.asset || '').replace(/"/g, '""')}"`,
      `"${(s.type || s.maintenanceType || s.description || '').replace(/"/g, '""')}"`,
      s.freq || s.frequency || 'Monthly',
      s.priority || 'Medium',
      s.status || 'Pending',
      `"${(s.tech || s.assignedTo || '').replace(/"/g, '""')}"`,
      s.nextDue || s.due || ''
    ]);

    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" 
      + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `PM-Schedules-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const StatCard = ({ icon: Icon, label, value, trend, trendColor }: any) => (
    <motion.div 
      whileHover={{ y: -5 }}
      className="bg-white backdrop-blur-md border border-slate-200 p-5 rounded-2xl shadow-lg relative overflow-hidden group"
    >
      <div className="absolute -right-4 -top-4 w-16 h-16 bg-sky-500/10 rounded-full blur-xl group-hover:bg-sky-100 transition-colors"></div>
      <div className="flex justify-between items-start mb-4">
        <div className="p-3 bg-slate-100 rounded-xl border border-slate-200 text-sky-600">
          <Icon className="w-6 h-6" />
        </div>
        <div className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${trendColor}`}>
          {trend}
        </div>
      </div>
      <div>
        <h3 className="text-3xl font-display font-bold text-slate-800 mb-1">{value}</h3>
        <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">{label}</p>
      </div>
    </motion.div>
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-500 text-slate-700">
      
      {/* HEADER */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 bg-white p-6 rounded-2xl border border-slate-200 backdrop-blur-sm">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold text-slate-800 font-display flex items-center gap-3">
            <ShieldCheck className="w-8 h-8 text-sky-600" />
            Preventive Maintenance
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Monitor preventive maintenance schedules, machine health, and maintenance performance.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 w-full xl:w-auto">
          <button onClick={scrollToCalendar} className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg border border-slate-300 transition-colors uppercase tracking-wider min-h-[38px]">
            <CalendarDays className="w-4 h-4" /> Calendar View
          </button>
          <button 
            disabled={isExportingPdf}
            onClick={() => generatePDF(false)} 
            className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg border border-slate-300 transition-colors uppercase tracking-wider min-h-[38px] disabled:opacity-50 cursor-pointer"
          >
            <FileText className="w-4 h-4 text-sky-600" />
            <span>{isExportingPdf ? 'Exporting PDF...' : 'Export PDF'}</span>
          </button>
          <button 
            disabled={isExportingPdf}
            onClick={() => generatePDF(true)} 
            className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg border border-slate-300 transition-colors uppercase tracking-wider min-h-[38px] disabled:opacity-50 cursor-pointer"
          >
            <Printer className="w-4 h-4 text-slate-600" />
            <span>Print</span>
          </button>
          <button onClick={() => { setIsCreateModalOpen(true); setSelectedAssetForForm(null); }} className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2 bg-sky-500 hover:bg-sky-400 text-white text-xs font-bold rounded-lg transition-colors shadow-lg shadow-sky-500/20 uppercase tracking-wider min-h-[38px]">
            <Plus className="w-4 h-4" /> Create PM Schedule
          </button>
        </div>
      </div>

      {/* KPI SUMMARY CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard icon={Calendar} label="Total PM Schedule" value="245" trend="+12%" trendColor="text-emerald-600 bg-emerald-400/10 border border-emerald-500/20" />
        <StatCard icon={Clock} label="Due Today" value="18" trend="+3" trendColor="text-amber-600 bg-amber-400/10 border border-amber-500/20" />
        <StatCard icon={AlertTriangle} label="Overdue Maintenance" value="5" trend="-2" trendColor="text-rose-600 bg-rose-400/10 border border-rose-500/20" />
        <StatCard icon={CheckCircle} label="Completed This Month" value="196" trend="+8%" trendColor="text-emerald-600 bg-emerald-400/10 border border-emerald-500/20" />
        <StatCard icon={HeartPulse} label="Machine Health" value="94%" trend="+1.2%" trendColor="text-emerald-600 bg-emerald-400/10 border border-emerald-500/20" />
        <StatCard icon={ShieldCheck} label="PM Compliance" value="97%" trend="+0.5%" trendColor="text-sky-600 bg-sky-400/10 border border-sky-500/20" />
      </div>

      
      {/* INTERACTIVE CALENDAR */}
      <div id="maintenance-calendar" className="scroll-mt-24">
        <PMCalendar 
          staffList={staffList} 
          authorizedUser={authorizedUser} 
          schedules={schedules}
          onAddWorkOrder={onAddWorkOrder}
          onAddPMClick={(date) => {
            setCreatePmInitialDate(date);
            setIsCreateModalOpen(true);
          }}
          onViewPMClick={(pm) => {
            setSelectedScheduleId(pm.id);
          }}
        />
      </div>

      {/* UPCOMING MAINTENANCE */}
      <div className="bg-white backdrop-blur-md border border-slate-200 rounded-2xl p-5 shadow-lg flex flex-col mt-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-600" /> Upcoming Maintenance
          </h3>
          <button className="text-[10px] bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 font-bold uppercase tracking-wider transition-colors">View All</button>
        </div>
        <div className="overflow-x-auto flex-1">
          <table className="w-full text-left text-sm whitespace-nowrap">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 uppercase tracking-wider text-[10px] font-bold bg-slate-100/30">
                <th className="py-3 px-3 rounded-tl-lg">Machine</th>
                <th className="py-3 px-3">Task</th>
                <th className="py-3 px-3">Freq</th>
                <th className="py-3 px-3">Due Date</th>
                <th className="py-3 px-3">Tech</th>
                <th className="py-3 px-3">Priority</th>
                <th className="py-3 px-3 rounded-tr-lg">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {upcomingMaint.slice(0, 5).map((pm, i) => (
                <tr key={i} className="hover:bg-slate-100/30 transition-colors text-xs font-medium">
                  <td className="py-3 px-3 text-slate-700">{pm.machine}</td>
                  <td className="py-3 px-3 text-slate-500">{pm.type}</td>
                  <td className="py-3 px-3 text-slate-500">{pm.freq}</td>
                  <td className="py-3 px-3 text-slate-700">{pm.due || pm.nextDue}</td>
                  <td className="py-3 px-3 text-slate-500">{pm.tech}</td>
                  <td className="py-3 px-3">
                    <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${
                      pm.priority === 'High' ? 'bg-rose-100 text-rose-700' :
                      pm.priority === 'Medium' ? 'bg-amber-100 text-amber-700' :
                      'bg-emerald-100 text-emerald-700'
                    }`}>
                      {pm.priority}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${
                      pm.status === 'Completed' ? 'bg-emerald-100 text-emerald-700' :
                      pm.status === 'In Progress' ? 'bg-amber-100 text-amber-700' :
                      pm.status === 'Overdue' ? 'bg-rose-100 text-rose-700' :
                      'bg-slate-100 text-slate-700'
                    }`}>
                      {pm.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        
        {/* PREVENTIVE MAINTENANCE SCHEDULE TABLE */}
        <div className="xl:col-span-3 bg-white backdrop-blur-md border border-slate-200 rounded-2xl p-5 shadow-lg flex flex-col">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4 border-b border-slate-200 pb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
                <Calendar className="w-5 h-5 text-sky-600" /> PM Schedule
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">Automated Work Order generation based on scheduled maintenance due dates.</p>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={handleTriggerSchedulerCheck}
                disabled={isSyncingScheduler}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-300 rounded-lg text-xs font-semibold transition-all cursor-pointer shadow-2xs disabled:opacity-60"
                title="Trigger immediate PM due date check in Asia/Kuala_Lumpur timezone"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-sky-600 ${isSyncingScheduler ? 'animate-spin' : ''}`} />
                <span>{isSyncingScheduler ? 'Checking Due PMs...' : 'Check Due PMs Now'}</span>
              </button>
              <div className="relative">
                <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input 
                  type="text" 
                  placeholder="Search schedules..." 
                  className="pl-9 pr-4 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:border-sky-500 w-full sm:w-48 transition-colors"
                />
              </div>
              <button className="p-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg text-slate-600 transition-colors">
                <Filter className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* AUTO WORK ORDER ENGINE STATUS BANNER */}
          {(() => {
            const isEngineActive = schedulerInfo ? schedulerInfo.active !== false : true;
            return (
              <div className="auto-wo-engine-card mb-4 p-3 sm:p-3.5 bg-slate-900 border border-slate-800 rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs shadow-xs transition-colors">
                <div className="flex flex-wrap items-center gap-2.5 min-w-0">
                  <span className="relative flex h-2.5 w-2.5 shrink-0" aria-label={`Engine Status: ${isEngineActive ? 'Active' : 'Standby'}`}>
                    {isEngineActive && (
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    )}
                    <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${isEngineActive ? 'bg-emerald-500' : 'bg-slate-500'}`}></span>
                  </span>
                  <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
                    <span className="font-semibold text-slate-100 flex items-center gap-1.5">
                      Auto Work Order Engine:
                      <span className={isEngineActive ? 'text-emerald-400 font-bold' : 'text-slate-400 font-medium'}>
                        {isEngineActive ? 'Active' : 'Standby'}
                      </span>
                    </span>
                    <span className="hidden sm:inline text-slate-600">|</span>
                    <span className="text-slate-400">
                      Timezone: <strong className="text-slate-200 font-medium">Asia/Kuala_Lumpur (GMT+8)</strong>
                    </span>
                    {schedulerInfo?.currentTimeInKL && (
                      <span className="text-slate-400">
                        <span className="hidden sm:inline text-slate-600 mr-2">|</span>
                        KL Time: <strong className="text-sky-400 font-mono font-medium">{schedulerInfo.currentTimeInKL}</strong>
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-3 sm:gap-4 text-[11px] shrink-0">
                  <span className="text-slate-400">
                    Interval: <strong className="text-slate-200 font-medium">{schedulerInfo?.intervalSeconds ? `Every ${schedulerInfo.intervalSeconds}s` : 'Every 60s'}</strong>
                  </span>
                  <span className="text-slate-400">
                    Total Auto-Generated: <strong className="text-sky-400 font-bold">{schedulerInfo?.totalGeneratedSinceStart ?? 0}</strong>
                  </span>
                </div>
              </div>
            );
          })()}
          
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm whitespace-nowrap">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 uppercase tracking-wider text-[10px] font-bold bg-slate-100/30">
                  <th className="py-3 px-3 rounded-tl-lg w-10"></th>
                  <th className="py-3 px-3">PM Number</th>
                  <th className="py-3 px-3">Linked Work Order</th>
                  <th className="py-3 px-3">Machine</th>
                  <th className="py-3 px-3">Type</th>
                  <th className="py-3 px-3">Freq</th>
                  <th className="py-3 px-3">Next Due</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-3 rounded-tr-lg text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {schedules.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="text-center py-10 text-slate-400">
                      No preventive maintenance schedules available.
                    </td>
                  </tr>
                ) : (
                  schedules.map((row, i) => (
                    <tr key={i} className="hover:bg-slate-100/30 transition-colors text-xs font-medium group">
                      <td className="py-3 px-3">
                        <input 
                          type="radio" 
                          name="pm-select" 
                          checked={selectedScheduleId === row.id}
                          onChange={() => setSelectedScheduleId(row.id)}
                          className="w-4 h-4 text-sky-600 border-slate-300 focus:ring-sky-500 cursor-pointer"
                        />
                      </td>
                      <td className="py-3 px-3 text-sky-600 font-mono font-bold">{row.id}</td>
                      <td className="py-3 px-3">
                        {row.linked_work_order_id || row.linkedWorkOrderId ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-sky-50 text-sky-800 border border-sky-300 shadow-2xs">
                            <CheckCircle2 className="w-3 h-3 text-sky-600" />
                            {row.linked_work_order_id || row.linkedWorkOrderId}
                          </span>
                        ) : (
                          <span className="text-[11px] text-slate-400 italic">Auto-generates when due</span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-slate-700 font-semibold">{row.machine || row.machine_name || row.asset_name}</td>
                      <td className="py-3 px-3 text-slate-500">{row.type || row.maintenance_type || 'Routine'}</td>
                      <td className="py-3 px-3 text-slate-500">{row.freq || row.frequency || 'Monthly'}</td>
                      <td className="py-3 px-3 text-slate-700 font-mono">{row.nextDue || row.next_due_date || row.scheduled_date}</td>
                      <td className="py-3 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          row.status === 'Overdue' ? 'bg-rose-500/10 text-rose-600 border border-rose-500/20' :
                          row.status === 'In Progress' ? 'bg-amber-500/10 text-amber-600 border border-amber-500/20' :
                          row.status === 'Scheduled' ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20' :
                          'bg-slate-100 text-slate-600 border border-slate-300'
                        }`}>
                          {row.status}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right">
                        <div className="flex items-center justify-end gap-1 sm:gap-2 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
                          <button onClick={() => generatePDF(false, row)} className="p-1.5 hover:bg-slate-200 rounded text-slate-500 hover:text-sky-600 cursor-pointer" title="Export PDF Work Record"><FileText className="w-3.5 h-3.5" /></button>
                          <button onClick={() => generatePDF(true, row)} className="p-1.5 hover:bg-slate-200 rounded text-slate-500 hover:text-slate-800 cursor-pointer" title="Print Work Record"><Printer className="w-3.5 h-3.5" /></button>
                          <button onClick={() => setSelectedScheduleId(row.id)} className="p-1.5 hover:bg-slate-200 rounded text-slate-500 hover:text-sky-600 cursor-pointer" title="Select"><Eye className="w-3.5 h-3.5" /></button>
                          <button className="p-1.5 hover:bg-slate-200 rounded text-slate-500 hover:text-rose-600 cursor-pointer" title="Delete"><Trash2 className="w-3.5 h-3.5" /></button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          <div className="mt-4 pt-4 border-t border-slate-200 flex justify-between items-center text-[10px] font-bold uppercase tracking-wider text-slate-500">
            <span>Showing {schedules.length === 0 ? '0' : `1 to ${schedules.length}`} of {schedules.length} entries</span>
            <div className="flex gap-1">
              <button disabled className="px-2 py-1 border border-slate-200 rounded hover:bg-slate-100 disabled:opacity-50">Prev</button>
              <button className="px-2 py-1 border border-sky-500 bg-sky-500/10 text-sky-600 rounded">1</button>
              <button disabled className="px-2 py-1 border border-slate-200 rounded hover:bg-slate-100 disabled:opacity-50">Next</button>
            </div>
          </div>
        </div>

        {/* RECENT ACTIVITY TIMELINE */}
        <div className="xl:col-span-1 bg-white backdrop-blur-md border border-slate-200 rounded-2xl p-5 shadow-lg flex flex-col">
          <h3 className="text-sm font-bold text-slate-600 uppercase tracking-wider mb-4 border-b border-slate-200 pb-4">
            Recent Activity
          </h3>
          <div className="flex-1 space-y-4">
            {PM_DATA.activity.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center">No recent maintenance activity.</p>
            ) : (
              PM_DATA.activity.map((act, i) => (
                <div key={i} className="flex gap-3 relative">
                  {i !== PM_DATA.activity.length - 1 && (
                    <div className="absolute left-[9px] top-6 bottom-[-16px] w-[2px] bg-slate-100"></div>
                  )}
                  <div className="w-5 h-5 rounded-full bg-slate-100 border-2 border-slate-300 shrink-0 z-10 flex items-center justify-center mt-0.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-slate-400"></div>
                  </div>
                  <div>
                    <p className="text-xs text-slate-700 font-medium">{act.action}</p>
                    <p className="text-[10px] font-bold text-sky-600 uppercase tracking-wider my-0.5">{act.target}</p>
                    <p className="text-[10px] text-slate-500">{act.time} • By {act.user}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

      {/* Checklist Modal Overlay */}
      {selectedMachine && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white border border-slate-200 shadow-2xl rounded-2xl w-full max-w-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center p-5 border-b border-slate-200 bg-white/90">
              <div>
                <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2 font-display">
                  <ShieldCheck className="w-5 h-5 text-sky-600" /> Maintenance Checklist
                </h2>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-wider mt-1">Machine ID: {selectedMachine}</p>
              </div>
              <button onClick={() => setSelectedMachine(null)} className="text-slate-500 hover:text-slate-800 p-2">✕</button>
            </div>
            <div className="p-6 bg-slate-50">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-500 font-bold uppercase tracking-wider text-[10px]">Overall Progress</span>
                <span className="text-sky-600 font-bold text-xs">{progressPercent}% Completed</span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden mb-6 shadow-inner">
                <div className="h-full rounded-full bg-sky-500 shadow-[0_0_10px_rgba(14,165,233,0.5)] transition-all duration-300" style={{ width: `${progressPercent}%` }}></div>
              </div>
              
              <div className="space-y-2.5 max-h-[40vh] overflow-y-auto pr-2 custom-scrollbar">
                {currentChecklist.map((item, idx) => (
                  <div key={idx} onClick={() => toggleChecklistItem(idx)} role="button" tabIndex={0} className={`flex items-center gap-3 p-3.5 rounded-xl border transition-all cursor-pointer select-none ${
                    item.done 
                      ? 'bg-emerald-50 border-emerald-200 text-slate-500' 
                      : 'bg-white border-slate-200 hover:border-sky-500/30 text-slate-700 shadow-md'
                  }`}>
                    <div className={`w-5 h-5 rounded border flex items-center justify-center shrink-0 transition-colors ${
                      item.done ? 'bg-emerald-500 border-emerald-500' : 'border-slate-300 bg-slate-100'
                    }`}>
                      {item.done && <CheckSquare className="w-3 h-3 text-slate-800" />}
                    </div>
                    <span className={`text-sm font-medium ${item.done ? 'line-through opacity-70' : ''}`}>{item.label}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="p-5 border-t border-slate-200 bg-white/80 flex justify-end gap-3 backdrop-blur-md">
              <button onClick={() => setSelectedMachine(null)} className="px-5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors">Close</button>
              <button onClick={() => setSelectedMachine(null)} className="px-5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider bg-sky-500 hover:bg-sky-400 text-white transition-colors shadow-lg shadow-sky-500/20">Save Progress</button>
            </div>
          </div>
        </div>
      )}



      {/* Create PM Schedule Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center p-2 sm:p-4 md:p-8 bg-slate-900/40 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white border border-slate-200 shadow-2xl rounded-2xl w-full max-w-5xl animate-in zoom-in-95 duration-200 my-auto sm:my-8 max-h-[92vh] flex flex-col overflow-hidden">
            <div className="flex justify-between items-center p-4 sm:p-6 border-b border-slate-200 bg-white rounded-t-2xl shrink-0">
              <div>
                <h2 className="text-lg sm:text-xl font-bold text-slate-800 flex items-center gap-2 font-display">
                  <ShieldCheck className="w-5 h-5 sm:w-6 sm:h-6 text-sky-600 shrink-0" /> Create Preventive Maintenance Schedule
                </h2>
                <p className="text-xs text-slate-500 mt-1">Configure automated maintenance routines and safety requirements.</p>
              </div>
              <button onClick={() => { setIsCreateModalOpen(false); setSelectedAssetForForm(null); }} className="text-slate-500 hover:text-slate-800 p-2 cursor-pointer">✕</button>
            </div>
            
            <form onSubmit={async (e) => {
              e.preventDefault();
              const form = e.target as any;
              const type = form.maintType.value;
              const freq = form.frequency.value;
              const machine = form.machine.value;
              const asset_id = form.asset_id?.value || 'A-01';
              const tech = form.tech.value;

              // Check for duplicate active PM schedules for this asset
              const hasActivePM = schedules.some(
                (pm: any) => pm.asset_id === asset_id && pm.category === type && pm.status !== 'Completed'
              );
              
              if (hasActivePM) {
                alert('There is already an active preventive maintenance task of this category scheduled for this asset.');
                return;
              }
              
              const locationVal = form.location?.value || selectedAssetForForm?.location || '';
              const instructionsVal = form.instructions?.value || '';
              const partsVal = form.partsAndTools?.value || '';

              const newPM = {
                id: 'PM-' + Math.floor(Math.random() * 10000),
                asset_id: asset_id,
                asset_name: machine,
                machine_name: machine,
                category: type,
                maintenance_type: type,
                maintenance_task: form.scheduleName?.value || form.maintType?.value || 'Preventive Maintenance',
                frequency: freq,
                next_due_date: form.startDate.value,
                scheduled_date: form.startDate.value,
                scheduled_time: '09:00 AM',
                assigned_to_name: tech,
                assigned_technician: tech,
                logged_by: form.supervisor?.value || authorizedUser,
                supervisor: form.supervisor?.value || authorizedUser,
                status: 'Pending',
                priority: form.priority.value,
                downtime_hours: parseFloat(form.estimatedDuration?.value || '2'),
                estimated_duration: parseFloat(form.estimatedDuration?.value || '2'),
                location: locationVal,
                checklist_instructions: instructionsVal,
                tools_and_materials: partsVal,
                tools: partsVal
              };
              
              try {
                const { error } = await supabase.from('preventive_maintenance').insert([newPM]);
                if (error) console.error('Error saving PM to Firestore', error);
                
                // Immediately notify server PM scheduler to generate work order if due today
                try {
                  await fetch('/api/pm-scheduler/trigger', { method: 'POST' });
                  await fetchPMData();
                } catch (trigErr) {}
              } catch (err) {
                console.error('Failed to insert PM schedule into Firestore:', err);
              }
              
              if (onAddPMTask) {
                onAddPMTask(newPM);
              }
              
              // update local state
              setSchedules(prev => [newPM as any, ...prev]);
              setUpcomingMaint(prev => [{
                id: newPM.id,
                machine: newPM.asset_name,
                type: newPM.category,
                freq: newPM.frequency,
                due: newPM.next_due_date,
                tech: newPM.assigned_to_name,
                priority: newPM.priority,
                status: 'Pending'
              }, ...prev]);
                 
              alert(`PM Schedule created successfully for ${newPM.scheduled_date}.`);
              setIsCreateModalOpen(false);
            }} className="flex flex-col flex-1 overflow-hidden">
              
              <div className="p-4 sm:p-6 md:p-8 flex-1 overflow-y-auto">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 mb-8">
                
                {/* General Info */}
                <div className="space-y-6 lg:col-span-1">
                  <h4 className="text-sm font-bold text-sky-600 uppercase tracking-wider border-b border-slate-200 pb-2">General</h4>
                  
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Schedule ID (Auto)</label>
                    <input type="text" readOnly value="PM-AUTO" className="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm text-slate-500 cursor-not-allowed" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Schedule Name</label>
                    <input required name="scheduleName" type="text" placeholder="e.g. Monthly CNC Calibration" className="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm text-slate-700 focus:border-sky-500 focus:outline-none" />
                  </div>
                  <div className="relative">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Asset Selection</label>
                    <div className="relative">
                      <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                      <input 
                        type="text" 
                        required={!selectedAssetForForm}
                        value={showAssetDropdown ? assetSearchQuery : (selectedAssetForForm ? selectedAssetForForm.name : '')}
                        onChange={(e) => {
                          setAssetSearchQuery(e.target.value);
                          setShowAssetDropdown(true);
                          if (!e.target.value) setSelectedAssetForForm(null);
                        }}
                        onFocus={() => setShowAssetDropdown(true)}
                        onBlur={() => setTimeout(() => setShowAssetDropdown(false), 200)}
                        placeholder="Search by asset name or ID..." 
                        className="w-full pl-9 bg-white border border-slate-200 rounded-lg p-2 text-sm text-slate-700 focus:border-sky-500 focus:outline-none" 
                      />
                      <input type="hidden" name="machine" value={selectedAssetForForm?.name || ''} />
                      <input type="hidden" name="asset_id" value={selectedAssetForForm?.id || ''} />
                    </div>
                    {showAssetDropdown && (
                      <div className="absolute z-10 w-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg max-h-48 overflow-y-auto">
                        {assets.filter(a => a.name.toLowerCase().includes(assetSearchQuery.toLowerCase()) || a.id.toLowerCase().includes(assetSearchQuery.toLowerCase())).map(asset => (
                          <div 
                            key={asset.id}
                            className="px-4 py-2 hover:bg-slate-50 cursor-pointer text-sm"
                            onClick={() => {
                              setSelectedAssetForForm(asset);
                              setAssetSearchQuery('');
                              setShowAssetDropdown(false);
                            }}
                          >
                            <div className="font-bold text-slate-700">{asset.name}</div>
                            <div className="text-xs text-slate-500 font-mono">{asset.id}</div>
                          </div>
                        ))}
                        {assets.length > 0 && assets.filter(a => a.name.toLowerCase().includes(assetSearchQuery.toLowerCase()) || a.id.toLowerCase().includes(assetSearchQuery.toLowerCase())).length === 0 && (
                          <div className="px-4 py-2 text-sm text-slate-500">No assets found</div>
                        )}
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Department / Location</label>
                    <input name="location" type="text" placeholder="e.g. Machining / Zone A" className="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm text-slate-700 focus:border-sky-500 focus:outline-none" />
                  </div>
                </div>

                {/* Scheduling */}
                <div className="space-y-6 lg:col-span-1">
                  <h4 className="text-sm font-bold text-amber-600 uppercase tracking-wider border-b border-slate-200 pb-2">Scheduling</h4>
                  
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Maintenance Type</label>
                    <select required name="maintType" className="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm text-slate-700 focus:border-amber-500 focus:outline-none">
                      <option value="Inspection">Inspection</option>
                      <option value="Calibration">Calibration</option>
                      <option value="Lubrication">Lubrication</option>
                      <option value="Part Replacement">Part Replacement</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Frequency</label>
                    <select required name="frequency" className="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm text-slate-700 focus:border-amber-500 focus:outline-none">
                      <option value="Daily">Daily</option>
                      <option value="Weekly">Weekly</option>
                      <option value="Monthly">Monthly</option>
                      <option value="Quarterly">Quarterly</option>
                      <option value="Yearly">Yearly</option>
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Start Date</label>
                      <input required name="startDate" type="date" defaultValue={createPmInitialDate} className="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm text-slate-700 focus:border-amber-500 focus:outline-none" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Est. Duration (hrs)</label>
                      <input required name="estimatedDuration" type="number" min="0.5" step="0.5" defaultValue="2" className="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm text-slate-700 focus:border-amber-500 focus:outline-none" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Priority</label>
                    <select required name="priority" className="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm text-slate-700 focus:border-amber-500 focus:outline-none">
                      <option value="High">High</option>
                      <option value="Medium">Medium</option>
                      <option value="Low">Low</option>
                    </select>
                  </div>
                </div>

                {/* Assignment & Execution */}
                <div className="space-y-6 lg:col-span-1">
                  <h4 className="text-sm font-bold text-emerald-600 uppercase tracking-wider border-b border-slate-200 pb-2">Execution</h4>
                  
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Assigned Technician</label>
                    <select required name="tech" className="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm text-slate-700 focus:border-emerald-500 focus:outline-none">
                      <option value="">Select Technician...</option>
                      {staffList
                        .filter(s => s.role === 'Technician')
                        .filter((t, idx, arr) => arr.findIndex(x => (x.userId && x.userId === t.userId) || (x.fullName && x.fullName === t.fullName)) === idx)
                        .map((t, idx) => (
                          <option key={`${t.userId || t.fullName}-${idx}`} value={t.fullName}>{t.fullName} ({t.department})</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Supervisor</label>
                    <input type="text" name="supervisor" defaultValue={authorizedUser || ''} className="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm text-slate-700 focus:border-emerald-500 focus:outline-none" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Safety Requirements</label>
                    <div className="space-y-2 mt-2">
                      <label className="flex items-center gap-2 text-sm text-slate-600"><input type="checkbox" className="w-4 h-4 rounded border-slate-300 bg-white text-sky-500" /> Lockout/Tagout (LOTO)</label>
                      <label className="flex items-center gap-2 text-sm text-slate-600"><input type="checkbox" className="w-4 h-4 rounded border-slate-300 bg-white text-sky-500" /> PPE Required</label>
                      <label className="flex items-center gap-2 text-sm text-slate-600"><input type="checkbox" className="w-4 h-4 rounded border-slate-300 bg-white text-sky-500" /> Permit to Work</label>
                    </div>
                  </div>
                </div>

              </div>

              {/* Extra Details */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mb-8">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Checklist & Instructions</label>
                  <textarea name="instructions" rows={4} className="w-full bg-white border border-slate-200 rounded-lg p-3 text-sm text-slate-700 focus:border-sky-500 focus:outline-none custom-scrollbar" placeholder="- Visual inspection&#10;- Lubricate bearings&#10;- Test functionality"></textarea>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Required Spare Parts & Tools</label>
                  <textarea name="partsAndTools" rows={4} className="w-full bg-white border border-slate-200 rounded-lg p-3 text-sm text-slate-700 focus:border-sky-500 focus:outline-none custom-scrollbar" placeholder="Parts: Filter pack, ISO 68 Oil&#10;Tools: Wrench set, Multimeter"></textarea>
                </div>
              </div>
              </div>

              <div className="flex flex-col-reverse sm:flex-row justify-between items-stretch sm:items-center gap-3 p-4 sm:p-6 border-t border-slate-200 bg-white rounded-b-2xl shrink-0 mt-4">
                <button type="reset" className="px-5 py-2.5 rounded-lg text-sm font-bold text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors text-center cursor-pointer min-h-[40px]">Reset</button>
                <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
                  <button type="button" onClick={() => { setIsCreateModalOpen(false); setSelectedAssetForForm(null); }} className="flex-1 sm:flex-initial px-5 py-2.5 rounded-lg text-sm font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors text-center cursor-pointer min-h-[40px]">Save Draft</button>
                  <button type="submit" className="flex-1 sm:flex-initial px-6 py-2.5 rounded-lg text-sm font-bold text-white bg-sky-500 hover:bg-sky-400 shadow-lg shadow-sky-500/20 transition-colors text-center cursor-pointer min-h-[40px]">Save Schedule</button>
                </div>
              </div>

            </form>
          </div>
        </div>
      )}


    </div>
  );
};
