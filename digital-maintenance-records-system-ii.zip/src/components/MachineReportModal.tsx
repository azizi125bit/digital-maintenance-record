import React, { useState, useMemo, useRef } from 'react';
import { Asset, UserRole } from '../types';
import { UnifiedMaintenanceRecord } from './MaintenanceRecordsView';
import { 
  generateMachineMaintenanceReportPDF, 
  MachineReportSectionOptions 
} from '../utils/machineMaintenanceReportPdf';
import { 
  FileText, 
  Download, 
  Printer, 
  Eye, 
  X, 
  Calendar, 
  Wrench, 
  CheckSquare, 
  Square, 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  SlidersHorizontal,
  ChevronDown,
  Layers,
  ArrowLeft,
  FileCheck,
  ShieldCheck,
  User,
  MapPin,
  Tag,
  Building,
  RefreshCw,
  Info
} from 'lucide-react';

interface MachineReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  assets: Asset[];
  initialAssetId?: string;
  rawPms: any[];
  rawBreakdowns: any[];
  rawWorkOrders: any[];
  currentRole: UserRole;
  authorizedUser: string;
}

export const MachineReportModal: React.FC<MachineReportModalProps> = ({
  isOpen,
  onClose,
  assets,
  initialAssetId,
  rawPms,
  rawBreakdowns,
  rawWorkOrders,
  currentRole,
  authorizedUser
}) => {
  // Machine Selection
  const [selectedMachineId, setSelectedMachineId] = useState<string>(() => {
    return initialAssetId || (assets.length > 0 ? assets[0].id : '');
  });

  // Reporting Period
  const [periodType, setPeriodType] = useState<'all' | 'this_month' | 'last_month' | 'custom'>('all');
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');

  // Report Content Checkbox Options
  const [sections, setSections] = useState<MachineReportSectionOptions>({
    machineInfo: true,
    maintenanceSummary: true,
    maintenanceHistory: true,
    preventiveMaintenance: true,
    correctiveMaintenance: true,
    checklist: true,
    measurements: true,
    technicianTools: true,
    findingsActions: true,
    downtimeSummary: true,
    verification: true
  });

  // View Mode: 'config' or 'preview'
  const [viewMode, setViewMode] = useState<'config' | 'preview'>('config');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [imgErrorMap, setImgErrorMap] = useState<Record<string, boolean>>({});

  // Sync initial asset if modal reopens
  React.useEffect(() => {
    if (initialAssetId && assets.some(a => a.id === initialAssetId)) {
      setSelectedMachineId(initialAssetId);
    } else if (!selectedMachineId && assets.length > 0) {
      setSelectedMachineId(assets[0].id);
    }
  }, [initialAssetId, isOpen, assets]);

  // Selected Machine Object
  const selectedMachine = useMemo(() => {
    return assets.find(a => a.id === selectedMachineId) || null;
  }, [assets, selectedMachineId]);

  // Determine Date Range Label & Filter Boundaries
  const { periodLabel, startDate, endDate } = useMemo(() => {
    const now = new Date();
    const curYear = now.getFullYear();
    const curMonth = now.getMonth(); // 0-indexed

    if (periodType === 'this_month') {
      const start = new Date(curYear, curMonth, 1);
      const end = new Date(curYear, curMonth + 1, 0, 23, 59, 59);
      const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      return {
        periodLabel: `${monthNames[curMonth]} ${curYear}`,
        startDate: start,
        endDate: end
      };
    }

    if (periodType === 'last_month') {
      const start = new Date(curYear, curMonth - 1, 1);
      const end = new Date(curYear, curMonth, 0, 23, 59, 59);
      const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      const prevMonthIdx = curMonth === 0 ? 11 : curMonth - 1;
      const prevYear = curMonth === 0 ? curYear - 1 : curYear;
      return {
        periodLabel: `${monthNames[prevMonthIdx]} ${prevYear}`,
        startDate: start,
        endDate: end
      };
    }

    if (periodType === 'custom') {
      const start = dateFrom ? new Date(dateFrom) : null;
      const end = dateTo ? new Date(dateTo) : null;
      let label = 'Custom Range';
      if (dateFrom && dateTo) label = `${dateFrom} to ${dateTo}`;
      else if (dateFrom) label = `From ${dateFrom}`;
      else if (dateTo) label = `Up to ${dateTo}`;

      return {
        periodLabel: label,
        startDate: start,
        endDate: end
      };
    }

    // Default 'all'
    return {
      periodLabel: 'All Maintenance Records (All Time)',
      startDate: null,
      endDate: null
    };
  }, [periodType, dateFrom, dateTo]);

  // Unified Maintenance Records strictly for selected machine & period
  const machineRecords = useMemo(() => {
    if (!selectedMachineId) return [];

    const targetId = selectedMachineId.trim().toLowerCase();
    const result: UnifiedMaintenanceRecord[] = [];
    const seenRecordKeys = new Set<string>();

    // 1. PM Schedules
    for (const pm of rawPms) {
      const pmAssetId = String(pm.asset_id || pm.assetId || pm.asset || '').trim().toLowerCase();
      if (pmAssetId === targetId) {
        const recId = String(pm.id || `PM-${pm.scheduled_date || Date.now()}`);
        const dateStr = pm.scheduled_date || pm.startDate || pm.created_at || '';
        
        // Date range filter
        if (startDate || endDate) {
          const recDate = new Date(dateStr).getTime();
          if (!isNaN(recDate)) {
            if (startDate && recDate < startDate.getTime()) continue;
            if (endDate && recDate > endDate.getTime()) continue;
          }
        }

        let checklistArr: any[] = [];
        if (Array.isArray(pm.checklist)) checklistArr = pm.checklist;
        else if (Array.isArray(pm.safety_requirements)) {
          checklistArr = pm.safety_requirements.map((s: string) => ({ task: s, status: 'OK', remarks: 'Standard' }));
        }

        const taskDesc = pm.maintenance_task || pm.task_description || pm.description || 'Scheduled preventive maintenance service';

        result.push({
          id: recId,
          recordType: 'Preventive Maintenance',
          assetId: selectedMachineId,
          assetName: selectedMachine?.name || pm.machine_name || selectedMachineId,
          serialNumber: selectedMachine?.serialNumber || pm.serial_number || '',
          date: dateStr,
          time: pm.scheduled_time || '',
          workOrderId: pm.linked_work_order_id || pm.id,
          technician: pm.assigned_technician || pm.technician || 'Assigned Technician',
          technicianId: pm.technician_id || '',
          status: pm.status || 'Completed',
          maintenanceDescription: taskDesc,
          findings: pm.findings || pm.inspection_findings || pm.remarks || (pm.status === 'Completed' ? 'Inspection completed without anomalies.' : 'Scheduled preventive service.'),
          actionTaken: pm.action_taken || pm.actions_taken || taskDesc || 'Preventive servicing and inspection routine executed.',
          partsUsed: pm.materials_used || pm.parts_replaced || 'None required',
          downtimeHours: Number(pm.downtime_hours || pm.estimated_duration || 0),
          verificationStatus: pm.status === 'Completed' ? 'Verified' : (pm.status || 'Pending'),
          supervisor: pm.supervisor || 'Maintenance Supervisor',
          verificationDate: pm.verification_date || (pm.status === 'Completed' ? dateStr : undefined),
          supervisorRemarks: pm.supervisor_remarks || 'Maintenance verified according to standard operational checklist.',
          checklist: checklistArr,
          measurements: Array.isArray(pm.measurements) ? pm.measurements : undefined,
          tools: Array.isArray(pm.tools) ? pm.tools : undefined,
          photos: pm.photo_url ? [pm.photo_url] : [],
          documents: [],
          sourceCollection: 'preventive_maintenance',
          rawRecord: pm
        });
        seenRecordKeys.add(recId);
      }
    }

    // 2. Machine Breakdowns
    for (const brk of rawBreakdowns) {
      const brkAssetId = String(brk.asset_id || brk.assetId || '').trim().toLowerCase();
      if (brkAssetId === targetId) {
        const recId = String(brk.breakdown_id || brk.id || `BRK-${Date.now()}`);
        if (!seenRecordKeys.has(recId)) {
          const dateStr = brk.reported_date || brk.created_at || brk.downtime_start || '';
          
          if (startDate || endDate) {
            const recDate = new Date(dateStr).getTime();
            if (!isNaN(recDate)) {
              if (startDate && recDate < startDate.getTime()) continue;
              if (endDate && recDate > endDate.getTime()) continue;
            }
          }

          const issueDesc = brk.problem_description || brk.issue || 'Machine breakdown repair';

          result.push({
            id: recId,
            recordType: brk.breakdown_category === 'Mechanical' ? 'Breakdown Repair' : 'Corrective Maintenance',
            assetId: selectedMachineId,
            assetName: selectedMachine?.name || brk.machine_name || selectedMachineId,
            serialNumber: selectedMachine?.serialNumber || brk.serial_number || '',
            date: dateStr,
            time: brk.reported_time || '',
            workOrderId: brk.linked_work_order_id || recId,
            technician: brk.technician_name || brk.assigned_to_name || 'Maintenance Specialist',
            technicianId: brk.technician_id || '',
            status: brk.status || 'Reported',
            maintenanceDescription: issueDesc,
            findings: brk.problem_description || brk.issue || 'Breakdown reported on operational unit.',
            actionTaken: brk.immediate_action || brk.action_taken || 'Diagnosed and restored machine functionality.',
            partsUsed: brk.parts_replaced || brk.materials_used || 'None recorded',
            downtimeHours: Number(brk.total_downtime || brk.downtime_hours || 0),
            verificationStatus: brk.status === 'Completed' || brk.status === 'Closed' ? 'Verified' : (brk.status || 'In Progress'),
            supervisor: brk.reported_by || 'Plant Supervisor',
            verificationDate: brk.updated_at || (brk.status === 'Completed' ? dateStr : undefined),
            supervisorRemarks: brk.remarks || 'Breakdown rectified and machine tested operational.',
            photos: brk.photo_url ? [brk.photo_url] : [],
            documents: [],
            sourceCollection: 'machine_breakdowns',
            rawRecord: brk
          });
          seenRecordKeys.add(recId);
        }
      }
    }

    // 3. Work Orders
    for (const wo of rawWorkOrders) {
      const woAssetId = String(wo.asset_id || wo.assetId || '').trim().toLowerCase();
      if (woAssetId === targetId) {
        const recId = String(wo.id || `WO-${wo.timestamp}`);
        if (!seenRecordKeys.has(recId)) {
          const dateStr = wo.timestamp || wo.completedTime || '';
          
          if (startDate || endDate) {
            const recDate = new Date(dateStr).getTime();
            if (!isNaN(recDate)) {
              if (startDate && recDate < startDate.getTime()) continue;
              if (endDate && recDate > endDate.getTime()) continue;
            }
          }

          const woDesc = wo.issue || wo.description || 'Corrective maintenance work order';

          result.push({
            id: recId,
            recordType: wo.category ? (wo.category.includes('Mechanical') ? 'Corrective Maintenance' : 'General') : 'Corrective Maintenance',
            assetId: selectedMachineId,
            assetName: selectedMachine?.name || wo.assetName || selectedMachineId,
            serialNumber: selectedMachine?.serialNumber || wo.serial_number || '',
            date: dateStr,
            workOrderId: wo.id,
            technician: wo.assigned_to_name || wo.assignedToName || 'Assigned Technician',
            technicianId: wo.assigned_to_id || wo.assignedToId || '',
            status: wo.status || 'Completed',
            maintenanceDescription: woDesc,
            findings: wo.issue || 'Work order logged for maintenance service.',
            actionTaken: wo.actions_taken || wo.actionsTaken || 'Maintenance work performed as dispatched.',
            partsUsed: wo.materials_used || wo.materialsUsed || 'None recorded',
            downtimeHours: Number(wo.downtime_hours || wo.downtimeHours || 0),
            verificationStatus: wo.status === 'Completed' ? 'Verified' : (wo.status || 'Pending'),
            supervisor: wo.logged_by || wo.loggedBy || 'Management',
            verificationDate: wo.completed_time || wo.completedTime || undefined,
            supervisorRemarks: 'Work order executed and completed per standard specifications.',
            checklist: Array.isArray(wo.checklist) ? wo.checklist.map((c: any) => ({
              task: typeof c === 'string' ? c : c.task || c.item,
              status: c.completed ? 'OK' : 'In Progress',
              remarks: 'Task verified'
            })) : undefined,
            photos: [],
            documents: [],
            sourceCollection: 'work_orders',
            rawRecord: wo
          });
          seenRecordKeys.add(recId);
        }
      }
    }

    result.sort((a, b) => (new Date(b.date).getTime() || 0) - (new Date(a.date).getTime() || 0));
    return result;
  }, [selectedMachineId, selectedMachine, rawPms, rawBreakdowns, rawWorkOrders, startDate, endDate]);

  // Summary Metrics
  const summaryStats = useMemo(() => {
    const totalRecords = machineRecords.length;
    const pmCount = machineRecords.filter(r => r.recordType === 'Preventive Maintenance').length;
    const cmCount = machineRecords.filter(r => r.recordType === 'Corrective Maintenance' || r.recordType === 'General').length;
    const breakdownCount = machineRecords.filter(r => r.recordType === 'Breakdown Repair').length;
    const totalDowntime = machineRecords.reduce((acc, r) => acc + (Number(r.downtimeHours) || 0), 0);

    const completedBreakdowns = machineRecords.filter(r => 
      r.recordType === 'Breakdown Repair' && 
      (r.status.toLowerCase() === 'completed' || r.status.toLowerCase() === 'closed' || r.status.toLowerCase() === 'resolved')
    );
    const completedBreakdownDowntime = completedBreakdowns.reduce((acc, r) => acc + (Number(r.downtimeHours) || 0), 0);
    const avgDowntime = completedBreakdowns.length > 0 
      ? (completedBreakdownDowntime / completedBreakdowns.length).toFixed(1)
      : '0.0';

    const completedCount = machineRecords.filter(r => 
      r.status.toLowerCase() === 'completed' || r.status.toLowerCase() === 'closed' || r.status.toLowerCase() === 'verified'
    ).length;
    const pendingCount = totalRecords - completedCount;

    return {
      totalRecords,
      pmCount,
      cmCount,
      breakdownCount,
      totalDowntime: totalDowntime.toFixed(1),
      avgDowntime,
      completedCount,
      pendingCount
    };
  }, [machineRecords]);

  // Toggle specific section
  const toggleSection = (key: keyof MachineReportSectionOptions) => {
    setSections(prev => ({ ...prev, [key]: !prev[key] }));
  };

  // Select all or deselect all sections
  const handleSelectAllSections = (enable: boolean) => {
    setSections({
      machineInfo: enable,
      maintenanceSummary: enable,
      maintenanceHistory: enable,
      preventiveMaintenance: enable,
      correctiveMaintenance: enable,
      checklist: enable,
      measurements: enable,
      technicianTools: enable,
      findingsActions: enable,
      downtimeSummary: enable,
      verification: enable
    });
  };

  // Generate and Download PDF
  const handleGeneratePDF = async () => {
    if (!selectedMachine) return;
    setIsGenerating(true);
    setFeedback(null);
    try {
      await generateMachineMaintenanceReportPDF({
        asset: selectedMachine,
        records: machineRecords,
        periodLabel,
        dateFrom,
        dateTo,
        sections,
        printMode: false
      });
      setFeedback('PDF report generated and downloaded successfully.');
      setTimeout(() => setFeedback(null), 4000);
    } catch (err: any) {
      console.error('Failed generating machine report PDF:', err);
      setFeedback('Error generating PDF report: ' + (err?.message || 'Unknown error'));
    } finally {
      setIsGenerating(false);
    }
  };

  // Print Report Handler
  const handlePrintReport = () => {
    if (!selectedMachine) return;
    // Switch to preview mode and trigger print
    setViewMode('preview');
    setTimeout(() => {
      window.print();
    }, 300);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-5xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        
        {/* ===================================================================== */}
        {/* MODAL HEADER */}
        {/* ===================================================================== */}
        <div className="px-5 py-4 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 rounded-lg">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white font-display">
                  Machine Maintenance Report Generator
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-cyan-950 text-cyan-300 border border-cyan-800/80">
                  A4 Technical Standard
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Generate professional engineering documentation inspired by technical equipment reporting standards.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* View Mode Toggle Button */}
            <div className="flex items-center bg-slate-800 p-0.5 rounded-lg border border-slate-700 text-xs">
              <button
                type="button"
                onClick={() => setViewMode('config')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                  viewMode === 'config'
                    ? 'bg-cyan-600 text-white font-semibold shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span>Configure</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('preview')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                  viewMode === 'preview'
                    ? 'bg-cyan-600 text-white font-semibold shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Preview</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Feedback Alert */}
        {feedback && (
          <div className="mx-5 mt-3 p-2.5 rounded-lg bg-cyan-950/80 border border-cyan-800/80 text-cyan-200 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>{feedback}</span>
          </div>
        )}

        {/* ===================================================================== */}
        {/* MODAL BODY */}
        {/* ===================================================================== */}
        <div className="p-5 overflow-y-auto flex-1 space-y-6">
          {viewMode === 'config' ? (
            /* CONFIGURATION VIEW */
            <div className="space-y-6">
              
              {/* SECTION A: MACHINE SELECTION */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Wrench className="w-4 h-4 text-cyan-400" />
                    <h3 className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider">
                      A. Machine Selection (Asset Directory)
                    </h3>
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono">
                    {assets.length} Machines Registered
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                      Select Registered Machine
                    </label>
                    <select
                      value={selectedMachineId}
                      onChange={e => setSelectedMachineId(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-cyan-500 font-medium"
                    >
                      {assets.map(a => (
                        <option key={a.id} value={a.id}>
                          {a.id} - {a.name} ({a.location || 'Workshop'})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Machine Details Card */}
                  {selectedMachine && (
                    <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 text-xs space-y-1.5 flex flex-col justify-center">
                      <div className="flex items-center justify-between font-bold text-slate-200">
                        <span className="text-cyan-400">{selectedMachine.id}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] uppercase ${
                          selectedMachine.status === 'Operational' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                          selectedMachine.status === 'Breakdown' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                          'bg-amber-950 text-amber-300 border border-amber-800'
                        }`}>
                          {selectedMachine.status || 'Operational'}
                        </span>
                      </div>
                      <div className="text-white font-semibold">{selectedMachine.name}</div>
                      <div className="text-slate-400 text-[11px] flex flex-wrap gap-x-3 gap-y-1">
                        <span>Serial: <strong className="text-slate-300">{selectedMachine.serialNumber || 'N/A'}</strong></span>
                        <span>Location: <strong className="text-slate-300">{selectedMachine.location || 'Workshop'}</strong></span>
                        <span>Dept: <strong className="text-slate-300">{selectedMachine.department || 'N/A'}</strong></span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* SECTION B: REPORTING PERIOD */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-cyan-400" />
                  <h3 className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider">
                    B. Reporting Period
                  </h3>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => setPeriodType('all')}
                    className={`p-2.5 rounded-lg border text-xs font-semibold text-left transition-all cursor-pointer ${
                      periodType === 'all'
                        ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300 shadow-sm'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    All Maintenance Records
                  </button>
                  <button
                    type="button"
                    onClick={() => setPeriodType('this_month')}
                    className={`p-2.5 rounded-lg border text-xs font-semibold text-left transition-all cursor-pointer ${
                      periodType === 'this_month'
                        ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300 shadow-sm'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    This Month
                  </button>
                  <button
                    type="button"
                    onClick={() => setPeriodType('last_month')}
                    className={`p-2.5 rounded-lg border text-xs font-semibold text-left transition-all cursor-pointer ${
                      periodType === 'last_month'
                        ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300 shadow-sm'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    Last Month
                  </button>
                  <button
                    type="button"
                    onClick={() => setPeriodType('custom')}
                    className={`p-2.5 rounded-lg border text-xs font-semibold text-left transition-all cursor-pointer ${
                      periodType === 'custom'
                        ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300 shadow-sm'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    Custom Date Range
                  </button>
                </div>

                {periodType === 'custom' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div>
                      <label className="text-[11px] font-semibold text-slate-300 block mb-1">Date From</label>
                      <input
                        type="date"
                        value={dateFrom}
                        onChange={e => setDateFrom(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-semibold text-slate-300 block mb-1">Date To</label>
                      <input
                        type="date"
                        value={dateTo}
                        onChange={e => setDateTo(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                  </div>
                )}

                <div className="text-[11px] text-cyan-400 font-mono flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 shrink-0" />
                  <span>Selected Range: <strong>{periodLabel}</strong> ({machineRecords.length} records matching)</span>
                </div>
              </div>

              {/* SECTION C: REPORT CONTENT CHECKLIST */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-cyan-400" />
                    <h3 className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider">
                      C. Report Content Sections
                    </h3>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => handleSelectAllSections(true)}
                      className="text-cyan-400 hover:underline cursor-pointer"
                    >
                      Select All
                    </button>
                    <span className="text-slate-600">•</span>
                    <button
                      type="button"
                      onClick={() => handleSelectAllSections(false)}
                      className="text-slate-400 hover:underline cursor-pointer"
                    >
                      Deselect All
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {[
                    { key: 'machineInfo', label: 'Machine Information' },
                    { key: 'maintenanceSummary', label: 'Maintenance Summary' },
                    { key: 'maintenanceHistory', label: 'Maintenance History' },
                    { key: 'preventiveMaintenance', label: 'Preventive Maintenance Records' },
                    { key: 'correctiveMaintenance', label: 'Corrective Maintenance & Breakdown Records' },
                    { key: 'checklist', label: 'Maintenance Checklist' },
                    { key: 'measurements', label: 'Measurements & Inspection Results' },
                    { key: 'technicianTools', label: 'Technician & Tools' },
                    { key: 'findingsActions', label: 'Findings & Actions Taken' },
                    { key: 'downtimeSummary', label: 'Downtime Summary' },
                    { key: 'verification', label: 'Verification & Approval' }
                  ].map(sec => {
                    const isChecked = !!sections[sec.key as keyof MachineReportSectionOptions];
                    return (
                      <button
                        key={sec.key}
                        type="button"
                        onClick={() => toggleSection(sec.key as keyof MachineReportSectionOptions)}
                        className={`p-2.5 rounded-lg border text-left text-xs transition-colors flex items-center gap-2.5 cursor-pointer ${
                          isChecked
                            ? 'bg-slate-900 border-cyan-800/80 text-white'
                            : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-400'
                        }`}
                      >
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-cyan-400 shrink-0" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-600 shrink-0" />
                        )}
                        <span className="font-medium">{sec.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            /* PREVIEW VIEW: WYSIWYG A4 REPORT SIMULATION */
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-white">Visual Layout Preview</span>
                  <span>•</span>
                  <span>A4 Format (Portrait)</span>
                  <span>•</span>
                  <span>{machineRecords.length} Records</span>
                </div>
                <button
                  type="button"
                  onClick={() => setViewMode('config')}
                  className="text-cyan-400 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  <span>Adjust Sections</span>
                </button>
              </div>

              {/* A4 Sheet Container */}
              <div 
                id="machine-report-print-area"
                className="bg-white text-slate-900 rounded-xl p-6 sm:p-8 shadow-2xl border border-slate-300 max-w-4xl mx-auto font-sans select-text"
              >
                {/* 1. Header Bar */}
                <div className="border-t-4 border-slate-900 pt-3 border-b pb-3 mb-4">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="text-[10px] font-bold uppercase tracking-wider text-slate-800">
                        DIGITAL MAINTENANCE RECORDS SYSTEM (DMR)
                      </div>
                      <div className="text-[9px] text-slate-500 mb-1">
                        Industrial Plant CMMS • Equipment Technical Maintenance Report
                      </div>
                      <h1 className="text-xl font-extrabold tracking-tight text-slate-950 font-display">
                        MACHINE MAINTENANCE REPORT
                      </h1>
                    </div>

                    <div className="border border-slate-300 bg-slate-50 rounded-lg p-2.5 text-[9px] min-w-[200px] space-y-1">
                      <div className="flex justify-between">
                        <span className="text-slate-500 font-bold">REPORT REF:</span>
                        <span className="font-mono font-bold text-slate-900">MMR-{selectedMachine?.id || 'ASSET'}-2026</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500 font-bold">GENERATED:</span>
                        <span className="text-slate-800">{new Date().toISOString().slice(0, 16).replace('T', ' ')}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500 font-bold">PERIOD:</span>
                        <span className="text-cyan-700 font-bold">{periodLabel}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 2. Machine Specs & Photo (FLIR Side-by-Side Reference Layout) */}
                {sections.machineInfo && selectedMachine && (
                  <div className="mb-5">
                    <div className="bg-slate-100 px-3 py-1 text-[10px] font-bold text-slate-900 tracking-wider uppercase mb-2 border-l-2 border-slate-900">
                      1.0 MACHINE SPECIFICATIONS & ASSET IDENTIFICATION
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      {/* Specs Table (2 Columns) */}
                      <div className="md:col-span-2 border border-slate-300 rounded overflow-hidden">
                        <table className="w-full text-[10px] border-collapse">
                          <tbody>
                            <tr className="border-b border-slate-200">
                              <td className="bg-slate-50 font-bold text-slate-700 p-1.5 w-1/4 border-r border-slate-200">Machine Name</td>
                              <td className="p-1.5 w-1/4 font-semibold text-slate-900 border-r border-slate-200">{selectedMachine.name}</td>
                              <td className="bg-slate-50 font-bold text-slate-700 p-1.5 w-1/4 border-r border-slate-200">Asset ID</td>
                              <td className="p-1.5 w-1/4 font-mono font-bold text-cyan-800">{selectedMachine.id}</td>
                            </tr>
                            <tr className="border-b border-slate-200">
                              <td className="bg-slate-50 font-bold text-slate-700 p-1.5 border-r border-slate-200">Serial Number</td>
                              <td className="p-1.5 font-mono text-slate-800 border-r border-slate-200">{selectedMachine.serialNumber || 'Not Available'}</td>
                              <td className="bg-slate-50 font-bold text-slate-700 p-1.5 border-r border-slate-200">Operating Status</td>
                              <td className="p-1.5 font-bold text-slate-900">{selectedMachine.status || 'Operational'}</td>
                            </tr>
                            <tr className="border-b border-slate-200">
                              <td className="bg-slate-50 font-bold text-slate-700 p-1.5 border-r border-slate-200">Manufacturer</td>
                              <td className="p-1.5 text-slate-800 border-r border-slate-200">{selectedMachine.manufacturer || 'Not Available'}</td>
                              <td className="bg-slate-50 font-bold text-slate-700 p-1.5 border-r border-slate-200">Model</td>
                              <td className="p-1.5 text-slate-800">{selectedMachine.model || 'Not Available'}</td>
                            </tr>
                            <tr className="border-b border-slate-200">
                              <td className="bg-slate-50 font-bold text-slate-700 p-1.5 border-r border-slate-200">Machine Type</td>
                              <td className="p-1.5 text-slate-800 border-r border-slate-200">{selectedMachine.machineType || selectedMachine.category || 'Production Unit'}</td>
                              <td className="bg-slate-50 font-bold text-slate-700 p-1.5 border-r border-slate-200">Criticality</td>
                              <td className="p-1.5 text-slate-800">{selectedMachine.criticality || 'Medium'}</td>
                            </tr>
                            <tr>
                              <td className="bg-slate-50 font-bold text-slate-700 p-1.5 border-r border-slate-200">Department</td>
                              <td className="p-1.5 text-slate-800 border-r border-slate-200">{selectedMachine.department || 'Not Available'}</td>
                              <td className="bg-slate-50 font-bold text-slate-700 p-1.5 border-r border-slate-200">Location</td>
                              <td className="p-1.5 text-slate-800">{selectedMachine.location || 'Workshop'}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>

                      {/* Photo Frame */}
                      <div className="border border-slate-300 rounded overflow-hidden bg-slate-50 p-1.5 flex flex-col items-center justify-center text-center">
                        {(selectedMachine.photoUrl || selectedMachine.machine_photo) && !imgErrorMap[selectedMachine.id] ? (
                          <img 
                            src={selectedMachine.photoUrl || selectedMachine.machine_photo} 
                            alt={selectedMachine.name}
                            referrerPolicy="no-referrer"
                            onError={() => {
                              setImgErrorMap(prev => ({ ...prev, [selectedMachine.id]: true }));
                            }}
                            className="max-h-28 w-full object-contain rounded bg-white p-0.5 border border-slate-200/60 shadow-2xs transition-transform duration-200 hover:scale-[1.02]"
                          />
                        ) : (
                          <div className="text-slate-400 py-3 px-2 flex flex-col items-center w-full justify-center bg-white rounded border border-dashed border-slate-200">
                            <Wrench className="w-7 h-7 opacity-50 mb-1 text-cyan-600" />
                            <span className="text-[10px] font-bold text-slate-700">{selectedMachine.name}</span>
                            <span className="text-[9px] font-mono text-cyan-700 font-semibold">{selectedMachine.id}</span>
                            <span className="text-[8px] text-slate-400 mt-0.5">Asset Reference Photo</span>
                          </div>
                        )}
                        <span className="text-[8px] font-bold text-slate-500 uppercase mt-1">
                          Fig 1.0: Equipment Reference
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* 3. Maintenance Summary Metrics */}
                {sections.maintenanceSummary && (
                  <div className="mb-5">
                    <div className="bg-slate-100 px-3 py-1 text-[10px] font-bold text-slate-900 tracking-wider uppercase mb-2 border-l-2 border-slate-900">
                      2.0 MAINTENANCE EXECUTIVE SUMMARY & DOWNTIME METRICS
                    </div>

                    <div className="border border-slate-300 rounded overflow-hidden">
                      <table className="w-full text-[10px] border-collapse">
                        <tbody>
                          <tr className="border-b border-slate-200">
                            <td className="bg-slate-50 font-bold text-slate-700 p-2 w-1/4 border-r border-slate-200">Total Maintenance Records</td>
                            <td className="p-2 w-1/4 font-extrabold text-cyan-800 border-r border-slate-200 text-base">{summaryStats.totalRecords}</td>
                            <td className="bg-slate-50 font-bold text-slate-700 p-2 w-1/4 border-r border-slate-200">Total Machine Downtime</td>
                            <td className="p-2 w-1/4 font-extrabold text-amber-700 text-base">{summaryStats.totalDowntime} <span className="text-xs font-normal">Hrs</span></td>
                          </tr>
                          <tr className="border-b border-slate-200">
                            <td className="bg-slate-50 font-bold text-slate-700 p-2 border-r border-slate-200">Preventive Maintenance (PM)</td>
                            <td className="p-2 font-bold text-slate-900 border-r border-slate-200">{summaryStats.pmCount}</td>
                            <td className="bg-slate-50 font-bold text-slate-700 p-2 border-r border-slate-200">Avg Downtime / Breakdown</td>
                            <td className="p-2 font-bold text-slate-900">{summaryStats.avgDowntime} Hrs</td>
                          </tr>
                          <tr>
                            <td className="bg-slate-50 font-bold text-slate-700 p-2 border-r border-slate-200">Corrective & Breakdowns</td>
                            <td className="p-2 font-bold text-slate-900 border-r border-slate-200">{summaryStats.cmCount + summaryStats.breakdownCount}</td>
                            <td className="bg-slate-50 font-bold text-slate-700 p-2 border-r border-slate-200">Completed vs Pending</td>
                            <td className="p-2 font-bold text-slate-900">{summaryStats.completedCount} Completed / {summaryStats.pendingCount} Pending</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                    <div className="text-[8px] text-slate-500 italic mt-1">
                      * Machine Downtime measures equipment operational loss distinct from technician labour hours.
                    </div>
                  </div>
                )}

                {/* 4. Maintenance History Table */}
                {sections.maintenanceHistory && (
                  <div className="mb-5">
                    <div className="bg-slate-100 px-3 py-1 text-[10px] font-bold text-slate-900 tracking-wider uppercase mb-2 border-l-2 border-slate-900">
                      3.0 MAINTENANCE HISTORY LOG ({machineRecords.length} INTERVENTIONS)
                    </div>

                    <div className="border border-slate-300 rounded overflow-hidden">
                      <table className="w-full text-[9px] border-collapse text-left">
                        <thead className="bg-slate-900 text-white font-bold text-[8.5px]">
                          <tr>
                            <th className="p-1.5 border-r border-slate-800 text-center w-6">No.</th>
                            <th className="p-1.5 border-r border-slate-800 w-16">Date</th>
                            <th className="p-1.5 border-r border-slate-800 w-20">WO ID</th>
                            <th className="p-1.5 border-r border-slate-800 w-24">Type</th>
                            <th className="p-1.5 border-r border-slate-800 w-20">Technician</th>
                            <th className="p-1.5 border-r border-slate-800">Job Description / Findings</th>
                            <th className="p-1.5 border-r border-slate-800">Action Taken</th>
                            <th className="p-1.5 border-r border-slate-800 text-center w-12">Downtime</th>
                            <th className="p-1.5 text-center w-14">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {machineRecords.length > 0 ? (
                            machineRecords.map((r, i) => (
                              <tr key={r.id} className={i % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                                <td className="p-1.5 border-r border-slate-200 text-center font-mono">{i + 1}</td>
                                <td className="p-1.5 border-r border-slate-200 font-mono text-[8px]">{r.date.split('T')[0]}</td>
                                <td className="p-1.5 border-r border-slate-200 font-mono font-bold text-cyan-800">{r.workOrderId || r.id}</td>
                                <td className="p-1.5 border-r border-slate-200">{r.recordType}</td>
                                <td className="p-1.5 border-r border-slate-200">{r.technician}</td>
                                <td className="p-1.5 border-r border-slate-200 text-slate-800">{r.maintenanceDescription || r.findings}</td>
                                <td className="p-1.5 border-r border-slate-200 text-slate-800">{r.actionTaken}</td>
                                <td className="p-1.5 border-r border-slate-200 text-center font-bold text-amber-800">{r.downtimeHours ? `${r.downtimeHours}h` : '0h'}</td>
                                <td className="p-1.5 text-center font-bold">{r.status}</td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan={9} className="p-4 text-center text-slate-500 italic">
                                No maintenance records found for the selected reporting period.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* 5. Verification & Approval */}
                {sections.verification && (
                  <div className="mb-4">
                    <div className="bg-slate-100 px-3 py-1 text-[10px] font-bold text-slate-900 tracking-wider uppercase mb-2 border-l-2 border-slate-900">
                      4.0 VERIFICATION, QUALITY AUDIT & SIGN-OFF
                    </div>

                    <div className="border border-slate-300 rounded p-3 bg-slate-50 grid grid-cols-2 gap-4 text-[9px]">
                      <div className="border-r border-slate-200 pr-3 space-y-1">
                        <div className="font-bold text-slate-800 uppercase">Technical Verification</div>
                        <div>Verified By: <strong>{authorizedUser || 'Maintenance Supervisor'}</strong></div>
                        <div>Date: <strong>{new Date().toISOString().slice(0, 10)}</strong></div>
                        <div className="text-slate-500 italic">
                          "Maintenance tasks and condition parameters verified against operational engineering standards."
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="font-bold text-slate-800 uppercase">Management Authorization</div>
                        <div>Status: <strong className="text-emerald-700">APPROVED & ARCHIVED</strong></div>
                        <div className="pt-4 border-b border-slate-400 border-dashed w-3/4"></div>
                        <div className="text-[8px] text-slate-400">Authorized Plant Engineer Signature</div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Footer */}
                <div className="border-t border-slate-300 pt-2 flex items-center justify-between text-[8px] text-slate-500">
                  <span>CONFIDENTIAL • DIGITAL MAINTENANCE RECORDS SYSTEM (DMR)</span>
                  <span>PAGE 1 OF 1</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ===================================================================== */}
        {/* MODAL BOTTOM ACTION BAR */}
        {/* ===================================================================== */}
        <div className="px-5 py-3.5 bg-slate-950 border-t border-slate-800 flex items-center justify-between shrink-0 flex-wrap gap-2">
          <div className="text-xs text-slate-400">
            Target Machine: <strong className="text-white">{selectedMachine?.id || 'None'}</strong> • 
            Records: <strong className="text-cyan-400">{machineRecords.length}</strong>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
            >
              Cancel
            </button>

            {viewMode === 'config' ? (
              <button
                type="button"
                onClick={() => setViewMode('preview')}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-800/80 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
              >
                <Eye className="w-4 h-4" />
                <span>Preview Report</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setViewMode('config')}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5"
              >
                <SlidersHorizontal className="w-4 h-4" />
                <span>Edit Configuration</span>
              </button>
            )}

            <button
              type="button"
              onClick={handlePrintReport}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-800/80 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-sm"
              title="Print A4 Machine Maintenance Report"
            >
              <Printer className="w-4 h-4" />
              <span>Print Report</span>
            </button>

            <button
              type="button"
              onClick={handleGeneratePDF}
              disabled={isGenerating}
              className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-md shadow-cyan-600/30 disabled:opacity-50"
              title="Generate downloadable A4 PDF"
            >
              {isGenerating ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              <span>{isGenerating ? 'Generating PDF...' : 'Generate PDF'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
