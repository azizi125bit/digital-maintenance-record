import React, { useState } from 'react';
import { User, Shield, Lock, Bell, Moon, Sun, Save, CheckCircle2, ChevronRight, Mail } from 'lucide-react';

interface ProfileSettingsViewProps {
  authorizedUser: string;
  theme: string;
  currentRole: string;
}

export const ProfileSettingsView: React.FC<ProfileSettingsViewProps> = ({ authorizedUser, theme, currentRole }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'security' | 'preferences'>('profile');
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
  };

  const tabs = [
    { id: 'profile', label: 'General Profile', icon: User },
    { id: 'security', label: 'Security & Role', icon: Shield },
    { id: 'preferences', label: 'Preferences', icon: Bell },
  ] as const;

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      
      {/* Header Area */}
      <div className="flex flex-col sm:flex-row items-center sm:items-start md:items-center gap-4 sm:gap-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 sm:p-6 md:p-8 rounded-2xl shadow-sm text-center sm:text-left">
        <div className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 rounded-full bg-sky-500 text-white border-4 border-sky-100 dark:border-sky-900 flex items-center justify-center font-bold text-2xl sm:text-3xl shadow-md font-display shrink-0">
          {getInitials(authorizedUser)}
        </div>
        <div className="flex-1">
          <h2 className="text-xl sm:text-2xl font-bold font-display text-slate-800 dark:text-white break-words">{authorizedUser}</h2>
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 sm:gap-3 mt-2">
            <span className={`px-2.5 py-1 text-xs font-bold uppercase rounded-md border ${
              currentRole === 'Management' ? 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-400 dark:border-blue-800' :
              currentRole === 'Technician' ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/30 dark:text-amber-400 dark:border-amber-800' :
              'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400 dark:border-emerald-800'
            }`}>
              {currentRole} Access
            </span>
            <span className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 flex items-center gap-1 break-all">
              <Mail className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" /> {(authorizedUser || '').toLowerCase().replace(/\s+/g, '.')}@dmr.company.com
            </span>
          </div>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        
        {/* Sidebar Nav */}
        <div className="w-full lg:w-64 shrink-0">
          <nav className="flex flex-row lg:flex-col gap-2 overflow-x-auto pb-2 lg:pb-0 hide-scrollbar">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm text-left whitespace-nowrap border ${
                  activeTab === tab.id 
                    ? 'bg-sky-50 text-sky-700 border-sky-200 dark:bg-sky-900/20 dark:text-sky-400 dark:border-sky-800 shadow-sm'
                    : 'bg-white text-slate-600 border-transparent hover:bg-slate-50 hover:border-slate-200 dark:bg-transparent dark:text-slate-400 dark:hover:bg-slate-800/50 dark:hover:border-slate-800'
                }`}
              >
                <tab.icon className={`w-5 h-5 ${activeTab === tab.id ? 'text-sky-500' : 'text-slate-400'}`} />
                <span className="flex-1">{tab.label}</span>
                {activeTab === tab.id && <ChevronRight className="w-4 h-4 opacity-50 hidden lg:block" />}
              </button>
            ))}
          </nav>
        </div>

        {/* Form Content */}
        <div className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
          
          <form onSubmit={handleSave} className="p-4 sm:p-6 md:p-8">
            
            {activeTab === 'profile' && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
                  <h3 className="text-lg font-bold text-slate-800 dark:text-white">General Information</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Update your primary account details and public profile.</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">Full Name</label>
                    <input type="text" defaultValue={authorizedUser} className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-4 py-2.5 text-sm font-medium text-slate-800 dark:text-slate-200 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 focus:outline-none transition-all" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">Email Address</label>
                    <input type="email" defaultValue={`${(authorizedUser || '').toLowerCase().replace(/\s+/g, '.')}@dmr.company.com`} className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-4 py-2.5 text-sm font-medium text-slate-800 dark:text-slate-200 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 focus:outline-none transition-all" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">Department / Team</label>
                    <input type="text" defaultValue={currentRole === 'Management' ? 'Operations HQ' : currentRole === 'Auditor' ? 'Compliance' : 'Field Maintenance'} className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-4 py-2.5 text-sm font-medium text-slate-800 dark:text-slate-200 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 focus:outline-none transition-all" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">Phone Extension</label>
                    <input type="text" defaultValue="+1 (555) 019-2831" className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-4 py-2.5 text-sm font-medium text-slate-800 dark:text-slate-200 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 focus:outline-none transition-all" />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'security' && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
                  <h3 className="text-lg font-bold text-slate-800 dark:text-white">Security & Access</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Manage your credentials, PIN, and view active sessions.</p>
                </div>
                
                <div className="space-y-6">
                  <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 rounded-xl p-4 flex gap-3 items-start">
                    <Lock className="w-5 h-5 text-amber-600 dark:text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-bold text-amber-800 dark:text-amber-400">Authentication PIN</h4>
                      <p className="text-xs text-amber-700 dark:text-amber-500 mt-1 mb-3">Your PIN is required for rapid session switching and authorizing critical actions.</p>
                      <div className="flex items-center gap-3">
                        <input type="password" defaultValue="1234" maxLength={4} className="w-24 bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-700 rounded-lg px-4 py-2 text-center text-lg font-mono font-bold text-slate-800 dark:text-slate-200 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 focus:outline-none transition-all tracking-widest" />
                        <button type="button" className="text-xs font-bold text-amber-700 dark:text-amber-400 hover:underline">Change PIN</button>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">Active Sessions</h4>
                    <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden divide-y divide-slate-100 dark:divide-slate-800">
                      <div className="flex items-center justify-between p-4 bg-slate-50/50 dark:bg-slate-900/50">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                            <Shield className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-sm font-bold text-slate-800 dark:text-slate-200">Current Device (Chrome - Web)</p>
                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Last active: Just now • IP: 192.168.1.1</p>
                          </div>
                        </div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 bg-emerald-100 px-2 py-1 rounded">Active</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'preferences' && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
                  <h3 className="text-lg font-bold text-slate-800 dark:text-white">Workspace Preferences</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Customize your interface and notification settings.</p>
                </div>
                
                <div className="space-y-6">
                  <div>
                    <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-3">System Theme</h4>
                    <div className="flex gap-4">
                      <label className={`flex-1 flex flex-col items-center gap-2 p-4 border-2 rounded-xl cursor-pointer transition-all ${
                        theme === 'light' ? 'border-sky-500 bg-sky-50 dark:bg-sky-900/20' : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                      }`}>
                        <Sun className={`w-8 h-8 ${theme === 'light' ? 'text-sky-500' : 'text-slate-400'}`} />
                        <span className="text-sm font-bold text-slate-700 dark:text-slate-300">Light Mode</span>
                        <input type="radio" name="theme" value="light" className="sr-only" checked={theme === 'light'} readOnly />
                      </label>
                      <label className={`flex-1 flex flex-col items-center gap-2 p-4 border-2 rounded-xl cursor-pointer transition-all ${
                        theme === 'dark' ? 'border-sky-500 bg-sky-50 dark:bg-sky-900/20' : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                      }`}>
                        <Moon className={`w-8 h-8 ${theme === 'dark' ? 'text-sky-500' : 'text-slate-400'}`} />
                        <span className="text-sm font-bold text-slate-700 dark:text-slate-300">Dark Mode</span>
                        <input type="radio" name="theme" value="dark" className="sr-only" checked={theme === 'dark'} readOnly />
                      </label>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">Note: Global theme can also be changed from the top navigation bar.</p>
                  </div>

                  <hr className="border-slate-100 dark:border-slate-800" />

                  <div>
                    <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-3">Email Notifications</h4>
                    <div className="space-y-3">
                      <label className="flex items-center gap-3 p-3 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer transition-colors">
                        <input type="checkbox" defaultChecked className="w-4 h-4 rounded border-slate-300 text-sky-500 focus:ring-sky-500" />
                        <div className="flex-1">
                          <p className="text-sm font-bold text-slate-700 dark:text-slate-300">Work Order Assignments</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">Receive an email when you are assigned a new ticket.</p>
                        </div>
                      </label>
                      <label className="flex items-center gap-3 p-3 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer transition-colors">
                        <input type="checkbox" defaultChecked className="w-4 h-4 rounded border-slate-300 text-sky-500 focus:ring-sky-500" />
                        <div className="flex-1">
                          <p className="text-sm font-bold text-slate-700 dark:text-slate-300">System Alerts & Downtime</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">Critical notifications about machine breakdowns.</p>
                        </div>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Footer Action */}
            <div className="mt-6 sm:mt-8 pt-4 sm:pt-6 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between sm:justify-end gap-3">
              {isSaved && (
                <span className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-emerald-600 animate-in fade-in duration-300">
                  <CheckCircle2 className="w-4 h-4 shrink-0" /> Saved Successfully
                </span>
              )}
              <button 
                type="submit"
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 bg-sky-500 hover:bg-sky-400 text-white rounded-lg font-bold text-xs sm:text-sm shadow-md shadow-sky-500/20 transition-all active:scale-95 cursor-pointer min-h-[40px]"
              >
                <Save className="w-4 h-4" /> Save Changes
              </button>
            </div>

          </form>

        </div>
      </div>
    </div>
  );
};
