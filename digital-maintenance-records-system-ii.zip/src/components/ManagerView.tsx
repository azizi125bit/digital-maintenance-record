/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { WorkOrder, Asset, Technician, PriorityLevel, MaintenanceCategory, ActivityLog, MachineBreakdown } from '../types';
import { SEED_ASSETS, SEED_TECHNICIANS, SEED_ACTIVITY_LOGS, SEED_BREAKDOWNS } from '../data';
import { motion, AnimatePresence } from 'motion/react';
import { supabase } from '../lib/supabase';
import { getEffectiveMachineStatus, checkAssetHasActiveBreakdown, healAndSyncAllAssets } from '../utils/machineSync';
import { 
  PlusCircle, 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  UserPlus, 
  Tag, 
  Search, 
  Filter, 
  TrendingUp,
  Sliders,
  Check,
  ChevronRight,
  ClipboardList,
  Cpu,
  Zap,
  Activity,
  ShieldCheck,
  Package,
  Wrench,
  Shuffle,
  Scale,
  UserCheck,
  Calendar,
  Timer,
  AlertCircle,
  SlidersHorizontal,
  Info,
  CheckCircle2,
  FileText,
  Flame,
  RefreshCw,
  MapPin
} from 'lucide-react';
import { autoAssignTechnician, DEFAULT_MAX_WORKLOAD, type AssignmentResult } from '../lib/technicianAssignment';


interface ManagerViewProps {
  workOrders: WorkOrder[];
  activityLogs?: ActivityLog[];
  pmTasks?: any[];
  onAddWorkOrder: (order: Omit<WorkOrder, 'id' | 'timestamp' | 'status'>) => void;
  onUpdatePriority: (id: string, priority: PriorityLevel) => void;
  onReassignTechnician: (id: string, techId: string, techName: string) => void;
  onOpenRequireDocument?: (workOrderId?: string, defaultType?: 'JSA' | 'PTW' | 'JSA + PTW') => void;
  staffList: import('../types').Personnel[];
  technicians?: import('../types').Technician[];
  theme?: 'light' | 'dark';
  authorizedUserRole?: string;
  authorizedUser?: string;
}

export default function ManagerView({
  workOrders,
  activityLogs = [],
  pmTasks = [],
  onAddWorkOrder, 
  onUpdatePriority, 
  onReassignTechnician,
  onOpenRequireDocument,
  technicians,
  staffList,
  theme = 'light',
  authorizedUserRole,
  authorizedUser
}: ManagerViewProps) {
  const techniciansList = technicians || SEED_TECHNICIANS;
  const activeStaff = staffList ? staffList.filter(s => s.accountStatus === 'Active') : [];
  
  // Form States
  const [selectedAssetId, setSelectedAssetId] = useState('');
  const [assets, setAssets] = useState<Asset[]>(() => {
    try {
      const saved = localStorage.getItem('dmr_assets_list');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const demoAssetIds = [
            'LATHE-01', 'LATHE-02', 'MILL-03', 'CNC-01', 'PUMP-01', 
            'COMP-02', 'WELD-05', 'DRILL-04', 'SHAPER-01', 'PLC-08', 
            'MCH-001', 'MCH-002', 'MCH-003', 'A-03', 'H-01', 'P-02'
          ];
          return parsed.filter((a: any) => !demoAssetIds.includes(a.id));
        }
      }
    } catch (e) {
      console.error('Failed reading dmr_assets_list in ManagerView:', e);
    }
    return [];
  });
  const [assetSearchQuery, setAssetSearchQuery] = useState('');
  const [showAssetDropdown, setShowAssetDropdown] = useState(false);
  const [selectedAssetObj, setSelectedAssetObj] = useState<Asset | null>(null);
  const [machineBreakdowns, setMachineBreakdowns] = useState<MachineBreakdown[]>(() => {
    try {
      const saved = localStorage.getItem('dmr_machine_breakdowns');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    const fetchAssets = async () => {
      try {
        const { data, error } = await supabase.from('assets').select('*');
        if (!error && data) {
          const formatted = data.map((a: any) => ({
            id: a.id,
            name: a.name,
            category: a.category,
            status: a.status,
            location: a.location,
            criticality: a.criticality,
            department: a.department,
            description: a.description,
            manufacturer: a.manufacturer,
            model: a.model,
            serialNumber: a.serial_number || a.serialNumber,
            installationDate: a.installation_date || a.installationDate,
            nextMaintenanceDate: a.next_maintenance_date || a.nextMaintenanceDate,
            photoUrl: a.photo_url || a.photoUrl || a.machine_photo,
            machine_photo: a.machine_photo || a.photo_url
          }));
          setAssets(formatted as any);
        }
      } catch (e) {
        console.error('ManagerView asset fetch error:', e);
      }
    };

    const fetchBreakdowns = async () => {
      try {
        const { data, error } = await supabase.from('machine_breakdowns').select('*');
        if (!error && Array.isArray(data)) {
          setMachineBreakdowns(data);
        }
      } catch (e) {
        console.error('ManagerView breakdown fetch error:', e);
      }
    };

    const runSync = async () => {
      await fetchAssets();
      await fetchBreakdowns();
      await healAndSyncAllAssets();
    };

    runSync();

    const handleSync = () => {
      runSync();
    };
    window.addEventListener('dmr_machine_sync', handleSync);
    window.addEventListener('storage', handleSync);
    return () => {
      window.removeEventListener('dmr_machine_sync', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, []);
  const [category, setCategory] = useState<MaintenanceCategory>('Mechanical');
  const [issue, setIssue] = useState('');
  const [priority, setPriority] = useState<PriorityLevel>('Medium');
  const [scheduledDate, setScheduledDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [estimatedDuration, setEstimatedDuration] = useState<number>(2);
  const [maxWorkloadLimit, setMaxWorkloadLimit] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('dmr_max_workload_limit');
      return saved ? Math.max(1, Number(saved)) : DEFAULT_MAX_WORKLOAD;
    } catch {
      return DEFAULT_MAX_WORKLOAD;
    }
  });

  const selectedAssetObjResolved = useMemo(() => {
    return assets.find(a => a.id === selectedAssetId) || selectedAssetObj || null;
  }, [assets, selectedAssetId, selectedAssetObj]);

  // AUTOMATIC TECHNICIAN ASSIGNMENT COMPUTATION
  // Evaluates: 1. Department 2. Skills 3. Availability 4. Workload 5. Account Status
  const autoAssignment = useMemo<AssignmentResult>(() => {
    return autoAssignTechnician(
      {
        asset: selectedAssetObjResolved,
        maintenanceType: category,
        priority,
        issueDescription: issue,
        scheduledDate,
        estimatedDuration,
        maxWorkloadLimit,
      },
      staffList || [],
      workOrders,
      pmTasks
    );
  }, [selectedAssetObjResolved, category, priority, issue, scheduledDate, estimatedDuration, maxWorkloadLimit, staffList, workOrders, pmTasks]);

  const [loggedBy, setLoggedBy] = useState(authorizedUser || 'Encik Aziz (Supervisor)');
  
  useEffect(() => {
    if (authorizedUser) {
      setLoggedBy(authorizedUser);
    }
  }, [authorizedUser]);
  
  // UI States
  const [formSuccess, setFormSuccess] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [editingOrderId, setEditingOrderId] = useState<string | null>(null);
  const [tempTechId, setTempTechId] = useState('');

  // Auto-set Category when Asset changes
  useEffect(() => {
    if (selectedAssetId) {
      const asset = assets.find(a => a.id === selectedAssetId);
      if (asset) {
        setCategory(asset.category);
      }
    }
  }, [selectedAssetId]);

  const [isGeneratingChecklist, setIsGeneratingChecklist] = useState(false);

  // Handle Form Submit
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAssetId || !issue.trim()) {
      alert('Please fill in all required fields (Asset / Machine, Fault Description).');
      return;
    }

    // Check for existing active work orders for the same asset and issue
    const allTickets = [...workOrders, ...(pmTasks ? pmTasks : [])];
    const hasActiveTicket = allTickets.some(
      order => order.assetId === selectedAssetId && order.issue.trim() === issue.trim() && order.status !== 'Completed'
    );

    if (hasActiveTicket) {
      alert('There is already an active work order with this exact same issue for this asset.');
      return;
    }

    const asset = selectedAssetObjResolved || assets.find(a => a.id === selectedAssetId);
    if (!asset) return;

    let generatedChecklist = [];
    setIsGeneratingChecklist(true);
    try {
      const res = await fetch('/api/generate-checklist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ issue, category })
      });
      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        const data = await res.json();
        if (data && data.checklist) {
          generatedChecklist = data.checklist;
        }
      }
    } catch (err) {
      console.error("Failed to generate checklist:", err);
    } finally {
      setIsGeneratingChecklist(false);
    }

    if (autoAssignment.success && autoAssignment.technician) {
      onAddWorkOrder({
        assetId: selectedAssetId,
        assetName: asset.name,
        category,
        issue,
        priority,
        assignedToId: autoAssignment.technicianId,
        assignedToName: autoAssignment.technicianName,
        loggedBy,
        scheduledDate,
        estimatedDuration,
        assignmentReason: autoAssignment.assignmentReason,
        checklist: generatedChecklist.length > 0 ? generatedChecklist : undefined,
        status: 'Pending'
      } as any);
    } else {
      // Rule 9: If no suitable technician is available:
      // Set Work Order status to "Pending Technician Assignment"
      onAddWorkOrder({
        assetId: selectedAssetId,
        assetName: asset.name,
        category,
        issue,
        priority,
        assignedToId: 'UNASSIGNED',
        assignedToName: 'Unassigned (Pending Auto-Assignment)',
        loggedBy,
        scheduledDate,
        estimatedDuration,
        assignmentReason: autoAssignment.rejectionSummary.join(', ') || 'No suitable technician currently available',
        checklist: generatedChecklist.length > 0 ? generatedChecklist : undefined,
        status: 'Pending Technician Assignment'
      } as any);
    }

    // Reset Form
    setIssue('');
    setSelectedAssetId('');
    setSelectedAssetObj(null);
    setFormSuccess(true);
    setTimeout(() => setFormSuccess(false), 3000);
  };

  // Filtered orders
  
  const normalizedPMTasks = pmTasks.map(pm => ({
    id: String(pm.id).startsWith('PM-') ? pm.id : `PM-${pm.id}`,
    timestamp: pm.scheduled_date,
    assetId: pm.asset_id,
    assetName: pm.asset_name,
    category: pm.category || 'General',
    issue: `[${pm.maintenance_type || 'PM'}] ${pm.maintenance_task}`,
    priority: pm.priority,
    assignedToId: pm.assigned_to_id || 'unassigned',
    assignedToName: pm.assigned_to_name,
    status: pm.status,
    loggedBy: pm.supervisor || pm.logged_by || 'System',
    isPM: true,
    downtimeHours: pm.estimated_duration || 2,
    scheduledDate: pm.scheduled_date,
    estimatedDuration: pm.estimated_duration || 2,
    assignmentReason: 'Preventive Maintenance Routine Schedule'
  }));

  const allTickets: (WorkOrder & { isPM?: boolean })[] = useMemo(() => {
    const combined = [...workOrders, ...normalizedPMTasks];
    const seen = new Set<string>();
    return combined.filter(order => {
      if (!order.id || seen.has(order.id)) return false;
      seen.add(order.id);
      return true;
    });
  }, [workOrders, normalizedPMTasks]);

  const activeOrders = allTickets.filter(order => order.status !== 'Completed');
  const filteredActiveOrders = useMemo(() => {
    const seen = new Set<string>();
    return activeOrders.filter(order => {
      if (!order.id || seen.has(order.id)) return false;
      seen.add(order.id);
      const matchesSearch = 
        (order.id || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (order.assetName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (order.assignedToName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (order.issue || '').toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesPriority = filterPriority === 'all' || order.priority === filterPriority;
      
      return matchesSearch && matchesPriority;
    });
  }, [activeOrders, searchTerm, filterPriority]);

  // Calculate active & in-progress workload per technician
  const techWorkload = techniciansList.map(tech => {
    const techOrders = allTickets.filter(o => o.assignedToId === tech.id);
    const inProgressCount = techOrders.filter(o => o.status === 'In Progress').length;
    const pendingCount = techOrders.filter(o => o.status === 'Pending').length;
    const totalActive = inProgressCount + pendingCount;
    return {
      ...tech,
      inProgressCount,
      pendingCount,
      totalActive
    };
  });

  // Calculate completed work orders per technician to highlight high performance
  const completedOrdersPerTech = techniciansList.map(tech => {
    const totalCompleted = allTickets.filter(
      o => o.assignedToId === tech.id && o.status === 'Completed'
    ).length;
    return {
      name: tech.name.split(' ')[0],
      fullName: tech.name,
      completed: totalCompleted,
      specialty: tech.specialty,
    };
  });

  // Calculate completed work orders per asset to evaluate high performance / reliability
  const assetMaintenanceData = assets.map(asset => {
    const completedCount = allTickets.filter(
      o => o.assetId === asset.id && o.status === 'Completed'
    ).length;
    const totalCount = allTickets.filter(o => o.assetId === asset.id).length;
    return {
      name: asset.name.replace("System", "").replace("Unit", "").trim(),
      fullName: asset.name,
      completed: completedCount,
      total: totalCount,
      resolutionRate: totalCount === 0 ? 0 : Math.round((completedCount / totalCount) * 100),
    };
  });

  // Calculate downtime trend per asset over the last 30 days
  const downtimeTrendData = assets.map(asset => {
    // 30 days ago calculation
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const downtimeHours = allTickets
      .filter(o => o.assetId === asset.id && new Date(o.timestamp) >= thirtyDaysAgo)
      .reduce((sum, o) => sum + (o.downtimeHours || 0), 0);

    return {
      name: asset.name.replace("System", "").replace("Unit", "").trim(),
      fullName: asset.name,
      downtimeHours: parseFloat(downtimeHours.toFixed(1))
    };
  });

  return (
    <div className="space-y-6">

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 sm:gap-8">
        
        {/* Left Column Group */}
        <div className="space-y-6 xl:col-span-1">
          {/* Create Work Order Form Card */}
          {(!authorizedUserRole || authorizedUserRole === 'Management') ? (
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden" id="log-work-order">
            <div className="px-4 sm:px-5 py-3.5 sm:py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="font-display font-bold text-sm md:text-base flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-sky-400 shrink-0" /> Log Maintenance Work Order
              </h3>
              <span className="text-[10px] font-mono bg-sky-950 text-sky-300 px-2 py-0.5 rounded border border-sky-800 shrink-0">
                Zero-Cost Dispatch
              </span>
            </div>

          <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4">
            {formSuccess && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }} 
                animate={{ opacity: 1, y: 0 }} 
                className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs font-semibold flex items-center gap-2"
              >
                <Check className="w-4 h-4 text-emerald-600 shrink-0" /> Work Order Dispatched to Technician Successfully!
              </motion.div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-700 uppercase tracking-wider mb-1">
                Select Asset / Machinery <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input 
                  type="text" 
                  required={!selectedAssetId}
                  value={showAssetDropdown ? assetSearchQuery : (selectedAssetObj ? `[${selectedAssetObj.id}] ${selectedAssetObj.name}` : '')}
                  onChange={(e) => {
                    setAssetSearchQuery(e.target.value);
                    setShowAssetDropdown(true);
                    if (!e.target.value) {
                      setSelectedAssetObj(null);
                      setSelectedAssetId('');
                    }
                  }}
                  onFocus={() => setShowAssetDropdown(true)}
                  onBlur={() => setTimeout(() => setShowAssetDropdown(false), 200)}
                  placeholder="Search by asset name or ID..." 
                  className="w-full pl-9 bg-white border border-slate-300 rounded-lg p-2 text-sm text-slate-800 focus:border-sky-500 focus:outline-none" 
                />
                <input type="hidden" name="asset_id" value={selectedAssetId} />
              </div>
              {selectedAssetObj && !showAssetDropdown && (
                <div className="mt-1 flex items-center justify-between text-xs px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg">
                  <span className="text-slate-600 font-medium">Machine Status:</span>
                  {getEffectiveMachineStatus(selectedAssetObj, machineBreakdowns) === 'Breakdown' ? (
                    <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-rose-600 text-white shadow-2xs animate-pulse">
                      🔴 BREAKDOWN
                    </span>
                  ) : (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-700">
                      🟢 OPERATIONAL
                    </span>
                  )}
                </div>
              )}
              {showAssetDropdown && (
                <div className="absolute z-10 w-full left-0 right-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-xl max-h-56 overflow-y-auto">
                  {assets.filter(a => a.name.toLowerCase().includes(assetSearchQuery.toLowerCase()) || a.id.toLowerCase().includes(assetSearchQuery.toLowerCase())).map(asset => {
                    const effectiveStatus = getEffectiveMachineStatus(asset, machineBreakdowns);
                    return (
                      <div 
                        key={asset.id}
                        className="px-4 py-2 hover:bg-slate-50 cursor-pointer text-sm border-b border-slate-100 last:border-0 flex items-center gap-3"
                        onClick={() => {
                          setSelectedAssetObj(asset);
                          setSelectedAssetId(asset.id);
                          setAssetSearchQuery('');
                          setShowAssetDropdown(false);
                        }}
                      >
                        {asset.photoUrl ? (
                          <img 
                            src={asset.photoUrl} 
                            alt={asset.name} 
                            className="w-8 h-8 rounded object-cover border border-slate-200 shrink-0" 
                          />
                        ) : (
                          <div className="w-8 h-8 rounded bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0 text-slate-400">
                            <Package className="w-4 h-4" />
                          </div>
                        )}
                        <div>
                          <div className="font-bold text-slate-700 flex items-center gap-1.5">
                            <span>{asset.name}</span>
                            {effectiveStatus === 'Breakdown' ? (
                              <span className="text-[9px] px-1.5 py-0.5 rounded font-extrabold bg-rose-600 text-white">
                                🔴 BREAKDOWN
                              </span>
                            ) : (
                              <span className="text-[9px] px-1.5 py-0.5 rounded font-medium bg-emerald-100 text-emerald-700">
                                🟢 Operational
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-500 font-mono mt-0.5">{asset.id} &bull; {asset.location}</div>
                        </div>
                      </div>
                    );
                  })}
                  {assets.length > 0 && assets.filter(a => a.name.toLowerCase().includes(assetSearchQuery.toLowerCase()) || a.id.toLowerCase().includes(assetSearchQuery.toLowerCase())).length === 0 && (
                    <div className="px-4 py-2 text-sm text-slate-500">No assets found</div>
                  )}
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 uppercase tracking-wider mb-1">
                  System Category / Maintenance Type
                </label>
                <select
                  className="block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-800 bg-white focus:border-brand-500 focus:ring-1 focus:ring-brand-500 outline-none"
                  value={category}
                  onChange={(e) => setCategory(e.target.value as MaintenanceCategory)}
                >
                  <option value="Mechanical">Mechanical</option>
                  <option value="Electrical">Electrical</option>
                  <option value="Pneumatic">Pneumatic</option>
                  <option value="General">General</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 uppercase tracking-wider mb-1">
                  Priority Level
                </label>
                <select
                  className="block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-800 bg-white focus:border-brand-500 focus:ring-1 focus:ring-brand-500 outline-none"
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as PriorityLevel)}
                >
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                  <option value="Critical">Critical (Immediate Dispatch)</option>
                </select>
              </div>
            </div>

            {/* Scheduled Date & Estimated Duration */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-500" />
                  Scheduled Date <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  required
                  className="block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-800 bg-white focus:border-brand-500 focus:ring-1 focus:ring-brand-500 outline-none"
                  value={scheduledDate}
                  onChange={(e) => setScheduledDate(e.target.value)}
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                  <Timer className="w-3.5 h-3.5 text-slate-500" />
                  Estimated Duration (Hours)
                </label>
                <input
                  type="number"
                  min="0.5"
                  step="0.5"
                  max="72"
                  className="block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-800 bg-white focus:border-brand-500 focus:ring-1 focus:ring-brand-500 outline-none"
                  value={estimatedDuration}
                  onChange={(e) => setEstimatedDuration(Number(e.target.value) || 1)}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 uppercase tracking-wider mb-1">
                Fault / Repair Diagnostics Description <span className="text-rose-500">*</span>
              </label>
              <textarea
                required
                rows={3}
                className="block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:border-brand-500 focus:ring-1 focus:ring-brand-500 outline-none resize-none"
                placeholder="Describe the symptoms of failure, diagnostic findings, or instructions..."
                value={issue}
                onChange={(e) => setIssue(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 uppercase tracking-wider mb-1">
                Logging Supervisor / Manager
              </label>
              <input
                type="text"
                disabled={!!authorizedUser}
                className="block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-800 bg-slate-50 border-slate-200 outline-none disabled:opacity-75 disabled:cursor-not-allowed"
                value={loggedBy}
                onChange={(e) => setLoggedBy(e.target.value)}
              />
            </div>

            <button
              type="submit"
              disabled={isGeneratingChecklist}
              className="w-full mt-2 inline-flex justify-center items-center px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-white bg-slate-800 hover:bg-slate-900 rounded-lg cursor-pointer transition-all shadow-md hover:shadow-lg disabled:opacity-75 disabled:cursor-wait"
            >
              {isGeneratingChecklist ? (
                <>Generating Checklist... <span className="animate-spin ml-2 w-4 h-4 border-2 border-white border-t-transparent rounded-full block"></span></>
              ) : (
                <>Dispatch Ticket <ChevronRight className="w-4 h-4 ml-1" /></>
              )}
            </button>
          </form>
        </div>
        ) : (
          <div className="bg-slate-50 rounded-xl border border-slate-200 shadow-sm overflow-hidden p-8 flex flex-col items-center justify-center text-center min-h-[400px]">
            <div className="w-16 h-16 bg-slate-200 rounded-full flex items-center justify-center mb-4">
              <ShieldCheck className="w-8 h-8 text-slate-400" />
            </div>
            <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-2">Access Restricted</h3>
            <p className="text-xs text-slate-500 max-w-[200px]">
              You must have Management authorization to create new work orders.
            </p>
          </div>
        )}
      </div>

      {/* Dispatch Progress Tracking list */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden xl:col-span-2">
          <div className="px-4 sm:px-5 py-3.5 sm:py-4 bg-slate-50 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h3 className="font-display font-bold text-slate-800 text-sm md:text-base flex items-center gap-2">
                <ClipboardList className="w-5 h-5 text-slate-600 shrink-0" /> Supervisor Dispatch Console
              </h3>
              <p className="text-xs text-slate-500">Monitor active repair jobs and adjust technicians or priorities.</p>
            </div>
            
            {/* Search/Filters */}
            <div className="flex flex-wrap sm:flex-nowrap gap-2 w-full sm:w-auto">
              <div className="relative flex-1 sm:flex-none">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search orders..."
                  className="pl-8 pr-3 py-1.5 w-full sm:w-44 text-xs rounded-lg border border-slate-300 bg-white outline-none focus:border-slate-500 focus:ring-1 focus:ring-slate-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <select
                className="px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white outline-none cursor-pointer focus:border-slate-500 shrink-0"
                value={filterPriority}
                onChange={(e) => setFilterPriority(e.target.value)}
              >
                <option value="all">Priority (All)</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>
          </div>

          {/* Active Work Order Grid/List */}
          <div className="p-5 max-h-[500px] overflow-y-auto">
            {filteredActiveOrders.length === 0 ? (
              <div className="text-center py-12 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <CheckCircle className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <h4 className="font-display font-semibold text-slate-700 text-sm">No work orders available.</h4>
                <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                  Use the Dispatch Work Order form to register a new maintenance ticket.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <AnimatePresence initial={false}>
                  {filteredActiveOrders.map((order, idx) => (
                    <motion.div
                      key={`${order.id}-${order.isPM ? 'pm' : 'wo'}-${idx}`}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className={`border rounded-lg p-4 transition-all bg-white relative overflow-hidden ${
                        order.priority === 'High' 
                          ? 'alert-pulse-high bg-rose-50/10' 
                          : 'border-slate-200 hover:border-slate-300 hover:shadow-sm'
                      }`}
                    >
                      {/* Priority Ribbon */}
                      <div className={`absolute top-0 left-0 right-0 h-1 ${
                        order.priority === 'High' ? 'bg-rose-500' :
                        order.priority === 'Medium' ? 'bg-amber-500' : 'bg-slate-400'
                      }`} />

                      {/* WORK ORDER CARD CONTAINER - FULL WIDTH RESPONSIVE LAYOUT */}
                      <div className="w-full space-y-3.5">
                        
                        {/* A & B: TOP HEADER & ACTION ROW */}
                        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800/80">
                          
                          {/* A. HEADER AREA: ID, Status, Priority, Logged Date, Scheduled Date, Safety Doc */}
                          <div className="flex flex-wrap items-center gap-2 min-w-0">
                            {/* Work Order ID */}
                            <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 dark:bg-slate-800 dark:text-slate-100 px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700 shadow-2xs">
                              {order.id}
                            </span>

                            {/* Status Badge */}
                            <span className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded ${
                              order.status === 'In Progress' 
                                ? 'bg-amber-100 text-amber-800 border border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800' 
                                : order.status === 'Pending Technician Assignment'
                                ? 'bg-rose-100 text-rose-800 border border-rose-200 font-bold dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800'
                                : 'bg-slate-100 text-slate-700 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700'
                            }`}>
                              {order.status === 'In Progress' ? (
                                <>
                                  <Clock className="w-3 h-3 animate-spin text-amber-600 dark:text-amber-400" />
                                  In Progress
                                </>
                              ) : order.status === 'Pending Technician Assignment' ? (
                                <>
                                  <AlertTriangle className="w-3 h-3 text-rose-600 dark:text-rose-400" />
                                  Pending Technician Assignment
                                </>
                              ) : (
                                <>
                                  <Sliders className="w-3 h-3 text-slate-500 dark:text-slate-400" />
                                  Assigned & Pending
                                </>
                              )}
                            </span>

                            {/* Priority Badge */}
                            <span className={`inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded border ${
                              order.priority === 'High' 
                                ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/50 dark:text-rose-300 dark:border-rose-800' :
                              order.priority === 'Medium' 
                                ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:border-amber-800' :
                                'bg-slate-50 text-slate-600 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'
                            }`}>
                              <Flame className="w-2.5 h-2.5" />
                              {order.priority}
                            </span>

                            {/* Logged Date */}
                            <span className="inline-flex items-center gap-1 text-[10px] font-mono text-slate-500 dark:text-slate-400">
                              <Clock className="w-2.5 h-2.5 text-slate-400" />
                              Logged: {new Date(order.timestamp).toLocaleDateString()}
                            </span>

                            {/* Scheduled Date */}
                            {order.scheduledDate && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-mono text-sky-700 bg-sky-50 dark:bg-sky-950/40 dark:text-sky-300 dark:border-sky-800 px-1.5 py-0.5 rounded border border-sky-200">
                                <Calendar className="w-2.5 h-2.5 text-sky-600 dark:text-sky-400" />
                                Sched: {order.scheduledDate}
                              </span>
                            )}

                            {/* Linked PM Schedule */}
                            {order.pmScheduleId && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold bg-sky-50 text-sky-800 border border-sky-300 dark:bg-sky-950/40 dark:text-sky-300 dark:border-sky-800 px-1.5 py-0.5 rounded shadow-2xs" title={`Linked to PM Schedule ${order.pmScheduleId}`}>
                                <ShieldCheck className="w-2.5 h-2.5 text-sky-600 dark:text-sky-400" />
                                <span>PM: {order.pmScheduleId}</span>
                              </span>
                            )}

                            {/* Auto-Generated by PM engine */}
                            {order.autoGenerated && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950/40 dark:text-indigo-300 dark:border-indigo-800 px-1.5 py-0.5 rounded" title="Automatically generated by PM Schedule engine">
                                <RefreshCw className="w-2.5 h-2.5 text-indigo-600 dark:text-indigo-400" />
                                <span>Auto-Generated</span>
                              </span>
                            )}

                            {/* Safety Documents indicator badge */}
                            {order.safetyDocumentStatus ? (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onOpenRequireDocument && onOpenRequireDocument(order.id, order.safetyDocumentType || 'JSA');
                                }}
                                className={`inline-flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-md border shadow-2xs hover:shadow-xs active:scale-95 transition-all cursor-pointer ${
                                  order.safetyDocumentStatus === 'Approved' || order.safetyDocumentStatus === 'Active'
                                    ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800'
                                    : order.safetyDocumentStatus === 'Pending Approval'
                                    ? 'bg-yellow-50 text-yellow-800 border-yellow-300 hover:bg-yellow-100 animate-pulse dark:bg-yellow-950/40 dark:text-yellow-300 dark:border-yellow-800'
                                    : order.safetyDocumentStatus === 'Rejected'
                                    ? 'bg-rose-50 text-rose-800 border-rose-300 hover:bg-rose-100 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800'
                                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700'
                                }`}
                                title={`Click to open ${order.safetyDocumentType || 'Document'}: ${order.safetyDocumentStatus}`}
                              >
                                <ShieldCheck className="w-2.5 h-2.5" />
                                <span>{order.safetyDocumentType || 'DOC'}: {order.safetyDocumentStatus}</span>
                              </button>
                            ) : (order.priority === 'High' || order.category === 'Electrical') ? (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onOpenRequireDocument && onOpenRequireDocument(order.id, 'JSA');
                                }}
                                className="inline-flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-300 hover:bg-amber-100 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800 active:scale-95 transition-all cursor-pointer shadow-2xs"
                                title="Click to generate JSA / PTW for this ticket"
                              >
                                <AlertTriangle className="w-2.5 h-2.5 text-amber-600 dark:text-amber-400" />
                                <span>PTW / JSA Needed</span>
                              </button>
                            ) : null}
                          </div>

                          {/* B. ACTION AREA: Action Buttons & Controls aligned to top-right */}
                          <div className="flex flex-wrap items-center gap-2 lg:justify-end shrink-0">
                            {editingOrderId === order.id ? (
                              <div className="flex flex-wrap items-center gap-2">
                                <select
                                  className="px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 shadow-xs focus:outline-none focus:ring-1 focus:ring-slate-500 max-w-[200px]"
                                  value={tempTechId}
                                  onChange={(e) => setTempTechId(e.target.value)}
                                >
                                  <option value="">Reassign Tech...</option>
                                  {activeStaff
                                    .filter((t, idx, arr) => arr.findIndex(x => (x.userId && x.userId === t.userId) || (x.username && x.username === t.username)) === idx)
                                    .map((t, idx) => (
                                      <option key={`${t.userId || t.username || t.fullName}-${idx}`} value={t.userId}>{t.fullName} — {t.position} — {t.role}</option>
                                  ))}
                                </select>
                                <button
                                  onClick={() => {
                                    if (tempTechId) {
                                      const techObj = techniciansList.find(t => t.id === tempTechId);
                                      if (techObj) {
                                        onReassignTechnician(order.id, techObj.id, techObj.name);
                                      }
                                    }
                                    setEditingOrderId(null);
                                  }}
                                  className="bg-slate-800 dark:bg-slate-700 text-white px-3 py-1.5 text-xs font-semibold rounded-lg hover:bg-slate-950 dark:hover:bg-slate-600 cursor-pointer shadow-xs whitespace-nowrap"
                                >
                                  Save
                                </button>
                                <button 
                                  onClick={() => setEditingOrderId(null)} 
                                  className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 underline px-1 py-1 cursor-pointer whitespace-nowrap"
                                >
                                  Cancel
                                </button>
                              </div>
                            ) : (
                              <>
                                {/* Auto-Assign trigger if order is pending technician assignment */}
                                {order.status === 'Pending Technician Assignment' && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const asset = assets.find(a => a.id === order.assetId);
                                      const res = autoAssignTechnician(
                                        {
                                          asset: asset || null,
                                          maintenanceType: order.category,
                                          priority: order.priority,
                                          issueDescription: order.issue,
                                          scheduledDate: order.scheduledDate,
                                          estimatedDuration: order.estimatedDuration,
                                          maxWorkloadLimit,
                                        },
                                        staffList || [],
                                        workOrders,
                                        pmTasks
                                      );
                                      if (res.success && res.technician) {
                                        onReassignTechnician(order.id, res.technicianId, res.technicianName);
                                      } else {
                                        alert(`Cannot assign yet:\n${res.rejectionSummary.join('\n') || 'No suitable technician currently available.'}`);
                                      }
                                    }}
                                    className="text-xs inline-flex items-center justify-center px-2.5 py-1.5 border border-amber-300 dark:border-amber-700 text-amber-900 dark:text-amber-200 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 rounded-lg transition-colors font-bold cursor-pointer whitespace-nowrap shadow-xs hover:shadow"
                                    title="Trigger automatic assignment engine now"
                                  >
                                    <UserCheck className="w-3.5 h-3.5 mr-1 text-emerald-600 dark:text-emerald-400" /> Auto-Assign
                                  </button>
                                )}

                                {/* Reassign action button */}
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingOrderId(order.id);
                                    setTempTechId(order.assignedToId);
                                  }}
                                  className="text-xs inline-flex items-center justify-center px-2.5 py-1.5 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg transition-colors font-semibold cursor-pointer whitespace-nowrap shadow-xs hover:shadow"
                                >
                                  <Sliders className="w-3.5 h-3.5 mr-1" /> Reassign
                                </button>

                                {/* Priority toggle */}
                                <select
                                  className="text-xs px-2.5 py-1.5 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors cursor-pointer whitespace-nowrap shadow-xs focus:outline-none focus:ring-1 focus:ring-slate-400"
                                  value={order.priority}
                                  onChange={(e) => onUpdatePriority(order.id, e.target.value as PriorityLevel)}
                                >
                                  <option value="Low">Low</option>
                                  <option value="Medium">Medium</option>
                                  <option value="High">High</option>
                                </select>

                                {/* Safety Documents Quick Actions */}
                                {onOpenRequireDocument && (
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onOpenRequireDocument(order.id, 'JSA');
                                    }}
                                    className="text-xs inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg font-bold border border-blue-400/80 bg-gradient-to-b from-blue-50 to-blue-100 dark:from-blue-950/50 dark:to-blue-900/40 text-blue-900 dark:text-blue-200 hover:from-blue-100 hover:to-blue-200 hover:border-blue-500 shadow-xs hover:shadow active:scale-95 transition-all duration-150 cursor-pointer whitespace-nowrap select-none group focus:outline-none focus:ring-2 focus:ring-blue-400/50"
                                    title="Buka / Jana Job Safety Analysis (JSA) bagi tiket ini"
                                    aria-label="Job Safety Analysis (JSA)"
                                  >
                                    <FileText className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 group-hover:scale-110 transition-transform shrink-0" />
                                    <span>JSA</span>
                                    <span className="text-[9px] px-1.5 py-0.2 rounded font-mono font-bold bg-blue-200/90 dark:bg-blue-800 text-blue-950 dark:text-blue-100 group-hover:bg-blue-300">
                                      {order.safetyDocumentType === 'JSA' && order.safetyDocumentStatus ? order.safetyDocumentStatus : '+ Doc'}
                                    </span>
                                  </button>
                                )}

                                {onOpenRequireDocument && (
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onOpenRequireDocument(order.id, 'PTW');
                                    }}
                                    className="text-xs inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg font-bold border border-amber-400/80 bg-gradient-to-b from-amber-50 to-amber-100 dark:from-amber-950/50 dark:to-amber-900/40 text-amber-950 dark:text-amber-200 hover:from-amber-100 hover:to-amber-200 hover:border-amber-500 shadow-xs hover:shadow active:scale-95 transition-all duration-150 cursor-pointer whitespace-nowrap select-none group focus:outline-none focus:ring-2 focus:ring-amber-400/50"
                                    title="Buka / Jana Permit to Work (PTW) bagi tiket ini"
                                    aria-label="Permit to Work (PTW)"
                                  >
                                    <Flame className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 group-hover:scale-110 transition-transform shrink-0" />
                                    <span>PTW</span>
                                    <span className="text-[9px] px-1.5 py-0.2 rounded font-mono font-bold bg-amber-200/90 dark:bg-amber-800 text-amber-950 dark:text-amber-100 group-hover:bg-amber-300">
                                      {order.safetyDocumentType === 'PTW' && order.safetyDocumentStatus ? order.safetyDocumentStatus : '+ Permit'}
                                    </span>
                                  </button>
                                )}
                              </>
                            )}
                          </div>
                        </div>

                        {/* C. MACHINE AND MAINTENANCE DETAILS - BALANCED 2-COLUMN RESPONSIVE GRID */}
                        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start w-full">
                          
                          {/* LEFT COLUMN: Machine Name, Asset ID, Location, Issue Description, Category */}
                          <div className="lg:col-span-7 space-y-2.5 min-w-0">
                            <div>
                              <div className="flex flex-wrap items-center gap-2">
                                <h4 className="font-display font-bold text-sm sm:text-base text-slate-800 dark:text-slate-100 leading-snug">
                                  {order.assetName}
                                </h4>
                                <span className="text-xs font-mono font-semibold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700">
                                  {order.assetId}
                                </span>
                                {order.location && (
                                  <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/80 px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700">
                                    <MapPin className="w-3 h-3 text-slate-400 shrink-0" /> {order.location}
                                  </span>
                                )}
                                {order.serialNumber && order.serialNumber !== 'N/A' && (
                                  <span className="text-[11px] font-mono text-slate-400 dark:text-slate-500">
                                    S/N: {order.serialNumber}
                                  </span>
                                )}
                              </div>

                              {/* Maintenance Description / Issue */}
                              <div className="bg-slate-900/90 dark:bg-slate-950/80 border border-slate-800 dark:border-slate-800/90 rounded-lg p-2.5 sm:p-3 mt-1.5 shadow-2xs">
                                <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                                  <Wrench className="w-3 h-3 text-sky-400" />
                                  <span>Maintenance Task & Issue Description</span>
                                </div>
                                <p className="text-xs sm:text-[13px] text-slate-100 dark:text-slate-200 leading-relaxed break-words font-sans">
                                  {order.issue}
                                </p>
                              </div>
                            </div>

                            {/* Maintenance Category & Type Tags */}
                            <div className="flex flex-wrap items-center gap-2 text-xs">
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900/90 dark:bg-slate-950/80 text-slate-200 border border-slate-800 font-medium">
                                <Tag className="w-3.5 h-3.5 text-slate-400" />
                                <span className="text-slate-400">Category:</span>
                                <strong className="text-slate-100 font-semibold">{order.category}</strong>
                              </span>
                              {order.maintenanceType && (
                                <span className="inline-flex items-center gap-1 text-xs font-semibold bg-emerald-950/40 text-emerald-300 border border-emerald-800/80 px-2.5 py-1 rounded-md">
                                  {order.maintenanceType}
                                </span>
                              )}
                            </div>
                          </div>

                          {/* RIGHT COLUMN: Assigned Technician, Estimated Duration, Auto-Assignment info */}
                          <div className="lg:col-span-5 space-y-2.5 min-w-0">
                            <div className="bg-slate-900/90 dark:bg-slate-950/80 border border-slate-800 dark:border-slate-800/90 rounded-lg p-3 space-y-2.5 shadow-2xs">
                              {/* Technician info row */}
                              <div className="flex items-center justify-between gap-3">
                                <div className="flex items-center gap-2.5 min-w-0">
                                  <div className="w-8 h-8 rounded-full bg-emerald-950/60 border border-emerald-700/60 flex items-center justify-center shrink-0">
                                    <UserCheck className="w-4 h-4 text-emerald-400" />
                                  </div>
                                  <div className="min-w-0">
                                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Assigned Technician</span>
                                    <span className={`text-xs sm:text-sm font-bold truncate block ${
                                      order.status === 'Pending Technician Assignment' ? 'text-rose-400' : 'text-slate-100'
                                    }`}>
                                      {order.assignedToName || 'Unassigned'}
                                    </span>
                                  </div>
                                </div>

                                {order.estimatedDuration && (
                                  <div className="text-right shrink-0">
                                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Est. Duration</span>
                                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-slate-200">
                                      <Timer className="w-3.5 h-3.5 text-slate-400" />
                                      {order.estimatedDuration} hrs
                                    </span>
                                  </div>
                                )}
                              </div>

                              {/* Auto-Assignment Reason if present */}
                              {order.assignmentReason && (
                                <div className="text-[11px] text-slate-200 bg-slate-950/90 border border-slate-800 rounded-md p-2 flex items-start gap-1.5 shadow-2xs">
                                  <Info className="w-3.5 h-3.5 text-sky-400 shrink-0 mt-0.5" />
                                  <span className="leading-snug">
                                    <strong className="text-slate-100 font-semibold">Auto-Assignment:</strong> {order.assignmentReason}
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>

                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
