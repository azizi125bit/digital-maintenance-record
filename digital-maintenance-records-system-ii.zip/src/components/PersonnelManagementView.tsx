import React, { useState, useMemo } from 'react';
import { Users, Search, Plus, UserPlus, Filter, X, Shield, Lock, Trash2, CheckCircle2, UserX, Edit2 } from 'lucide-react';
import { Personnel, UserRole, AccountStatus } from '../types';

interface PersonnelManagementViewProps {
  personnelList: Personnel[];
  onUpdatePersonnel: (updated: Personnel) => void;
  onAddPersonnel: (personnel: Personnel) => void;
  onRemovePersonnel: (userId: string) => void;
  currentRole: UserRole;
}

export const PersonnelManagementView: React.FC<PersonnelManagementViewProps> = ({ 
  personnelList, 
  onUpdatePersonnel,
  onAddPersonnel,
  onRemovePersonnel,
  currentRole 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [roleFilter, setRoleFilter] = useState<string>('All');
  
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [deactivateConfirmId, setDeactivateConfirmId] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);

  // New User Form State
  const [newFullName, setNewFullName] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('Technician');
  const [newDepartment, setNewDepartment] = useState('Plant Maintenance');
  const [newPrimarySkill, setNewPrimarySkill] = useState('Mechanical');
  const [newSkills, setNewSkills] = useState('Mechanical, Pump, Motor');
  const [newMaxWorkload, setNewMaxWorkload] = useState(5);

  if (currentRole !== 'Management') {
    return (
      <div className="flex flex-col items-center justify-center p-10 h-96 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm text-center">
        <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mb-4">
          <Lock className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold font-display text-slate-800 dark:text-white mb-2">Access Denied</h2>
        <p className="text-sm text-slate-500 max-w-md">
          You must have Management authorization to access the Personnel Management module.
        </p>
      </div>
    );
  }

  // Deduplicate personnelList by userId/username to guarantee absolute uniqueness
  const uniquePersonnelList = useMemo(() => {
    const seen = new Set<string>();
    return (personnelList || []).filter(p => {
      if (!p) return false;
      const key = p.userId || p.username;
      if (!key) return true;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }, [personnelList]);

  const filteredPersonnel = useMemo(() => {
    const term = (searchTerm || '').trim().toLowerCase();
    return uniquePersonnelList.filter(p => {
      const matchesSearch = !term || 
                            (p.fullName || '').toLowerCase().includes(term) || 
                            (p.employeeId || '').toLowerCase().includes(term) ||
                            (p.userId || '').toLowerCase().includes(term) ||
                            (p.username || '').toLowerCase().includes(term);
      const matchesStatus = statusFilter === 'All' || p.accountStatus === statusFilter;
      const matchesRole = roleFilter === 'All' || p.role === roleFilter;
      return matchesSearch && matchesStatus && matchesRole;
    });
  }, [uniquePersonnelList, searchTerm, statusFilter, roleFilter]);

  const handleDeactivate = (userId: string) => {
    const user = personnelList.find(p => p.userId === userId);
    if (user) {
      onUpdatePersonnel({ ...user, accountStatus: 'Inactive' });
    }
    setDeactivateConfirmId(null);
  };


  const handleDelete = (userId: string) => {
    onRemovePersonnel(userId);
    setDeleteConfirmId(null);
  };

  const handleActivate = (userId: string) => {
    const user = personnelList.find(p => p.userId === userId);
    if (user) {
      onUpdatePersonnel({ ...user, accountStatus: 'Active' });
    }
  };

  const handleResetPassword = (userId: string) => {
    const user = personnelList.find(p => p.userId === userId);
    if (user) {
      // Dummy password reset to 0000 for simplicity in this frontend
      onUpdatePersonnel({ ...user, pin: '0000' });
      alert(`Password for ${user.fullName} has been reset to default.`);
    }
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();

    const existsUsername = personnelList.some(p => (p.username || '').toLowerCase() === newUsername.trim().toLowerCase() && p.userId !== editingUserId);
    if (existsUsername) {
      alert('Username already registered.');
      return;
    }

    const parsedSkills = newSkills
      .split(',')
      .map(s => s.trim())
      .filter(s => s.length > 0);

    if (editingUserId) {
      const user = personnelList.find(p => p.userId === editingUserId);
      if (user) {
        onUpdatePersonnel({
          ...user,
          fullName: newFullName,
          username: newUsername,
          pin: newPassword, // Simulated hashed password saving
          role: newRole,
          department: newDepartment,
          primarySkill: newPrimarySkill,
          skills: parsedSkills,
          maxWorkload: newMaxWorkload,
          position: newRole === 'Technician' ? `${newPrimarySkill} Technician` : user.position || newRole
        });
        alert('Staff account updated successfully.');
      }
    } else {
      let uniqueId = `USR-${Math.floor(Math.random() * 90000) + 10000}`;
      let attempts = 0;
      while (personnelList.some(p => p.userId === uniqueId) && attempts < 50) {
        uniqueId = `USR-${Math.floor(Math.random() * 90000) + 10000}`;
        attempts++;
      }
      if (personnelList.some(p => p.userId === uniqueId)) {
        uniqueId = `USR-${Date.now()}`;
      }

      const newUser: Personnel = {
        userId: uniqueId,
        employeeId: `EMP-${Math.floor(Math.random() * 9000) + 1000}`,
        fullName: newFullName.trim(),
        username: newUsername.trim(),
        email: `${newUsername.trim().toLowerCase()}@dmr.company.com`,
        phone: '',
        department: newDepartment,
        position: newRole === 'Technician' ? `${newPrimarySkill} Technician` : newRole,
        role: newRole,
        accountStatus: 'Active',
        dateJoined: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        pin: newPassword,
        primarySkill: newPrimarySkill,
        skills: parsedSkills,
        maxWorkload: newMaxWorkload
      };
      onAddPersonnel(newUser);
      alert('Staff account created successfully.');
    }
    
    setIsAddModalOpen(false);
  };

  const openEditModal = (user: Personnel) => {
    setEditingUserId(user.userId);
    setNewFullName(user.fullName);
    setNewUsername(user.username || '');
    setNewPassword(user.pin || '');
    setNewRole(user.role);
    setNewDepartment(user.department || 'Plant Maintenance');
    setNewPrimarySkill(user.primarySkill || user.skills?.[0] || 'Mechanical');
    setNewSkills((user.skills || []).join(', ') || 'Mechanical, Pump, Motor');
    setNewMaxWorkload(user.maxWorkload || 5);
    setIsAddModalOpen(true);
  };

  const openAddModal = () => {
    setEditingUserId(null);
    setNewFullName('');
    setNewUsername('');
    setNewPassword('');
    setNewRole('Technician');
    setNewDepartment('Plant Maintenance');
    setNewPrimarySkill('Mechanical');
    setNewSkills('Mechanical, Pump, Motor, Lubrication');
    setNewMaxWorkload(5);
    setIsAddModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 bg-slate-50 dark:bg-slate-900/50">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2 font-display">
              <Users className="w-5 h-5 text-indigo-500 shrink-0" />
              <span>Personnel Management</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Manage employee accounts, roles, access privileges, and system status securely.
            </p>
          </div>
          
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button 
              onClick={openAddModal}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-900 dark:bg-amber-500 dark:hover:bg-sky-600 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-all shadow-md hover:shadow-lg cursor-pointer min-h-[38px]"
            >
              <UserPlus className="w-4 h-4" /> Add Personnel
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="p-3 sm:p-4 border-b border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-950 flex flex-col sm:flex-row gap-3 sm:gap-4 items-stretch sm:items-center">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder="Search by name or ID..." 
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs sm:text-sm focus:outline-none focus:border-indigo-500 dark:text-slate-200 min-h-[38px]"
            />
          </div>
          <div className="flex gap-2 sm:gap-3 w-full sm:w-auto">
            <select 
              value={roleFilter}
              onChange={e => setRoleFilter(e.target.value)}
              className="flex-1 sm:w-40 px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs sm:text-sm focus:outline-none dark:text-slate-200 min-h-[38px]"
            >
              <option value="All">All Roles</option>
              <option value="Management">Management</option>
              <option value="Technician">Technician</option>
              <option value="Supervisor">Supervisor</option>
            </select>
            <select 
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="flex-1 sm:w-40 px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs sm:text-sm focus:outline-none dark:text-slate-200 min-h-[38px]"
            >
              <option value="All">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="Suspended">Suspended</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                <th className="p-4">Employee ID</th>
                <th className="p-4">Full Name</th>
                <th className="p-4">Username</th>
                <th className="p-4">Department</th>
                <th className="p-4">Position</th>
                <th className="p-4">Role</th>
                <th className="p-4">Status</th>
                <th className="p-4">Last Login</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
              {filteredPersonnel.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-12 text-center text-slate-500">
                    <div className="flex flex-col items-center justify-center space-y-2">
                      <Users className="w-10 h-10 text-slate-300 dark:text-slate-600 mb-1" />
                      <p className="font-semibold text-slate-700 dark:text-slate-300 text-sm">
                        {personnelList.length === 0 ? "No staff registered yet." : "No staff records found matching filters."}
                      </p>
                      {personnelList.length === 0 && (
                        <p className="text-xs text-slate-400">
                          Use 'Add Staff' to create a staff account.
                        </p>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                filteredPersonnel.map((person, index) => (
                  <tr key={`${person.userId || 'usr'}-${person.username || ''}-${index}`} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                    <td className="p-4 text-xs font-mono text-slate-600 dark:text-slate-400">{person.employeeId}</td>
                    <td className="p-4 font-bold text-sm text-slate-800 dark:text-slate-200">{person.fullName}</td>
                    <td className="p-4 text-xs text-slate-600 dark:text-slate-400">@{person.username}</td>
                    <td className="p-4 text-xs text-slate-600 dark:text-slate-400">{person.department}</td>
                    <td className="p-4 text-xs font-semibold text-slate-700 dark:text-slate-300">{person.position}</td>
                    <td className="p-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        person.role === 'Management' ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-400' :
                        person.role === 'Technician' ? 'bg-amber-100 text-sky-700 dark:bg-sky-900/40 dark:text-amber-400' :
                        'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400'
                      }`}>
                        {person.role}
                      </span>
                    </td>
                    <td className="p-4">
                      <span className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase ${
                        person.accountStatus === 'Active' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400' :
                        person.accountStatus === 'Suspended' ? 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-400' :
                        'bg-slate-200 text-slate-600 dark:bg-slate-700/50 dark:text-slate-400'
                      }`}>
                        {person.accountStatus}
                      </span>
                    </td>
                    <td className="p-4 text-xs text-slate-500 dark:text-slate-400 font-mono">
                      {person.lastLogin ? new Date(person.lastLogin).toLocaleString() : 'Never'}
                    </td>
                    <td className="p-4 text-right flex items-center justify-end gap-2">
                      {person.accountStatus === 'Active' ? (
                        <button 
                          onClick={() => setDeactivateConfirmId(person.userId)}
                          className="text-[10px] font-bold px-2 py-1 bg-rose-50 hover:bg-rose-100 dark:bg-rose-900/20 dark:hover:bg-rose-900/40 text-rose-600 dark:text-rose-400 rounded transition-colors cursor-pointer"
                          title="Deactivate Account"
                        >
                          Deactivate
                        </button>
                      ) : (
                        <button 
                          onClick={() => handleActivate(person.userId)}
                          className="text-[10px] font-bold px-2 py-1 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-900/20 dark:hover:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 rounded transition-colors cursor-pointer"
                          title="Activate Account"
                        >
                          Activate
                        </button>
                      )}
                      
                      <button 
                        onClick={() => setDeleteConfirmId(person.userId)}
                        className="text-[10px] font-bold px-2 py-1 bg-rose-50 hover:bg-rose-100 dark:bg-rose-900/20 dark:hover:bg-rose-900/40 text-rose-600 dark:text-rose-400 rounded transition-colors cursor-pointer flex items-center gap-1"
                        title="Delete User"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-2 sm:p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl max-w-md w-full border border-slate-200 dark:border-slate-800 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-rose-50 dark:bg-rose-900/20">
              <h3 className="font-bold text-rose-600 dark:text-rose-400 flex items-center gap-2 text-sm sm:text-base">
                <Trash2 className="w-5 h-5 shrink-0" /> Confirm Deletion
              </h3>
              <button 
                onClick={() => setDeleteConfirmId(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer min-h-[36px] min-w-[36px] flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 sm:p-6">
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                Are you sure you want to permanently delete this user account?<br/><br/>
                This action cannot be undone. Historical records associated with this user might lose their reference.
              </p>
              <div className="flex flex-wrap items-center gap-2 sm:gap-3 justify-end mt-4 sm:mt-6">
                <button 
                  onClick={() => setDeleteConfirmId(null)}
                  className="flex-1 sm:flex-initial px-4 py-2 text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer min-h-[38px]"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => handleDelete(deleteConfirmId)}
                  className="flex-1 sm:flex-initial px-4 py-2 text-xs sm:text-sm font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-sm transition-colors cursor-pointer min-h-[38px]"
                >
                  Delete User
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Deactivate Confirmation Modal */}
      {deactivateConfirmId && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-2 sm:p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl max-w-md w-full border border-slate-200 dark:border-slate-800 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-rose-50 dark:bg-rose-900/20">
              <h3 className="font-bold text-rose-600 dark:text-rose-400 flex items-center gap-2 text-sm sm:text-base">
                <UserX className="w-5 h-5 shrink-0" /> Confirm Deactivation
              </h3>
              <button 
                onClick={() => setDeactivateConfirmId(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer min-h-[36px] min-w-[36px] flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 sm:p-6">
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                Are you sure you want to deactivate this employee?<br/><br/>
                The employee will no longer be able to log in or be assigned to new maintenance work. Historical records (Work Orders, PMs, Activity Logs) will remain intact.
              </p>
              <div className="flex flex-wrap items-center gap-2 sm:gap-3 justify-end mt-4 sm:mt-6">
                <button 
                  onClick={() => setDeactivateConfirmId(null)}
                  className="flex-1 sm:flex-initial px-4 py-2 text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer min-h-[38px]"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => handleDeactivate(deactivateConfirmId)}
                  className="flex-1 sm:flex-initial px-4 py-2 text-xs sm:text-sm font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-sm transition-colors cursor-pointer min-h-[38px]"
                >
                  Deactivate User
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Personnel Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl max-w-2xl w-full border border-slate-200 dark:border-slate-800 overflow-hidden my-4 sm:my-8 max-h-[92vh] sm:max-h-[90vh] flex flex-col">
            <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900/50 shrink-0">
              <h3 className="font-bold font-display text-base sm:text-lg text-slate-800 dark:text-white flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-indigo-500 shrink-0" /> <span>{editingUserId ? 'Edit Staff Profile' : 'Register New Personnel'}</span>
              </h3>
              <button 
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer min-h-[36px] min-w-[36px] flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleSaveUser} className="p-4 sm:p-6 overflow-y-auto flex-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5 mb-5 sm:mb-6">
                {/* Full Name */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Full Name</label>
                  <input required type="text" value={newFullName} onChange={e => setNewFullName(e.target.value)} className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-sm outline-none focus:border-indigo-500 dark:text-slate-200" placeholder="Full Name" />
                </div>
                {/* Username */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Username</label>
                  <input required type="text" value={newUsername} onChange={e => setNewUsername(e.target.value)} className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-sm outline-none focus:border-indigo-500 dark:text-slate-200" placeholder="Username" />
                </div>
                {/* Password */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Password</label>
                  <input required type="text" value={newPassword} onChange={e => setNewPassword(e.target.value)} className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-sm outline-none focus:border-indigo-500 dark:text-slate-200 font-mono" placeholder="Password" />
                </div>
                {/* System Role */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Role</label>
                  <select 
                    value={newRole} 
                    onChange={e => setNewRole(e.target.value as UserRole)}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-sm outline-none focus:border-indigo-500 dark:text-slate-200"
                  >
                    <option value="Technician">Technician</option>
                    <option value="Auditor">Auditor</option>
                    <option value="Management">Management</option>
                  </select>
                </div>

                {/* Department */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Department</label>
                  <select
                    value={newDepartment}
                    onChange={e => setNewDepartment(e.target.value)}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-sm outline-none focus:border-indigo-500 dark:text-slate-200"
                  >
                    <option value="Plant Maintenance">Plant Maintenance</option>
                    <option value="Machining">Machining</option>
                    <option value="Electrical">Electrical</option>
                    <option value="Pneumatics">Pneumatics</option>
                    <option value="Compliance">Compliance</option>
                    <option value="Operations">Operations</option>
                  </select>
                </div>

                {/* Primary Skill */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Primary Skill</label>
                  <select
                    value={newPrimarySkill}
                    onChange={e => setNewPrimarySkill(e.target.value)}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-sm outline-none focus:border-indigo-500 dark:text-slate-200"
                  >
                    <option value="Mechanical">Mechanical</option>
                    <option value="Electrical">Electrical</option>
                    <option value="Pneumatic">Pneumatic</option>
                    <option value="General">General</option>
                  </select>
                </div>

                {/* Maintenance Skills (Comma separated) */}
                <div className="space-y-1 sm:col-span-2">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Maintenance Skills (comma separated)
                  </label>
                  <input
                    type="text"
                    value={newSkills}
                    onChange={e => setNewSkills(e.target.value)}
                    placeholder="e.g. Mechanical, Pump, Motor, Lubrication, Alignment"
                    className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-sm outline-none focus:border-indigo-500 dark:text-slate-200"
                  />
                  <p className="text-[10px] text-slate-400">Used by the automatic work order assignment engine for skill matching.</p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 sm:gap-3 justify-end pt-4 border-t border-slate-100 dark:border-slate-800">
                <button 
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="flex-1 sm:flex-initial px-4 sm:px-5 py-2 sm:py-2.5 text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer min-h-[38px]"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 sm:flex-initial px-4 sm:px-5 py-2 sm:py-2.5 text-xs sm:text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors flex items-center justify-center gap-2 cursor-pointer min-h-[38px]"
                >
                  <CheckCircle2 className="w-4 h-4" /> {editingUserId ? 'Save Account' : 'Register User'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
