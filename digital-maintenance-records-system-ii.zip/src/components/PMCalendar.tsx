import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '../lib/supabase';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon, 
  Clock, 
  CheckCircle, 
  AlertTriangle, 
  Plus, 
  X, 
  Search, 
  Filter, 
  Wrench, 
  FileText, 
  Printer,
  RotateCcw
} from 'lucide-react';
import { PMSchedule, PriorityLevel, Personnel, WorkOrder } from '../types';
import { generatePMWorkRecordPDF } from '../utils/pmPdfExport';

interface PMCalendarProps {
  staffList: Personnel[];
  authorizedUser: string | null;
  schedules?: any[];
  onAddWorkOrder?: (order: Omit<WorkOrder, 'id' | 'timestamp' | 'status'>) => void;
  onAddPMClick: (date: string) => void;
  onViewPMClick: (pm: PMSchedule) => void;
}

export const PMCalendar: React.FC<PMCalendarProps> = ({ 
  staffList, 
  authorizedUser, 
  schedules: propSchedules, 
  onAddWorkOrder,
  onAddPMClick, 
  onViewPMClick 
}) => {
  const [dbSchedules, setDbSchedules] = useState<PMSchedule[]>([]);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isGeneratingWO, setIsGeneratingWO] = useState(false);
  const [woSuccessMsg, setWoSuccessMsg] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  
  // Format local date YYYY-MM-DD reliably without UTC timezone distortion
  const formatLocalDate = (year: number, monthIndex: number, day: number) => {
    const m = String(monthIndex + 1).padStart(2, '0');
    const d = String(day).padStart(2, '0');
    return `${year}-${m}-${d}`;
  };

  const todayObj = new Date();
  const todayStr = formatLocalDate(todayObj.getFullYear(), todayObj.getMonth(), todayObj.getDate());
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);

  // Normalize any PMSchedule object from DB, props or local form submissions
  const normalizePMSchedule = (p: any): PMSchedule => {
    const rawDate = p.scheduled_date || p.next_due_date || p.nextDue || p.scheduledDate || p.due || todayStr;
    const dateOnly = String(rawDate).split('T')[0];

    return {
      id: p.id || `PM-${Math.floor(Math.random() * 10000)}`,
      asset_id: p.asset_id || p.asset || p.machine || 'General',
      machine_name: p.machine_name || p.asset_name || p.machine || p.name || 'Equipment',
      maintenance_task: p.maintenance_task || p.issue || p.description || p.type || 'Preventive Maintenance',
      maintenance_type: p.maintenance_type || p.category || p.type || 'General',
      frequency: p.frequency || p.freq || 'Monthly',
      scheduled_date: dateOnly,
      scheduled_time: p.scheduled_time || p.scheduledTime || '09:00 AM',
      estimated_duration: Number(p.estimated_duration || p.downtime_hours || p.estimatedDuration || 2),
      assigned_technician: p.assigned_technician || p.assigned_to_name || p.assignedTo || p.tech || 'Unassigned',
      supervisor: p.supervisor || p.logged_by || authorizedUser || 'Supervisor',
      priority: (p.priority || 'Medium') as PriorityLevel,
      status: p.status || 'Pending',
      safety_requirements: p.safety_requirements || p.safetyRequirements || [],
      remarks: p.remarks || ''
    };
  };

  // Filters
  const [statusFilter, setStatusFilter] = useState('All');
  const [techFilter, setTechFilter] = useState('All');
  const [assetFilter, setAssetFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');
  
  const [viewingPM, setViewingPM] = useState<PMSchedule | null>(null);
  
  const fetchPMs = async () => {
    try {
      const { data, error } = await supabase.from('preventive_maintenance').select('*');
      if (!error && data) {
        const mapped: PMSchedule[] = data.map(normalizePMSchedule);
        setDbSchedules(mapped);
      }
    } catch (err) {
      console.error('Failed to fetch PMs from Firestore in PMCalendar:', err);
    }
  };

  useEffect(() => {
    fetchPMs();
  }, []);

  // Merge propSchedules and dbSchedules (deduped by ID)
  const allSchedules = useMemo(() => {
    const combined = [...(propSchedules || []), ...dbSchedules];
    const map = new Map<string, PMSchedule>();
    combined.forEach(item => {
      if (item && (item.id || item.asset_id || item.machine)) {
        const normalized = normalizePMSchedule(item);
        map.set(normalized.id, normalized);
      }
    });
    return Array.from(map.values());
  }, [propSchedules, dbSchedules]);

  const nextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  const prevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  const goToday = () => {
    const now = new Date();
    setCurrentDate(now);
    setSelectedDate(formatLocalDate(now.getFullYear(), now.getMonth(), now.getDate()));
  };

  const filteredSchedules = useMemo(() => {
    return allSchedules.map(pm => {
      // Auto mark overdue
      if (pm.status !== 'Completed' && pm.status !== 'Cancelled') {
        const pmDate = new Date(pm.scheduled_date);
        const now = new Date();
        now.setHours(0,0,0,0);
        if (pmDate < now) {
          return { ...pm, status: 'Overdue' };
        }
      }
      return pm;
    }).filter(pm => {
      if (statusFilter !== 'All' && statusFilter !== 'Today') {
        if (pm.status !== statusFilter) return false;
      }
      if (statusFilter === 'Today') {
        if (pm.scheduled_date !== todayStr) return false;
      }
      if (techFilter !== 'All') {
        if (pm.assigned_technician !== techFilter) return false;
      }
      if (assetFilter !== 'All') {
        if (pm.asset_id !== assetFilter && pm.machine_name !== assetFilter) return false;
      }
      if (priorityFilter !== 'All') {
        if (pm.priority !== priorityFilter) return false;
      }
      return true;
    });
  }, [allSchedules, statusFilter, techFilter, assetFilter, priorityFilter, todayStr]);

  const pmsByDate = useMemo(() => {
    const map: Record<string, PMSchedule[]> = {};
    filteredSchedules.forEach(pm => {
      const d = (pm.scheduled_date || '').split('T')[0];
      if (d) {
        if (!map[d]) map[d] = [];
        map[d].push(pm);
      }
    });
    return map;
  }, [filteredSchedules]);

  // Calendar calculations (Monday start: M T W T F S S)
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const daysInCurrentMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfWeek = new Date(year, month, 1).getDay(); // 0 = Sun, 1 = Mon ...
  const startOffset = (firstDayOfWeek + 6) % 7; // 0 for Mon, 6 for Sun
  const daysInPrevMonth = new Date(year, month, 0).getDate();

  const totalSlots = startOffset + daysInCurrentMonth;
  const totalRows = Math.ceil(totalSlots / 7); // 5 or 6 rows
  const totalGridCells = totalRows * 7; // 35 or 42 cells

  const weekdays = [
    { short: 'M', full: 'Mon' },
    { short: 'T', full: 'Tue' },
    { short: 'W', full: 'Wed' },
    { short: 'T', full: 'Thu' },
    { short: 'F', full: 'Fri' },
    { short: 'S', full: 'Sat' },
    { short: 'S', full: 'Sun' }
  ];

  const calendarDays = useMemo(() => {
    const days = [];
    for (let i = 0; i < totalGridCells; i++) {
      let dayNumber: number;
      let cellDateStr: string;
      let isCurrentMonth: boolean;

      if (i < startOffset) {
        dayNumber = daysInPrevMonth - startOffset + i + 1;
        const prevDate = new Date(year, month - 1, dayNumber);
        cellDateStr = formatLocalDate(prevDate.getFullYear(), prevDate.getMonth(), dayNumber);
        isCurrentMonth = false;
      } else if (i < startOffset + daysInCurrentMonth) {
        dayNumber = i - startOffset + 1;
        cellDateStr = formatLocalDate(year, month, dayNumber);
        isCurrentMonth = true;
      } else {
        dayNumber = i - (startOffset + daysInCurrentMonth) + 1;
        const nextDate = new Date(year, month + 1, dayNumber);
        cellDateStr = formatLocalDate(nextDate.getFullYear(), nextDate.getMonth(), dayNumber);
        isCurrentMonth = false;
      }

      const isToday = cellDateStr === todayStr;
      const isSelected = cellDateStr === selectedDate;
      const dayPMs = pmsByDate[cellDateStr] || [];

      days.push({
        dayNumber,
        cellDateStr,
        isCurrentMonth,
        isToday,
        isSelected,
        dayPMs
      });
    }
    return days;
  }, [totalGridCells, startOffset, daysInPrevMonth, year, month, daysInCurrentMonth, todayStr, selectedDate, pmsByDate]);

  const handleDayClick = (dayInfo: typeof calendarDays[0]) => {
    if (!dayInfo.isCurrentMonth) {
      const clickedDate = new Date(dayInfo.cellDateStr + 'T00:00:00');
      setCurrentDate(new Date(clickedDate.getFullYear(), clickedDate.getMonth(), 1));
    }
    setSelectedDate(dayInfo.cellDateStr);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed': return 'bg-emerald-400';
      case 'In Progress': return 'bg-amber-400';
      case 'Overdue': return 'bg-rose-500';
      default: return 'bg-sky-400';
    }
  };

  const activeFiltersCount = 
    (statusFilter !== 'All' ? 1 : 0) + 
    (techFilter !== 'All' ? 1 : 0) + 
    (assetFilter !== 'All' ? 1 : 0) + 
    (priorityFilter !== 'All' ? 1 : 0);

  const selectedDatePMs = selectedDate ? (pmsByDate[selectedDate] || []) : [];

  const selectedDateFormatted = useMemo(() => {
    if (!selectedDate) return '';
    try {
      const parts = selectedDate.split('-');
      const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
      return d.toLocaleDateString('default', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
    } catch {
      return selectedDate;
    }
  }, [selectedDate]);

  return (
    <div className="flex flex-col gap-4 w-full">
      {/* COMPACT MONTHLY CALENDAR CARD */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-5 shadow-xl text-slate-100 flex flex-col w-full overflow-hidden">
        
        {/* COMPACT CALENDAR HEADER (One Horizontal Row) */}
        <div className="flex items-center justify-between gap-1.5 sm:gap-3 mb-2.5 sm:mb-3 pb-2.5 sm:pb-3 border-b border-slate-800/80 min-h-[38px]">
          {/* Left: Month, Year & Today button */}
          <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
            <h2 className="text-xs sm:text-base font-bold text-white tracking-tight truncate flex items-center gap-1">
              <span>{currentDate.toLocaleString('default', { month: 'long' })}</span>
              <span className="text-slate-400 font-semibold">{currentDate.getFullYear()}</span>
            </h2>
            <button 
              type="button"
              onClick={goToday} 
              className="px-2 py-0.5 text-[10px] sm:text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-sky-400 hover:text-sky-300 border border-slate-700/80 rounded-md transition-colors cursor-pointer shrink-0"
              title="Jump to today"
            >
              Today
            </button>
          </div>

          {/* Right: Controls in one horizontal row */}
          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
            {/* Filter Toggle Button */}
            <button 
              type="button"
              onClick={() => setShowFilters(prev => !prev)}
              className={`p-1.5 sm:px-2 sm:py-1 rounded-lg border text-xs flex items-center gap-1 transition-colors cursor-pointer ${
                activeFiltersCount > 0 
                  ? 'bg-sky-500/20 text-sky-300 border-sky-500/50' 
                  : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border-slate-700/80'
              }`}
              title="Filter PM schedules"
              aria-label="Filter PM schedules"
            >
              <Filter className="w-3.5 h-3.5" />
              {activeFiltersCount > 0 && (
                <span className="text-[10px] font-bold bg-sky-500 text-white rounded-full w-4 h-4 flex items-center justify-center leading-none">
                  {activeFiltersCount}
                </span>
              )}
            </button>

            {/* Prev Month */}
            <button 
              type="button"
              onClick={prevMonth} 
              className="p-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg border border-slate-700/80 transition-colors cursor-pointer"
              aria-label="Previous month"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            {/* Next Month */}
            <button 
              type="button"
              onClick={nextMonth} 
              className="p-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg border border-slate-700/80 transition-colors cursor-pointer"
              aria-label="Next month"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            {/* Add PM Schedule (+) Button */}
            <button 
              type="button"
              onClick={() => onAddPMClick(selectedDate || todayStr)}
              className="inline-flex items-center justify-center gap-1 px-2.5 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors cursor-pointer"
              title="Add PM Schedule"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Add PM</span>
            </button>
          </div>
        </div>

        {/* EXPANDABLE FILTER ROW */}
        {showFilters && (
          <div className="mb-3 p-2.5 bg-slate-950/70 border border-slate-800 rounded-xl grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs animate-in fade-in duration-150">
            <div>
              <label className="block text-[10px] font-semibold uppercase text-slate-400 mb-1">Status</label>
              <select 
                value={statusFilter} 
                onChange={e => setStatusFilter(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-2 py-1.5 outline-none focus:border-sky-500"
              >
                <option value="All">All Statuses</option>
                <option value="Today">Today Only</option>
                <option value="Pending">Pending</option>
                <option value="In Progress">In Progress</option>
                <option value="Completed">Completed</option>
                <option value="Overdue">Overdue</option>
              </select>
            </div>
            
            <div>
              <label className="block text-[10px] font-semibold uppercase text-slate-400 mb-1">Technician</label>
              <select 
                value={techFilter} 
                onChange={e => setTechFilter(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-2 py-1.5 outline-none focus:border-sky-500"
              >
                <option value="All">All Technicians</option>
                {staffList
                  .filter(s => s.role === 'Technician')
                  .filter((t, idx, arr) => arr.findIndex(x => (x.userId && x.userId === t.userId) || (x.fullName && x.fullName === t.fullName)) === idx)
                  .map((t, idx) => (
                    <option key={`${t.userId || t.fullName}-${idx}`} value={t.fullName}>{t.fullName}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-semibold uppercase text-slate-400 mb-1">Asset</label>
              <select 
                value={assetFilter} 
                onChange={e => setAssetFilter(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-2 py-1.5 outline-none focus:border-sky-500"
              >
                <option value="All">All Assets</option>
                {Array.from(new Set(allSchedules.map(s => s.asset_id))).filter(Boolean).map(a => (
                  <option key={a} value={a}>{a}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-semibold uppercase text-slate-400 mb-1">Priority</label>
              <select 
                value={priorityFilter} 
                onChange={e => setPriorityFilter(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-2 py-1.5 outline-none focus:border-sky-500"
              >
                <option value="All">All Priorities</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>

            {activeFiltersCount > 0 && (
              <div className="col-span-2 sm:col-span-4 flex justify-end pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setStatusFilter('All');
                    setTechFilter('All');
                    setAssetFilter('All');
                    setPriorityFilter('All');
                  }}
                  className="text-[11px] text-sky-400 hover:text-sky-300 font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" /> Reset Filters
                </button>
              </div>
            )}
          </div>
        )}

        {/* WEEKDAY LABELS (M T W T F S S) */}
        <div className="grid grid-cols-7 gap-1 sm:gap-1.5 mb-1 text-center">
          {weekdays.map((w, idx) => (
            <div key={idx} className="py-1 text-[11px] sm:text-xs font-bold text-slate-400 uppercase tracking-wider">
              <span className="sm:hidden">{w.short}</span>
              <span className="hidden sm:inline">{w.full}</span>
            </div>
          ))}
        </div>

        {/* 7-COLUMN MONTHLY CALENDAR GRID */}
        <div className="grid grid-cols-7 gap-1 sm:gap-1.5 w-full">
          {calendarDays.map((dayInfo) => (
            <div 
              key={dayInfo.cellDateStr}
              onClick={() => handleDayClick(dayInfo)}
              className={`
                relative flex flex-col items-center justify-between
                p-1 sm:p-1.5 md:p-2
                h-10 sm:h-12 md:h-20 lg:h-24
                border rounded-lg sm:rounded-xl cursor-pointer transition-all duration-150 select-none group
                ${!dayInfo.isCurrentMonth 
                  ? 'bg-slate-950/20 border-slate-800/40 text-slate-600 opacity-35 hover:opacity-70' 
                  : dayInfo.isSelected
                    ? 'bg-sky-950/80 border-sky-400 ring-2 ring-sky-400 shadow-[0_0_12px_rgba(56,189,248,0.3)] z-10'
                    : dayInfo.isToday
                      ? 'bg-slate-800/70 border-sky-500/60 ring-1 ring-sky-500/40 hover:border-sky-400'
                      : 'bg-slate-900/80 border-slate-800/80 hover:bg-slate-800/60 hover:border-slate-700'
                }
              `}
            >
              {/* Date Number Header inside cell */}
              <div className="w-full flex items-center justify-between">
                <span className={`
                  text-xs sm:text-sm font-semibold leading-none
                  ${dayInfo.isSelected 
                    ? 'text-sky-300 font-bold' 
                    : dayInfo.isToday 
                      ? 'text-sky-400 font-bold' 
                      : dayInfo.isCurrentMonth 
                        ? 'text-slate-100' 
                        : 'text-slate-600'
                  }
                `}>
                  {dayInfo.dayNumber}
                </span>

                {dayInfo.isToday && (
                  <span className="hidden lg:inline text-[9px] font-bold uppercase tracking-wider text-sky-400 bg-sky-950/80 px-1 py-0.5 rounded border border-sky-500/30">
                    Today
                  </span>
                )}
              </div>

              {/* Mobile / Tablet Compact Dot Indicators */}
              {dayInfo.dayPMs.length > 0 && (
                <div className="flex items-center justify-center gap-0.5 sm:gap-1 mt-auto w-full md:hidden pb-0.5">
                  {dayInfo.dayPMs.slice(0, 3).map((pm, idx) => (
                    <span 
                      key={pm.id || idx}
                      className={`w-1.5 h-1.5 rounded-full shrink-0 ${getStatusColor(pm.status)}`}
                      title={`${pm.machine_name}: ${pm.maintenance_task} (${pm.status})`}
                    />
                  ))}
                  {dayInfo.dayPMs.length > 3 && (
                    <span className="text-[8px] font-bold text-sky-400 leading-none">
                      +{dayInfo.dayPMs.length - 2}
                    </span>
                  )}
                </div>
              )}

              {/* Desktop Badges (md and up) */}
              {dayInfo.dayPMs.length > 0 && (
                <div className="hidden md:flex flex-col gap-1 mt-auto w-full overflow-hidden">
                  {dayInfo.dayPMs.slice(0, 2).map((pm, idx) => (
                    <div 
                      key={pm.id || idx}
                      onClick={(e) => {
                        e.stopPropagation();
                        setViewingPM(pm);
                        onViewPMClick(pm);
                      }}
                      className={`text-[10px] truncate px-1.5 py-0.5 rounded font-medium flex items-center gap-1 cursor-pointer transition-all hover:scale-[1.02] ${
                        pm.status === 'Completed' ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/60' :
                        pm.status === 'In Progress' ? 'bg-amber-950/80 text-amber-300 border border-amber-800/60' :
                        pm.status === 'Overdue' ? 'bg-rose-950/80 text-rose-300 border border-rose-800/60' :
                        'bg-sky-950/80 text-sky-300 border border-sky-800/60'
                      }`}
                      title={`${pm.machine_name} - ${pm.maintenance_task} (${pm.status})`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${getStatusColor(pm.status)}`} />
                      <span className="truncate">{pm.scheduled_time || '09:00'} {pm.machine_name}</span>
                    </div>
                  ))}
                  {dayInfo.dayPMs.length > 2 && (
                    <div className="text-[9px] text-slate-400 font-semibold px-1">
                      +{dayInfo.dayPMs.length - 2} more
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* SELECTED DATE PM SCHEDULE DETAILS PANEL (Appears below calendar, uses normal page scroll) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg flex flex-col gap-3 text-slate-100">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5 flex-wrap">
            <div className="p-2 bg-sky-950/80 border border-sky-500/30 rounded-lg text-sky-400 shrink-0">
              <CalendarIcon className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2 flex-wrap">
                <span>{selectedDateFormatted}</span>
                {selectedDate === todayStr && (
                  <span className="text-[10px] uppercase font-bold tracking-wider bg-sky-500/20 text-sky-400 border border-sky-500/30 px-2 py-0.5 rounded">
                    Today
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {selectedDatePMs.length === 0 
                  ? 'No PM routines scheduled for this date' 
                  : `${selectedDatePMs.length} schedule${selectedDatePMs.length === 1 ? '' : 's'} (${selectedDatePMs.filter(p => p.status === 'Completed').length} completed, ${selectedDatePMs.filter(p => p.status === 'Overdue').length} overdue)`
                }
              </p>
            </div>
          </div>
          
          <button 
            type="button"
            onClick={() => onAddPMClick(selectedDate)}
            className="inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors cursor-pointer shrink-0 self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Add PM for this date</span>
          </button>
        </div>

        {selectedDatePMs.length === 0 ? (
          <div className="text-center py-8 text-slate-500">
            <CalendarIcon className="w-8 h-8 text-slate-700 mx-auto mb-2 opacity-60" />
            <p className="text-xs font-medium text-slate-400">No Preventive Maintenance scheduled for this date.</p>
            <button 
              type="button"
              onClick={() => onAddPMClick(selectedDate)}
              className="mt-2.5 text-xs text-sky-400 hover:text-sky-300 font-semibold inline-flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" /> Create new PM schedule
            </button>
          </div>
        ) : (
          <div className="space-y-2.5">
            {selectedDatePMs.map((pm, idx) => (
              <div 
                key={`${pm.id || 'pm'}-${idx}`} 
                onClick={() => { setViewingPM(pm); onViewPMClick(pm); }}
                className="bg-slate-950/60 border border-slate-800/90 hover:border-slate-700 rounded-xl p-3 sm:p-4 shadow-sm hover:shadow-md transition-all cursor-pointer group"
              >
                <div className="flex justify-between items-start mb-2 gap-2 flex-wrap">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-bold font-mono text-sky-400 bg-sky-950/80 px-2 py-0.5 rounded border border-sky-800/40">
                      {pm.id}
                    </span>
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${
                      pm.status === 'Completed' ? 'bg-emerald-950/80 text-emerald-400 border-emerald-800/60' :
                      pm.status === 'In Progress' ? 'bg-amber-950/80 text-amber-400 border-amber-800/60' :
                      pm.status === 'Overdue' ? 'bg-rose-950/80 text-rose-400 border-rose-800/60' :
                      'bg-sky-950/80 text-sky-400 border-sky-800/60'
                    }`}>
                      {pm.status}
                    </span>
                  </div>
                  <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border shrink-0 ${
                    pm.priority === 'High' ? 'bg-rose-950/80 text-rose-400 border-rose-800/60' :
                    pm.priority === 'Medium' ? 'bg-amber-950/80 text-amber-400 border-amber-800/60' : 
                    'bg-emerald-950/80 text-emerald-400 border-emerald-800/60'
                  }`}>
                    {pm.priority} Priority
                  </span>
                </div>
                
                <h4 className="text-sm sm:text-base font-bold text-white mb-1 break-words group-hover:text-sky-300 transition-colors">
                  {pm.machine_name} <span className="text-xs font-mono font-normal text-slate-400">({pm.asset_id})</span>
                </h4>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-2.5 pt-2.5 border-t border-slate-800/80 text-xs">
                  <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase">Task</p>
                    <p className="text-slate-300 truncate font-medium">{pm.maintenance_task}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase">Time</p>
                    <p className="text-slate-300 flex items-center gap-1 font-medium">
                      <Clock className="w-3.5 h-3.5 text-slate-500 shrink-0" /> 
                      <span className="truncate">{pm.scheduled_time || '09:00 AM'}</span>
                    </p>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase">Technician</p>
                    <p className="text-slate-300 truncate font-medium">{pm.assigned_technician}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase">Type</p>
                    <p className="text-slate-300 truncate font-medium">{pm.maintenance_type}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* VIEW PM DETAILS MODAL (Full details, work order generation, PDF export, completion) */}
      {viewingPM && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-2 sm:p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-slate-900 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[92vh] sm:max-h-[90vh] flex flex-col animate-in zoom-in-95 duration-150 border border-slate-800 text-slate-100">
            <div className="flex justify-between items-center p-4 sm:p-5 border-b border-slate-800 bg-slate-950/50 rounded-t-2xl shrink-0">
              <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <Wrench className="w-4 h-4 sm:w-5 sm:h-5 text-sky-400 shrink-0" />
                <span>PM Schedule Details</span>
              </h3>
              <button 
                type="button"
                onClick={() => setViewingPM(null)} 
                className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors cursor-pointer shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4">
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-3">
                <div>
                  <h4 className="text-lg sm:text-xl font-bold text-white break-words">{viewingPM.machine_name}</h4>
                  <p className="font-mono text-slate-400 text-xs sm:text-sm">{viewingPM.asset_id}</p>
                </div>
                <div className="flex sm:flex-col items-center sm:items-end gap-2 flex-wrap">
                  <span className="font-mono font-bold text-sky-400 bg-sky-950/80 px-2.5 py-1 rounded-lg border border-sky-800/60 text-xs sm:text-sm">
                    {viewingPM.id}
                  </span>
                  <span className={`px-2.5 py-1 text-[10px] sm:text-xs font-bold uppercase tracking-wider rounded-lg border ${
                    viewingPM.status === 'Completed' ? 'bg-emerald-950/80 text-emerald-400 border-emerald-800/60' :
                    viewingPM.status === 'In Progress' ? 'bg-amber-950/80 text-amber-400 border-amber-800/60' :
                    viewingPM.status === 'Overdue' ? 'bg-rose-950/80 text-rose-400 border-rose-800/60' :
                    'bg-sky-950/80 text-sky-400 border-sky-800/60'
                  }`}>
                    {viewingPM.status}
                  </span>
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3">
                <div className="bg-slate-950/50 p-3 sm:p-3.5 rounded-xl border border-slate-800/80">
                  <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Maintenance Task</p>
                  <p className="text-xs sm:text-sm font-medium text-slate-200 break-words">{viewingPM.maintenance_task}</p>
                </div>
                <div className="bg-slate-950/50 p-3 sm:p-3.5 rounded-xl border border-slate-800/80">
                  <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Maintenance Type</p>
                  <p className="text-xs sm:text-sm font-medium text-slate-200">{viewingPM.maintenance_type}</p>
                </div>
                <div className="bg-slate-950/50 p-3 sm:p-3.5 rounded-xl border border-slate-800/80">
                  <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Scheduled Date & Time</p>
                  <p className="text-xs sm:text-sm font-medium text-slate-200">{viewingPM.scheduled_date} at {viewingPM.scheduled_time || '09:00 AM'}</p>
                </div>
                <div className="bg-slate-950/50 p-3 sm:p-3.5 rounded-xl border border-slate-800/80">
                  <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Estimated Duration</p>
                  <p className="text-xs sm:text-sm font-medium text-slate-200">{viewingPM.estimated_duration} Hours</p>
                </div>
                <div className="bg-slate-950/50 p-3 sm:p-3.5 rounded-xl border border-slate-800/80">
                  <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Frequency</p>
                  <p className="text-xs sm:text-sm font-medium text-slate-200">{viewingPM.frequency}</p>
                </div>
                <div className="bg-slate-950/50 p-3 sm:p-3.5 rounded-xl border border-slate-800/80">
                  <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Priority</p>
                  <p className="text-xs sm:text-sm font-medium text-slate-200">{viewingPM.priority}</p>
                </div>
                <div className="bg-slate-950/50 p-3 sm:p-3.5 rounded-xl border border-slate-800/80">
                  <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Assigned Technician</p>
                  <p className="text-xs sm:text-sm font-medium text-slate-200 truncate">{viewingPM.assigned_technician}</p>
                </div>
                <div className="bg-slate-950/50 p-3 sm:p-3.5 rounded-xl border border-slate-800/80">
                  <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Supervisor</p>
                  <p className="text-xs sm:text-sm font-medium text-slate-200 truncate">{viewingPM.supervisor}</p>
                </div>
              </div>
              
              {viewingPM.safety_requirements && viewingPM.safety_requirements.length > 0 && (
                <div>
                  <h5 className="text-xs font-bold text-slate-300 border-b border-slate-800 pb-1.5 mb-2.5 uppercase tracking-wider">
                    Safety Requirements
                  </h5>
                  <ul className="space-y-1.5">
                    {viewingPM.safety_requirements.map((req, i) => (
                      <li key={i} className="flex items-center gap-2 text-xs text-slate-300">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> {req}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              
              {viewingPM.remarks && (
                <div>
                  <h5 className="text-xs font-bold text-slate-300 border-b border-slate-800 pb-1.5 mb-2.5 uppercase tracking-wider">
                    Remarks
                  </h5>
                  <p className="text-xs text-slate-300 whitespace-pre-wrap">{viewingPM.remarks}</p>
                </div>
              )}

              {woSuccessMsg && (
                <div className="p-3 bg-emerald-950/80 border border-emerald-600/60 rounded-xl text-xs text-emerald-300 font-medium flex items-center gap-2 animate-in fade-in duration-150">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                  <div>
                    <p className="font-bold">Work Order Generated Successfully!</p>
                    <p className="text-[11px] text-emerald-400/90">{woSuccessMsg}</p>
                  </div>
                </div>
              )}
            </div>
            
            <div className="p-3 sm:p-4 border-t border-slate-800 bg-slate-950/50 rounded-b-2xl flex flex-wrap justify-end gap-2 shrink-0">
               <button 
                 type="button"
                 onClick={() => setViewingPM(null)} 
                 className="px-3.5 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-lg transition-colors cursor-pointer"
               >
                 Close
               </button>
               <button 
                 type="button"
                 onClick={async () => {
                   if (!viewingPM) return;
                   await generatePMWorkRecordPDF({
                     pmSchedule: viewingPM,
                     scheduleId: viewingPM.id,
                     printMode: false,
                     staffList
                   });
                 }}
                 className="px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-lg transition-colors cursor-pointer inline-flex items-center gap-1.5"
               >
                 <FileText className="w-3.5 h-3.5 text-sky-400" />
                 PDF
               </button>
               <button 
                 type="button"
                 onClick={async () => {
                   if (!viewingPM) return;
                   await generatePMWorkRecordPDF({
                     pmSchedule: viewingPM,
                     scheduleId: viewingPM.id,
                     printMode: true,
                     staffList
                   });
                 }}
                 className="px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-lg transition-colors cursor-pointer inline-flex items-center gap-1.5"
               >
                 <Printer className="w-3.5 h-3.5 text-slate-400" />
                 Print
               </button>
               <button 
                 type="button"
                 disabled={isGeneratingWO}
                 onClick={async () => {
                   if (!viewingPM) return;
                   setIsGeneratingWO(true);

                   const assigned = (viewingPM.assigned_technician || '').trim();
                   let matchedTech = staffList.find(s => 
                     s.fullName.toLowerCase() === assigned.toLowerCase() ||
                     s.userId.toLowerCase() === assigned.toLowerCase() ||
                     s.username.toLowerCase() === assigned.toLowerCase() ||
                     s.employeeId.toLowerCase() === assigned.toLowerCase()
                   );

                   if (!matchedTech && assigned) {
                     matchedTech = staffList.find(s => 
                       s.fullName.toLowerCase().includes(assigned.toLowerCase()) ||
                       assigned.toLowerCase().includes(s.fullName.toLowerCase())
                     );
                   }

                   if (!matchedTech) {
                     matchedTech = staffList.find(s => s.role === 'Technician' && s.accountStatus === 'Active');
                   }

                   const assignedTechId = matchedTech ? matchedTech.userId : (assigned || 'USR-002');
                   const assignedTechName = matchedTech ? matchedTech.fullName : (assigned || 'Technician');

                   if (onAddWorkOrder) {
                     onAddWorkOrder({
                       assetId: viewingPM.asset_id,
                       assetName: viewingPM.machine_name || viewingPM.asset_id,
                       category: (viewingPM.maintenance_type as any) || 'General',
                       issue: `[PM Routine] ${viewingPM.maintenance_task || 'Preventive Maintenance'} (${viewingPM.frequency || 'Periodic'})`,
                       priority: viewingPM.priority || 'Medium',
                       assignedToId: assignedTechId,
                       assignedToName: assignedTechName,
                       loggedBy: authorizedUser || viewingPM.supervisor || 'Management',
                       checklist: [
                         { task: `Perform routine: ${viewingPM.maintenance_task}`, completed: false },
                         { task: 'Check equipment status and safety guards', completed: false },
                         ...(viewingPM.safety_requirements?.map(r => ({ task: r, completed: false })) || []),
                         { task: 'Housekeeping and return to operational service', completed: false }
                       ],
                       downtimeHours: viewingPM.estimated_duration || 2
                     });
                   }

                   try {
                     await supabase.from('preventive_maintenance').update({ status: 'In Progress' }).eq('id', viewingPM.id);
                   } catch (err) {
                     console.error('Failed to update PM status:', err);
                   }

                   setViewingPM(prev => prev ? { ...prev, status: 'In Progress' } : null);
                   setWoSuccessMsg(`Ticket assigned to ${assignedTechName} (${assignedTechId}). Ready in technician queue.`);
                   setIsGeneratingWO(false);

                   setTimeout(() => {
                     setWoSuccessMsg(null);
                   }, 5000);
                 }}
                 className="px-3 py-1.5 text-xs font-semibold bg-amber-600 hover:bg-amber-500 text-white rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
               >
                 {isGeneratingWO ? (
                   <><span className="animate-spin w-3 h-3 border-2 border-white border-t-transparent rounded-full block"></span> Generating...</>
                 ) : (
                   <>Generate Work Order</>
                 )}
               </button>
               <button 
                 type="button"
                 onClick={async () => {
                   if (!viewingPM) return;
                   try {
                     await supabase.from('preventive_maintenance').update({ status: 'Completed' }).eq('id', viewingPM.id);
                   } catch (err) {
                     console.error('Failed to complete PM in database:', err);
                   }
                   setViewingPM(prev => prev ? { ...prev, status: 'Completed' } : null);
                 }}
                 className="px-3.5 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors cursor-pointer"
               >
                 Complete
               </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
