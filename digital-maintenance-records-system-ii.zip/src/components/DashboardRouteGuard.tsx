import React, { useEffect } from 'react';
import { UserRole } from '../types';
import { isRoleAuthorizedForDashboard, getAuthorizedDashboardForRole, getAccessDeniedMessage } from '../utils/rbac';
import { ShieldAlert, ArrowRight, Lock } from 'lucide-react';

interface DashboardRouteGuardProps {
  requiredDashboard: UserRole;
  userRole: UserRole;
  onRedirect: (authorizedDashboard: UserRole) => void;
  children: React.ReactNode;
}

export const DashboardRouteGuard: React.FC<DashboardRouteGuardProps> = ({
  requiredDashboard,
  userRole,
  onRedirect,
  children
}) => {
  const isAuthorized = isRoleAuthorizedForDashboard(userRole, requiredDashboard);

  useEffect(() => {
    if (!isAuthorized) {
      const timer = setTimeout(() => {
        onRedirect(getAuthorizedDashboardForRole(userRole));
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [isAuthorized, userRole, onRedirect]);

  if (!isAuthorized) {
    const authorizedDashboard = getAuthorizedDashboardForRole(userRole);
    return (
      <div className="w-full min-h-[500px] flex items-center justify-center p-4 sm:p-6 animate-in fade-in zoom-in-95 duration-200">
        <div className="max-w-md w-full bg-slate-900 border-2 border-rose-600/70 rounded-2xl p-6 sm:p-8 text-center shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-rose-600 via-amber-500 to-rose-600 animate-pulse" />
          
          <div className="w-16 h-16 bg-rose-500/10 border-2 border-rose-500/30 rounded-2xl flex items-center justify-center mx-auto mb-4 text-rose-500">
            <ShieldAlert className="w-9 h-9" />
          </div>

          <span className="inline-block px-2.5 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-widest bg-rose-950 text-rose-400 border border-rose-800/80 mb-3">
            RBAC SECURITY POLICY ENFORCED
          </span>

          <h2 className="text-lg sm:text-xl font-bold text-white mb-2 font-display">
            {getAccessDeniedMessage(requiredDashboard)}
          </h2>

          <p className="text-xs text-slate-400 leading-relaxed mb-6">
            Your authenticated role is <strong className="text-white uppercase font-mono">{userRole}</strong>. 
            Access to the <span className="text-rose-300 font-semibold">{requiredDashboard} Dashboard</span> is strictly prohibited by security policy.
          </p>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-400 flex items-center justify-between gap-3 mb-4">
            <span className="flex items-center gap-1.5 text-slate-300">
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              Authorized Target:
            </span>
            <span className="font-bold text-emerald-400 uppercase font-mono">
              {authorizedDashboard} Console
            </span>
          </div>

          <button
            onClick={() => onRedirect(authorizedDashboard)}
            className="w-full py-2.5 px-4 bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white text-xs font-bold uppercase tracking-wider rounded-lg transition-all shadow-lg shadow-rose-900/30 flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Proceed to {authorizedDashboard} Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};
