import React, { useState, useMemo } from 'react';
import { WorkOrder, PriorityLevel, UserRole, Personnel, Technician } from '../types';
import { 
  X, 
  Search, 
  Filter, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  Calendar, 
  Wrench, 
  UserCheck, 
  Sliders, 
  Tag, 
  FileText, 
  ChevronRight, 
  AlertCircle, 
  CheckSquare, 
  Layers, 
  ArrowRight,
  Eye,
  RefreshCw,
  Play,
  Pause,
  Check,
  ShieldCheck,
  Info
} from 'lucide-react';

export interface IncompleteJobItem {
  id: string;
  assetId: string;
  assetName: string;
  maintenanceType: string;
  issue: string;
  assignedToId: string;
  assignedToName: string;
  priority: PriorityLevel;
  scheduledDate: string;
  dueDate: string;
  status: string;
  normalizedStatus: 'Open' | 'Assigned' | 'In Progress' | 'Waiting for Spare Parts' | 'Overdue' | 'Pending';
  isOverdue: boolean;
  isPM?: boolean;
  loggedBy?: string;
  checklist?: { task: string; completed: boolean }[];
  actionsTaken?: string;
  materialsUsed?: string;
  downtimeHours?: number;
  assignmentReason?: string;
  rawRecord?: any;
}

interface IncompleteJobsModalProps {
  isOpen: boolean;
  onClose: () => void;
  workOrders: WorkOrder[];
  pmTasks: any[];
  staffList: Personnel[];
  technicians: Technician[];
  currentRole: UserRole;
  authorizedUser: string;
  theme?: 'light' | 'dark';
  onUpdatePriority: (id: string, priority: PriorityLevel) => Promise<void> | void;
  onReassignTechnician: (id: string, techId: string, techName: string) => Promise<void> | void;
  onStartWork: (id: string) => Promise<void> | void;
  onPauseWork: (id: string) => Promise<void> | void;
  onCompleteWork: (id: string, actions: string, materials: string, downtime: number) => Promise<void> | void;
  onUpdateStatus?: (id: string, newStatus: string) => Promise<void> | void;
  onRefresh?: () => void;
}

const EXCLUDED_STATUSES = ['completed', 'closed', 'cancelled', 'resolved', 'repaired'];

// Helper to determine if a job is incomplete
export function isJobUnfinished(status: string | undefined): boolean {
  if (!status) return true;
  const s = status.toLowerCase().trim();
  return !EXCLUDED_STATUSES.includes(s);
}

export const IncompleteJobsModal: React.FC<IncompleteJobsModalProps> = ({
  isOpen,
  onClose,
  workOrders,
  pmTasks,
  staffList,
  technicians,
  currentRole,
  authorizedUser,
  theme = 'light',
  onUpdatePriority,
  onReassignTechnician,
  onStartWork,
  onPauseWork,
  onCompleteWork,
  onUpdateStatus,
  onRefresh
}) => {
  // Search and Filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [typeFilter, setTypeFilter] = useState('All');

  // Selected job for Details Modal
  const [selectedJob, setSelectedJob] = useState<IncompleteJobItem | null>(null);

  // Completion modal state within details
  const [isCompleting, setIsCompleting] = useState(false);
  const [actionsTakenInput, setActionsTakenInput] = useState('');
  const [materialsUsedInput, setMaterialsUsedInput] = useState('');
  const [downtimeHoursInput, setDowntimeHoursInput] = useState<number>(1);

  // Editing state within details modal
  const [editingTechId, setEditingTechId] = useState('');
  const [editingPriority, setEditingPriority] = useState<PriorityLevel | ''>('');
  const [editingStatus, setEditingStatus] = useState('');
  const [isActionSuccess, setIsActionSuccess] = useState<string | null>(null);
  // Active technicians from staff
  const activeStaff = staffList.filter(s => s.accountStatus === 'Active');
  const technicianStaff = activeStaff.filter(s => s.role === 'Technician');

  // Normalize Work Orders and PM tasks into unified incomplete job items
  const allIncompleteJobs = useMemo(() => {
    const list: IncompleteJobItem[] = [];
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Use active workOrders as single source of truth with unique ID deduplication
    const seenWo = new Set<string>();
    const uniqueWos = (workOrders || []).filter(w => {
      if (!w || !w.id) return false;
      const cleanId = String(w.id).trim();
      if (!cleanId || seenWo.has(cleanId)) return false;
      seenWo.add(cleanId);
      return true;
    });

    // Process Work Orders (including generated PM work orders)
    uniqueWos.forEach(wo => {
      if (!isJobUnfinished(wo.status)) return;

      const schedDate = wo.scheduledDate || (wo.timestamp ? wo.timestamp.split('T')[0] : '');
      const dueDate = wo.dueDate || schedDate;
      
      let isOverdue = false;
      if (wo.status?.toLowerCase() === 'overdue') {
        isOverdue = true;
      } else if (dueDate) {
        try {
          const d = new Date(dueDate);
          if (!isNaN(d.getTime()) && d < today) {
            isOverdue = true;
          }
        } catch (_) {}
      }

      // Map to normalized status category
      let normStatus: IncompleteJobItem['normalizedStatus'] = 'Open';
      const rawStatusLower = (wo.status || '').toLowerCase();

      if (isOverdue || rawStatusLower === 'overdue') {
        normStatus = 'Overdue';
      } else if (rawStatusLower.includes('spare') || rawStatusLower.includes('part') || rawStatusLower.includes('waiting')) {
        normStatus = 'Waiting for Spare Parts';
      } else if (rawStatusLower === 'in progress' || rawStatusLower === 'under repair') {
        normStatus = 'In Progress';
      } else if (wo.assignedToId && wo.assignedToId !== 'unassigned' && wo.assignedToId !== 'UNASSIGNED') {
        normStatus = 'Assigned';
      } else if (rawStatusLower === 'pending' || rawStatusLower.includes('assignment')) {
        normStatus = 'Pending';
      } else {
        normStatus = 'Open';
      }

      list.push({
        id: wo.id,
        assetId: wo.assetId,
        assetName: wo.assetName,
        maintenanceType: wo.category || 'Mechanical',
        issue: wo.issue,
        assignedToId: wo.assignedToId || 'unassigned',
        assignedToName: wo.assignedToName || 'Unassigned',
        priority: wo.priority,
        scheduledDate: schedDate,
        dueDate: dueDate,
        status: wo.status,
        normalizedStatus: normStatus,
        isOverdue,
        isPM: !!wo.isPM,
        loggedBy: wo.loggedBy,
        checklist: wo.checklist,
        actionsTaken: wo.actionsTaken,
        materialsUsed: wo.materialsUsed,
        downtimeHours: wo.downtimeHours,
        assignmentReason: wo.assignmentReason,
        rawRecord: wo
      });
    });

    return list;
  }, [workOrders]);

  // Apply Role-Based Access Control
  const roleFilteredJobs = useMemo(() => {
    if (currentRole === 'Management' || currentRole === 'Auditor') {
      return allIncompleteJobs;
    }
    if (currentRole === 'Technician') {
      const cleanUser = (authorizedUser || '').toLowerCase().trim();
      const currentStaff = staffList.find(
        s => s.fullName?.toLowerCase().trim() === cleanUser || s.username?.toLowerCase().trim() === cleanUser
      );
      const techId = currentStaff?.userId || currentStaff?.employeeId;

      return allIncompleteJobs.filter(job => {
        const assignedId = (job.assignedToId || '').toLowerCase().trim();
        const assignedName = (job.assignedToName || '').toLowerCase().trim();
        return (
          (techId && assignedId === techId.toLowerCase()) ||
          (cleanUser && assignedName.includes(cleanUser)) ||
          (currentStaff?.fullName && assignedName.includes(currentStaff.fullName.toLowerCase()))
        );
      });
    }
    return allIncompleteJobs;
  }, [allIncompleteJobs, currentRole, authorizedUser, staffList]);

  // Calculate summary counts from role-filtered records
  const summaryCounts = useMemo(() => {
    const total = roleFilteredJobs.length;
    const openJobs = roleFilteredJobs.filter(j => 
      j.normalizedStatus === 'Open' || j.normalizedStatus === 'Assigned' || j.normalizedStatus === 'Pending'
    ).length;
    const inProgress = roleFilteredJobs.filter(j => j.normalizedStatus === 'In Progress').length;
    const waitingSpareParts = roleFilteredJobs.filter(j => j.normalizedStatus === 'Waiting for Spare Parts').length;
    const overdue = roleFilteredJobs.filter(j => j.isOverdue || j.normalizedStatus === 'Overdue').length;

    return {
      total,
      openJobs,
      inProgress,
      waitingSpareParts,
      overdue
    };
  }, [roleFilteredJobs]);

  // Filtered jobs according to search and dropdown filters
  const displayedJobs = useMemo(() => {
    return roleFilteredJobs.filter(job => {
      // 1. Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchId = job.id.toLowerCase().includes(q);
        const matchMachine = job.assetName.toLowerCase().includes(q);
        const matchAssetId = job.assetId.toLowerCase().includes(q);
        const matchTech = job.assignedToName.toLowerCase().includes(q);
        const matchIssue = job.issue.toLowerCase().includes(q);
        if (!matchId && !matchMachine && !matchAssetId && !matchTech && !matchIssue) {
          return false;
        }
      }

      // 2. Status Filter
      if (statusFilter !== 'All') {
        if (statusFilter === 'Overdue') {
          if (!job.isOverdue && job.normalizedStatus !== 'Overdue') return false;
        } else if (statusFilter === 'Open') {
          if (job.normalizedStatus !== 'Open' && job.status !== 'Open') return false;
        } else if (statusFilter === 'Assigned') {
          if (job.normalizedStatus !== 'Assigned' && job.status !== 'Assigned') return false;
        } else if (statusFilter === 'In Progress') {
          if (job.normalizedStatus !== 'In Progress' && job.status !== 'In Progress') return false;
        } else if (statusFilter === 'Waiting for Spare Parts') {
          if (job.normalizedStatus !== 'Waiting for Spare Parts' && job.status !== 'Waiting for Spare Parts') return false;
        } else if (statusFilter === 'Pending') {
          if (job.normalizedStatus !== 'Pending' && job.status !== 'Pending') return false;
        }
      }

      // 3. Priority Filter
      if (priorityFilter !== 'All') {
        if (job.priority !== priorityFilter) return false;
      }

      // 4. Maintenance Type Filter
      if (typeFilter !== 'All') {
        const t = (job.maintenanceType || '').toLowerCase();
        const filterVal = typeFilter.toLowerCase();
        if (!t.includes(filterVal)) return false;
      }

      return true;
    });
  }, [roleFilteredJobs, searchQuery, statusFilter, priorityFilter, typeFilter]);

  // Helper for Status Badge styling as specified:
  // Open = Gray, Assigned = Blue, In Progress = Cyan, Waiting for Spare Parts = Orange, Overdue = Red
  const renderStatusBadge = (job: IncompleteJobItem) => {
    if (job.isOverdue || job.normalizedStatus === 'Overdue') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-rose-100 text-rose-800 border border-rose-300 dark:bg-rose-950/70 dark:text-rose-300 dark:border-rose-800">
          <AlertCircle className="w-3 h-3 text-rose-600 dark:text-rose-400" />
          Overdue
        </span>
      );
    }

    if (job.normalizedStatus === 'Waiting for Spare Parts') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-amber-100 text-amber-900 border border-amber-300 dark:bg-amber-950/70 dark:text-amber-300 dark:border-amber-800">
          <Clock className="w-3 h-3 text-amber-600 dark:text-amber-400" />
          Waiting for Spare Parts
        </span>
      );
    }

    if (job.normalizedStatus === 'In Progress') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-cyan-100 text-cyan-900 border border-cyan-300 dark:bg-cyan-950/70 dark:text-cyan-300 dark:border-cyan-800">
          <Clock className="w-3 h-3 animate-spin text-cyan-600 dark:text-cyan-400" />
          In Progress
        </span>
      );
    }

    if (job.normalizedStatus === 'Assigned') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-blue-100 text-blue-900 border border-blue-300 dark:bg-blue-950/70 dark:text-blue-300 dark:border-blue-800">
          <UserCheck className="w-3 h-3 text-blue-600 dark:text-blue-400" />
          Assigned
        </span>
      );
    }

    if (job.normalizedStatus === 'Pending') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-slate-100 text-slate-800 border border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700">
          <Clock className="w-3 h-3 text-slate-500" />
          Pending
        </span>
      );
    }

    // Default: Open = Gray
    return (
      <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-slate-100 text-slate-800 border border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700">
        <FileText className="w-3 h-3 text-slate-500" />
        Open
      </span>
    );
  };

  // Helper for Priority Badge
  const renderPriorityBadge = (priority: PriorityLevel) => {
    switch (priority) {
      case 'Critical':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200 dark:bg-rose-950/50 dark:text-rose-300 dark:border-rose-800">
            <AlertTriangle className="w-2.5 h-2.5 text-rose-600" /> Critical
          </span>
        );
      case 'High':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-orange-50 text-orange-700 border border-orange-200 dark:bg-orange-950/50 dark:text-orange-300 dark:border-orange-800">
            <AlertTriangle className="w-2.5 h-2.5 text-orange-600" /> High
          </span>
        );
      case 'Medium':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:border-amber-800">
            Medium
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700">
            Low
          </span>
        );
    }
  };

  // Handle open job details
  const handleOpenDetails = (job: IncompleteJobItem) => {
    setSelectedJob(job);
    setEditingTechId(job.assignedToId || '');
    setEditingPriority(job.priority);
    setEditingStatus(job.status);
    setIsCompleting(false);
    setActionsTakenInput(job.actionsTaken || '');
    setMaterialsUsedInput(job.materialsUsed || '');
    setDowntimeHoursInput(job.downtimeHours || 1);
    setIsActionSuccess(null);
  };

  // Submit complete job inside details modal
  const handleCompleteSubmitInModal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedJob) return;
    if (!actionsTakenInput.trim()) {
      alert('Please enter actions taken during repair.');
      return;
    }

    await onCompleteWork(selectedJob.id, actionsTakenInput, materialsUsedInput, downtimeHoursInput);
    setIsActionSuccess(`Work order ${selectedJob.id} has been marked completed.`);
    setTimeout(() => {
      setSelectedJob(null);
      setIsCompleting(false);
    }, 1500);
  };

  // Quick Action: Management Reassign
  const handleSaveReassign = async () => {
    if (!selectedJob || !editingTechId) return;
    const targetStaff = staffList.find(s => s.userId === editingTechId);
    const techName = targetStaff ? targetStaff.fullName : 'Technician';
    await onReassignTechnician(selectedJob.id, editingTechId, techName);
    setSelectedJob(prev => prev ? { ...prev, assignedToId: editingTechId, assignedToName: techName } : null);
    setIsActionSuccess(`Reassigned to ${techName}`);
    setTimeout(() => setIsActionSuccess(null), 2500);
  };

  // Quick Action: Management Update Priority
  const handleSavePriority = async (newPriority: PriorityLevel) => {
    if (!selectedJob) return;
    await onUpdatePriority(selectedJob.id, newPriority);
    setSelectedJob(prev => prev ? { ...prev, priority: newPriority } : null);
    setEditingPriority(newPriority);
    setIsActionSuccess(`Priority updated to ${newPriority}`);
    setTimeout(() => setIsActionSuccess(null), 2500);
  };

  // Quick Action: Update Status
  const handleSaveStatus = async (newStatus: string) => {
    if (!selectedJob) return;
    if (onUpdateStatus) {
      await onUpdateStatus(selectedJob.id, newStatus);
    } else if (newStatus === 'In Progress') {
      await onStartWork(selectedJob.id);
    } else if (newStatus === 'Paused' || newStatus === 'Waiting for Spare Parts') {
      await onPauseWork(selectedJob.id);
    }
    setSelectedJob(prev => prev ? { ...prev, status: newStatus } : null);
    setEditingStatus(newStatus);
    setIsActionSuccess(`Status updated to ${newStatus}`);
    setTimeout(() => setIsActionSuccess(null), 2500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-sm overflow-y-auto animate-fadeIn">
      {/* Modal Card */}
      <div 
        className="w-full max-w-6xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden my-auto"
        role="dialog"
        aria-modal="true"
        aria-labelledby="incomplete-jobs-title"
      >
        {/* Header */}
        <div className="px-5 sm:px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 flex items-center justify-between shrink-0">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="p-1.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400">
                <Wrench className="w-5 h-5" />
              </span>
              <h2 id="incomplete-jobs-title" className="text-base sm:text-lg font-bold font-display uppercase tracking-wider text-slate-900 dark:text-white">
                INCOMPLETE MAINTENANCE JOBS
              </h2>
              {currentRole === 'Technician' && (
                <span className="text-[10px] font-semibold bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-200 px-2 py-0.5 rounded border border-blue-200 dark:border-blue-700">
                  Assigned to Me
                </span>
              )}
              {currentRole === 'Auditor' && (
                <span className="text-[10px] font-semibold bg-purple-100 text-purple-800 dark:bg-purple-900/50 dark:text-purple-200 px-2 py-0.5 rounded border border-purple-200 dark:border-purple-700">
                  Auditor View
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Maintenance tasks that have not been completed.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {onRefresh && (
              <button
                type="button"
                onClick={onRefresh}
                className="p-2 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                title="Refresh database records"
                aria-label="Refresh"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Close modal"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1">
          
          {/* 5 Summary KPI Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 sm:gap-3">
            {/* Total Incomplete Jobs */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-3 sm:p-3.5 rounded-xl border border-slate-200 dark:border-slate-700/80">
              <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">
                Total Incomplete Jobs
              </span>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-xl sm:text-2xl font-bold font-display text-slate-900 dark:text-white">
                  {summaryCounts.total}
                </span>
                <span className="text-[11px] text-slate-400 font-medium">jobs</span>
              </div>
            </div>

            {/* Open / Assigned Jobs */}
            <button
              type="button"
              onClick={() => setStatusFilter(statusFilter === 'Open' ? 'All' : 'Open')}
              className={`text-left p-3 sm:p-3.5 rounded-xl border transition-all cursor-pointer ${
                statusFilter === 'Open' ? 'bg-slate-200/80 dark:bg-slate-700 border-slate-400' : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/80 hover:border-slate-400'
              }`}
              title="Click to filter Open / Assigned jobs"
            >
              <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">
                Open / Assigned
              </span>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-xl sm:text-2xl font-bold font-display text-slate-700 dark:text-slate-200">
                  {summaryCounts.openJobs}
                </span>
                <span className="text-[11px] text-slate-400 font-medium">pending</span>
              </div>
            </button>

            {/* In Progress */}
            <div className="bg-cyan-50/50 dark:bg-cyan-950/20 p-3 sm:p-3.5 rounded-xl border border-cyan-200 dark:border-cyan-800/50">
              <span className="text-[10px] font-bold text-cyan-700 dark:text-cyan-400 uppercase tracking-wider block">
                In Progress
              </span>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-xl sm:text-2xl font-bold font-display text-cyan-900 dark:text-cyan-200">
                  {summaryCounts.inProgress}
                </span>
                <span className="text-[11px] text-cyan-600/70 dark:text-cyan-400/70 font-medium">active</span>
              </div>
            </div>

            {/* Waiting for Spare Parts */}
            <div className="bg-amber-50/50 dark:bg-amber-950/20 p-3 sm:p-3.5 rounded-xl border border-amber-200 dark:border-amber-800/50">
              <span className="text-[10px] font-bold text-amber-700 dark:text-amber-400 uppercase tracking-wider block">
                Waiting for Spare Parts
              </span>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-xl sm:text-2xl font-bold font-display text-amber-900 dark:text-amber-200">
                  {summaryCounts.waitingSpareParts}
                </span>
                <span className="text-[11px] text-amber-600/70 dark:text-amber-400/70 font-medium">on hold</span>
              </div>
            </div>

            {/* Overdue */}
            <div className="bg-rose-50/50 dark:bg-rose-950/20 p-3 sm:p-3.5 rounded-xl border border-rose-200 dark:border-rose-800/50 col-span-2 sm:col-span-1">
              <span className="text-[10px] font-bold text-rose-700 dark:text-rose-400 uppercase tracking-wider block">
                Overdue
              </span>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-xl sm:text-2xl font-bold font-display text-rose-900 dark:text-rose-200">
                  {summaryCounts.overdue}
                </span>
                <span className="text-[11px] text-rose-600/70 dark:text-rose-400/70 font-medium">delayed</span>
              </div>
            </div>
          </div>

          {/* Search Bar & Filters Section */}
          <div className="bg-slate-50 dark:bg-slate-800/40 p-3.5 sm:p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex flex-col lg:flex-row gap-3">
              {/* Search Bar */}
              <div className="relative flex-1">
                <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by Work Order ID, Machine Name, Asset ID, Technician..."
                  className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              {/* Filters */}
              <div className="flex flex-wrap sm:flex-nowrap items-center gap-2">
                {/* Status Filter */}
                <div className="flex-1 sm:flex-none">
                  <select
                    className="w-full sm:w-auto px-2.5 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-200 focus:outline-none focus:border-amber-500 cursor-pointer"
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    aria-label="Filter by Status"
                  >
                    <option value="All">All Statuses</option>
                    <option value="Open">Open</option>
                    <option value="Assigned">Assigned</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Pending">Pending</option>
                    <option value="Waiting for Spare Parts">Waiting for Spare Parts</option>
                    <option value="Overdue">Overdue</option>
                  </select>
                </div>

                {/* Priority Filter */}
                <div className="flex-1 sm:flex-none">
                  <select
                    className="w-full sm:w-auto px-2.5 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-200 focus:outline-none focus:border-amber-500 cursor-pointer"
                    value={priorityFilter}
                    onChange={(e) => setPriorityFilter(e.target.value)}
                    aria-label="Filter by Priority"
                  >
                    <option value="All">All Priorities</option>
                    <option value="Critical">Critical</option>
                    <option value="High">High</option>
                    <option value="Medium">Medium</option>
                    <option value="Low">Low</option>
                  </select>
                </div>

                {/* Maintenance Type Filter */}
                <div className="flex-1 sm:flex-none">
                  <select
                    className="w-full sm:w-auto px-2.5 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-200 focus:outline-none focus:border-amber-500 cursor-pointer"
                    value={typeFilter}
                    onChange={(e) => setTypeFilter(e.target.value)}
                    aria-label="Filter by Maintenance Type"
                  >
                    <option value="All">All Types</option>
                    <option value="Mechanical">Mechanical</option>
                    <option value="Electrical">Electrical</option>
                    <option value="Preventive">Preventive Maintenance</option>
                    <option value="Pneumatic">Pneumatic</option>
                    <option value="Hydraulic">Hydraulic</option>
                    <option value="General">General</option>
                  </select>
                </div>

                {/* Reset Filters */}
                {(searchQuery || statusFilter !== 'All' || priorityFilter !== 'All' || typeFilter !== 'All') && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setStatusFilter('All');
                      setPriorityFilter('All');
                      setTypeFilter('All');
                    }}
                    className="px-2.5 py-2 text-xs text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white underline cursor-pointer"
                  >
                    Reset
                  </button>
                )}
              </div>
            </div>
            
            <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-1 border-t border-slate-200/60 dark:border-slate-700/60">
              <span>Showing <strong>{displayedJobs.length}</strong> of <strong>{roleFilteredJobs.length}</strong> incomplete jobs</span>
              {currentRole === 'Technician' && (
                <span className="text-blue-600 dark:text-blue-400 font-medium">Technician Scope: Only jobs assigned to you</span>
              )}
            </div>
          </div>

          {/* Jobs Table & Cards View */}
          {displayedJobs.length === 0 ? (
            <div className="text-center py-16 bg-slate-50 dark:bg-slate-800/30 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 p-6">
              <CheckCircle2 className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
              <h3 className="font-display font-bold text-slate-700 dark:text-slate-200 text-sm">
                No incomplete maintenance jobs found.
              </h3>
              <p className="text-xs text-slate-400 dark:text-slate-500 mt-1 max-w-sm mx-auto">
                {roleFilteredJobs.length === 0 
                  ? (allIncompleteJobs.length > 0 
                      ? `Terdapat ${allIncompleteJobs.length} tugasan aktif dalam sistem (di luar skop tugasan anda).` 
                      : 'All maintenance jobs are currently completed, resolved, or clear in the database.')
                  : 'No jobs match your current search criteria or active filters.'}
              </p>
              {(searchQuery || statusFilter !== 'All' || priorityFilter !== 'All' || typeFilter !== 'All') && (
                <div className="mt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setStatusFilter('All');
                      setPriorityFilter('All');
                      setTypeFilter('All');
                    }}
                    className="px-4 py-2 text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white rounded-lg transition-colors cursor-pointer shadow-sm"
                  >
                    Set Semula Penapis (Papar {roleFilteredJobs.length} Tugasan)
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
              {/* Desktop Table View */}
              <div className="hidden lg:block overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-50 dark:bg-slate-950/80 border-b border-slate-200 dark:border-slate-800 text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 tracking-wider">
                      <th className="py-3 px-3.5">Work Order ID</th>
                      <th className="py-3 px-3.5">Machine / Asset</th>
                      <th className="py-3 px-3.5">Type & Task</th>
                      <th className="py-3 px-3.5">Assigned Technician</th>
                      <th className="py-3 px-3.5">Priority</th>
                      <th className="py-3 px-3.5">Schedule / Due</th>
                      <th className="py-3 px-3.5">Status</th>
                      <th className="py-3 px-3.5 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 bg-white dark:bg-slate-900">
                    {displayedJobs.map((job) => (
                      <tr 
                        key={job.id} 
                        className={`hover:bg-slate-50/70 dark:hover:bg-slate-800/50 transition-colors ${
                          job.isOverdue ? 'bg-rose-50/20 dark:bg-rose-950/10' : ''
                        }`}
                      >
                        {/* Work Order ID */}
                        <td className="py-3 px-3.5 whitespace-nowrap">
                          <span className="font-mono font-bold text-xs text-slate-900 dark:text-slate-100 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700">
                            {job.id}
                          </span>
                          {job.isPM && (
                            <span className="block text-[9px] font-semibold text-sky-600 dark:text-sky-400 mt-1">
                              PM Schedule
                            </span>
                          )}
                        </td>

                        {/* Machine Name & Asset ID */}
                        <td className="py-3 px-3.5">
                          <div className="font-bold text-slate-800 dark:text-slate-200 leading-tight">
                            {job.assetName}
                          </div>
                          <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500">
                            ID: {job.assetId}
                          </span>
                        </td>

                        {/* Maintenance Type & Task Description */}
                        <td className="py-3 px-3.5 max-w-xs">
                          <div className="flex items-center gap-1.5 mb-1">
                            <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                              <Tag className="w-2.5 h-2.5 text-slate-400" />
                              {job.maintenanceType}
                            </span>
                          </div>
                          <p className="text-slate-600 dark:text-slate-400 line-clamp-2 text-xs leading-relaxed">
                            {job.issue}
                          </p>
                        </td>

                        {/* Assigned Technician */}
                        <td className="py-3 px-3.5 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <div className="w-6 h-6 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-[10px] font-bold text-slate-700 dark:text-slate-300">
                              {job.assignedToName && job.assignedToName !== 'Unassigned'
                                ? job.assignedToName.charAt(0).toUpperCase()
                                : '?'}
                            </div>
                            <div>
                              <span className={`block font-semibold text-xs ${
                                job.assignedToName === 'Unassigned' 
                                  ? 'text-rose-500 dark:text-rose-400' 
                                  : 'text-slate-800 dark:text-slate-200'
                              }`}>
                                {job.assignedToName}
                              </span>
                            </div>
                          </div>
                        </td>

                        {/* Priority */}
                        <td className="py-3 px-3.5 whitespace-nowrap">
                          {renderPriorityBadge(job.priority)}
                        </td>

                        {/* Scheduled Date & Due Date */}
                        <td className="py-3 px-3.5 whitespace-nowrap">
                          <div className="text-xs text-slate-700 dark:text-slate-300 flex items-center gap-1 font-mono">
                            <Calendar className="w-3 h-3 text-slate-400" />
                            <span>Sched: {job.scheduledDate || 'Not set'}</span>
                          </div>
                          <div className="text-[10px] font-mono mt-0.5">
                            <span className={job.isOverdue ? 'text-rose-600 font-bold' : 'text-slate-400'}>
                              Due: {job.dueDate || job.scheduledDate || 'N/A'}
                            </span>
                          </div>
                        </td>

                        {/* Current Status Badge */}
                        <td className="py-3 px-3.5 whitespace-nowrap">
                          {renderStatusBadge(job)}
                        </td>

                        {/* Action: View Details Button */}
                        <td className="py-3 px-3.5 text-right whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => handleOpenDetails(job)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-950 text-white dark:bg-slate-800 dark:hover:bg-slate-700 shadow-xs hover:shadow transition-all cursor-pointer active:scale-95"
                          >
                            <Eye className="w-3 h-3" />
                            <span>View Details</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile / Tablet Cards View */}
              <div className="lg:hidden divide-y divide-slate-100 dark:divide-slate-800 bg-white dark:bg-slate-900">
                {displayedJobs.map((job) => (
                  <div 
                    key={job.id} 
                    className={`p-4 space-y-3 ${
                      job.isOverdue ? 'bg-rose-50/20 dark:bg-rose-950/10' : ''
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-mono font-bold text-xs text-slate-900 dark:text-slate-100 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700">
                            {job.id}
                          </span>
                          {renderStatusBadge(job)}
                          {renderPriorityBadge(job.priority)}
                        </div>
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white mt-1">
                          {job.assetName} <span className="text-xs font-normal text-slate-400">({job.assetId})</span>
                        </h4>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/50 p-2.5 rounded-lg border border-slate-200/70 dark:border-slate-700/70">
                      {job.issue}
                    </p>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Technician</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">{job.assignedToName}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Due Date</span>
                        <span className={`font-mono text-xs ${job.isOverdue ? 'text-rose-600 font-bold' : 'text-slate-600 dark:text-slate-300'}`}>
                          {job.dueDate || job.scheduledDate || 'N/A'}
                        </span>
                      </div>
                    </div>

                    <div className="pt-2 flex justify-end">
                      <button
                        type="button"
                        onClick={() => handleOpenDetails(job)}
                        className="w-full sm:w-auto inline-flex justify-center items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-950 text-white dark:bg-slate-800 dark:hover:bg-slate-700 shadow-xs transition-all cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View Details</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-5 sm:px-6 py-3.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 shrink-0">
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-amber-500"></span>
            <span>Database synchronized</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors font-medium cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* DETAILED WORK ORDER MODAL (Opens upon "View Details")     */}
      {/* ========================================================= */}
      {selectedJob && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-3 sm:p-5 bg-slate-950/85 backdrop-blur-md overflow-y-auto animate-fadeIn">
          <div 
            className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden my-auto"
            role="dialog"
            aria-modal="true"
          >
            {/* Details Header */}
            <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/80 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <span className="font-mono text-sm font-bold bg-slate-200 dark:bg-slate-800 text-slate-900 dark:text-slate-100 px-2.5 py-1 rounded border border-slate-300 dark:border-slate-700">
                  {selectedJob.id}
                </span>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">
                  Work Order Details
                </span>
                {renderStatusBadge(selectedJob)}
              </div>
              <button
                type="button"
                onClick={() => {
                  setSelectedJob(null);
                  setIsCompleting(false);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Notification if action performed */}
            {isActionSuccess && (
              <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/50 border-b border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs font-semibold flex items-center gap-2 px-5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>{isActionSuccess}</span>
              </div>
            )}

            {/* Details Body */}
            <div className="p-5 sm:p-6 overflow-y-auto space-y-5 flex-1">
              
              {/* Machine & Basic info grid */}
              <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-200 dark:border-slate-700 pb-3">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Machine / Equipment</span>
                    <h3 className="font-bold text-base text-slate-900 dark:text-white">
                      {selectedJob.assetName}
                    </h3>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block sm:text-right">Asset Tag</span>
                    <span className="font-mono text-xs font-bold text-slate-700 dark:text-slate-300">
                      {selectedJob.assetId}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-medium block">Type</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">{selectedJob.maintenanceType}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-medium block">Priority</span>
                    <div>{renderPriorityBadge(selectedJob.priority)}</div>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-medium block">Scheduled</span>
                    <span className="font-mono text-slate-700 dark:text-slate-300">{selectedJob.scheduledDate || 'Not specified'}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-medium block">Due Date</span>
                    <span className={`font-mono ${selectedJob.isOverdue ? 'text-rose-600 font-bold' : 'text-slate-700 dark:text-slate-300'}`}>
                      {selectedJob.dueDate || selectedJob.scheduledDate || 'Not specified'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Problem Description / Task */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-slate-400" />
                  Problem Description / Maintenance Task
                </label>
                <div className="bg-slate-50 dark:bg-slate-800/50 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 leading-relaxed font-sans whitespace-pre-wrap">
                  {selectedJob.issue}
                </div>
              </div>

              {/* Assigned Technician Card */}
              <div className="bg-slate-50 dark:bg-slate-800/30 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Assigned Technician</span>
                  <div className="flex items-center gap-2 mt-1">
                    <UserCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span className="font-bold text-sm text-slate-800 dark:text-slate-100">
                      {selectedJob.assignedToName}
                    </span>
                  </div>
                  {selectedJob.assignmentReason && (
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                      Reason: {selectedJob.assignmentReason}
                    </p>
                  )}
                </div>

                {selectedJob.loggedBy && (
                  <div className="text-right sm:border-l sm:pl-4 sm:border-slate-200 dark:sm:border-slate-700">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Logged By</span>
                    <span className="font-medium text-slate-700 dark:text-slate-300">{selectedJob.loggedBy}</span>
                  </div>
                )}
              </div>

              {/* Task Checklist if present */}
              {selectedJob.checklist && selectedJob.checklist.length > 0 && (
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                    <CheckSquare className="w-3.5 h-3.5 text-slate-400" />
                    Task Checklist
                  </label>
                  <ul className="space-y-1.5 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                    {selectedJob.checklist.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs text-slate-700 dark:text-slate-300">
                        <span className={`w-4 h-4 rounded flex items-center justify-center shrink-0 mt-0.5 ${
                          item.completed 
                            ? 'bg-emerald-500 text-white' 
                            : 'border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-transparent'
                        }`}>
                          <Check className="w-3 h-3" />
                        </span>
                        <span className={item.completed ? 'line-through text-slate-400' : ''}>{item.task}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* ===================================================== */}
              {/* ROLE-BASED ACTIONS SECTION                             */}
              {/* ===================================================== */}
              
              {/* Completion Form (Technician or Management) */}
              {isCompleting ? (
                <form onSubmit={handleCompleteSubmitInModal} className="bg-amber-50/50 dark:bg-amber-950/20 p-4 rounded-xl border border-amber-200 dark:border-amber-800/60 space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900 dark:text-amber-300 flex items-center gap-1.5">
                    <Check className="w-4 h-4 text-emerald-600" />
                    Submit Repair Completion
                  </h4>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Actions Taken / Repair Findings <span className="text-rose-500">*</span>
                    </label>
                    <textarea
                      required
                      rows={2}
                      className="w-full p-2.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 outline-none focus:border-amber-500"
                      placeholder="Describe what steps were taken to resolve this maintenance job..."
                      value={actionsTakenInput}
                      onChange={(e) => setActionsTakenInput(e.target.value)}
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Spare Parts / Materials Used
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 outline-none focus:border-amber-500"
                        placeholder="e.g. 6205 Bearing, Hydraulic Oil 46"
                        value={materialsUsedInput}
                        onChange={(e) => setMaterialsUsedInput(e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Downtime Duration (Hours)
                      </label>
                      <input
                        type="number"
                        min="0.25"
                        step="0.25"
                        required
                        className="w-full p-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 outline-none focus:border-amber-500"
                        value={downtimeHoursInput}
                        onChange={(e) => setDowntimeHoursInput(Number(e.target.value) || 1)}
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      type="submit"
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-sm"
                    >
                      Confirm Complete Job
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsCompleting(false)}
                      className="px-3 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-semibold hover:bg-slate-300 transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              ) : (
                <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                      Permitted Role Actions ({currentRole})
                    </span>
                  </div>

                  {/* MANAGEMENT PERMISSIONS: Edit Priority, Reassign, Update Status */}
                  {currentRole === 'Management' && (
                    <div className="space-y-3 bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                        {/* Change Priority */}
                        <div>
                          <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">
                            Modify Priority
                          </label>
                          <select
                            className="w-full p-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg cursor-pointer"
                            value={editingPriority}
                            onChange={(e) => handleSavePriority(e.target.value as PriorityLevel)}
                          >
                            <option value="Low">Low</option>
                            <option value="Medium">Medium</option>
                            <option value="High">High</option>
                            <option value="Critical">Critical</option>
                          </select>
                        </div>

                        {/* Update Status */}
                        <div>
                          <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">
                            Update Status
                          </label>
                          <select
                            className="w-full p-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg cursor-pointer"
                            value={editingStatus}
                            onChange={(e) => handleSaveStatus(e.target.value)}
                          >
                            <option value="Open">Open</option>
                            <option value="Assigned">Assigned</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Waiting for Spare Parts">Waiting for Spare Parts</option>
                            <option value="Pending">Pending</option>
                          </select>
                        </div>

                        {/* Reassign Tech */}
                        <div>
                          <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">
                            Reassign Technician
                          </label>
                          <div className="flex items-center gap-1">
                            <select
                              className="w-full p-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg cursor-pointer flex-1"
                              value={editingTechId}
                              onChange={(e) => setEditingTechId(e.target.value)}
                            >
                              <option value="">Select Tech...</option>
                              {activeStaff
                                .filter((t, idx, arr) => arr.findIndex(x => x.userId === t.userId) === idx)
                                .map((t) => (
                                  <option key={t.userId} value={t.userId}>
                                    {t.fullName} ({t.role})
                                  </option>
                              ))}
                            </select>
                            <button
                              type="button"
                              onClick={handleSaveReassign}
                              disabled={!editingTechId || editingTechId === selectedJob.assignedToId}
                              className="px-2 py-1.5 text-xs bg-slate-800 text-white rounded hover:bg-slate-900 disabled:opacity-50 cursor-pointer font-semibold"
                            >
                              Save
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Management Complete button */}
                      <div className="pt-2 border-t border-slate-200/80 dark:border-slate-700/80 flex justify-end">
                        <button
                          type="button"
                          onClick={() => setIsCompleting(true)}
                          className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1"
                        >
                          <Check className="w-3.5 h-3.5" /> Mark Job As Completed
                        </button>
                      </div>
                    </div>
                  )}

                  {/* TECHNICIAN PERMISSIONS: Start, Pause, Complete */}
                  {currentRole === 'Technician' && (
                    <div className="flex flex-wrap items-center gap-2 bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700">
                      {selectedJob.status !== 'In Progress' ? (
                        <button
                          type="button"
                          onClick={async () => {
                            await onStartWork(selectedJob.id);
                            setSelectedJob(prev => prev ? { ...prev, status: 'In Progress', normalizedStatus: 'In Progress' } : null);
                            setIsActionSuccess('Repair job started.');
                            setTimeout(() => setIsActionSuccess(null), 2500);
                          }}
                          className="px-4 py-2 bg-slate-800 hover:bg-slate-950 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
                        >
                          <Play className="w-3.5 h-3.5" /> Start Repair
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={async () => {
                            await onPauseWork(selectedJob.id);
                            setSelectedJob(prev => prev ? { ...prev, status: 'Waiting for Spare Parts', normalizedStatus: 'Waiting for Spare Parts' } : null);
                            setIsActionSuccess('Repair job paused.');
                            setTimeout(() => setIsActionSuccess(null), 2500);
                          }}
                          className="px-4 py-2 bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5"
                        >
                          <Pause className="w-3.5 h-3.5" /> Pause Job
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => setIsCompleting(true)}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
                      >
                        <Check className="w-3.5 h-3.5" /> Complete Repair
                      </button>
                    </div>
                  )}

                  {/* AUDITOR PERMISSIONS: Read-Only message */}
                  {currentRole === 'Auditor' && (
                    <div className="bg-purple-50 dark:bg-purple-950/30 p-3.5 rounded-xl border border-purple-200 dark:border-purple-800/50 flex items-center gap-2 text-xs text-purple-800 dark:text-purple-300">
                      <ShieldCheck className="w-4 h-4 shrink-0 text-purple-600" />
                      <span>Auditor Read-Only Access: Viewing active maintenance record for compliance inspection.</span>
                    </div>
                  )}
                </div>
              )}

            </div>

            {/* Details Footer */}
            <div className="px-5 py-3.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/80 flex items-center justify-between text-xs text-slate-500 shrink-0">
              <span className="font-mono text-[11px] text-slate-400">ID: {selectedJob.id}</span>
              <button
                type="button"
                onClick={() => {
                  setSelectedJob(null);
                  setIsCompleting(false);
                }}
                className="px-4 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-semibold hover:bg-slate-900 cursor-pointer"
              >
                Back to Incomplete Jobs
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default IncompleteJobsModal;
