/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { WorkOrder, MaintenanceCategory } from '../types';
import { 
  ShieldCheck, 
  Search, 
  Filter, 
  Activity, 
  BarChart3, 
  Printer, 
  ArrowUpDown, 
  FileSpreadsheet, 
  ChevronDown, 
  ChevronUp, 
  FileText, 
  Wrench, 
  ExternalLink,
  Eye
} from 'lucide-react';

interface AuditorViewProps {
  workOrders: WorkOrder[];
  auditorName?: string;
}

export default function AuditorView({ workOrders, auditorName = 'Sarah Lim' }: AuditorViewProps) {
  // Filters
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  
  // Sorting
  const [sortBy, setSortBy] = useState<'id' | 'timestamp' | 'priority' | 'downtimeHours'>('id');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Report Modal state
  const [showReportModal, setShowReportModal] = useState(false);

  // Expanded row details ID
  const [expandedRowId, setExpandedRowId] = useState<string | null>(null);

  // Toggle row expand
  const toggleRow = (id: string) => {
    setExpandedRowId(expandedRowId === id ? null : id);
  };

  // KPI Calculations
  const metrics = useMemo(() => {
    const total = workOrders.length;
    const completed = workOrders.filter(w => w.status === 'Completed').length;
    const pending = workOrders.filter(w => w.status === 'Pending').length;
    const inProgress = workOrders.filter(w => w.status === 'In Progress').length;
    
    // MTTR calculation
    const completedWithDowntime = workOrders.filter(w => w.status === 'Completed' && w.downtimeHours !== undefined);
    const totalDowntime = completedWithDowntime.reduce((acc, curr) => acc + (curr.downtimeHours || 0), 0);
    const mttr = completedWithDowntime.length > 0 ? (totalDowntime / completedWithDowntime.length).toFixed(2) : '0';

    const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;

    return { total, completed, pending, inProgress, mttr, completionRate };
  }, [workOrders]);

  // Category Breakdown for Dynamic SVG Charts
  const categoryChartData = useMemo(() => {
    const counts: Record<MaintenanceCategory, number> = {
      Mechanical: 0,
      Electrical: 0,
      Pneumatic: 0,
      General: 0
    };

    workOrders.forEach(w => {
      if (counts[w.category] !== undefined) {
        counts[w.category]++;
      }
    });

    const maxCount = Math.max(...Object.values(counts), 1);

    return Object.entries(counts).map(([cat, val]) => ({
      name: cat,
      count: val,
      percent: Math.round((val / (workOrders.length || 1)) * 100),
      relativeHeight: Math.round((val / maxCount) * 100)
    }));
  }, [workOrders]);

  // Filter & Sort work orders
  const filteredAndSortedOrders = useMemo(() => {
    return workOrders
      .filter(w => {
        const matchesSearch = 
          (w.id || '').toLowerCase().includes(search.toLowerCase()) ||
          (w.assetId || '').toLowerCase().includes(search.toLowerCase()) ||
          (w.assetName || '').toLowerCase().includes(search.toLowerCase()) ||
          (w.assignedToName || '').toLowerCase().includes(search.toLowerCase()) ||
          (w.issue || '').toLowerCase().includes(search.toLowerCase()) ||
          (w.actionsTaken && (w.actionsTaken || '').toLowerCase().includes(search.toLowerCase()));

        const matchesCategory = categoryFilter === 'all' || w.category === categoryFilter;
        const matchesPriority = priorityFilter === 'all' || w.priority === priorityFilter;
        const matchesStatus = statusFilter === 'all' || w.status === statusFilter;

        return matchesSearch && matchesCategory && matchesPriority && matchesStatus;
      })
      .sort((a, b) => {
        let valueA: any = a[sortBy];
        let valueB: any = b[sortBy];

        if (sortBy === 'timestamp') {
          valueA = new Date(a.timestamp).getTime();
          valueB = new Date(b.timestamp).getTime();
        }

        if (valueA === undefined) valueA = 0;
        if (valueB === undefined) valueB = 0;

        if (valueA < valueB) return sortOrder === 'asc' ? -1 : 1;
        if (valueA > valueB) return sortOrder === 'asc' ? 1 : -1;
        return 0;
      });
  }, [workOrders, search, categoryFilter, priorityFilter, statusFilter, sortBy, sortOrder]);

  const reportMetrics = useMemo(() => {
    const total = filteredAndSortedOrders.length;
    const completed = filteredAndSortedOrders.filter(w => w.status === 'Completed').length;
    const pending = filteredAndSortedOrders.filter(w => w.status === 'Pending').length;
    const inProgress = filteredAndSortedOrders.filter(w => w.status === 'In Progress').length;
    
    const completedWithDowntime = filteredAndSortedOrders.filter(w => w.status === 'Completed' && w.downtimeHours !== undefined);
    const totalDowntime = completedWithDowntime.reduce((acc, curr) => acc + (curr.downtimeHours || 0), 0);
    const mttr = completedWithDowntime.length > 0 ? (totalDowntime / completedWithDowntime.length).toFixed(2) : '0';
    const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;

    const categoryBreakdown = filteredAndSortedOrders.reduce((acc, curr) => {
      acc[curr.category] = (acc[curr.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return { total, completed, pending, inProgress, mttr, completionRate, categoryBreakdown, totalDowntime };
  }, [filteredAndSortedOrders]);

  const handleSort = (field: 'id' | 'timestamp' | 'priority' | 'downtimeHours') => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
  };

  const handlePrintAudit = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Compliance Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">CMMS Database Volume</span>
          <div className="flex items-baseline space-x-2 mt-1.5">
            <span className="font-display font-bold text-slate-800 text-2xl">{metrics.total}</span>
            <span className="text-xs text-slate-500">Tickets Logged</span>
          </div>
          <div className="mt-2 text-xs text-slate-500 border-t border-slate-100 pt-2 flex justify-between">
            <span>Pending: <strong>{metrics.pending}</strong></span>
            <span>Working: <strong>{metrics.inProgress}</strong></span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Compliance Resolve Rate</span>
          <div className="flex items-baseline space-x-2 mt-1.5">
            <span className="font-display font-bold text-emerald-600 text-2xl">{metrics.completionRate}%</span>
            <span className="text-xs text-slate-500">SLA Met</span>
          </div>
          <div className="mt-2 w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
            <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: `${metrics.completionRate}%` }} />
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Mean Time to Repair (MTTR)</span>
          <div className="flex items-baseline space-x-2 mt-1.5">
            <span className="font-display font-bold text-slate-800 text-2xl">{metrics.mttr} hr{metrics.mttr !== '1' ? 's' : ''}</span>
            <span className="text-xs text-slate-500">Average Duration</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2 border-t border-slate-100 pt-2">
            Target SLA limit: <strong>&lt; 6.00 hours</strong> per breakdown.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Auditor Verification Seal</span>
          <div className="flex items-center space-x-2 mt-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 pulse-indicator" />
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded">
              ISO Compliant (SQL)
            </span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2.5 border-t border-slate-100 pt-2">
            Automated Cloud Database tamper protection active.
          </p>
        </div>
      </div>

      {/* SVG Analytics and KPI breakdown charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* SVG bar chart */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm lg:col-span-2">
          <h4 className="font-display font-bold text-slate-800 text-sm flex items-center gap-2 mb-6">
            <BarChart3 className="w-4 h-4 text-slate-500" /> Breakdowns by System Category
          </h4>
          
          <div className="grid grid-cols-4 gap-4 h-40 items-end border-b border-slate-200 pb-2 relative">
            {categoryChartData.map((data, idx) => (
              <div key={idx} className="flex flex-col items-center group relative h-full justify-end">
                {/* Bar */}
                <div 
                  className="w-full max-w-12 bg-slate-800 group-hover:bg-sky-600 rounded-t transition-all duration-500 ease-out"
                  style={{ height: `${data.relativeHeight}%` }}
                >
                  <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10 font-mono">
                    {data.count} Order{data.count !== 1 ? 's' : ''} ({data.percent}%)
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-4 gap-4 mt-2 text-center text-[11px] font-medium text-slate-500 font-display">
            {categoryChartData.map((data, idx) => (
              <div key={idx} className="truncate">
                {data.name}
                <span className="block font-bold text-slate-800 mt-0.5">{data.count}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Circular / Ring SLA metrics */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm lg:col-span-1 flex flex-col justify-between">
          <h4 className="font-display font-bold text-slate-800 text-sm flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4 text-slate-500" /> SLA Response Performance
          </h4>

          <div className="flex justify-center items-center py-4 relative">
            {/* SVG Circle indicator */}
            <svg className="w-32 h-32 transform -rotate-90">
              <circle
                cx="64"
                cy="64"
                r="50"
                className="stroke-slate-100 fill-none"
                strokeWidth="10"
              />
              <circle
                cx="64"
                cy="64"
                r="50"
                className="stroke-emerald-500 fill-none transition-all duration-1000 ease-out"
                strokeWidth="10"
                strokeDasharray="314"
                strokeDashoffset={314 - (314 * metrics.completionRate) / 100}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="font-display font-bold text-slate-900 text-2xl">{metrics.completionRate}%</span>
              <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Resolved</span>
            </div>
          </div>

          <div className="space-y-2 text-xs text-slate-600 border-t border-slate-100 pt-3">
            <div className="flex justify-between items-center">
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-emerald-500" /> Resolved SLA:</span>
              <span className="font-bold text-slate-800">{metrics.completed}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-slate-300" /> Backlogged:</span>
              <span className="font-bold text-slate-800">{metrics.pending + metrics.inProgress}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Advanced Filterable Data Ledger Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden" id="audit-table">
        <div className="px-5 py-4 bg-slate-50 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h4 className="font-display font-bold text-slate-800 text-sm flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-slate-500" /> Workshop Repair ledger
            </h4>
            <p className="text-xs text-slate-500">Filtered index of verified TVET maintenance log history.</p>
          </div>

          {/* Table Level Filters */}
          <div className="flex flex-wrap gap-2 w-full md:w-auto">
            <div className="relative flex-1 sm:flex-none">
              <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search ledger..."
                className="pl-8 pr-3 py-1.5 w-full sm:w-44 text-xs rounded-lg border border-slate-300 bg-white outline-none focus:border-slate-500"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            <select
              className="px-2 py-1.5 text-xs rounded-lg border border-slate-300 bg-white outline-none focus:border-slate-500 flex-1 sm:flex-initial"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
            >
              <option value="all">Category (All)</option>
              <option value="Mechanical">Mechanical</option>
              <option value="Electrical">Electrical</option>
              <option value="Pneumatic">Pneumatic</option>
              <option value="General">General</option>
            </select>

            <select
              className="px-2 py-1.5 text-xs rounded-lg border border-slate-300 bg-white outline-none focus:border-slate-500 flex-1 sm:flex-initial"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">Status (All)</option>
              <option value="Pending">Pending</option>
              <option value="In Progress">In Progress</option>
              <option value="Completed">Completed</option>
            </select>
          </div>
        </div>

        {/* Ledger Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse whitespace-nowrap">
            <thead>
              <tr className="bg-slate-50 text-slate-500 border-b border-slate-200 select-none">
                <th className="py-3 px-4 font-bold uppercase tracking-wider font-mono cursor-pointer hover:bg-slate-100" onClick={() => handleSort('id')}>
                  ID {sortBy === 'id' && (sortOrder === 'asc' ? '▲' : '▼')}
                </th>
                <th className="py-3 px-4 font-bold uppercase tracking-wider cursor-pointer hover:bg-slate-100" onClick={() => handleSort('timestamp')}>
                  Logged Date {sortBy === 'timestamp' && (sortOrder === 'asc' ? '▲' : '▼')}
                </th>
                <th className="py-3 px-4 font-bold uppercase tracking-wider">Asset Description</th>
                <th className="py-3 px-4 font-bold uppercase tracking-wider">Technician Assigned</th>
                <th className="py-3 px-4 font-bold uppercase tracking-wider">Category</th>
                <th className="py-3 px-4 font-bold uppercase tracking-wider text-right cursor-pointer hover:bg-slate-100" onClick={() => handleSort('downtimeHours')}>
                  Downtime {sortBy === 'downtimeHours' && (sortOrder === 'asc' ? '▲' : '▼')}
                </th>
                <th className="py-3 px-4 font-bold uppercase tracking-wider text-center">Status</th>
                <th className="py-3 px-4 text-center">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredAndSortedOrders.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-10 text-slate-400">
                    {workOrders.length === 0 ? "No maintenance records available." : "No records found matching the specified filters."}
                  </td>
                </tr>
              ) : (
                filteredAndSortedOrders.map((order, idx) => (
                  <React.Fragment key={`${order.id}-${idx}`}>
                    <tr 
                      className={`hover:bg-slate-50/80 transition-colors cursor-pointer ${
                        expandedRowId === order.id ? 'bg-slate-50' : ''
                      }`}
                      onClick={() => toggleRow(order.id)}
                    >
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">{order.id}</td>
                      <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                        {new Date(order.timestamp).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-800">{order.assetName}</div>
                        <div className="text-[10px] text-slate-400 font-mono mt-0.5">{order.assetId}</div>
                      </td>
                      <td className="py-3 px-4 text-slate-700 font-semibold">{order.assignedToName}</td>
                      <td className="py-3 px-4 text-slate-500">{order.category}</td>
                      <td className="py-3 px-4 text-right font-mono font-semibold text-slate-800">
                        {order.status === 'Completed' ? `${order.downtimeHours || 0} hr` : '—'}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                          order.status === 'Completed' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' :
                          order.status === 'In Progress' ? 'bg-amber-50 text-amber-700 border-amber-100' :
                          'bg-slate-50 text-slate-600 border-slate-200'
                        }`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button className="text-slate-400 hover:text-slate-700">
                          {expandedRowId === order.id ? <ChevronUp className="w-4 h-4 mx-auto" /> : <ChevronDown className="w-4 h-4 mx-auto" />}
                        </button>
                      </td>
                    </tr>

                    {/* Expandable details row */}
                    {expandedRowId === order.id && (
                      <tr className="bg-slate-50/50">
                        <td colSpan={8} className="p-5 border-l-2 border-slate-800">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-700">
                            <div className="space-y-2.5">
                              <h5 className="font-display font-bold text-slate-900 uppercase tracking-wider text-[10px]">Diagnostics Summary</h5>
                              <div>
                                <strong className="text-slate-800 font-semibold">Reported Issue:</strong>
                                <p className="mt-1 bg-white border border-slate-200 rounded p-2.5 leading-relaxed text-slate-600">{order.issue}</p>
                              </div>
                              <div className="flex gap-4">
                                <div>
                                  <strong className="text-slate-800 font-semibold">Logged By:</strong>
                                  <p className="mt-0.5 text-slate-600">{order.loggedBy}</p>
                                </div>
                                <div>
                                  <strong className="text-slate-800 font-semibold">Logged Time:</strong>
                                  <p className="mt-0.5 text-slate-600">{new Date(order.timestamp).toLocaleString()}</p>
                                </div>
                              </div>
                            </div>

                            <div className="space-y-2.5">
                              <h5 className="font-display font-bold text-slate-900 uppercase tracking-wider text-[10px]">Technical Actions Summary</h5>
                              {order.status === 'Completed' ? (
                                <>
                                  <div>
                                    <strong className="text-slate-800 font-semibold">Repairs Completed:</strong>
                                    <p className="mt-1 bg-white border border-slate-250 rounded p-2.5 leading-relaxed text-slate-600">{order.actionsTaken}</p>
                                  </div>
                                  <div className="grid grid-cols-2 gap-4">
                                    <div>
                                      <strong className="text-slate-800 font-semibold">Materials / Spare Parts Used:</strong>
                                      <p className="mt-0.5 text-slate-600">{order.materialsUsed || 'No replacement components used.'}</p>
                                    </div>
                                    <div>
                                      <strong className="text-slate-800 font-semibold">Resolution Date:</strong>
                                      <p className="mt-0.5 text-slate-600 font-mono">
                                        {order.completedTime ? new Date(order.completedTime).toLocaleString() : '—'}
                                      </p>
                                    </div>
                                  </div>
                                </>
                              ) : (
                                <div className="p-4 bg-amber-50/50 border border-amber-100 rounded text-amber-800 leading-relaxed">
                                  <strong>Status: {order.status}</strong>
                                  <p className="mt-0.5">This ticket is currently being handled by technician {order.assignedToName}. Direct results will appear here once submitted.</p>
                                </div>
                              )}
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Dynamic PDF Report Compiler & Print Preview Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 flex items-start justify-center overflow-y-auto p-2 sm:p-4 md:p-6 print:absolute print:inset-0 print:p-0 print:bg-white print:overflow-visible">
          {/* Main Printable Document Canvas */}
          <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl p-4 sm:p-8 md:p-10 my-4 sm:my-8 text-slate-800 border border-slate-200/60 flex flex-col print:shadow-none print:my-0 print:p-0 print:w-full print:max-w-none print:border-0 relative">
            
            {/* Modal Actions Bar (hidden during printing) */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 sm:mb-8 pb-4 border-b border-slate-200 print:hidden">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-sky-50 rounded-lg text-sky-600 shrink-0">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-display font-bold text-slate-900 text-sm">Printable Audit Report Ready</h4>
                  <p className="text-xs text-slate-500">Review, print, or download as a structured PDF document.</p>
                </div>
              </div>
              <div className="flex flex-wrap sm:flex-nowrap gap-2 w-full sm:w-auto">
                <button
                  onClick={() => window.print()}
                  className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold uppercase tracking-wider shadow-sm transition-all cursor-pointer border border-slate-800 min-h-[38px]"
                >
                  <Printer className="w-4 h-4" /> Print / Save as PDF
                </button>
                <button
                  onClick={() => setShowReportModal(false)}
                  className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer border border-slate-200 min-h-[38px]"
                >
                  Close Preview
                </button>
              </div>
            </div>

            {/* Document Body starts here */}
            <div className="space-y-6 print:space-y-6">
              {/* Official Letterhead */}
              <div className="flex flex-col items-center text-center pb-6 border-b-2 border-double border-slate-300">
                <span className="text-[10px] font-bold tracking-widest text-slate-400 uppercase font-sans">
                  KEMENTERIAN PENGAJIAN TINGGI • JABATAN PENDIDIKAN KOLEJ KOMUNITI DAN TVET
                </span>
                <h1 className="font-display font-extrabold text-base sm:text-lg md:text-xl text-slate-900 tracking-tight mt-1 uppercase">
                  DMR Workshop Management System
                </h1>
                <p className="text-xs text-slate-500 font-semibold tracking-wider uppercase mt-0.5">
                  TECHNICAL CMMS MAINTENANCE LOGS & COMPLIANCE LEDGER
                </p>
                <div className="mt-2 text-[10px] font-mono text-slate-400 bg-slate-50 border border-slate-150 rounded px-2.5 py-1">
                  Report ID: DMR-AUD-{(new Date()).getFullYear()}-{Math.floor(Math.random() * 90000 + 10000)} • Status: OFFICIAL LEDGER EXPORT
                </div>
              </div>

              {/* Document Header Metadata */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 border border-slate-200 rounded-lg p-4 text-xs">
                <div className="space-y-1.5 text-left">
                  <p className="text-slate-500"><strong className="text-slate-700 font-bold">Document Type:</strong> Technical Maintenance Audit Report</p>
                  <p className="text-slate-500"><strong className="text-slate-700 font-bold">Compiled By:</strong> {auditorName} (Lead Compliance Auditor)</p>
                  <p className="text-slate-500"><strong className="text-slate-700 font-bold">Date Generated:</strong> {new Date().toLocaleString('en-US')}</p>
                </div>
                <div className="space-y-1.5 sm:border-l border-slate-200 sm:pl-4 text-left border-t sm:border-t-0 pt-3 sm:pt-0">
                  <p className="text-slate-500"><strong className="text-slate-700 font-bold">Category Filter:</strong> {categoryFilter === 'all' ? 'All System Categories' : categoryFilter}</p>
                  <p className="text-slate-500"><strong className="text-slate-700 font-bold">Status Filter:</strong> {statusFilter === 'all' ? 'All Lifecycle States' : statusFilter}</p>
                  <p className="text-slate-500"><strong className="text-slate-700 font-bold">Search Scope:</strong> {search ? `"${search}"` : 'None (Full Ledger View)'}</p>
                </div>
              </div>

              {/* Executive Summary Narrative */}
              <div className="space-y-2 text-left">
                <h3 className="text-xs font-extrabold uppercase tracking-widest text-slate-900 border-b border-slate-200 pb-1 flex items-center gap-2">
                  <span className="w-1.5 h-3 bg-slate-800 rounded-xs"></span>
                  1. Executive Summary & Compliance Index
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  This report has been digitally compiled from the active TVET Workshop Computerized Maintenance Management System (CMMS). A total of <strong className="text-slate-900">{reportMetrics.total}</strong> records match the current filter scope. Automated validation checks have verified that all technician diagnostic logs and parts updates are consistent with safety procedures under Malaysia TVET Safety Act 139.
                </p>
              </div>

              {/* KPI block in document */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 text-center">
                <div className="border border-slate-200 rounded-lg p-3">
                  <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider">Total Tickets</span>
                  <span className="block text-xl font-bold font-display text-slate-900 mt-1">{reportMetrics.total}</span>
                </div>
                <div className="border border-slate-200 rounded-lg p-3">
                  <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider">Resolved SLA</span>
                  <span className="block text-xl font-bold font-display text-emerald-600 mt-1">{reportMetrics.completionRate}%</span>
                </div>
                <div className="border border-slate-200 rounded-lg p-3">
                  <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider">MTTR Average</span>
                  <span className="block text-xl font-bold font-display text-slate-900 mt-1">{reportMetrics.mttr} hr{reportMetrics.mttr !== '1' ? 's' : ''}</span>
                </div>
                <div className="border border-slate-200 rounded-lg p-3">
                  <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider">Total Downtime</span>
                  <span className="block text-xl font-bold font-display text-slate-900 mt-1">{reportMetrics.totalDowntime.toFixed(1)} hrs</span>
                </div>
              </div>

              {/* Breakdown metrics lists */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 text-left">
                <div>
                  <h4 className="text-[11px] font-bold text-slate-900 uppercase tracking-wider mb-2 border-b border-slate-100 pb-1">
                    System Breakdown Categories
                  </h4>
                  <div className="space-y-1.5 text-xs">
                    {Object.entries(reportMetrics.categoryBreakdown).length > 0 ? (
                      Object.entries(reportMetrics.categoryBreakdown).map(([cat, count]) => (
                        <div key={cat} className="flex justify-between text-slate-600">
                          <span>{cat}:</span>
                          <strong className="text-slate-900">{count} breakdown{count !== 1 ? 's' : ''}</strong>
                        </div>
                      ))
                    ) : (
                      <p className="text-slate-400 italic">No category breakdown matches available.</p>
                    )}
                  </div>
                </div>

                <div>
                  <h4 className="text-[11px] font-bold text-slate-900 uppercase tracking-wider mb-2 border-b border-slate-100 pb-1">
                    Lifecycle Backlog Status
                  </h4>
                  <div className="space-y-1.5 text-xs text-slate-600">
                    <div className="flex justify-between">
                      <span>Completed / SLA Met:</span>
                      <strong className="text-emerald-600 font-bold">{reportMetrics.completed}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Under Active Diagnostics:</span>
                      <strong className="text-sky-600 font-bold">{reportMetrics.inProgress}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Pending Assignment Backlog:</span>
                      <strong className="text-amber-600 font-bold">{reportMetrics.pending}</strong>
                    </div>
                  </div>
                </div>
              </div>

              {/* Compiled Work Orders Ledger Table */}
              <div className="space-y-2 text-left">
                <h3 className="text-xs font-extrabold uppercase tracking-widest text-slate-900 border-b border-slate-200 pb-1 flex items-center gap-2">
                  <span className="w-1.5 h-3 bg-slate-800 rounded-xs"></span>
                  2. Compiled Maintenance Log Ledger
                </h3>
                
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-[10px] border-collapse border border-slate-200">
                    <thead>
                      <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 font-bold">
                        <th className="p-2 border-r border-slate-200">ID</th>
                        <th className="p-2 border-r border-slate-200">Date Logged</th>
                        <th className="p-2 border-r border-slate-200">Asset & Location</th>
                        <th className="p-2 border-r border-slate-200">Specialist Assigned</th>
                        <th className="p-2 border-r border-slate-200">Diagnostic Details</th>
                        <th className="p-2 border-r border-slate-200">Repair Actions / Materials</th>
                        <th className="p-2 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredAndSortedOrders.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="p-4 text-center text-slate-400 italic">
                            No work orders match the selected filters.
                          </td>
                        </tr>
                      ) : (
                        filteredAndSortedOrders.map((order, idx) => (
                          <tr key={`${order.id}-${idx}`} className="border-b border-slate-200 hover:bg-slate-50/50">
                            <td className="p-2 font-mono font-bold text-slate-900 border-r border-slate-200 whitespace-nowrap">{order.id}</td>
                            <td className="p-2 text-slate-500 border-r border-slate-200 whitespace-nowrap">{new Date(order.timestamp).toLocaleDateString()}</td>
                            <td className="p-2 border-r border-slate-200">
                              <span className="font-bold text-slate-800 block">{order.assetName}</span>
                              <span className="text-[9px] text-slate-400 font-mono block">[{order.assetId}] • {order.category}</span>
                            </td>
                            <td className="p-2 border-r border-slate-200 font-medium text-slate-700">{order.assignedToName}</td>
                            <td className="p-2 border-r border-slate-200 text-slate-600 max-w-[150px] truncate" title={order.issue}>{order.issue}</td>
                            <td className="p-2 border-r border-slate-200 text-slate-600 max-w-[180px]">
                              {order.status === 'Completed' ? (
                                <div className="space-y-1">
                                  <p className="leading-normal"><strong className="text-slate-700 font-bold">Fix:</strong> {order.actionsTaken}</p>
                                  {order.materialsUsed && <p className="text-[9px] text-slate-500 font-medium italic">Parts: {order.materialsUsed}</p>}
                                  <p className="text-[9px] text-emerald-600 font-bold font-mono">Downtime: {order.downtimeHours || 0} hrs</p>
                                </div>
                              ) : (
                                <span className="text-slate-400 italic">Awaiting technical resolution...</span>
                              )}
                            </td>
                            <td className="p-2 text-center whitespace-nowrap">
                              <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold uppercase tracking-wider border ${
                                order.status === 'Completed' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                                order.status === 'In Progress' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                                'bg-slate-50 text-slate-600 border-slate-200'
                              }`}>
                                {order.status}
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Professional Signature Block (Official Verification) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-10 pt-6 sm:pt-10 mt-6 sm:mt-10 border-t border-slate-200 text-left">
                <div className="space-y-8 sm:space-y-12">
                  <p className="text-xs text-slate-500 font-semibold uppercase tracking-wider">
                    Prepared and Compiled By:
                  </p>
                  <div>
                    <div className="border-b border-slate-400 w-48 max-w-full h-0.5"></div>
                    <p className="text-xs font-bold text-slate-800 mt-2">{auditorName}</p>
                    <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Lead Compliance Auditor</p>
                    <p className="text-[9px] text-slate-500 italic mt-0.5">Authorized Signature (Digital Key Issued)</p>
                  </div>
                </div>

                <div className="space-y-8 sm:space-y-12 sm:border-l border-slate-200 sm:pl-10 border-t sm:border-t-0 pt-6 sm:pt-0">
                  <p className="text-xs text-slate-500 font-semibold uppercase tracking-wider">
                    Verified and Endorsed By:
                  </p>
                  <div>
                    <div className="border-b border-slate-400 w-48 max-w-full h-0.5"></div>
                    <p className="text-xs font-bold text-slate-800 mt-2">Encik Aziz (Supervisor)</p>
                    <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Workshop Supervisor & Custodian</p>
                    <p className="text-[9px] text-slate-500 italic mt-0.5">Automated System Endorsement Active</p>
                  </div>
                </div>
              </div>

              {/* Small fine-print footer */}
              <div className="text-center pt-8 border-t border-slate-100 text-[8px] text-slate-400 select-none">
                DMR DIGITAL CMMS RECORD COMPLIANCE • SECURED ENCRYPTED LEDGER BACKEND • GAS COMPLIANT V1.0.0
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
