import React, { useState, useEffect, useRef, useMemo } from 'react';
import { supabase } from '../lib/supabase';
import { 
  MachineBreakdown, 
  Asset, 
  PriorityLevel, 
  BreakdownCategory, 
  BreakdownStatus, 
  UserRole 
} from '../types';
import { syncAssetBreakdownStatus, isBreakdownActive, healAndSyncAllAssets, getEffectiveMachineStatus, broadcastMachineSync } from '../utils/machineSync';
import { 
  AlertTriangle, 
  Wrench, 
  Clock, 
  CheckCircle, 
  Plus, 
  Eye, 
  FileText, 
  Camera, 
  Upload, 
  X, 
  RefreshCw, 
  Trash2, 
  ShieldAlert, 
  Layers, 
  ExternalLink, 
  Image as ImageIcon,
  ChevronLeft,
  ChevronRight,
  Calendar,
  User,
  MapPin,
  Check,
  AlertCircle,
  History,
  Search,
  Filter,
  ShieldCheck
} from 'lucide-react';

interface MachineBreakdownViewProps {
  currentRole: UserRole;
  authorizedUser: string;
  onNavigateToWorkOrder?: (assetId: string, issue: string, priority: PriorityLevel, breakdownId: string) => void;
  onUpdateAssetStatus?: (assetId: string, status: Asset['status']) => void;
  assets?: Asset[];
}

// Helper utilities for resilient, crash-free data access
const getSafeString = (val: any): string => {
  if (val === null || val === undefined) return '';
  if (typeof val === 'string') return val;
  if (typeof val === 'number') return String(val);
  if (typeof val === 'object') {
    return val.full_name || val.name || val.username || val.machine_name || val.label || val.id || '';
  }
  return String(val);
};

const normalizePriority = (p?: any): PriorityLevel => {
  if (!p) return 'Medium';
  const str = String(p).toLowerCase().trim();
  if (str === 'critical') return 'Critical';
  if (str === 'high') return 'High';
  if (str === 'medium') return 'Medium';
  if (str === 'low') return 'Low';
  return 'Medium';
};

export const isCompletedBreakdown = (status?: string | null): boolean => {
  if (!status) return false;
  const s = String(status).trim().toLowerCase();
  return (
    s === 'completed' || 
    s === 'resolved' || 
    s === 'repaired' || 
    s === 'closed' ||
    s === 'cancelled' ||
    s === 'canceled'
  );
};

export const isActiveBreakdown = (status?: string | null): boolean => {
  if (!status) return true;
  return !isCompletedBreakdown(status);
};

const normalizeStatus = (s?: any): BreakdownStatus => {
  if (!s) return 'Reported';
  const str = String(s).trim();
  const valid: BreakdownStatus[] = [
    'Reported', 
    'Acknowledged', 
    'Under Repair', 
    'In Progress', 
    'Waiting for Spare Parts', 
    'Completed', 
    'Resolved', 
    'Closed',
    'Cancelled'
  ];
  const match = valid.find(v => v.toLowerCase() === str.toLowerCase());
  if (match) return match;
  const lower = str.toLowerCase();
  if (lower === 'repaired' || lower === 'resolved') return 'Resolved';
  if (lower === 'ongoing' || lower === 'in progress') return 'In Progress';
  if (lower === 'cancelled' || lower === 'canceled') return 'Cancelled';
  return 'Reported';
};

export const MachineBreakdownView: React.FC<MachineBreakdownViewProps> = ({
  currentRole,
  authorizedUser,
  onNavigateToWorkOrder,
  onUpdateAssetStatus,
  assets: propAssets
}) => {
  // Permission guard: Only Management can generate work orders
  const isManagement = currentRole === 'Management';

  // Breakdowns state loaded from localStorage or Supabase
  const [breakdowns, setBreakdowns] = useState<MachineBreakdown[]>(() => {
    try {
      const saved = localStorage.getItem('dmr_machine_breakdowns');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const demoBrkIds = ['BRK-001', 'BRK-002', 'BRK-2026-001', 'BRK-2026-002'];
          return parsed.filter((b: any) => b && !demoBrkIds.includes(b.id) && !demoBrkIds.includes(b.breakdown_id));
        }
      }
    } catch (e) {
      console.error('Failed to load local breakdowns:', e);
    }
    return [];
  });

  // Assets list
  const [assets, setAssets] = useState<Asset[]>(() => {
    if (propAssets && propAssets.length > 0) return propAssets;
    try {
      const saved = localStorage.getItem('dmr_assets_list');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const demoAssetIds = [
            'LATHE-01', 'LATHE-02', 'MILL-03', 'CNC-01', 'PUMP-01', 
            'COMP-02', 'WELD-05', 'DRILL-04', 'SHAPER-01', 'PLC-08', 
            'MCH-001', 'MCH-002', 'MCH-003', 'A-03', 'H-01', 'P-02'
          ];
          return parsed.filter((a: any) => a && !demoAssetIds.includes(a.id));
        }
      }
    } catch (e) {
      console.error('Failed to load local assets:', e);
    }
    return [];
  });

  // Loading and Error handling states
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [fetchError, setFetchError] = useState<string | null>(null);

  // Reusable Supabase fetching functions
  const fetchBreakdowns = async () => {
    setIsLoading(true);
    setFetchError(null);
    try {
      const { data, error } = await supabase
        .from('machine_breakdowns')
        .select('*')
        .order('reported_date', { ascending: false });

      if (error) {
        console.error('Error fetching breakdowns from Supabase:', error);
        setFetchError(error.message || 'Unable to load breakdown records. Please check database connectivity.');
      } else if (data) {
        const cleanData = Array.isArray(data) ? data.filter(Boolean) : [];
        setBreakdowns(cleanData);
        try {
          localStorage.setItem('dmr_machine_breakdowns', JSON.stringify(cleanData));
        } catch {}
      }
    } catch (err: any) {
      console.error('Error fetching breakdowns:', err);
      setFetchError(err?.message || 'Error loading machine breakdown records.');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchAssets = async () => {
    try {
      const { data, error } = await supabase.from('assets').select('*');
      if (!error && data) {
        const cleanAssets = Array.isArray(data) ? data.filter(Boolean) : [];
        setAssets(cleanAssets);
        try {
          localStorage.setItem('dmr_assets_list', JSON.stringify(cleanAssets));
        } catch {}
      }
    } catch (err) {
      console.error('Error syncing assets for breakdown view:', err);
    }
  };

  // Keep localStorage in sync
  useEffect(() => {
    try {
      if (breakdowns && Array.isArray(breakdowns)) {
        localStorage.setItem('dmr_machine_breakdowns', JSON.stringify(breakdowns));
      }
    } catch (e) {
      console.error('Error saving breakdowns to localStorage:', e);
    }
  }, [breakdowns]);

  // Load from Supabase/Firestore on mount and listen to cross-module sync events
  useEffect(() => {
    const runDataSync = async () => {
      await fetchBreakdowns();
      await fetchAssets();
      await healAndSyncAllAssets();
    };

    runDataSync();

    const handleSync = () => {
      runDataSync();
    };

    window.addEventListener('dmr_machine_sync', handleSync);
    window.addEventListener('storage', handleSync);

    return () => {
      window.removeEventListener('dmr_machine_sync', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, []);

  // Tab State: 'active' for Active Unresolved Breakdowns, 'history' for Breakdown History
  const [activeTab, setActiveTab] = useState<'active' | 'history'>('active');

  // View state & Pagination for Active Breakdowns
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [itemsPerPage, setItemsPerPage] = useState<number>(10);

  // Breakdown History Filtering State
  const [historySearchTerm, setHistorySearchTerm] = useState('');
  const [historyStatusFilter, setHistoryStatusFilter] = useState<'ALL' | 'Completed' | 'Resolved' | 'Closed' | 'Cancelled'>('ALL');
  const [historyDateFilter, setHistoryDateFilter] = useState('');
  const [historyPage, setHistoryPage] = useState(1);
  const [historyItemsPerPage, setHistoryItemsPerPage] = useState(10);
  const [verificationFit, setVerificationFit] = useState(true);

  // Modals
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [viewingBreakdown, setViewingBreakdown] = useState<MachineBreakdown | null>(null);
  const [feedbackToast, setFeedbackToast] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  const showToast = (type: 'success' | 'error' | 'info', text: string) => {
    setFeedbackToast({ type, text });
    setTimeout(() => setFeedbackToast(null), 4000);
  };

  // Form State for reporting a breakdown
  const [selectedAssetId, setSelectedAssetId] = useState('');
  const [problemDescription, setProblemDescription] = useState('');
  const [breakdownCategory, setBreakdownCategory] = useState<BreakdownCategory>('Mechanical');
  const [priority, setPriority] = useState<PriorityLevel>('High');
  const [machineCondition, setMachineCondition] = useState('');
  const [immediateAction, setImmediateAction] = useState('');
  const [machineIsolated, setMachineIsolated] = useState(true);
  const [safetyRisk, setSafetyRisk] = useState('');
  const [temporarySolution, setTemporarySolution] = useState('');
  const [remarks, setRemarks] = useState('');
  const [reportDate, setReportDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [reportTime, setReportTime] = useState(() => {
    const d = new Date();
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  });

  // Photo upload states
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string>('');
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [photoUploadError, setPhotoUploadError] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Selected asset object details
  const selectedAsset = useMemo(() => {
    return assets.find(a => a.id === selectedAssetId);
  }, [assets, selectedAssetId]);

  // Handle Photo selection
  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPhotoUploadError('');
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
      if (!validTypes.includes(file.type.toLowerCase())) {
        setPhotoUploadError('Supported image formats: JPG, JPEG, PNG, WEBP.');
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        setPhotoUploadError('File size exceeds the 5MB limit.');
        return;
      }
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        setPhotoPreview(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    setPhotoFile(null);
    setPhotoPreview('');
    setPhotoUploadError('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Upload photo to Supabase storage bucket: breakdown-images
  const uploadBreakdownPhoto = async (breakdownCode: string): Promise<string> => {
    if (!photoFile) return photoPreview || '';
    try {
      setIsUploadingPhoto(true);
      const fileExt = photoFile.name.split('.').pop() || 'jpg';
      const fileName = `${breakdownCode}-${Date.now()}.${fileExt}`;
      const filePath = `breakdowns/${fileName}`;

      const { data, error } = await supabase.storage
        .from('breakdown-images')
        .upload(filePath, photoFile, {
          upsert: true,
          contentType: photoFile.type
        });

      if (error) {
        console.warn('Storage upload error, falling back to base64:', error);
        return photoPreview;
      }

      const { data: urlData } = supabase.storage
        .from('breakdown-images')
        .getPublicUrl(data?.path || filePath);

      return urlData?.publicUrl || photoPreview;
    } catch (err) {
      console.error('Photo upload failed:', err);
      return photoPreview;
    } finally {
      setIsUploadingPhoto(false);
    }
  };

  // Auto-generate Breakdown ID e.g. BRK-2026-004
  const generateBreakdownId = (): string => {
    const year = new Date().getFullYear();
    const count = breakdowns.length + 1;
    return `BRK-${year}-${String(count).padStart(3, '0')}`;
  };

  // Handle Form Submit
  const handleReportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAssetId) {
      showToast('error', 'Please select a broken machine / asset.');
      return;
    }
    if (!problemDescription.trim()) {
      showToast('error', 'Please describe the problem.');
      return;
    }

    const bId = generateBreakdownId();
    const nowIso = new Date(`${reportDate}T${reportTime}:00`).toISOString();

    // 1. Upload photo if present
    let uploadedPhotoUrl = '';
    if (photoFile) {
      uploadedPhotoUrl = await uploadBreakdownPhoto(bId);
    }

    const newBreakdown: MachineBreakdown = {
      id: `BRK-${Date.now()}`,
      breakdown_id: bId,
      asset_id: selectedAssetId,
      machine_name: selectedAsset?.name || selectedAssetId,
      department: selectedAsset?.department || 'General Machining',
      location: selectedAsset?.location || 'Workshop',
      reported_by: authorizedUser || 'Technician',
      reported_date: reportDate,
      reported_time: reportTime,
      problem_description: problemDescription.trim(),
      breakdown_category: breakdownCategory,
      priority,
      status: 'Reported',
      machine_condition: machineCondition.trim() || 'Halted / Inoperable',
      downtime_start: nowIso,
      immediate_action: immediateAction.trim() || 'Machine isolated from main power supply',
      machine_isolated: machineIsolated,
      safety_risk: safetyRisk.trim(),
      temporary_solution: temporarySolution.trim(),
      remarks: remarks.trim(),
      photo_url: uploadedPhotoUrl,
      created_at: new Date().toISOString()
    };

    // 2. Persist in database
    try {
      await supabase.from('machine_breakdowns').insert([newBreakdown]);
    } catch (err) {
      console.warn('Failed to insert breakdown into backend table:', err);
    }

    // 3. Update local state
    setBreakdowns(prev => [newBreakdown, ...prev]);

    // 4. Update Asset status to BREAKDOWN across database and modules
    const updatedAssets = assets.map(a => {
      if (a.id === selectedAssetId) {
        return { ...a, status: 'Breakdown' as const };
      }
      return a;
    });
    setAssets(updatedAssets);

    // Call prop callback if provided
    if (onUpdateAssetStatus) {
      onUpdateAssetStatus(selectedAssetId, 'Breakdown');
    }

    // Bidirectional sync to Firestore, localStorage, and event bus
    try {
      await syncAssetBreakdownStatus(selectedAssetId, true, `Breakdown ${bId} reported`);
    } catch (err) {
      console.warn('Failed to sync asset breakdown status:', err);
    }

    // Reset Form
    setSelectedAssetId('');
    setProblemDescription('');
    setBreakdownCategory('Mechanical');
    setPriority('High');
    setMachineCondition('');
    setImmediateAction('');
    setMachineIsolated(true);
    setSafetyRisk('');
    setTemporarySolution('');
    setRemarks('');
    handleRemovePhoto();
    setIsReportModalOpen(false);

    showToast('success', `Breakdown ${bId} registered! Machine status set to 🔴 BREAKDOWN.`);
  };

  // Handle Breakdown Status Update
  const handleUpdateStatus = async (
    breakdownId: string, 
    newStatus: BreakdownStatus, 
    remarksText?: string,
    isVerifiedFit: boolean = true
  ) => {
    const target = breakdowns.find(b => b.id === breakdownId || b.breakdown_id === breakdownId);
    if (!target) return;

    let updatedEnd = target.downtime_end;
    let updatedTotalDowntime = target.total_downtime;

    // When status changes to Completed, Resolved, Repaired or Closed, calculate final downtime
    if (isCompletedBreakdown(newStatus)) {
      if (!isManagement) {
        showToast('error', 'Akses Terhad: Hanya peranan Management sahaja dibenarkan menandakan laporan kerosakan sebagai selesai.');
        return;
      }
      const now = new Date();
      updatedEnd = now.toISOString();
      const startMs = new Date(target.downtime_start).getTime();
      const endMs = now.getTime();
      const diffHours = Math.max(0.1, Number(((endMs - startMs) / (1000 * 60 * 60)).toFixed(2)));
      updatedTotalDowntime = diffHours;
    }

    const updatedBreakdowns = breakdowns.map(b => {
      if (b.id === target.id) {
        return {
          ...b,
          status: newStatus,
          downtime_end: updatedEnd,
          total_downtime: updatedTotalDowntime,
          remarks: remarksText !== undefined ? remarksText : b.remarks,
          updated_at: new Date().toISOString()
        };
      }
      return b;
    });

    setBreakdowns(updatedBreakdowns);
    localStorage.setItem('dmr_machine_breakdowns', JSON.stringify(updatedBreakdowns));

    if (viewingBreakdown && viewingBreakdown.id === target.id) {
      setViewingBreakdown({
        ...viewingBreakdown,
        status: newStatus,
        downtime_end: updatedEnd,
        total_downtime: updatedTotalDowntime,
        remarks: remarksText !== undefined ? remarksText : viewingBreakdown.remarks
      });
    }

    const targetAssetId = (target.asset_id || (target as any).assetId || '').trim();
    const targetMachineName = (target.machine_name || '').trim().toLowerCase();

    // Check machine status when breakdown completed or reopened
    if (isCompletedBreakdown(newStatus)) {
      const remainingActiveBreakdownsForAsset = updatedBreakdowns.filter(b => {
        const bAssetId = (b.asset_id || (b as any).assetId || '').trim();
        const bMachineName = (b.machine_name || '').trim().toLowerCase();
        const isSameMachine = (targetAssetId && bAssetId.toLowerCase() === targetAssetId.toLowerCase()) || 
                              (targetMachineName && bMachineName === targetMachineName);
        return isSameMachine && isActiveBreakdown(b.status);
      });

      if (remainingActiveBreakdownsForAsset.length === 0) {
        // If verified fit for service -> Operational (Running), else Under Maintenance
        const finalAssetStatus: Asset['status'] = isVerifiedFit ? 'Operational' : 'Under Maintenance';
        
        const newAssetList = assets.map(a => {
          const aId = (a.id || '').trim().toLowerCase();
          const aName = (a.name || '').trim().toLowerCase();
          if ((targetAssetId && aId === targetAssetId.toLowerCase()) || (targetMachineName && aName === targetMachineName)) {
            return { ...a, status: finalAssetStatus };
          }
          return a;
        });
        setAssets(newAssetList);

        if (onUpdateAssetStatus && targetAssetId) {
          onUpdateAssetStatus(targetAssetId, finalAssetStatus);
        }

        try {
          if (targetAssetId) {
            await syncAssetBreakdownStatus(
              targetAssetId, 
              false, 
              `Breakdown ${target.breakdown_id || target.id} resolved (${newStatus}) - verified fit: ${isVerifiedFit}`
            );
          }
          await healAndSyncAllAssets(newAssetList, updatedBreakdowns);
        } catch (err) {
          console.warn('Failed to restore asset status to Operational:', err);
        }

        if (isVerifiedFit) {
          showToast('success', `Laporan kerosakan ${target.breakdown_id || target.id} selesai. Mesin disahkan sedia dan status bertukar ke 🟢 OPERATIONAL!`);
        } else {
          showToast('info', `Laporan kerosakan ${target.breakdown_id || target.id} selesai. Status mesin kekal 'Under Maintenance' (menunggu verifikasi akhir).`);
        }
      } else {
        showToast('info', `Laporan kerosakan ditandakan ${newStatus}. Status mesin kekal 🔴 BREAKDOWN kerana masih terdapat ${remainingActiveBreakdownsForAsset.length} laporan aktif.`);
      }
    } else if (isActiveBreakdown(newStatus)) {
      // Re-flag machine as Breakdown if reopened
      const newAssetList = assets.map(a => {
        const aId = (a.id || '').trim().toLowerCase();
        const aName = (a.name || '').trim().toLowerCase();
        if ((targetAssetId && aId === targetAssetId.toLowerCase()) || (targetMachineName && aName === targetMachineName)) {
          return { ...a, status: 'Breakdown' as const };
        }
        return a;
      });
      setAssets(newAssetList);

      if (onUpdateAssetStatus && targetAssetId) {
        onUpdateAssetStatus(targetAssetId, 'Breakdown');
      }

      try {
        if (targetAssetId) {
          await syncAssetBreakdownStatus(targetAssetId, true, `Breakdown ${target.breakdown_id || target.id} status changed to ${newStatus}`);
        }
        await healAndSyncAllAssets(newAssetList, updatedBreakdowns);
      } catch (err) {}
      showToast('success', `Status dikemaskini ke ${newStatus}. Mesin disetkan ke 🔴 BREAKDOWN.`);
    } else {
      showToast('success', `Status dikemaskini ke ${newStatus}`);
    }

    // Update breakdown in Supabase
    try {
      await supabase.from('machine_breakdowns').update({
        status: newStatus,
        downtime_end: updatedEnd,
        total_downtime: updatedTotalDowntime,
        remarks: remarksText !== undefined ? remarksText : target.remarks,
        updated_at: new Date().toISOString()
      }).eq('id', target.id);

      if (target.breakdown_id && target.breakdown_id !== target.id) {
        await supabase.from('machine_breakdowns').update({
          status: newStatus,
          downtime_end: updatedEnd,
          total_downtime: updatedTotalDowntime,
          remarks: remarksText !== undefined ? remarksText : target.remarks,
          updated_at: new Date().toISOString()
        }).eq('breakdown_id', target.breakdown_id);
      }
    } catch (err) {
      console.warn('Failed to update breakdown in database:', err);
    }

    broadcastMachineSync(targetAssetId, newStatus, { breakdownId: target.id });

    // Update linked Work Order if exists
    if (target.linked_work_order_id && isCompletedBreakdown(newStatus)) {
      try {
        await supabase.from('work_orders').update({
          status: 'Completed',
          completed_time: updatedEnd,
          downtime_hours: updatedTotalDowntime,
          actions_taken: remarksText || target.remarks || 'Breakdown repair completed'
        }).eq('id', target.linked_work_order_id);

        const savedWo = localStorage.getItem('dmr_work_orders');
        if (savedWo) {
          const parsed = JSON.parse(savedWo);
          const updatedWo = parsed.map((wo: any) => 
            (wo.id === target.linked_work_order_id) ? { ...wo, status: 'Completed', completedTime: updatedEnd } : wo
          );
          localStorage.setItem('dmr_work_orders', JSON.stringify(updatedWo));
        }
      } catch (woErr) {
        console.warn('Failed to update linked work order:', woErr);
      }
    }
  };

  // Create Work Order from Breakdown Details (Restricted to Management only)
  const handleCreateWorkOrderFromBreakdown = (breakdown: MachineBreakdown) => {
    if (!isManagement) {
      showToast('error', 'Access Restricted: Only Management personnel can generate or dispatch work orders.');
      return;
    }
    if (onNavigateToWorkOrder) {
      onNavigateToWorkOrder(
        breakdown.asset_id,
        `[BREAKDOWN ${breakdown.breakdown_id}] ${breakdown.problem_description}`,
        breakdown.priority,
        breakdown.breakdown_id
      );
    }
    setViewingBreakdown(null);
  };

  // Helper getters for robust relational fallbacks (handles asset deleted, missing reported_by, etc.)
  const getBreakdownMachineName = (b?: MachineBreakdown | null): string => {
    if (!b) return 'Unknown Machine';
    const anyB = b as any;
    if (anyB.machine_name && typeof anyB.machine_name === 'string' && anyB.machine_name.trim()) return anyB.machine_name.trim();
    if (anyB.asset?.machine_name) return anyB.asset.machine_name;
    if (anyB.asset?.name) return anyB.asset.name;
    const found = (assets || []).find(a => a && a.id === (anyB.asset_id || anyB.asset?.id));
    if (found?.name) return found.name;
    return anyB.asset_id || anyB.asset?.id || 'Unknown Machine';
  };

  const getBreakdownAssetId = (b?: MachineBreakdown | null): string => {
    if (!b) return '-';
    const anyB = b as any;
    return anyB.asset_id || anyB.asset?.id || '-';
  };

  const getBreakdownDepartment = (b?: MachineBreakdown | null): string => {
    if (!b) return 'General Machining';
    const anyB = b as any;
    if (anyB.department && typeof anyB.department === 'string' && anyB.department.trim()) return anyB.department.trim();
    if (anyB.asset?.department) return anyB.asset.department;
    const found = (assets || []).find(a => a && a.id === (anyB.asset_id || anyB.asset?.id));
    if (found?.department) return found.department;
    return 'General Machining';
  };

  const getBreakdownLocation = (b?: MachineBreakdown | null): string => {
    if (!b) return 'Workshop';
    const anyB = b as any;
    if (anyB.location && typeof anyB.location === 'string' && anyB.location.trim()) return anyB.location.trim();
    if (anyB.asset?.location) return anyB.asset.location;
    const found = (assets || []).find(a => a && a.id === (anyB.asset_id || anyB.asset?.id));
    if (found?.location) return found.location;
    return 'Workshop';
  };

  const getBreakdownReporter = (b?: MachineBreakdown | null): string => {
    if (!b) return 'Unknown Reporter';
    const anyB = b as any;
    if (typeof anyB.reported_by === 'string' && anyB.reported_by.trim()) {
      return anyB.reported_by.trim();
    }
    if (anyB.reported_user) {
      if (typeof anyB.reported_user === 'string' && anyB.reported_user.trim()) return anyB.reported_user.trim();
      if (anyB.reported_user.full_name) return anyB.reported_user.full_name;
      if (anyB.reported_user.username) return anyB.reported_user.username;
    }
    if (anyB.profile) {
      if (typeof anyB.profile === 'string' && anyB.profile.trim()) return anyB.profile.trim();
      if (anyB.profile.full_name) return anyB.profile.full_name;
      if (anyB.profile.username) return anyB.profile.username;
    }
    if (anyB.user) {
      if (typeof anyB.user === 'string' && anyB.user.trim()) return anyB.user.trim();
      if (anyB.user.full_name) return anyB.user.full_name;
      if (anyB.user.username) return anyB.user.username;
    }
    return 'Unknown Reporter';
  };

  // Calculate live ongoing downtime in hours safely
  function calculateOngoingHours(startTime?: string): number {
    if (!startTime) return 0;
    try {
      const startMs = new Date(startTime).getTime();
      if (isNaN(startMs)) return 0;
      const nowMs = Date.now();
      const diff = nowMs - startMs;
      if (diff <= 0) return 0;
      return Math.max(0, Number((diff / (1000 * 60 * 60)).toFixed(1)));
    } catch {
      return 0;
    }
  }

  // Formatting hours to readable string safely
  const formatDowntimeDisplay = (b?: MachineBreakdown | null) => {
    if (!b) return '0.0 hrs';
    if (isCompletedBreakdown(b.status)) {
      const hours = b.total_downtime !== undefined && b.total_downtime !== null && !isNaN(Number(b.total_downtime))
        ? Number(b.total_downtime) 
        : calculateOngoingHours(b.downtime_start);
      return `${Number(hours || 0).toFixed(1)} hrs`;
    }
    const ongoingHours = calculateOngoingHours(b.downtime_start);
    return `Ongoing (${Number(ongoingHours || 0).toFixed(1)} hrs)`;
  };

  // Active / unresolved breakdowns only for the Active Breakdown Report
  const activeBreakdowns = useMemo(() => {
    return (breakdowns || []).filter(b => b && isActiveBreakdown(b.status));
  }, [breakdowns]);

  // KPIs with full null safety
  const totalBreakdownsCount = (breakdowns || []).filter(Boolean).length;
  const activeBreakdownsCount = activeBreakdowns.length;
  const openBreakdownsCount = (breakdowns || []).filter(b => {
    if (!b) return false;
    const st = normalizeStatus(b.status);
    return isActiveBreakdown(b.status) && st !== 'Under Repair' && st !== 'In Progress';
  }).length;
  const underRepairCount = (breakdowns || []).filter(b => {
    if (!b) return false;
    const st = normalizeStatus(b.status);
    return st === 'Under Repair' || st === 'In Progress';
  }).length;
  const completedCount = (breakdowns || []).filter(b => b && isCompletedBreakdown(b.status)).length;
  const criticalCount = (breakdowns || []).filter(b => {
    if (!b) return false;
    const p = normalizePriority(b.priority);
    return p === 'Critical' && isActiveBreakdown(b.status);
  }).length;

  const totalDowntimeHours = useMemo(() => {
    return (breakdowns || []).reduce((acc, b) => {
      if (!b) return acc;
      if (b.total_downtime !== undefined && b.total_downtime !== null && !isNaN(Number(b.total_downtime))) {
        return acc + Number(b.total_downtime || 0);
      }
      return acc + calculateOngoingHours(b.downtime_start);
    }, 0);
  }, [breakdowns]);

  // Repeated breakdowns map for machines with safe keys (historical analysis)
  const machineBreakdownFrequency = useMemo(() => {
    const counts: Record<string, { count: number; name: string; assetId: string }> = {};
    (breakdowns || []).forEach(b => {
      if (!b) return;
      const aId = getBreakdownAssetId(b);
      const mName = getBreakdownMachineName(b);
      const assetKey = aId !== '-' ? aId : (mName || 'UNKNOWN');
      if (!counts[assetKey]) {
        counts[assetKey] = {
          count: 0,
          name: mName,
          assetId: aId
        };
      }
      counts[assetKey].count += 1;
    });
    return Object.values(counts).sort((a, b) => b.count - a.count);
  }, [breakdowns, assets]);

  // Sorted breakdowns with complete null/undefined protection (Newest Breakdown First)
  // Displays ONLY active/unresolved breakdowns in the Active Machine Breakdown Report list
  const sortedBreakdowns = useMemo(() => {
    return [...activeBreakdowns].sort((a, b) => {
      const timeA = a?.downtime_start ? new Date(a.downtime_start).getTime() : 0;
      const timeB = b?.downtime_start ? new Date(b.downtime_start).getTime() : 0;
      const safeTimeA = isNaN(timeA) ? 0 : timeA;
      const safeTimeB = isNaN(timeB) ? 0 : timeB;
      return safeTimeB - safeTimeA;
    });
  }, [activeBreakdowns]);

  // Pagination calculation for Active Breakdowns
  const totalPages = Math.max(1, Math.ceil(sortedBreakdowns.length / itemsPerPage));
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages);
    }
  }, [currentPage, totalPages]);

  const paginatedBreakdowns = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return sortedBreakdowns.slice(start, start + itemsPerPage);
  }, [sortedBreakdowns, currentPage, itemsPerPage]);

  // Historical / completed / closed breakdowns
  const historyBreakdowns = useMemo(() => {
    return (breakdowns || []).filter(b => b && isCompletedBreakdown(b.status));
  }, [breakdowns]);

  // Filtered History Breakdowns based on search, status filter, and date filter
  const filteredHistoryBreakdowns = useMemo(() => {
    return historyBreakdowns.filter(b => {
      const q = historySearchTerm.toLowerCase().trim();
      const mName = getBreakdownMachineName(b).toLowerCase();
      const aId = getBreakdownAssetId(b).toLowerCase();
      const bId = (b.breakdown_id || b.id || '').toLowerCase();
      const tech = (b.reported_by || '').toLowerCase();
      const desc = (b.problem_description || '').toLowerCase();
      const rDate = (b.reported_date || '').toLowerCase();
      const cDate = (b.downtime_end || b.updated_at || '').toLowerCase();

      const matchesSearch = !q || 
        mName.includes(q) || 
        aId.includes(q) || 
        bId.includes(q) || 
        tech.includes(q) || 
        desc.includes(q) || 
        rDate.includes(q) || 
        cDate.includes(q);

      const norm = normalizeStatus(b.status);
      const matchesStatus = historyStatusFilter === 'ALL' || 
        norm.toLowerCase() === historyStatusFilter.toLowerCase();

      const matchesDate = !historyDateFilter || (b.reported_date && b.reported_date.startsWith(historyDateFilter));

      return matchesSearch && matchesStatus && matchesDate;
    }).sort((a, b) => {
      const timeA = a?.downtime_end ? new Date(a.downtime_end).getTime() : (a?.reported_date ? new Date(a.reported_date).getTime() : 0);
      const timeB = b?.downtime_end ? new Date(b.downtime_end).getTime() : (b?.reported_date ? new Date(b.reported_date).getTime() : 0);
      return (isNaN(timeB) ? 0 : timeB) - (isNaN(timeA) ? 0 : timeA);
    });
  }, [historyBreakdowns, historySearchTerm, historyStatusFilter, historyDateFilter]);

  const totalHistoryPages = Math.max(1, Math.ceil(filteredHistoryBreakdowns.length / historyItemsPerPage));
  useEffect(() => {
    if (historyPage > totalHistoryPages) {
      setHistoryPage(totalHistoryPages);
    }
  }, [historyPage, totalHistoryPages]);

  const paginatedHistoryBreakdowns = useMemo(() => {
    const start = (historyPage - 1) * historyItemsPerPage;
    return filteredHistoryBreakdowns.slice(start, start + historyItemsPerPage);
  }, [filteredHistoryBreakdowns, historyPage, historyItemsPerPage]);

  // Helper badge color functions
  const getStatusBadge = (status?: BreakdownStatus | string) => {
    const norm = normalizeStatus(status);
    switch (norm) {
      case 'Reported':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border-amber-300 dark:border-amber-800';
      case 'Acknowledged':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300 border-blue-300 dark:border-blue-800';
      case 'Under Repair':
      case 'In Progress':
        return 'bg-orange-100 text-orange-800 dark:bg-orange-950/60 dark:text-orange-300 border-orange-300 dark:border-orange-800 animate-pulse';
      case 'Waiting for Spare Parts':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300 border-purple-300 dark:border-purple-800';
      case 'Completed':
      case 'Resolved':
        return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800';
      case 'Closed':
        return 'bg-slate-200 text-slate-800 dark:bg-slate-800 dark:text-slate-300 border-slate-300 dark:border-slate-700';
      case 'Cancelled':
        return 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300 border-rose-300 dark:border-rose-800';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getPriorityBadge = (priority?: PriorityLevel | string) => {
    const norm = normalizePriority(priority);
    switch (norm) {
      case 'Critical':
        return 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300 border-rose-300 dark:border-rose-800 font-extrabold';
      case 'High':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border-amber-300 dark:border-amber-800 font-bold';
      case 'Medium':
        return 'bg-sky-100 text-sky-800 dark:bg-sky-950/60 dark:text-sky-300 border-sky-300 dark:border-sky-800';
      case 'Low':
        return 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-300 dark:border-slate-700';
      default:
        return 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-300 dark:border-slate-700';
    }
  };

  return (
    <div className="space-y-5 sm:space-y-6">
      {/* Toast Feedback */}
      {feedbackToast && (
        <div className={`fixed bottom-5 right-5 z-50 px-4 py-3 rounded-xl shadow-xl border flex items-center gap-2 text-xs font-semibold animate-in fade-in slide-in-from-bottom-5 duration-200 ${
          feedbackToast.type === 'success' 
            ? 'bg-emerald-900 text-white border-emerald-700' 
            : feedbackToast.type === 'error'
              ? 'bg-rose-900 text-white border-rose-700'
              : 'bg-slate-900 text-white border-slate-700'
        }`}>
          {feedbackToast.type === 'success' ? <Check className="w-4 h-4 text-emerald-400" /> : <AlertCircle className="w-4 h-4 text-rose-400" />}
          <span>{feedbackToast.text}</span>
        </div>
      )}

      {/* ======================================================== */}
      {/* 1. TOP HEADER & MAIN ACTIONS */}
      {/* ======================================================== */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white p-5 sm:p-6 rounded-2xl shadow-lg border border-slate-800 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2.5 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold tracking-widest uppercase bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                TELEMETRY & CRITICAL ALERTS
              </span>
              <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">• Supabase Storage Live</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-display tracking-tight text-white flex items-center gap-2.5">
              <AlertTriangle className="w-6 h-6 text-amber-400" />
              Machine Breakdown Reports
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Real-time equipment downtime tracking, digital incident logs, root cause analysis, and immediate work order dispatch.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={() => {
                fetchBreakdowns();
                fetchAssets();
              }}
              disabled={isLoading}
              className="px-3.5 py-2 rounded-xl text-xs font-bold uppercase tracking-wider bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
              title="Refresh breakdown reports"
            >
              <RefreshCw className={`w-4 h-4 text-sky-400 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </button>

            {/* + REPORT MACHINE BREAKDOWN BUTTON */}
            <button
              onClick={() => {
                setPhotoFile(null);
                setPhotoPreview('');
                setPhotoUploadError('');
                setIsReportModalOpen(true);
              }}
              className="px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white transition-all flex items-center gap-2 shadow-lg shadow-rose-600/30 hover:shadow-rose-600/50 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              + REPORT MACHINE BREAKDOWN
            </button>
          </div>
        </div>
      </div>

      {/* Error State Banner */}
      {fetchError && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-800 dark:text-rose-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs sm:text-sm shadow-xs">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0" />
            <div>
              <p className="font-semibold text-rose-900 dark:text-rose-100">Unable to load machine breakdown reports</p>
              <p className="text-xs text-rose-700 dark:text-rose-300 mt-0.5">{fetchError}</p>
            </div>
          </div>
          <button
            onClick={() => {
              fetchBreakdowns();
              fetchAssets();
            }}
            className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Retry
          </button>
        </div>
      )}

      {/* ======================================================== */}
      {/* 2. TOP KPI CARDS */}
      {/* ======================================================== */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* KPI 1: Active Breakdowns */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <p className="text-[10px] font-bold text-rose-600 dark:text-rose-400 uppercase tracking-wider">Active Breakdowns</p>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-display text-rose-600 dark:text-rose-400 tracking-tight">{activeBreakdownsCount}</span>
            <span className="text-[11px] text-slate-400 font-medium">unresolved</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2">Active in report list</p>
        </div>

        {/* KPI 2: Open Breakdowns */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <p className="text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">Reported / Pending</p>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-display text-amber-600 dark:text-amber-400 tracking-tight">{openBreakdownsCount}</span>
            <span className="text-[11px] text-slate-400 font-medium">pending</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2">Awaiting technician</p>
        </div>

        {/* KPI 3: Under Repair */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <p className="text-[10px] font-bold text-orange-600 dark:text-orange-400 uppercase tracking-wider">Under Repair</p>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-display text-orange-600 dark:text-orange-400 tracking-tight">{underRepairCount}</span>
            <span className="text-[11px] text-slate-400 font-medium">in-work</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2">Technician on-site</p>
        </div>

        {/* KPI 4: Completed */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <p className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">Completed</p>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-display text-emerald-600 dark:text-emerald-400 tracking-tight">{completedCount}</span>
            <span className="text-[11px] text-slate-400 font-medium">resolved</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2">Repairs restored</p>
        </div>

        {/* KPI 5: Critical Breakdowns */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <p className="text-[10px] font-bold text-rose-600 dark:text-rose-400 uppercase tracking-wider">Critical Alerts</p>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-display text-rose-600 dark:text-rose-400 tracking-tight">{criticalCount}</span>
            <span className="text-[11px] text-slate-400 font-medium">urgent</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2">Immediate LOTO / Danger</p>
        </div>

        {/* KPI 6: Total Downtime */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <p className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">Total Downtime</p>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-display text-indigo-600 dark:text-indigo-400 tracking-tight">{totalDowntimeHours.toFixed(1)}</span>
            <span className="text-[11px] text-slate-400 font-medium">hours</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2">Cumulative loss</p>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 3. BREAKDOWN REPORT LIST & BREAKDOWN HISTORY (TABS) */}
      {/* ======================================================== */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col w-full min-w-0">
        {/* Navigation Tabs Header */}
        <div className="p-3 sm:p-4 bg-slate-50 dark:bg-slate-900/90 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 w-full min-w-0">
          <div className="grid grid-cols-2 sm:flex sm:items-center gap-2 w-full sm:w-auto min-w-0">
            <button
              type="button"
              onClick={() => setActiveTab('active')}
              className={`w-full sm:w-auto min-w-0 min-h-[42px] sm:min-h-0 px-2 sm:px-4 py-2 rounded-xl text-[11px] sm:text-xs font-bold uppercase tracking-tight sm:tracking-wider transition-all flex items-center justify-center gap-1.5 sm:gap-2 cursor-pointer text-center ${
                activeTab === 'active'
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/60 border border-slate-200 dark:border-slate-700'
              }`}
            >
              <AlertTriangle className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'active' ? 'text-white' : 'text-rose-500'}`} />
              <span className="leading-tight text-center break-words sm:whitespace-nowrap">Active Breakdowns</span>
              <span className={`shrink-0 px-1.5 sm:px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                activeTab === 'active' ? 'bg-white/20 text-white' : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
              }`}>
                {activeBreakdownsCount}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('history')}
              className={`w-full sm:w-auto min-w-0 min-h-[42px] sm:min-h-0 px-2 sm:px-4 py-2 rounded-xl text-[11px] sm:text-xs font-bold uppercase tracking-tight sm:tracking-wider transition-all flex items-center justify-center gap-1.5 sm:gap-2 cursor-pointer text-center ${
                activeTab === 'history'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/60 border border-slate-200 dark:border-slate-700'
              }`}
            >
              <History className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'history' ? 'text-white' : 'text-indigo-500'}`} />
              <span className="leading-tight text-center break-words sm:whitespace-nowrap">Breakdown History</span>
              <span className={`shrink-0 px-1.5 sm:px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                activeTab === 'history' ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-800 dark:bg-slate-700 dark:text-slate-300'
              }`}>
                {completedCount}
              </span>
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            {activeTab === 'active' ? (
              <>
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                <span>Active & unresolved reports only</span>
              </>
            ) : (
              <>
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span>Completed & archived breakdown records</span>
              </>
            )}
          </div>
        </div>

        {/* ======================================================== */}
        {/* TAB CONTENT: ACTIVE BREAKDOWNS */}
        {/* ======================================================== */}
        {activeTab === 'active' && (
          <>
            {/* Table View (Desktop & Tablet) */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-max">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-900/80 border-b border-slate-200 dark:border-slate-800 text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    <th className="p-3.5">Breakdown ID</th>
                    <th className="p-3.5">Asset ID & Machine</th>
                    <th className="p-3.5">Location</th>
                    <th className="p-3.5">Reported By</th>
                    <th className="p-3.5">Date & Time</th>
                    <th className="p-3.5 text-center">Priority</th>
                    <th className="p-3.5 text-center">Status</th>
                    <th className="p-3.5 text-center">Downtime</th>
                    <th className="p-3.5 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                  {isLoading ? (
                    <tr>
                      <td colSpan={9} className="p-10 text-center text-slate-500 dark:text-slate-400">
                        <div className="flex flex-col items-center justify-center gap-2">
                          <RefreshCw className="w-5 h-5 animate-spin text-rose-500" />
                          <span className="font-medium">Loading machine breakdown reports...</span>
                        </div>
                      </td>
                    </tr>
                  ) : paginatedBreakdowns.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="p-10 text-center text-slate-500 dark:text-slate-400">
                        <div className="flex flex-col items-center justify-center gap-1.5">
                          <CheckCircle className="w-8 h-8 text-emerald-500 mb-1" />
                          <span className="font-semibold text-slate-700 dark:text-slate-200">No active machine breakdowns</span>
                          <span className="text-xs text-slate-400">All machine equipment is currently operational. Completed breakdown records remain safely archived in Breakdown History.</span>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    paginatedBreakdowns.map((b, idx) => {
                      const mName = getBreakdownMachineName(b);
                      const aId = getBreakdownAssetId(b);
                      const loc = getBreakdownLocation(b);
                      const dept = getBreakdownDepartment(b);
                      const rBy = getBreakdownReporter(b);
                      const normPriority = normalizePriority(b.priority);
                      const normStatus = normalizeStatus(b.status);

                      return (
                        <tr 
                          key={b.id || b.breakdown_id || `brk-row-${idx}`} 
                          className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors cursor-pointer group"
                          onClick={() => setViewingBreakdown(b)}
                        >
                          <td className="p-3.5 font-mono font-bold text-rose-600 dark:text-rose-400">
                            {b.breakdown_id || b.id || 'BRK-LOG'}
                          </td>
                          <td className="p-3.5">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-slate-900 dark:text-white group-hover:text-rose-600 transition-colors">
                                {mName}
                              </span>
                              {isActiveBreakdown(b.status) ? (
                                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-rose-600 text-white shadow-2xs animate-pulse shrink-0">
                                  🔴 BREAKDOWN
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-400 shrink-0">
                                  🟢 OPERATIONAL
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] font-mono text-slate-500">{aId}</div>
                          </td>
                          <td className="p-3.5 text-slate-600 dark:text-slate-300">
                            <div>{loc}</div>
                            <div className="text-[10px] text-slate-400">{dept}</div>
                          </td>
                          <td className="p-3.5 text-slate-700 dark:text-slate-300 font-medium">
                            {rBy}
                          </td>
                          <td className="p-3.5 text-slate-600 dark:text-slate-400">
                            <div>{b.reported_date || '-'}</div>
                            <div className="text-[10px] font-mono text-slate-400">{b.reported_time || '-'}</div>
                          </td>
                          <td className="p-3.5 text-center">
                            <span className={`px-2 py-0.5 rounded text-[10px] border uppercase ${getPriorityBadge(normPriority)}`}>
                              {normPriority}
                            </span>
                          </td>
                          <td className="p-3.5 text-center">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${getStatusBadge(normStatus)}`}>
                              {normStatus}
                            </span>
                          </td>
                          <td className="p-3.5 text-center font-mono font-semibold">
                            {normStatus === 'Completed' || normStatus === 'Closed' ? (
                              <span className="text-emerald-600 dark:text-emerald-400">
                                {formatDowntimeDisplay(b)}
                              </span>
                            ) : (
                              <span className="text-rose-600 dark:text-rose-400 flex items-center justify-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping"></span>
                                {formatDowntimeDisplay(b)}
                              </span>
                            )}
                          </td>
                          <td className="p-3.5 text-right" onClick={e => e.stopPropagation()}>
                            <div className="flex items-center justify-end gap-1.5">
                              {isManagement && isActiveBreakdown(b.status) && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleUpdateStatus(b.id, 'Completed', undefined, true);
                                  }}
                                  className="px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-1 shadow-xs cursor-pointer transition-all hover:scale-105"
                                  title="Tandakan Pembaikan Selesai (Hanya Management: Kembalikan mesin ke 🟢 Operational)"
                                >
                                  <CheckCircle className="w-3 h-3" /> Selesai
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => setViewingBreakdown(b)}
                                className="p-1.5 text-slate-400 hover:text-slate-800 dark:hover:text-white rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                                title="View Breakdown Details"
                              >
                                <Eye className="w-4 h-4" />
                              </button>
                              {isManagement && isActiveBreakdown(b.status) && (
                                <button
                                  type="button"
                                  onClick={() => handleCreateWorkOrderFromBreakdown(b)}
                                  className="px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded bg-amber-500 hover:bg-amber-600 text-white flex items-center gap-1 shadow-xs cursor-pointer"
                                  title="Dispatch Work Order"
                                >
                                  <Wrench className="w-3 h-3" /> WO
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards View (Smartphones & small screens) */}
            <div className="md:hidden divide-y divide-slate-100 dark:divide-slate-800">
              {isLoading ? (
                <div className="p-8 text-center text-slate-500 text-xs flex flex-col items-center justify-center gap-2">
                  <RefreshCw className="w-5 h-5 animate-spin text-rose-500" />
                  <span className="font-medium">Loading machine breakdown reports...</span>
                </div>
              ) : paginatedBreakdowns.length === 0 ? (
                <div className="p-8 text-center text-slate-500 text-xs flex flex-col items-center justify-center gap-1.5">
                  <CheckCircle className="w-7 h-7 text-emerald-500 mb-1" />
                  <span className="font-semibold text-slate-700 dark:text-slate-200">No active machine breakdowns</span>
                  <span className="text-xs text-slate-400">All machine equipment is currently operational. Completed breakdown records remain safely archived in Breakdown History.</span>
                </div>
              ) : (
                paginatedBreakdowns.map((b, idx) => {
                  const mName = getBreakdownMachineName(b);
                  const aId = getBreakdownAssetId(b);
                  const loc = getBreakdownLocation(b);
                  const rBy = getBreakdownReporter(b);
                  const normPriority = normalizePriority(b.priority);
                  const normStatus = normalizeStatus(b.status);

                  return (
                    <div 
                      key={b.id || b.breakdown_id || `mobile-brk-${idx}`} 
                      className="p-4 space-y-3 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                      onClick={() => setViewingBreakdown(b)}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="text-[10px] font-mono font-bold text-rose-600 dark:text-rose-400 block">
                            {b.breakdown_id || b.id || 'BRK-LOG'}
                          </span>
                          <div className="flex flex-wrap items-center gap-1.5 mt-0.5">
                            <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                              {mName}
                            </h4>
                            {isActiveBreakdown(b.status) ? (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-rose-600 text-white shadow-2xs">
                                🔴 BREAKDOWN
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-400">
                                🟢 OPERATIONAL
                              </span>
                            )}
                          </div>
                          <p className="text-xs font-mono text-slate-500">{aId} • {loc}</p>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase shrink-0 ${getStatusBadge(normStatus)}`}>
                          {normStatus}
                        </span>
                      </div>

                      <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2">
                        {b.problem_description || 'No problem description provided.'}
                      </p>

                      <div className="flex flex-wrap items-center justify-between text-xs pt-2 border-t border-slate-100 dark:border-slate-800 gap-2">
                        <div className="flex items-center gap-2">
                          <span className={`px-1.5 py-0.5 rounded text-[9px] border uppercase ${getPriorityBadge(normPriority)}`}>
                            {normPriority}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {b.reported_date || '-'} {b.reported_time || '-'} • By {rBy}
                          </span>
                        </div>

                        <span className="text-xs font-mono font-bold text-rose-600 dark:text-rose-400">
                          {formatDowntimeDisplay(b)}
                        </span>
                      </div>

                      <div className="flex items-center justify-end gap-2 pt-1" onClick={e => e.stopPropagation()}>
                        {isManagement && isActiveBreakdown(b.status) && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleUpdateStatus(b.id, 'Completed', undefined, true);
                            }}
                            className="px-2.5 py-1.5 text-xs font-bold uppercase tracking-wider text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg flex items-center gap-1 cursor-pointer transition-all shadow-xs"
                          >
                            <CheckCircle className="w-3.5 h-3.5" /> Selesai
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setViewingBreakdown(b)}
                          className="px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-lg cursor-pointer"
                        >
                          View Details
                        </button>
                        {isManagement && isActiveBreakdown(b.status) && (
                          <button
                            type="button"
                            onClick={() => handleCreateWorkOrderFromBreakdown(b)}
                            className="px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-white bg-amber-500 hover:bg-amber-600 rounded-lg flex items-center gap-1 cursor-pointer"
                          >
                            <Wrench className="w-3.5 h-3.5" /> Create WO
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Pagination Bar for Active Breakdowns */}
            <div className="p-3.5 sm:p-4 bg-slate-50 dark:bg-slate-900/80 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
              <div className="text-slate-500 dark:text-slate-400 text-center sm:text-left">
                Showing <strong>{sortedBreakdowns.length === 0 ? 0 : (currentPage - 1) * itemsPerPage + 1}</strong> to <strong>{Math.min(currentPage * itemsPerPage, sortedBreakdowns.length)}</strong> of <strong>{sortedBreakdowns.length}</strong> active reports
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="font-mono text-slate-700 dark:text-slate-300 font-bold px-2">
                  Page {currentPage} of {totalPages}
                </span>
                <button
                  type="button"
                  onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </>
        )}

        {/* ======================================================== */}
        {/* TAB CONTENT: BREAKDOWN HISTORY */}
        {/* ======================================================== */}
        {activeTab === 'history' && (
          <>
            {/* Search and Filters Toolbar */}
            <div className="p-3 sm:p-4 bg-slate-50/70 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-800 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
              <div className="flex-1 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                {/* Search Input */}
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={historySearchTerm}
                    onChange={(e) => {
                      setHistorySearchTerm(e.target.value);
                      setHistoryPage(1);
                    }}
                    placeholder="Search by Machine, Asset ID, Breakdown ID, Technician, Issue..."
                    className="w-full pl-9 pr-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-indigo-500 text-slate-800 dark:text-slate-200 placeholder-slate-400"
                  />
                  {historySearchTerm && (
                    <button
                      type="button"
                      onClick={() => setHistorySearchTerm('')}
                      className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Date Filter */}
                <div className="flex items-center gap-1.5">
                  <input
                    type="date"
                    value={historyDateFilter}
                    onChange={(e) => {
                      setHistoryDateFilter(e.target.value);
                      setHistoryPage(1);
                    }}
                    className="px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-indigo-500 text-slate-800 dark:text-slate-200"
                    title="Filter by report or completion date"
                  />
                  {historyDateFilter && (
                    <button
                      type="button"
                      onClick={() => setHistoryDateFilter('')}
                      className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded"
                      title="Clear date filter"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Status Dropdown */}
                <div className="flex items-center gap-1.5">
                  <select
                    value={historyStatusFilter}
                    onChange={(e) => {
                      setHistoryStatusFilter(e.target.value as any);
                      setHistoryPage(1);
                    }}
                    className="px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-indigo-500 text-slate-800 dark:text-slate-200 font-medium"
                  >
                    <option value="ALL">All Statuses</option>
                    <option value="Completed">Completed</option>
                    <option value="Resolved">Resolved</option>
                    <option value="Closed">Closed</option>
                    <option value="Cancelled">Cancelled</option>
                  </select>
                </div>
              </div>

              {(historySearchTerm || historyDateFilter || historyStatusFilter !== 'ALL') && (
                <button
                  type="button"
                  onClick={() => {
                    setHistorySearchTerm('');
                    setHistoryDateFilter('');
                    setHistoryStatusFilter('ALL');
                    setHistoryPage(1);
                  }}
                  className="px-3 py-1.5 text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors font-semibold flex items-center justify-center gap-1 cursor-pointer self-start sm:self-auto"
                >
                  <X className="w-3.5 h-3.5" />
                  Reset Filters
                </button>
              )}
            </div>

            {/* Desktop & Tablet Table for History */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-max">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-900/80 border-b border-slate-200 dark:border-slate-800 text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    <th className="p-3.5">Breakdown ID</th>
                    <th className="p-3.5">Asset ID & Machine</th>
                    <th className="p-3.5">Report Date</th>
                    <th className="p-3.5">Completion Date</th>
                    <th className="p-3.5">Technician</th>
                    <th className="p-3.5 max-w-xs">Problem Description</th>
                    <th className="p-3.5 text-center">Total Downtime</th>
                    <th className="p-3.5 text-center">Final Status</th>
                    <th className="p-3.5 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                  {isLoading ? (
                    <tr>
                      <td colSpan={9} className="p-10 text-center text-slate-500 dark:text-slate-400">
                        <div className="flex flex-col items-center justify-center gap-2">
                          <RefreshCw className="w-5 h-5 animate-spin text-indigo-500" />
                          <span className="font-medium">Loading breakdown history...</span>
                        </div>
                      </td>
                    </tr>
                  ) : paginatedHistoryBreakdowns.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="p-10 text-center text-slate-500 dark:text-slate-400">
                        <div className="flex flex-col items-center justify-center gap-1.5">
                          <History className="w-8 h-8 text-slate-400 mb-1" />
                          <span className="font-semibold text-slate-700 dark:text-slate-200">No historical records found</span>
                          <span className="text-xs text-slate-400">
                            {historySearchTerm || historyDateFilter || historyStatusFilter !== 'ALL'
                              ? 'No records match the current filter criteria. Try clearing filters.'
                              : 'When repairs are completed, resolved breakdown reports will be stored here permanently for auditing and analytics.'}
                          </span>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    paginatedHistoryBreakdowns.map((b, idx) => {
                      const mName = getBreakdownMachineName(b);
                      const aId = getBreakdownAssetId(b);
                      const rBy = getBreakdownReporter(b);
                      const normStatus = normalizeStatus(b.status);
                      const completionDateDisplay = (() => {
                        if (b.downtime_end) {
                          try {
                            const d = new Date(b.downtime_end);
                            return isNaN(d.getTime()) ? b.downtime_end : d.toLocaleString();
                          } catch {
                            return b.downtime_end;
                          }
                        }
                        if (b.updated_at) {
                          try {
                            const d = new Date(b.updated_at);
                            return isNaN(d.getTime()) ? b.updated_at : d.toLocaleString();
                          } catch {
                            return b.updated_at;
                          }
                        }
                        return '-';
                      })();

                      return (
                        <tr
                          key={b.id || b.breakdown_id || `hist-row-${idx}`}
                          className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors cursor-pointer group"
                          onClick={() => setViewingBreakdown(b)}
                        >
                          <td className="p-3.5 font-mono font-bold text-indigo-600 dark:text-indigo-400">
                            {b.breakdown_id || b.id || 'BRK-LOG'}
                          </td>
                          <td className="p-3.5">
                            <div className="font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 transition-colors">
                              {mName}
                            </div>
                            <div className="text-[10px] font-mono text-slate-500">{aId}</div>
                          </td>
                          <td className="p-3.5 text-slate-600 dark:text-slate-400">
                            <div>{b.reported_date || '-'}</div>
                            <div className="text-[10px] font-mono text-slate-400">{b.reported_time || ''}</div>
                          </td>
                          <td className="p-3.5 text-slate-600 dark:text-slate-400">
                            <div className="font-mono text-xs">{completionDateDisplay}</div>
                          </td>
                          <td className="p-3.5 text-slate-700 dark:text-slate-300 font-medium">
                            {rBy}
                          </td>
                          <td className="p-3.5 text-slate-600 dark:text-slate-300 max-w-xs">
                            <p className="truncate" title={b.problem_description}>
                              {b.problem_description || 'No description logged'}
                            </p>
                          </td>
                          <td className="p-3.5 text-center font-mono font-bold text-emerald-600 dark:text-emerald-400">
                            {formatDowntimeDisplay(b)}
                          </td>
                          <td className="p-3.5 text-center">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${getStatusBadge(normStatus)}`}>
                              {normStatus}
                            </span>
                          </td>
                          <td className="p-3.5 text-right" onClick={e => e.stopPropagation()}>
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() => setViewingBreakdown(b)}
                                className="px-2.5 py-1 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                                title="View full historical report details"
                              >
                                <Eye className="w-3.5 h-3.5" /> View
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards View for History */}
            <div className="md:hidden divide-y divide-slate-100 dark:divide-slate-800">
              {isLoading ? (
                <div className="p-8 text-center text-slate-500 text-xs flex flex-col items-center justify-center gap-2">
                  <RefreshCw className="w-5 h-5 animate-spin text-indigo-500" />
                  <span className="font-medium">Loading breakdown history...</span>
                </div>
              ) : paginatedHistoryBreakdowns.length === 0 ? (
                <div className="p-8 text-center text-slate-500 text-xs flex flex-col items-center justify-center gap-1.5">
                  <History className="w-7 h-7 text-slate-400 mb-1" />
                  <span className="font-semibold text-slate-700 dark:text-slate-200">No historical records found</span>
                  <span className="text-xs text-slate-400">No completed breakdown reports recorded yet.</span>
                </div>
              ) : (
                paginatedHistoryBreakdowns.map((b, idx) => {
                  const mName = getBreakdownMachineName(b);
                  const aId = getBreakdownAssetId(b);
                  const rBy = getBreakdownReporter(b);
                  const normStatus = normalizeStatus(b.status);

                  return (
                    <div
                      key={b.id || b.breakdown_id || `mobile-hist-${idx}`}
                      className="p-4 space-y-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                      onClick={() => setViewingBreakdown(b)}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="text-[10px] font-mono font-bold text-indigo-600 dark:text-indigo-400 block">
                            {b.breakdown_id || b.id || 'BRK-LOG'}
                          </span>
                          <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                            {mName}
                          </h4>
                          <p className="text-xs font-mono text-slate-500">{aId}</p>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase shrink-0 ${getStatusBadge(normStatus)}`}>
                          {normStatus}
                        </span>
                      </div>

                      <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2">
                        {b.problem_description || 'No description logged'}
                      </p>

                      <div className="flex flex-wrap items-center justify-between text-xs pt-2 border-t border-slate-100 dark:border-slate-800 gap-2">
                        <div className="text-[10px] text-slate-400">
                          Reported: {b.reported_date || '-'} • Tech: {rBy}
                        </div>
                        <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400 text-xs">
                          {formatDowntimeDisplay(b)}
                        </span>
                      </div>

                      <div className="flex justify-end pt-1" onClick={e => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={() => setViewingBreakdown(b)}
                          className="px-3 py-1 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-lg cursor-pointer"
                        >
                          View Details
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Pagination Bar for Breakdown History */}
            <div className="p-3.5 sm:p-4 bg-slate-50 dark:bg-slate-900/80 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
              <div className="text-slate-500 dark:text-slate-400 text-center sm:text-left">
                Showing <strong>{filteredHistoryBreakdowns.length === 0 ? 0 : (historyPage - 1) * historyItemsPerPage + 1}</strong> to <strong>{Math.min(historyPage * historyItemsPerPage, filteredHistoryBreakdowns.length)}</strong> of <strong>{filteredHistoryBreakdowns.length}</strong> historical records
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setHistoryPage(p => Math.max(1, p - 1))}
                  disabled={historyPage === 1}
                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="font-mono text-slate-700 dark:text-slate-300 font-bold px-2">
                  Page {historyPage} of {totalHistoryPages}
                </span>
                <button
                  type="button"
                  onClick={() => setHistoryPage(p => Math.min(totalHistoryPages, p + 1))}
                  disabled={historyPage === totalHistoryPages}
                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      {/* ======================================================== */}
      {/* 7. REPORT MACHINE BREAKDOWN MODAL */}
      {/* ======================================================== */}
      {isReportModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[94vh]">
            {/* Modal Header */}
            <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900/50 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-rose-600 text-white flex items-center justify-center font-bold shadow-md">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-base sm:text-lg text-slate-900 dark:text-white">
                    Report Machine Breakdown
                  </h3>
                  <p className="text-[11px] text-slate-500 font-mono">
                    ID: {generateBreakdownId()} • Reporter: {authorizedUser || 'Current User'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsReportModalOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded-full transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <div className="p-4 sm:p-6 overflow-y-auto flex-1">
              <form id="reportBreakdownForm" onSubmit={handleReportSubmit} className="space-y-6">
                
                {/* SECTION A: BREAKDOWN INFORMATION */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 pb-1 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                    Breakdown Information
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Machine Selector */}
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Select Broken Machine / Asset <span className="text-rose-500">*</span>
                      </label>
                      <select
                        required
                        value={selectedAssetId}
                        onChange={e => setSelectedAssetId(e.target.value)}
                        className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-sm focus:outline-none focus:border-rose-500 dark:text-white"
                      >
                        <option value="">{(assets || []).length === 0 ? '-- No machines registered yet --' : '-- Choose Machine Equipment --'}</option>
                        {(assets || []).filter(Boolean).map((a, idx) => (
                          <option key={a.id || `select-asset-${idx}`} value={a.id}>
                            {a.name || a.id} ({a.id}) — {a.location || 'Workshop'} [{a.status || 'Operational'}]
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Auto-displayed Machine Name */}
                    <div>
                      <label className="block text-[11px] font-medium text-slate-500 uppercase tracking-wider mb-1">
                        Machine Name (Auto Display)
                      </label>
                      <input
                        type="text"
                        readOnly
                        value={selectedAsset?.name || 'Select a machine above'}
                        className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 outline-none"
                      />
                    </div>

                    {/* Auto-displayed Asset ID */}
                    <div>
                      <label className="block text-[11px] font-medium text-slate-500 uppercase tracking-wider mb-1">
                        Asset ID (Auto Display)
                      </label>
                      <input
                        type="text"
                        readOnly
                        value={selectedAsset?.id || '-'}
                        className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-mono font-semibold text-slate-700 dark:text-slate-200 outline-none"
                      />
                    </div>

                    {/* Auto-displayed Department */}
                    <div>
                      <label className="block text-[11px] font-medium text-slate-500 uppercase tracking-wider mb-1">
                        Department (Auto Display)
                      </label>
                      <input
                        type="text"
                        readOnly
                        value={selectedAsset?.department || 'General Machining'}
                        className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 outline-none"
                      />
                    </div>

                    {/* Auto-displayed Location */}
                    <div>
                      <label className="block text-[11px] font-medium text-slate-500 uppercase tracking-wider mb-1">
                        Location (Auto Display)
                      </label>
                      <input
                        type="text"
                        readOnly
                        value={selectedAsset?.location || '-'}
                        className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 outline-none"
                      />
                    </div>

                    {/* Report Date */}
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Report Date <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="date"
                        required
                        value={reportDate}
                        onChange={e => setReportDate(e.target.value)}
                        className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-rose-500 dark:text-white"
                      />
                    </div>

                    {/* Report Time */}
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Report Time <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="time"
                        required
                        value={reportTime}
                        onChange={e => setReportTime(e.target.value)}
                        className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-rose-500 dark:text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* SECTION B: PROBLEM INFORMATION */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 pb-1 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                    Problem Information
                  </h4>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Problem Description <span className="text-rose-500">*</span>
                      </label>
                      <textarea
                        required
                        rows={3}
                        value={problemDescription}
                        onChange={e => setProblemDescription(e.target.value)}
                        placeholder="Clearly state what happened, abnormal sounds, vibrations, error codes, failed components..."
                        className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-rose-500 dark:text-white resize-none"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                          Breakdown Category <span className="text-rose-500">*</span>
                        </label>
                        <select
                          value={breakdownCategory}
                          onChange={e => setBreakdownCategory(e.target.value as BreakdownCategory)}
                          className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-rose-500 dark:text-white"
                        >
                          <option value="Mechanical">Mechanical</option>
                          <option value="Electrical">Electrical</option>
                          <option value="Hydraulic">Hydraulic</option>
                          <option value="Pneumatic">Pneumatic</option>
                          <option value="Control / Instrumentation">Control / Instrumentation</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                          Priority <span className="text-rose-500">*</span>
                        </label>
                        <select
                          value={priority}
                          onChange={e => setPriority(e.target.value as PriorityLevel)}
                          className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-rose-500 dark:text-white"
                        >
                          <option value="Critical">🔴 Critical (Total Stop / Hazard)</option>
                          <option value="High">🟠 High (Heavy Impact)</option>
                          <option value="Medium">🟡 Medium (Partial Impairment)</option>
                          <option value="Low">🟢 Low (Minor / Non-urgent)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                          Machine Condition
                        </label>
                        <input
                          type="text"
                          value={machineCondition}
                          onChange={e => setMachineCondition(e.target.value)}
                          placeholder="e.g. Unusable / E-stop pressed"
                          className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-rose-500 dark:text-white"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* SECTION C: PHOTO UPLOAD */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50/60 dark:bg-slate-950/40">
                  <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-200 dark:border-slate-800">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                      <Camera className="w-4 h-4 text-sky-500" />
                      Breakdown Photo Upload
                    </h4>
                    <span className="text-[10px] text-slate-500">Max 5MB • JPG, PNG, WEBP</span>
                  </div>

                  {/* Hidden inputs */}
                  <input
                    ref={fileInputRef}
                    type="file"
                    id="breakdownPhotoInput"
                    accept="image/jpeg,image/jpg,image/png,image/webp"
                    capture="environment" // Mobile camera shortcut
                    onChange={handlePhotoSelect}
                    className="hidden"
                  />
                  <input
                    type="file"
                    id="breakdownPhotoLibraryInput"
                    accept="image/jpeg,image/jpg,image/png,image/webp"
                    onChange={handlePhotoSelect}
                    className="hidden"
                  />

                  {photoUploadError && (
                    <div className="mb-3 p-2 bg-rose-50 text-rose-700 text-xs rounded-lg flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{photoUploadError}</span>
                    </div>
                  )}

                  {photoPreview ? (
                    <div className="relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-black/10 max-h-64 flex items-center justify-center group">
                      <img src={photoPreview} alt="Breakdown Preview" className="max-h-64 object-contain" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="px-3 py-1.5 bg-white text-slate-800 text-xs font-bold rounded-lg shadow-md hover:bg-slate-100 cursor-pointer flex items-center gap-1"
                        >
                          <RefreshCw className="w-3.5 h-3.5" /> Replace
                        </button>
                        <button
                          type="button"
                          onClick={handleRemovePhoto}
                          className="px-3 py-1.5 bg-rose-600 text-white text-xs font-bold rounded-lg shadow-md hover:bg-rose-700 cursor-pointer flex items-center gap-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Remove
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-5 text-center bg-white dark:bg-slate-900">
                      <Upload className="w-6 h-6 text-slate-400 mx-auto mb-2" />
                      <p className="text-xs font-medium text-slate-700 dark:text-slate-300">
                        Take a photo or upload from device
                      </p>
                      <div className="flex flex-wrap items-center justify-center gap-2 mt-3">
                        <label
                          htmlFor="breakdownPhotoInput"
                          className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5"
                        >
                          <Camera className="w-3.5 h-3.5" /> Take Photo
                        </label>
                        <label
                          htmlFor="breakdownPhotoLibraryInput"
                          className="px-3.5 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5"
                        >
                          <Upload className="w-3.5 h-3.5 text-slate-500" /> Choose File
                        </label>
                      </div>
                    </div>
                  )}
                </div>

                {/* SECTION D: IMMEDIATE ACTION & SAFETY */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 pb-1 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    Immediate Action & Safety
                  </h4>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Immediate Action Taken
                      </label>
                      <input
                        type="text"
                        value={immediateAction}
                        onChange={e => setImmediateAction(e.target.value)}
                        placeholder="e.g. Emergency stop triggered, main isolator switched off."
                        className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-rose-500 dark:text-white"
                      />
                    </div>

                    <div className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                      <input
                        type="checkbox"
                        id="machineIsolatedCheck"
                        checked={machineIsolated}
                        onChange={e => setMachineIsolated(e.target.checked)}
                        className="w-4 h-4 text-rose-600 rounded focus:ring-rose-500 cursor-pointer"
                      />
                      <label htmlFor="machineIsolatedCheck" className="text-xs font-medium text-slate-800 dark:text-slate-200 cursor-pointer">
                        Machine Isolated & Locked Out (LOTO applied / Danger tag affixed)
                      </label>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                          Safety Risk Identified
                        </label>
                        <input
                          type="text"
                          value={safetyRisk}
                          onChange={e => setSafetyRisk(e.target.value)}
                          placeholder="e.g. Hot surface, oil leakage, high pressure"
                          className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-rose-500 dark:text-white"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                          Temporary Solution
                        </label>
                        <input
                          type="text"
                          value={temporarySolution}
                          onChange={e => setTemporarySolution(e.target.value)}
                          placeholder="e.g. Switched production line to Lathe B"
                          className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-rose-500 dark:text-white"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Remarks / Observations
                      </label>
                      <input
                        type="text"
                        value={remarks}
                        onChange={e => setRemarks(e.target.value)}
                        placeholder="Additional notes for technician / supervisor..."
                        className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-rose-500 dark:text-white"
                      />
                    </div>
                  </div>
                </div>

              </form>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex items-center justify-between gap-3 shrink-0">
              <span className="text-[11px] text-rose-600 font-semibold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
                Machine status will automatically change to 🔴 BREAKDOWN
              </span>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsReportModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  form="reportBreakdownForm"
                  disabled={isUploadingPhoto}
                  className="px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isUploadingPhoto ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Uploading Photo...
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" /> Submit Breakdown Report
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 8. BREAKDOWN DETAILS MODAL */}
      {/* ======================================================== */}
      {viewingBreakdown && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[94vh]">
            {/* Header */}
            <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900/50 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-rose-600 text-white flex items-center justify-center font-bold">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-display font-bold text-base sm:text-lg text-slate-900 dark:text-white">
                      {viewingBreakdown.breakdown_id || viewingBreakdown.id || 'BRK-LOG'}
                    </h3>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${getStatusBadge(viewingBreakdown.status)}`}>
                      {normalizeStatus(viewingBreakdown.status)}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${getPriorityBadge(viewingBreakdown.priority)}`}>
                      {normalizePriority(viewingBreakdown.priority)}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-mono">
                    Asset: {getBreakdownAssetId(viewingBreakdown)} • Reported by {getBreakdownReporter(viewingBreakdown)} on {viewingBreakdown.reported_date || '-'} at {viewingBreakdown.reported_time || '-'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setViewingBreakdown(null)}
                className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded-full transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Details Content */}
            <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-6">
              
              {/* Prominent Live Downtime Banner */}
              <div className="p-4 rounded-xl bg-slate-900 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
                <div>
                  <span className="text-[10px] font-bold text-rose-400 uppercase tracking-widest block mb-0.5">
                    MACHINE DOWNTIME METRICS
                  </span>
                  <div className="flex flex-wrap items-center gap-2 mt-0.5">
                    <h4 className="text-lg font-bold font-display text-white">
                      {getBreakdownMachineName(viewingBreakdown)}
                    </h4>
                    {isActiveBreakdown(viewingBreakdown.status) ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-rose-600 text-white shadow-xs animate-pulse">
                        🔴 MACHINE BREAKDOWN
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500 text-white shadow-xs">
                        🟢 MACHINE OPERATIONAL
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    Location: {getBreakdownLocation(viewingBreakdown)} • Dept: {getBreakdownDepartment(viewingBreakdown)}
                  </p>
                </div>

                <div className="text-right sm:text-right">
                  <div className="text-2xl font-bold font-mono text-amber-400">
                    {formatDowntimeDisplay(viewingBreakdown)}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Started: {(() => {
                      if (!viewingBreakdown.downtime_start) return '-';
                      try {
                        const d = new Date(viewingBreakdown.downtime_start);
                        return isNaN(d.getTime()) ? viewingBreakdown.downtime_start : d.toLocaleString();
                      } catch {
                        return viewingBreakdown.downtime_start || '-';
                      }
                    })()}
                  </div>
                </div>
              </div>

              {/* Photo Display if uploaded */}
              {viewingBreakdown.photo_url && (
                <div>
                  <h5 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Breakdown Photo</h5>
                  <div className="rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950 max-h-72 flex items-center justify-center">
                    <img 
                      src={viewingBreakdown.photo_url} 
                      alt="Breakdown Photo" 
                      className="max-h-72 w-full object-contain"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                  </div>
                </div>
              )}

              {/* Problem Description */}
              <div>
                <h5 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Problem Description</h5>
                <p className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 bg-slate-50 dark:bg-slate-950 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 whitespace-pre-wrap leading-relaxed">
                  {viewingBreakdown.problem_description || 'No problem description logged.'}
                </p>
              </div>

              {/* Parameters Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Category</span>
                  <p className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">{viewingBreakdown.breakdown_category || 'General'}</p>
                </div>

                <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Machine Condition</span>
                  <p className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">{viewingBreakdown.machine_condition || '-'}</p>
                </div>

                <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Machine Isolated</span>
                  <p className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">
                    {viewingBreakdown.machine_isolated ? '✅ Yes (LOTO applied)' : '⚠️ Not isolated'}
                  </p>
                </div>

                <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Safety Risk</span>
                  <p className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">{viewingBreakdown.safety_risk || 'None reported'}</p>
                </div>
              </div>

              {/* Immediate Action & Temporary Solution */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                  <h6 className="font-bold text-slate-700 dark:text-slate-300 uppercase text-[10px] tracking-wider mb-1">
                    Immediate Action Taken
                  </h6>
                  <p className="text-slate-600 dark:text-slate-400">
                    {viewingBreakdown.immediate_action || 'No immediate action logged.'}
                  </p>
                </div>

                <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                  <h6 className="font-bold text-slate-700 dark:text-slate-300 uppercase text-[10px] tracking-wider mb-1">
                    Temporary Solution / Bypass
                  </h6>
                  <p className="text-slate-600 dark:text-slate-400">
                    {viewingBreakdown.temporary_solution || 'No temporary workaround applied.'}
                  </p>
                </div>
              </div>

              {/* Remarks */}
              {viewingBreakdown.remarks && (
                <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 text-xs">
                  <h6 className="font-bold text-slate-700 dark:text-slate-300 uppercase text-[10px] tracking-wider mb-1">
                    Technician Remarks / Observations
                  </h6>
                  <p className="text-slate-600 dark:text-slate-400">
                    {viewingBreakdown.remarks}
                  </p>
                </div>
              )}

              {/* Status Update Control Section */}
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 space-y-3">
                <div className="flex items-center justify-between">
                  <h6 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                    Update Repair & Breakdown Status
                  </h6>
                  <span className="text-[10px] text-slate-400">Allowed for Technician & Management</span>
                </div>

                {isCompletedBreakdown(viewingBreakdown.status) ? (
                  <div className="p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Laporan ini telah selesai dan diarkibkan dalam <strong>Breakdown History</strong> (Jumlah Downtime: <strong>{formatDowntimeDisplay(viewingBreakdown)}</strong>).</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs">
                    <input 
                      type="checkbox"
                      id="verifyFitCheck"
                      checked={verificationFit}
                      onChange={(e) => setVerificationFit(e.target.checked)}
                      className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                    />
                    <label htmlFor="verifyFitCheck" className="text-slate-700 dark:text-slate-300 font-medium cursor-pointer flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                      Mesin telah diverifikasi sedia (Tukar status mesin ke 🟢 Running / Operational apabila ditandakan Completed)
                    </label>
                  </div>
                )}

                <div className="flex flex-wrap items-center gap-2">
                  {(['Reported', 'Acknowledged', 'Under Repair', 'In Progress', 'Waiting for Spare Parts', 'Completed', 'Resolved', 'Closed', 'Cancelled'] as BreakdownStatus[])
                    .filter(st => isManagement || !isCompletedBreakdown(st))
                    .map(st => (
                      <button
                        key={st}
                        onClick={() => handleUpdateStatus(viewingBreakdown.id, st, undefined, verificationFit)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                          viewingBreakdown.status === st
                            ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm font-bold'
                            : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                </div>
              </div>

            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex flex-wrap items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-2">
                {/* Work Order Connection Button */}
                {viewingBreakdown.linked_work_order_id ? (
                  <span className="px-3 py-1.5 rounded-lg text-xs font-mono font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-300">
                    Linked to Work Order: {viewingBreakdown.linked_work_order_id}
                  </span>
                ) : isManagement ? (
                  <button
                    onClick={() => handleCreateWorkOrderFromBreakdown(viewingBreakdown)}
                    className="px-4 py-2 text-xs font-bold uppercase tracking-wider text-white bg-amber-500 hover:bg-amber-600 rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <Wrench className="w-3.5 h-3.5" />
                    Create Work Order
                  </button>
                ) : (
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 italic flex items-center gap-1">
                    <ShieldAlert className="w-3.5 h-3.5 text-slate-400" />
                    Work Order dispatch restricted to Management
                  </span>
                )}
              </div>

              <button
                onClick={() => setViewingBreakdown(null)}
                className="px-5 py-2 text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 rounded-xl transition-all cursor-pointer shadow-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
