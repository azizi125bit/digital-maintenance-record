import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '../lib/supabase';
import { Asset, UserRole } from '../types';
import { generateMachineHistoryPDF } from '../utils/machineHistoryPdfExport';
import { getEffectiveMachineStatus, healAndSyncAllAssets } from '../utils/machineSync';
import { MachineReportModal } from './MachineReportModal';
import { 
  History, 
  Search, 
  Filter, 
  Download, 
  Eye, 
  Calendar, 
  Wrench, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldCheck, 
  X, 
  RefreshCw, 
  FileText, 
  SlidersHorizontal,
  ChevronDown,
  Layers,
  Image as ImageIcon,
  ExternalLink,
  Lock,
  Tag,
  MapPin,
  Building,
  Check,
  AlertCircle,
  RotateCcw,
  Hash,
  UserCheck
} from 'lucide-react';

export interface UnifiedMaintenanceRecord {
  id: string; // e.g. BRK-2026-001 or PM-3370 or DMR-1001
  recordType: 'Preventive Maintenance' | 'Corrective Maintenance' | 'Breakdown Repair' | 'Inspection' | 'General';
  assetId: string;
  assetName: string;
  serialNumber?: string;
  date: string; // YYYY-MM-DD or ISO
  time?: string;
  workOrderId?: string;
  technician: string;
  technicianId?: string;
  status: string; // 'Completed', 'In Progress', 'Verified', etc.
  maintenanceDescription?: string;
  findings: string;
  actionTaken: string;
  partsUsed: string;
  downtimeHours?: number;
  verificationStatus: string;
  supervisor?: string;
  verificationDate?: string;
  supervisorRemarks?: string;
  checklist?: Array<{ task: string; completed?: boolean; status?: string; remarks?: string }>;
  measurements?: Array<{ parameter: string; standard: string; reading: string; unit: string; status: string }>;
  tools?: Array<string | { name: string; quantity?: number; remarks?: string }>;
  photos?: string[];
  documents?: string[];
  sourceCollection: 'preventive_maintenance' | 'machine_breakdowns' | 'work_orders';
  rawRecord: any;
}

interface MaintenanceRecordsViewProps {
  currentRole: UserRole;
  authorizedUser: string;
  theme?: 'light' | 'dark';
}

export const MaintenanceRecordsView: React.FC<MaintenanceRecordsViewProps> = ({
  currentRole,
  authorizedUser,
  theme = 'dark'
}) => {
  // Permission: Management and Supervisor can export PDF
  const canExport = currentRole === 'Management' || (currentRole as any) === 'Supervisor';

  // State: Assets and selected Asset (persisted to localStorage to survive page refresh)
  const [assets, setAssets] = useState<Asset[]>([]);
  const [selectedAssetId, setSelectedAssetId] = useState<string>(() => {
    return localStorage.getItem('dmr_mr_selected_asset_id') || '';
  });
  const [assetSearchQuery, setAssetSearchQuery] = useState<string>('');

  // State: Raw maintenance sources & data loading
  const [rawPms, setRawPms] = useState<any[]>([]);
  const [rawBreakdowns, setRawBreakdowns] = useState<any[]>([]);
  const [rawWorkOrders, setRawWorkOrders] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [fetchError, setFetchError] = useState<string | null>(null);

  // State: Data Retrieval & Filter Options (persisted to localStorage so retrieved records remain after refresh)
  const [filterMachineName, setFilterMachineName] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('dmr_mr_filters');
      if (saved) return JSON.parse(saved).filterMachineName || '';
    } catch {}
    return '';
  });

  const [filterAssetOrSerial, setFilterAssetOrSerial] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('dmr_mr_filters');
      if (saved) return JSON.parse(saved).filterAssetOrSerial || '';
    } catch {}
    return '';
  });

  const [filterType, setFilterType] = useState<'all' | 'PM' | 'CM'>(() => {
    try {
      const saved = localStorage.getItem('dmr_mr_filters');
      if (saved) return JSON.parse(saved).filterType || 'all';
    } catch {}
    return 'all';
  });

  const [filterTechnician, setFilterTechnician] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('dmr_mr_filters');
      if (saved) return JSON.parse(saved).filterTechnician || '';
    } catch {}
    return '';
  });

  const [filterDateFrom, setFilterDateFrom] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('dmr_mr_filters');
      if (saved) return JSON.parse(saved).filterDateFrom || '';
    } catch {}
    return '';
  });

  const [filterDateTo, setFilterDateTo] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('dmr_mr_filters');
      if (saved) return JSON.parse(saved).filterDateTo || '';
    } catch {}
    return '';
  });

  // State: View mode (Table vs Timeline)
  const [viewMode, setViewMode] = useState<'table' | 'timeline'>('table');

  // State: Modal for viewing single record details
  const [viewingRecord, setViewingRecord] = useState<UnifiedMaintenanceRecord | null>(null);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);

  // Feedback notification
  const [feedback, setFeedback] = useState<{ type: 'success' | 'info' | 'error'; text: string } | null>(null);

  const showFeedback = (type: 'success' | 'info' | 'error', text: string) => {
    setFeedback({ type, text });
    setTimeout(() => setFeedback(null), 4000);
  };

  // Sync selectedAssetId to localStorage
  useEffect(() => {
    if (selectedAssetId) {
      localStorage.setItem('dmr_mr_selected_asset_id', selectedAssetId);
    }
  }, [selectedAssetId]);

  // Sync filters to localStorage to ensure records stay available after page refresh
  useEffect(() => {
    const filterState = {
      filterMachineName,
      filterAssetOrSerial,
      filterType,
      filterTechnician,
      filterDateFrom,
      filterDateTo
    };
    try {
      localStorage.setItem('dmr_mr_filters', JSON.stringify(filterState));
    } catch (e) {}
  }, [filterMachineName, filterAssetOrSerial, filterType, filterTechnician, filterDateFrom, filterDateTo]);

  // 1. Fetch real assets and maintenance records from Supabase
  const fetchData = async () => {
    setIsRefreshing(true);
    setFetchError(null);
    try {
      // Fetch Assets
      const { data: assetData, error: assetErr } = await supabase.from('assets').select('*');
      if (assetErr) throw assetErr;

      let loadedAssets: Asset[] = [];
      if (Array.isArray(assetData) && assetData.length > 0) {
        loadedAssets = assetData.map((a: any) => ({
          id: a.id,
          name: a.name,
          category: a.category || 'General',
          status: a.status || 'Operational',
          location: a.location || 'Workshop',
          criticality: a.criticality || 'Medium',
          department: a.department || 'Production',
          description: a.description || '',
          manufacturer: a.manufacturer || '',
          model: a.model || '',
          serialNumber: a.serial_number || a.serialNumber || '',
          installationDate: a.installation_date || a.installationDate || '',
          nextMaintenanceDate: a.next_maintenance_date || a.nextMaintenanceDate || '',
          photoUrl: a.photo_url || a.photoUrl || a.machine_photo || a.machinePhoto || '',
          customSpecifications: Array.isArray(a.customSpecifications)
            ? a.customSpecifications
            : Array.isArray(a.custom_specifications)
            ? a.custom_specifications
            : []
        }));
      } else {
        // Fallback to localStorage assets if Supabase returns empty
        const savedAssets = localStorage.getItem('dmr_assets_list');
        if (savedAssets) {
          try {
            const parsed = JSON.parse(savedAssets);
            if (Array.isArray(parsed)) loadedAssets = parsed;
          } catch {}
        }
      }
      setAssets(loadedAssets);

      // Determine selected asset: use stored or fallback to first
      const storedAssetId = localStorage.getItem('dmr_mr_selected_asset_id');
      if (storedAssetId && loadedAssets.some(a => a.id === storedAssetId)) {
        setSelectedAssetId(storedAssetId);
      } else if (loadedAssets.length > 0 && !selectedAssetId) {
        setSelectedAssetId(loadedAssets[0].id);
      }

      // Fetch PM Schedules
      const { data: pmData, error: pmErr } = await supabase.from('preventive_maintenance').select('*');
      if (pmErr) throw pmErr;
      if (Array.isArray(pmData)) {
        setRawPms(pmData);
      } else {
        const savedPm = localStorage.getItem('dmr_pm_tasks');
        if (savedPm) {
          try { setRawPms(JSON.parse(savedPm)); } catch {}
        }
      }

      // Fetch Machine Breakdowns
      const { data: brkData, error: brkErr } = await supabase.from('machine_breakdowns').select('*');
      if (brkErr) throw brkErr;
      if (Array.isArray(brkData)) {
        setRawBreakdowns(brkData);
      } else {
        const savedBrk = localStorage.getItem('dmr_machine_breakdowns');
        if (savedBrk) {
          try { setRawBreakdowns(JSON.parse(savedBrk)); } catch {}
        }
      }

      // Fetch Work Orders
      const { data: woData, error: woErr } = await supabase.from('work_orders').select('*');
      if (woErr) throw woErr;
      if (Array.isArray(woData)) {
        setRawWorkOrders(woData);
      } else {
        const savedWo = localStorage.getItem('dmr_work_orders');
        if (savedWo) {
          try { setRawWorkOrders(JSON.parse(savedWo)); } catch {}
        }
      }
    } catch (err: any) {
      console.error('Failed fetching data in MaintenanceRecordsView:', err);
      setFetchError(err?.message || 'Database query failed while retrieving maintenance records.');
      showFeedback('error', 'Error connecting to database. Please click Retry.');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    const runDataSync = async () => {
      await fetchData();
      await healAndSyncAllAssets();
    };

    runDataSync();

    const handleSync = () => {
      runDataSync();
    };

    window.addEventListener('dmr_machine_sync', handleSync);
    window.addEventListener('storage', handleSync);

    return () => {
      window.removeEventListener('dmr_machine_sync', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, []);

  // Selected Asset object
  const selectedAsset = useMemo(() => {
    return assets.find(a => a.id === selectedAssetId) || null;
  }, [assets, selectedAssetId]);

  // Computed current operational status of the selected asset with active breakdown sync
  const currentMachineStatus = useMemo(() => {
    return getEffectiveMachineStatus(selectedAsset, rawBreakdowns);
  }, [selectedAsset, rawBreakdowns]);

  // Filtered Assets for "SELECT MACHINE" Search (supporting Machine Name, Asset ID, Serial Number, Location, Department)
  const filteredAssets = useMemo(() => {
    if (!assetSearchQuery.trim()) return assets;
    const query = assetSearchQuery.toLowerCase().trim();
    return assets.filter(a => 
      (a.id || '').toLowerCase().includes(query) ||
      (a.name || '').toLowerCase().includes(query) ||
      (a.serialNumber || '').toLowerCase().includes(query) ||
      (a.location || '').toLowerCase().includes(query) ||
      (a.department || '').toLowerCase().includes(query)
    );
  }, [assets, assetSearchQuery]);

  // Unified Maintenance Records for selected Asset (Strictly linked by asset_id)
  const unifiedRecords = useMemo(() => {
    if (!selectedAssetId) return [];

    const targetId = selectedAssetId.trim().toLowerCase();
    const result: UnifiedMaintenanceRecord[] = [];
    const seenRecordKeys = new Set<string>();

    // 1. Process PM Schedules for this asset
    for (const pm of rawPms) {
      const pmAssetId = String(pm.asset_id || pm.assetId || pm.asset || '').trim().toLowerCase();
      if (pmAssetId === targetId) {
        const recId = String(pm.id || `PM-${pm.scheduled_date || Date.now()}`);
        const dateStr = pm.scheduled_date || pm.startDate || pm.created_at || '';
        
        let checklistArr: any[] = [];
        if (Array.isArray(pm.checklist)) checklistArr = pm.checklist;
        else if (Array.isArray(pm.safety_requirements)) {
          checklistArr = pm.safety_requirements.map((s: string) => ({ task: s, status: 'OK', remarks: 'Standard' }));
        }

        const taskDesc = pm.maintenance_task || pm.task_description || pm.description || 'Scheduled preventive maintenance service';

        result.push({
          id: recId,
          recordType: 'Preventive Maintenance',
          assetId: selectedAssetId,
          assetName: selectedAsset?.name || pm.machine_name || selectedAssetId,
          serialNumber: selectedAsset?.serialNumber || pm.serial_number || '',
          date: dateStr,
          time: pm.scheduled_time || '',
          workOrderId: pm.linked_work_order_id || pm.id,
          technician: pm.assigned_technician || pm.technician || 'Assigned Technician',
          technicianId: pm.technician_id || '',
          status: pm.status || 'Completed',
          maintenanceDescription: taskDesc,
          findings: pm.findings || pm.inspection_findings || pm.remarks || (pm.status === 'Completed' ? 'Inspection completed without anomalies.' : 'Scheduled preventive service.'),
          actionTaken: pm.action_taken || pm.actions_taken || taskDesc || 'Preventive servicing and inspection routine executed.',
          partsUsed: pm.materials_used || pm.parts_replaced || 'None required',
          downtimeHours: Number(pm.downtime_hours || pm.estimated_duration || 0),
          verificationStatus: pm.status === 'Completed' ? 'Verified' : (pm.status || 'Pending'),
          supervisor: pm.supervisor || 'Maintenance Supervisor',
          verificationDate: pm.verification_date || (pm.status === 'Completed' ? dateStr : undefined),
          supervisorRemarks: pm.supervisor_remarks || 'Maintenance verified according to standard operational checklist.',
          checklist: checklistArr,
          measurements: Array.isArray(pm.measurements) ? pm.measurements : undefined,
          tools: Array.isArray(pm.tools) ? pm.tools : undefined,
          photos: pm.photo_url ? [pm.photo_url] : [],
          documents: [],
          sourceCollection: 'preventive_maintenance',
          rawRecord: pm
        });
        seenRecordKeys.add(recId);
      }
    }

    // 2. Process Machine Breakdowns for this asset
    for (const brk of rawBreakdowns) {
      const brkAssetId = String(brk.asset_id || brk.assetId || '').trim().toLowerCase();
      if (brkAssetId === targetId) {
        const recId = String(brk.breakdown_id || brk.id || `BRK-${Date.now()}`);
        if (!seenRecordKeys.has(recId)) {
          const dateStr = brk.reported_date || brk.created_at || brk.downtime_start || '';
          const issueDesc = brk.problem_description || brk.issue || 'Machine breakdown repair';

          result.push({
            id: recId,
            recordType: brk.breakdown_category === 'Mechanical' ? 'Breakdown Repair' : 'Corrective Maintenance',
            assetId: selectedAssetId,
            assetName: selectedAsset?.name || brk.machine_name || selectedAssetId,
            serialNumber: selectedAsset?.serialNumber || brk.serial_number || '',
            date: dateStr,
            time: brk.reported_time || '',
            workOrderId: brk.linked_work_order_id || recId,
            technician: brk.technician_name || brk.assigned_to_name || 'Maintenance Specialist',
            technicianId: brk.technician_id || '',
            status: brk.status || 'Reported',
            maintenanceDescription: issueDesc,
            findings: brk.problem_description || brk.issue || 'Breakdown reported on operational unit.',
            actionTaken: brk.immediate_action || brk.action_taken || 'Diagnosed and restored machine functionality.',
            partsUsed: brk.parts_replaced || brk.materials_used || 'None recorded',
            downtimeHours: Number(brk.total_downtime || brk.downtime_hours || 0),
            verificationStatus: brk.status === 'Completed' || brk.status === 'Closed' ? 'Verified' : (brk.status || 'In Progress'),
            supervisor: brk.reported_by || 'Plant Supervisor',
            verificationDate: brk.updated_at || (brk.status === 'Completed' ? dateStr : undefined),
            supervisorRemarks: brk.remarks || 'Breakdown rectified and machine tested operational.',
            photos: brk.photo_url ? [brk.photo_url] : [],
            documents: [],
            sourceCollection: 'machine_breakdowns',
            rawRecord: brk
          });
          seenRecordKeys.add(recId);
        }
      }
    }

    // 3. Process Work Orders for this asset
    for (const wo of rawWorkOrders) {
      const woAssetId = String(wo.asset_id || wo.assetId || '').trim().toLowerCase();
      if (woAssetId === targetId) {
        const recId = String(wo.id || `WO-${wo.timestamp}`);
        if (!seenRecordKeys.has(recId)) {
          const dateStr = wo.timestamp || wo.completedTime || '';
          const woDesc = wo.issue || wo.description || 'Corrective maintenance work order';

          result.push({
            id: recId,
            recordType: wo.category ? (wo.category.includes('Mechanical') ? 'Corrective Maintenance' : 'General') : 'Corrective Maintenance',
            assetId: selectedAssetId,
            assetName: selectedAsset?.name || wo.assetName || selectedAssetId,
            serialNumber: selectedAsset?.serialNumber || wo.serial_number || '',
            date: dateStr,
            workOrderId: wo.id,
            technician: wo.assigned_to_name || wo.assignedToName || 'Assigned Technician',
            technicianId: wo.assigned_to_id || wo.assignedToId || '',
            status: wo.status || 'Completed',
            maintenanceDescription: woDesc,
            findings: wo.issue || 'Work order logged for maintenance service.',
            actionTaken: wo.actions_taken || wo.actionsTaken || 'Maintenance work performed as dispatched.',
            partsUsed: wo.materials_used || wo.materialsUsed || 'None recorded',
            downtimeHours: Number(wo.downtime_hours || wo.downtimeHours || 0),
            verificationStatus: wo.status === 'Completed' ? 'Verified' : (wo.status || 'Pending'),
            supervisor: wo.logged_by || wo.loggedBy || 'Management',
            verificationDate: wo.completed_time || wo.completedTime || undefined,
            supervisorRemarks: 'Work order executed and completed per standard specifications.',
            checklist: Array.isArray(wo.checklist) ? wo.checklist.map((c: any) => ({
              task: typeof c === 'string' ? c : c.task || c.item,
              status: c.completed ? 'OK' : 'In Progress',
              remarks: 'Task verified'
            })) : undefined,
            photos: [],
            documents: [],
            sourceCollection: 'work_orders',
            rawRecord: wo
          });
          seenRecordKeys.add(recId);
        }
      }
    }

    // Sort records: Newest → Oldest
    result.sort((a, b) => {
      const dateA = new Date(a.date).getTime() || 0;
      const dateB = new Date(b.date).getTime() || 0;
      return dateB - dateA;
    });

    return result;
  }, [selectedAssetId, selectedAsset, rawPms, rawBreakdowns, rawWorkOrders]);

  // Combined Multi-Filter Engine for Data Retrieval
  const filteredRecords = useMemo(() => {
    return unifiedRecords.filter(record => {
      // 1. Filter by Machine Name
      if (filterMachineName.trim()) {
        const q = filterMachineName.toLowerCase().trim();
        const matchName = (record.assetName || '').toLowerCase().includes(q);
        if (!matchName) return false;
      }

      // 2. Filter by Asset ID or Serial Number
      if (filterAssetOrSerial.trim()) {
        const q = filterAssetOrSerial.toLowerCase().trim();
        const matchAssetId = (record.assetId || '').toLowerCase().includes(q);
        const matchSerial = (record.serialNumber || selectedAsset?.serialNumber || '').toLowerCase().includes(q);
        if (!matchAssetId && !matchSerial) return false;
      }

      // 3. Filter by Maintenance Type (Preventive Maintenance [PM] or Corrective Maintenance [CM])
      if (filterType === 'PM') {
        const isPm = record.recordType === 'Preventive Maintenance' || record.recordType.toLowerCase().includes('preventive');
        if (!isPm) return false;
      } else if (filterType === 'CM') {
        const isCm = record.recordType === 'Corrective Maintenance' || 
                     record.recordType === 'Breakdown Repair' || 
                     record.recordType.toLowerCase().includes('corrective') || 
                     record.recordType.toLowerCase().includes('breakdown');
        if (!isCm) return false;
      }

      // 4. Filter by Technician Name
      if (filterTechnician.trim()) {
        const q = filterTechnician.toLowerCase().trim();
        const matchTech = (record.technician || '').toLowerCase().includes(q);
        if (!matchTech) return false;
      }

      // 5. Filter by Date Range: Date From
      if (filterDateFrom) {
        const recordDateStr = record.date ? record.date.slice(0, 10) : '';
        if (recordDateStr && recordDateStr < filterDateFrom) return false;
      }

      // 6. Filter by Date Range: Date To
      if (filterDateTo) {
        const recordDateStr = record.date ? record.date.slice(0, 10) : '';
        if (recordDateStr && recordDateStr > filterDateTo) return false;
      }

      return true;
    });
  }, [unifiedRecords, filterMachineName, filterAssetOrSerial, filterType, filterTechnician, filterDateFrom, filterDateTo, selectedAsset]);

  // Check if any filter is actively applied
  const isFilterActive = useMemo(() => {
    return Boolean(
      filterMachineName.trim() ||
      filterAssetOrSerial.trim() ||
      filterType !== 'all' ||
      filterTechnician.trim() ||
      filterDateFrom ||
      filterDateTo
    );
  }, [filterMachineName, filterAssetOrSerial, filterType, filterTechnician, filterDateFrom, filterDateTo]);

  // Reset Filters / Clear Search to restore default view
  const handleResetFilters = () => {
    setFilterMachineName('');
    setFilterAssetOrSerial('');
    setFilterType('all');
    setFilterTechnician('');
    setFilterDateFrom('');
    setFilterDateTo('');
    try {
      localStorage.removeItem('dmr_mr_filters');
    } catch {}
    showFeedback('info', 'Filters reset. Restored default maintenance record view.');
  };

  // Maintenance Summary calculations
  const summary = useMemo(() => {
    const totalRecords = filteredRecords.length;
    const latestRecord = filteredRecords[0] || null;

    let totalDowntimeHours = 0;
    let numberOfBreakdowns = 0;

    for (const r of filteredRecords) {
      if (r.downtimeHours) {
        totalDowntimeHours += r.downtimeHours;
      }
      if (r.recordType === 'Breakdown Repair' || r.recordType === 'Corrective Maintenance') {
        numberOfBreakdowns++;
      }
    }

    // Find next PM date for this asset
    let nextPmDate = selectedAsset?.nextMaintenanceDate || '';
    if (!nextPmDate) {
      const upcomingPm = rawPms.find(p => {
        const pAssetId = String(p.asset_id || p.assetId || '').trim().toLowerCase();
        return pAssetId === (selectedAssetId || '').toLowerCase() && p.status !== 'Completed';
      });
      if (upcomingPm) {
        nextPmDate = upcomingPm.scheduled_date || upcomingPm.next_due_date || '';
      }
    }

    return {
      totalRecords,
      lastMaintenanceDate: latestRecord && latestRecord.date ? latestRecord.date.split('T')[0] : 'N/A',
      lastMaintenanceType: latestRecord ? latestRecord.recordType : 'N/A',
      totalDowntimeHours,
      numberOfBreakdowns,
      nextPmDate: nextPmDate ? nextPmDate.split('T')[0] : 'N/A'
    };
  }, [filteredRecords, selectedAsset, rawPms, selectedAssetId]);

  // PDF Export handler
  const handleExportPdf = async () => {
    if (!selectedAsset) return;
    try {
      await generateMachineHistoryPDF({
        asset: selectedAsset,
        records: filteredRecords.map(r => ({
          id: r.id,
          date: r.date,
          recordType: r.recordType,
          workOrderId: r.workOrderId,
          technician: r.technician,
          findings: r.findings,
          actionTaken: r.actionTaken,
          partsUsed: r.partsUsed,
          downtimeHours: r.downtimeHours,
          verificationStatus: r.verificationStatus,
          supervisor: r.supervisor,
          verificationDate: r.verificationDate
        })),
        summary
      });
      showFeedback('success', `Exported maintenance history for ${selectedAsset.name} (${selectedAsset.id})`);
    } catch (err) {
      console.error('Error generating PDF:', err);
      showFeedback('error', 'Failed generating PDF document.');
    }
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* ========================================================================= */}
      {/* 1. TOP BANNER HEADER */}
      {/* ========================================================================= */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-6 backdrop-blur-md shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2.5 mb-1.5">
              <div className="p-2 bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 rounded-lg shadow-xs">
                <History className="w-5 h-5" />
              </div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white font-display">
                Maintenance Records
              </h1>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-cyan-950/80 text-cyan-400 border border-cyan-800/80">
                <Lock className="w-3 h-3 text-cyan-400" />
                Read-Only Module
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
              Complete historical service logs, breakdown interventions, and verification audit trail for registered machinery with database data retrieval.
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
            <button
              onClick={() => setIsReportModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-semibold text-xs rounded-lg transition-all shadow-md shadow-cyan-600/25 cursor-pointer"
              title="Open Machine Maintenance Report Generator"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Generate Machine Report</span>
            </button>

            <button
              onClick={fetchData}
              disabled={isRefreshing}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold rounded-lg transition-all cursor-pointer shadow-xs disabled:opacity-50"
              title="Refresh records from Supabase"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-cyan-400' : ''}`} />
              <span>{isRefreshing ? 'Refreshing...' : 'Refresh'}</span>
            </button>

            {canExport && selectedAsset && (
              <button
                onClick={handleExportPdf}
                disabled={filteredRecords.length === 0}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs rounded-lg transition-all shadow-md shadow-cyan-600/20 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                title="Export Machine Maintenance History to PDF"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export PDF</span>
              </button>
            )}
          </div>
        </div>

        {feedback && (
          <div className={`mt-3 p-2.5 rounded-lg border text-xs flex items-center gap-2 animate-in fade-in ${
            feedback.type === 'success' ? 'bg-cyan-950/70 border-cyan-800/80 text-cyan-200' :
            feedback.type === 'error' ? 'bg-rose-950/80 border-rose-800 text-rose-200' :
            'bg-slate-800 border-slate-700 text-slate-200'
          }`}>
            {feedback.type === 'success' && <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />}
            {feedback.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />}
            {feedback.type === 'info' && <Check className="w-4 h-4 text-slate-400 shrink-0" />}
            <span>{feedback.text}</span>
          </div>
        )}
      </div>

      {/* Database Error Alert Banner */}
      {fetchError && (
        <div className="p-4 bg-rose-950/80 border border-rose-800/80 rounded-xl text-rose-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            <div>
              <p className="font-bold text-white">Database Query Failure</p>
              <p className="text-rose-300 text-[11px] mt-0.5">{fetchError}</p>
            </div>
          </div>
          <button
            onClick={fetchData}
            className="px-3.5 py-1.5 bg-rose-800 hover:bg-rose-700 text-white font-semibold rounded-lg text-xs transition-colors cursor-pointer self-start sm:self-auto shrink-0 flex items-center gap-1.5"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Retry Query</span>
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. MACHINE SELECTION & DATA RETRIEVAL SEARCH */}
      {/* ========================================================================= */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-md backdrop-blur-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              SELECT REGISTERED MACHINE
            </label>
            <p className="text-xs text-slate-500 mt-0.5">
              Select or search by machine name, asset ID, or serial number to retrieve maintenance history
            </p>
          </div>

          <div className="relative w-full sm:w-80">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by Machine Name, Asset ID, Serial No..."
              value={assetSearchQuery}
              onChange={(e) => setAssetSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700/80 text-slate-200 placeholder-slate-500 pl-8 pr-8 py-1.5 text-xs rounded-lg focus:outline-none focus:border-cyan-500 font-sans"
            />
            {assetSearchQuery && (
              <button
                onClick={() => setAssetSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 text-xs"
                title="Clear machine search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Searchable Assets Pill Selection Strip */}
        <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto pr-1">
          {filteredAssets.length > 0 ? (
            filteredAssets.map(asset => {
              const isSelected = asset.id === selectedAssetId;
              const isAssetInBreakdown = getEffectiveMachineStatus(asset, rawBreakdowns) === 'Breakdown';

              return (
                <button
                  key={asset.id}
                  onClick={() => setSelectedAssetId(asset.id)}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-left text-xs transition-all cursor-pointer border ${
                    isSelected
                      ? 'bg-cyan-950/80 border-cyan-500 text-white ring-1 ring-cyan-500/50 shadow-md shadow-cyan-950/50'
                      : isAssetInBreakdown
                      ? 'bg-rose-950/40 border-rose-900/60 text-slate-200 hover:bg-rose-900/30'
                      : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800/60 hover:border-slate-700 hover:text-white'
                  }`}
                >
                  <span className={`font-mono font-bold px-1.5 py-0.5 rounded text-[11px] ${
                    isSelected ? 'bg-cyan-500 text-slate-950' : isAssetInBreakdown ? 'bg-rose-900/80 text-rose-300' : 'bg-slate-800 text-cyan-400'
                  }`}>
                    {asset.id}
                  </span>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold block truncate max-w-[140px] sm:max-w-[180px]">
                        {asset.name}
                      </span>
                      {isAssetInBreakdown && (
                        <span className="text-[9px] px-1 py-0.2 rounded font-extrabold bg-rose-600 text-white shrink-0">
                          🔴
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-slate-400 block truncate flex items-center gap-1">
                      <span>{asset.location || 'General Area'}</span>
                      {asset.serialNumber && (
                        <>
                          <span>•</span>
                          <span className="font-mono text-slate-500">SN: {asset.serialNumber}</span>
                        </>
                      )}
                    </div>
                  </div>
                  {isSelected && (
                    <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0 ml-1" />
                  )}
                </button>
              );
            })
          ) : (
            <div className="py-3 px-4 text-xs text-slate-500 w-full text-center bg-slate-950/40 rounded-lg border border-dashed border-slate-800">
              No registered machines match "{assetSearchQuery}".
            </div>
          )}
        </div>
      </div>

      {/* Loading Indicator while retrieving data */}
      {isLoading && (
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-8 text-center animate-pulse">
          <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-200">Retrieving Maintenance Records...</h3>
          <p className="text-xs text-slate-500 mt-1">
            Querying actual maintenance logs from the database for registered machines.
          </p>
        </div>
      )}

      {/* If no machine is selected */}
      {!isLoading && !selectedAsset && (
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-8 text-center space-y-3">
          <Wrench className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-sm font-bold text-slate-300">No Machine Selected</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Please select a registered machine from the list above, or open the Report Generator to select a machine and generate technical documentation.
          </p>
          <button
            onClick={() => setIsReportModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-semibold text-xs rounded-lg transition-all shadow-md shadow-cyan-600/25 cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            <span>Generate Machine Report</span>
          </button>
        </div>
      )}

      {!isLoading && selectedAsset && (
        <>
          {/* ========================================================================= */}
          {/* 3. MACHINE CARD (Requirement 3) */}
          {/* ========================================================================= */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg backdrop-blur-md">
            <div className="flex flex-col md:flex-row gap-5">
              {/* Machine Image */}
              <div className="w-full md:w-56 h-44 sm:h-48 rounded-xl overflow-hidden bg-slate-950 border border-slate-800 shrink-0 relative flex items-center justify-center group">
                {selectedAsset.photoUrl || selectedAsset.machine_photo ? (
                  <img 
                    src={selectedAsset.photoUrl || selectedAsset.machine_photo} 
                    alt={selectedAsset.name} 
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-slate-600 p-4 text-center">
                    <Wrench className="w-10 h-10 mb-2 opacity-50 text-cyan-500" />
                    <span className="text-[11px] font-medium text-slate-500">No Image Uploaded</span>
                  </div>
                )}
                <div className="absolute top-2 left-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-black/70 backdrop-blur-xs text-cyan-400 border border-cyan-500/30">
                    {selectedAsset.id}
                  </span>
                </div>
              </div>

              {/* Machine Specs & Parameters */}
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <div>
                    <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight font-display">
                      {selectedAsset.name}
                    </h2>
                    <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-2">
                      <span className="flex items-center gap-1"><MapPin className="w-3 h-3 text-cyan-400" /> {selectedAsset.location || 'N/A'}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1"><Building className="w-3 h-3 text-indigo-400" /> {selectedAsset.department || 'N/A'}</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Status Pill */}
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border shadow-xs transition-colors ${
                      currentMachineStatus === 'Operational'
                        ? 'bg-emerald-950/80 text-emerald-400 border-emerald-800'
                        : currentMachineStatus === 'Under Maintenance'
                        ? 'bg-amber-950/80 text-amber-400 border-amber-800'
                        : currentMachineStatus === 'Breakdown' || currentMachineStatus === 'Faulty'
                        ? 'bg-rose-950/80 text-rose-300 border-rose-800 animate-pulse'
                        : currentMachineStatus === 'Decommissioned'
                        ? 'bg-slate-800 text-slate-400 border-slate-700'
                        : 'bg-slate-800 text-slate-300 border-slate-700'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                        currentMachineStatus === 'Operational' ? 'bg-emerald-400 animate-pulse' :
                        currentMachineStatus === 'Under Maintenance' ? 'bg-amber-400' :
                        currentMachineStatus === 'Breakdown' || currentMachineStatus === 'Faulty' ? 'bg-rose-400 animate-ping' :
                        'bg-slate-500'
                      }`} />
                      {currentMachineStatus === 'Breakdown' ? '🔴 BREAKDOWN' : currentMachineStatus === 'Decommissioned' ? 'Scrapped' : currentMachineStatus}
                    </span>

                    {/* Criticality */}
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
                      selectedAsset.criticality === 'Critical'
                        ? 'bg-rose-950/60 text-rose-300 border-rose-800'
                        : selectedAsset.criticality === 'High'
                        ? 'bg-amber-950/60 text-amber-300 border-amber-800'
                        : 'bg-slate-800 text-slate-300 border-slate-700'
                    }`}>
                      {selectedAsset.criticality || 'Medium'} Priority
                    </span>

                    {/* Quick Report Button */}
                    <button
                      onClick={() => setIsReportModalOpen(true)}
                      className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-cyan-950/80 text-cyan-300 border border-slate-700 hover:border-cyan-700 rounded-lg text-xs font-semibold transition-all cursor-pointer shadow-xs ml-auto"
                      title="Generate Machine Maintenance Report for this asset"
                    >
                      <FileText className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Generate Machine Report</span>
                    </button>
                  </div>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3 py-3 border-y border-slate-800/80 my-2 text-xs">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Machine Type</span>
                    <span className="font-semibold text-slate-200 truncate block">
                      {selectedAsset.machineType || selectedAsset.category || 'General'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Manufacturer</span>
                    <span className="font-semibold text-slate-200 truncate block">
                      {selectedAsset.manufacturer || 'N/A'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Model</span>
                    <span className="font-semibold text-slate-200 truncate block">
                      {selectedAsset.model || 'N/A'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Serial Number</span>
                    <span className="font-semibold text-slate-200 font-mono truncate block">
                      {selectedAsset.serialNumber || 'N/A'}
                    </span>
                  </div>
                </div>

                {/* Custom Specifications */}
                {selectedAsset.customSpecifications && selectedAsset.customSpecifications.length > 0 && (
                  <div className="mt-2.5">
                    <span className="text-[10px] font-bold uppercase text-slate-500 tracking-wider block mb-1.5 flex items-center gap-1">
                      <Tag className="w-3 h-3 text-cyan-400" />
                      Custom Machine Specifications
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {selectedAsset.customSpecifications.map((spec, i) => (
                        <div 
                          key={i} 
                          className="px-2.5 py-1 bg-slate-950/80 border border-slate-800 rounded-md text-[11px] flex items-center gap-1.5 shadow-xs"
                        >
                          <span className="text-slate-400 font-medium">{spec.name}:</span>
                          <span className="font-bold text-cyan-300 font-mono">{spec.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* ========================================================================= */}
          {/* 4. MAINTENANCE SUMMARY CARDS */}
          {/* ========================================================================= */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {/* Total Records */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 shadow-sm">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Total Records</span>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-2xl font-bold text-white font-display">{summary.totalRecords}</span>
                <span className="text-[11px] text-slate-400">logs</span>
              </div>
              <span className="text-[10px] text-cyan-400 font-medium mt-1 block">
                {isFilterActive ? 'Filtered results' : 'Total in database'}
              </span>
            </div>

            {/* Last Maintenance */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 shadow-sm">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Last Service</span>
              <div className="mt-1">
                <span className="text-base sm:text-lg font-bold text-white font-display truncate block">
                  {summary.lastMaintenanceDate}
                </span>
              </div>
              <span className="text-[10px] text-slate-400 font-medium mt-1 block truncate">Date recorded</span>
            </div>

            {/* Last Maintenance Type */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 shadow-sm">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Last Service Type</span>
              <div className="mt-1">
                <span className="text-xs sm:text-sm font-bold text-cyan-300 truncate block" title={summary.lastMaintenanceType}>
                  {summary.lastMaintenanceType}
                </span>
              </div>
              <span className="text-[10px] text-slate-400 font-medium mt-1 block">Activity category</span>
            </div>

            {/* Total Downtime */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 shadow-sm">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Total Downtime</span>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-2xl font-bold text-amber-400 font-display">
                  {summary.totalDowntimeHours.toFixed(1)}
                </span>
                <span className="text-[11px] text-slate-400">hrs</span>
              </div>
              <span className="text-[10px] text-slate-400 font-medium mt-1 block">Accumulated</span>
            </div>

            {/* Breakdowns */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 shadow-sm">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Breakdowns</span>
              <div className="flex items-baseline gap-1 mt-1">
                <span className={`text-2xl font-bold font-display ${summary.numberOfBreakdowns > 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                  {summary.numberOfBreakdowns}
                </span>
                <span className="text-[11px] text-slate-400">events</span>
              </div>
              <span className="text-[10px] text-slate-400 font-medium mt-1 block">Failure reports</span>
            </div>

            {/* Next PM Date */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 shadow-sm">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Next PM Due</span>
              <div className="mt-1">
                <span className="text-base sm:text-lg font-bold text-emerald-400 font-display truncate block">
                  {summary.nextPmDate}
                </span>
              </div>
              <span className="text-[10px] text-slate-400 font-medium mt-1 block truncate">Preventive plan</span>
            </div>
          </div>

          {/* ========================================================================= */}
          {/* 5. DATA RETRIEVAL & RECORD FILTERS PANEL (Task 1 & 2) */}
          {/* ========================================================================= */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg backdrop-blur-md space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 rounded-md">
                  <SlidersHorizontal className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider font-display flex items-center gap-2">
                    Data Retrieval & Filter Options
                    {isFilterActive && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-950 text-cyan-400 border border-cyan-800">
                        Filters Active
                      </span>
                    )}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Filter retrieved records by machine, serial number, PM/CM type, technician, or date range
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Result count indicator */}
                <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-300">
                  <span className="text-cyan-400 font-bold">{filteredRecords.length}</span> of {unifiedRecords.length} records matching
                </span>

                {/* Reset Filters Button */}
                {isFilterActive && (
                  <button
                    onClick={handleResetFilters}
                    className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-lg text-xs font-semibold border border-slate-700 transition-all cursor-pointer shadow-xs"
                    title="Clear search and restore default view"
                  >
                    <RotateCcw className="w-3 h-3 text-cyan-400" />
                    <span>Reset Filters</span>
                  </button>
                )}
              </div>
            </div>

            {/* Filter Inputs Grid (6 Filters) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
              {/* Filter 1: Machine Name */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Machine Name
                </label>
                <div className="relative">
                  <Wrench className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    placeholder="e.g. Lathe, Milling..."
                    value={filterMachineName}
                    onChange={(e) => setFilterMachineName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 placeholder-slate-600 pl-8 pr-2.5 py-1.5 text-xs rounded-lg focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              {/* Filter 2: Asset ID or Serial Number */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Asset ID / Serial No
                </label>
                <div className="relative">
                  <Hash className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    placeholder="e.g. LATHE-01 or SN-88..."
                    value={filterAssetOrSerial}
                    onChange={(e) => setFilterAssetOrSerial(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 placeholder-slate-600 pl-8 pr-2.5 py-1.5 text-xs rounded-lg focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
              </div>

              {/* Filter 3: Maintenance Type (PM / CM / All) */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Maintenance Type
                </label>
                <div className="relative">
                  <Filter className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <select
                    value={filterType}
                    onChange={(e) => setFilterType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 pl-8 pr-7 py-1.5 text-xs rounded-lg focus:outline-none focus:border-cyan-500 cursor-pointer appearance-none"
                  >
                    <option value="all">All Types (PM & CM)</option>
                    <option value="PM">Preventive Maintenance (PM)</option>
                    <option value="CM">Corrective Maintenance (CM)</option>
                  </select>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>

              {/* Filter 4: Technician Name */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Technician Name
                </label>
                <div className="relative">
                  <UserCheck className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    placeholder="e.g. Ahmad, Raju..."
                    value={filterTechnician}
                    onChange={(e) => setFilterTechnician(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 placeholder-slate-600 pl-8 pr-2.5 py-1.5 text-xs rounded-lg focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              {/* Filter 5: Date From */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Date From
                </label>
                <div className="relative">
                  <Calendar className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="date"
                    value={filterDateFrom}
                    onChange={(e) => setFilterDateFrom(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 pl-8 pr-2.5 py-1.5 text-xs rounded-lg focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              {/* Filter 6: Date To */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Date To
                </label>
                <div className="relative">
                  <Calendar className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="date"
                    value={filterDateTo}
                    onChange={(e) => setFilterDateTo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 pl-8 pr-2.5 py-1.5 text-xs rounded-lg focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>
            </div>

            {/* Quick Filter Shortcuts & Active Chips */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/80 text-[11px]">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-slate-500 font-semibold text-[10px] uppercase mr-1">Quick Date Range:</span>
                <button
                  type="button"
                  onClick={() => {
                    const now = new Date();
                    const past7 = new Date();
                    past7.setDate(now.getDate() - 7);
                    setFilterDateFrom(past7.toISOString().slice(0, 10));
                    setFilterDateTo(now.toISOString().slice(0, 10));
                  }}
                  className="px-2 py-0.5 rounded bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-cyan-300 border border-slate-800 transition-colors cursor-pointer text-[10px]"
                >
                  Past 7 Days
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const now = new Date();
                    const past30 = new Date();
                    past30.setDate(now.getDate() - 30);
                    setFilterDateFrom(past30.toISOString().slice(0, 10));
                    setFilterDateTo(now.toISOString().slice(0, 10));
                  }}
                  className="px-2 py-0.5 rounded bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-cyan-300 border border-slate-800 transition-colors cursor-pointer text-[10px]"
                >
                  Past 30 Days
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const now = new Date();
                    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
                    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
                    setFilterDateFrom(firstDay.toISOString().slice(0, 10));
                    setFilterDateTo(lastDay.toISOString().slice(0, 10));
                  }}
                  className="px-2 py-0.5 rounded bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-cyan-300 border border-slate-800 transition-colors cursor-pointer text-[10px]"
                >
                  This Month
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setFilterDateFrom('');
                    setFilterDateTo('');
                  }}
                  className="px-2 py-0.5 rounded bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 transition-colors cursor-pointer text-[10px]"
                >
                  All Dates
                </button>
              </div>

              {isFilterActive && (
                <button
                  type="button"
                  onClick={handleResetFilters}
                  className="text-cyan-400 hover:text-cyan-300 underline font-semibold flex items-center gap-1 cursor-pointer text-[11px]"
                >
                  <X className="w-3 h-3" />
                  Clear All Filters
                </button>
              )}
            </div>
          </div>

          {/* ========================================================================= */}
          {/* 6. RETRIEVED MAINTENANCE RECORDS LIST (Table & Timeline Views) */}
          {/* ========================================================================= */}
          {unifiedRecords.length === 0 ? (
            /* Machine has zero records in database */
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-10 sm:p-12 text-center backdrop-blur-md shadow-md">
              <div className="w-14 h-14 bg-slate-800/80 border border-slate-700 rounded-2xl flex items-center justify-center text-slate-400 mx-auto mb-4">
                <FileText className="w-7 h-7 text-cyan-400/80" />
              </div>
              <h3 className="text-base sm:text-lg font-bold text-slate-200">
                No maintenance history available.
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 mt-1.5 max-w-md mx-auto leading-relaxed">
                Maintenance records will appear here after maintenance activities are completed.
              </p>
            </div>
          ) : filteredRecords.length === 0 ? (
            /* Records exist in database, but current search / filter returned 0 matches */
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-10 sm:p-12 text-center backdrop-blur-md shadow-md">
              <div className="w-14 h-14 bg-slate-800/80 border border-slate-700 rounded-2xl flex items-center justify-center text-amber-400 mx-auto mb-4">
                <Search className="w-7 h-7" />
              </div>
              <h3 className="text-base sm:text-lg font-bold text-slate-200">
                No records match your search criteria.
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 mt-1.5 max-w-md mx-auto leading-relaxed">
                No maintenance records for {selectedAsset.name} ({selectedAsset.id}) match the selected filters. Try widening your date range, technician name, or maintenance type filters.
              </p>
              <div className="mt-4">
                <button
                  onClick={handleResetFilters}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs rounded-lg transition-all shadow-md cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Filters & Show All Records</span>
                </button>
              </div>
            </div>
          ) : viewMode === 'table' ? (
            /* ===================================================================== */
            /* TABLE VIEW (Responsive Desktop Table / Mobile Cards) */
            /* ===================================================================== */
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-lg backdrop-blur-md">
              <div className="p-3.5 sm:p-4 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                    Retrieved Maintenance Records
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-cyan-400">
                    {filteredRecords.length} {filteredRecords.length === 1 ? 'record' : 'records'}
                  </span>
                  {isFilterActive && (
                    <span className="hidden sm:inline-block text-[11px] text-amber-400/90">
                      (Filtered from {unifiedRecords.length} total)
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 sm:gap-3">
                  {/* View Mode Toggle */}
                  <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
                    <button
                      onClick={() => setViewMode('table')}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                        viewMode === 'table'
                          ? 'bg-cyan-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Table</span>
                    </button>
                    <button
                      onClick={() => setViewMode('timeline')}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                        viewMode === 'timeline'
                          ? 'bg-cyan-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Layers className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Timeline</span>
                    </button>
                  </div>
                  <span className="text-[11px] text-slate-500 hidden sm:inline">
                    Sorted Newest → Oldest
                  </span>
                </div>
              </div>

              {/* Desktop & Tablet Table (Hidden on Mobile) */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950/80 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-3">Maintenance Date</th>
                      <th className="py-3 px-3">Machine & Asset / Serial</th>
                      <th className="py-3 px-3">Maintenance Type</th>
                      <th className="py-3 px-3">Work Order ID</th>
                      <th className="py-3 px-3">Technician</th>
                      <th className="py-3 px-3">Description & Findings</th>
                      <th className="py-3 px-3">Action Taken</th>
                      <th className="py-3 px-3 text-center">Downtime</th>
                      <th className="py-3 px-3 text-center">Status</th>
                      <th className="py-3 px-3 text-right">Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {filteredRecords.map((record) => (
                      <tr 
                        key={record.id}
                        onClick={() => setViewingRecord(record)}
                        className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                      >
                        {/* Maintenance Date */}
                        <td className="py-3 px-3 text-slate-200 whitespace-nowrap font-medium">
                          <div className="flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                            <span>{record.date ? record.date.split('T')[0] : 'N/A'}</span>
                          </div>
                          {record.time && (
                            <span className="text-[10px] font-mono text-slate-500 block pl-5">{record.time}</span>
                          )}
                        </td>

                        {/* Machine Name & Asset ID / Serial */}
                        <td className="py-3 px-3">
                          <span className="font-bold text-white block truncate max-w-[160px]">
                            {record.assetName}
                          </span>
                          <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-mono mt-0.5">
                            <span className="text-cyan-400">{record.assetId}</span>
                            {record.serialNumber && (
                              <>
                                <span>•</span>
                                <span className="text-slate-500">SN: {record.serialNumber}</span>
                              </>
                            )}
                          </div>
                        </td>

                        {/* Maintenance Type */}
                        <td className="py-3 px-3 whitespace-nowrap">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border ${
                            record.recordType === 'Preventive Maintenance'
                              ? 'bg-indigo-950/70 text-indigo-400 border-indigo-800/80'
                              : record.recordType === 'Breakdown Repair'
                              ? 'bg-rose-950/70 text-rose-400 border-rose-800/80'
                              : 'bg-amber-950/70 text-amber-400 border-amber-800/80'
                          }`}>
                            {record.recordType}
                          </span>
                        </td>

                        {/* Work Order ID */}
                        <td className="py-3 px-3 font-mono text-slate-300 whitespace-nowrap">
                          {record.workOrderId || record.id}
                        </td>

                        {/* Technician Name */}
                        <td className="py-3 px-3 text-slate-200 whitespace-nowrap font-medium">
                          {record.technician || 'Unassigned'}
                        </td>

                        {/* Maintenance Description & Findings */}
                        <td className="py-3 px-3 text-slate-300 max-w-[200px]" title={record.findings}>
                          <span className="font-semibold text-white block truncate">
                            {record.maintenanceDescription || record.findings}
                          </span>
                          <span className="text-[10px] text-slate-400 block truncate">
                            {record.findings}
                          </span>
                        </td>

                        {/* Action Taken */}
                        <td className="py-3 px-3 text-slate-400 max-w-[180px] truncate" title={record.actionTaken}>
                          {record.actionTaken}
                        </td>

                        {/* Downtime */}
                        <td className="py-3 px-3 text-center whitespace-nowrap font-mono font-semibold text-amber-400">
                          {record.downtimeHours ? `${record.downtimeHours}h` : '0h'}
                        </td>

                        {/* Maintenance Status */}
                        <td className="py-3 px-3 text-center whitespace-nowrap">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold border ${
                            record.status === 'Completed' || record.verificationStatus === 'Verified'
                              ? 'bg-emerald-950/70 text-emerald-400 border-emerald-800/80'
                              : 'bg-slate-800 text-slate-300 border-slate-700'
                          }`}>
                            {record.status === 'Completed' || record.verificationStatus === 'Verified' ? (
                              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Clock className="w-3 h-3 text-slate-400" />
                            )}
                            {record.status || record.verificationStatus}
                          </span>
                        </td>

                        {/* View Button */}
                        <td className="py-3 px-3 text-right whitespace-nowrap">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setViewingRecord(record);
                            }}
                            className="p-1.5 text-cyan-400 hover:text-white hover:bg-cyan-600/30 rounded-lg transition-all cursor-pointer inline-flex items-center gap-1 text-xs font-semibold"
                            title="View Full Record"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span className="hidden lg:inline">View</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile Card Layout */}
              <div className="md:hidden divide-y divide-slate-800/80">
                {filteredRecords.map((record) => (
                  <div 
                    key={record.id}
                    className="p-4 bg-slate-900/90 space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-xs text-cyan-400">
                          {record.workOrderId || record.id}
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                          record.recordType === 'Preventive Maintenance'
                            ? 'bg-indigo-950/70 text-indigo-400 border-indigo-800'
                            : record.recordType === 'Breakdown Repair'
                            ? 'bg-rose-950/70 text-rose-400 border-rose-800'
                            : 'bg-amber-950/70 text-amber-400 border-amber-800'
                        }`}>
                          {record.recordType}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {record.date ? record.date.split('T')[0] : 'N/A'}
                      </span>
                    </div>

                    <div>
                      <h4 className="font-bold text-white text-xs">{record.assetName}</h4>
                      <p className="text-[10px] text-slate-400 font-mono">
                        Asset: <span className="text-cyan-400">{record.assetId}</span>
                        {record.serialNumber && ` • SN: ${record.serialNumber}`}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs text-slate-300">
                      <div>
                        <span className="text-[10px] text-slate-500 uppercase block font-semibold">Technician</span>
                        <span className="font-medium text-white">{record.technician}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 uppercase block font-semibold">Status</span>
                        <span className="text-emerald-400 font-semibold">{record.status || record.verificationStatus}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 uppercase block font-semibold">Downtime</span>
                        <span className="text-amber-400 font-mono font-semibold">{record.downtimeHours ? `${record.downtimeHours}h` : '0h'}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 uppercase block font-semibold">Parts</span>
                        <span className="text-slate-300 truncate block">{record.partsUsed || 'None'}</span>
                      </div>
                    </div>

                    <div className="text-xs text-slate-400 space-y-1 pt-1 border-t border-slate-800/60">
                      {record.maintenanceDescription && (
                        <div><span className="text-slate-500 font-semibold">Task:</span> {record.maintenanceDescription}</div>
                      )}
                      <div><span className="text-slate-500 font-semibold">Findings:</span> {record.findings}</div>
                      <div><span className="text-slate-500 font-semibold">Action:</span> {record.actionTaken}</div>
                    </div>

                    <button
                      onClick={() => setViewingRecord(record)}
                      className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 font-semibold text-xs rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer mt-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View Details</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* ===================================================================== */
            /* TIMELINE VIEW */
            /* ===================================================================== */
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-7 shadow-lg backdrop-blur-md">
              <div className="flex items-center justify-between mb-6 pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                    Chronological Maintenance Timeline
                  </span>
                </div>
                <div className="flex items-center gap-2 sm:gap-3">
                  {/* View Mode Toggle */}
                  <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
                    <button
                      onClick={() => setViewMode('table')}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                        viewMode === 'table'
                          ? 'bg-cyan-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Table</span>
                    </button>
                    <button
                      onClick={() => setViewMode('timeline')}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                        viewMode === 'timeline'
                          ? 'bg-cyan-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Layers className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Timeline</span>
                    </button>
                  </div>
                  <span className="text-[11px] text-slate-400">
                    {filteredRecords.length} historical events
                  </span>
                </div>
              </div>

              {/* Vertical Timeline */}
              <div className="relative pl-6 sm:pl-8 space-y-6 before:absolute before:left-2.5 sm:before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-800">
                {filteredRecords.map((record) => (
                  <div 
                    key={record.id}
                    onClick={() => setViewingRecord(record)}
                    className="relative group cursor-pointer"
                  >
                    {/* Node Dot */}
                    <div className={`absolute -left-6 sm:-left-8 top-1.5 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all duration-300 ${
                      record.recordType === 'Preventive Maintenance'
                        ? 'border-indigo-400 bg-slate-950 text-indigo-400 group-hover:scale-110'
                        : record.recordType === 'Breakdown Repair'
                        ? 'border-rose-400 bg-slate-950 text-rose-400 group-hover:scale-110'
                        : 'border-amber-400 bg-slate-950 text-amber-400 group-hover:scale-110'
                    }`}>
                      <div className="w-1.5 h-1.5 rounded-full bg-current" />
                    </div>

                    {/* Timeline Card */}
                    <div className="bg-slate-950/80 border border-slate-800 hover:border-cyan-500/50 rounded-xl p-4 transition-all duration-200 shadow-sm group-hover:shadow-md group-hover:shadow-cyan-950/30">
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold font-mono text-cyan-400">
                            {record.date ? record.date.split('T')[0] : 'N/A'}
                          </span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                            record.recordType === 'Preventive Maintenance'
                              ? 'bg-indigo-950/70 text-indigo-400 border-indigo-800'
                              : record.recordType === 'Breakdown Repair'
                              ? 'bg-rose-950/70 text-rose-400 border-rose-800'
                              : 'bg-amber-950/70 text-amber-400 border-amber-800'
                          }`}>
                            {record.recordType}
                          </span>
                          <span className="text-xs font-mono text-slate-400">
                            ({record.workOrderId || record.id})
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-xs text-slate-400">
                            Technician: <strong className="text-slate-200">{record.technician}</strong>
                          </span>
                          <span className="px-2 py-0.5 bg-emerald-950/80 text-emerald-400 border border-emerald-800 rounded text-[10px] font-bold">
                            {record.status || record.verificationStatus}
                          </span>
                        </div>
                      </div>

                      <div className="text-xs text-slate-300 space-y-1">
                        {record.maintenanceDescription && (
                          <p><strong className="text-slate-400">Description:</strong> {record.maintenanceDescription}</p>
                        )}
                        <p><strong className="text-slate-400">Findings:</strong> {record.findings}</p>
                        <p><strong className="text-slate-400">Action:</strong> {record.actionTaken}</p>
                      </div>

                      <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-slate-800/80 text-[11px] text-slate-500">
                        <span className="flex items-center gap-1 font-mono">
                          <Clock className="w-3 h-3 text-amber-400" />
                          Downtime: <strong className="text-amber-300">{record.downtimeHours ? `${record.downtimeHours} Hours` : '0 Hours'}</strong>
                        </span>

                        <span className="text-cyan-400 group-hover:underline flex items-center gap-1 font-semibold">
                          View Full Record <ChevronDown className="w-3 h-3 -rotate-90" />
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {/* ========================================================================= */}
      {/* 7. STRICT READ-ONLY VIEW RECORD MODAL */}
      {/* ========================================================================= */}
      {viewingRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/90 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 rounded-lg">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base sm:text-lg font-bold text-white font-display">
                      MAINTENANCE RECORD DETAILS
                    </h3>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950 text-cyan-400 border border-cyan-800">
                      {viewingRecord.id}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[9px] font-bold uppercase bg-slate-800 text-slate-400 border border-slate-700">
                      READ-ONLY
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Machine: <strong className="text-slate-200">{viewingRecord.assetName}</strong> ({viewingRecord.assetId})
                    {viewingRecord.serialNumber && ` • Serial No: ${viewingRecord.serialNumber}`}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setViewingRecord(null)}
                className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body (Scrollable) */}
            <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-xs text-slate-200">
              {/* Top Overview Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-slate-950/70 border border-slate-800 rounded-xl">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Record / WO ID</span>
                  <span className="font-mono font-bold text-cyan-400">{viewingRecord.workOrderId || viewingRecord.id}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Maintenance Date</span>
                  <span className="font-semibold text-slate-200">{viewingRecord.date ? viewingRecord.date.split('T')[0] : 'N/A'}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Maintenance Type</span>
                  <span className="font-semibold text-indigo-300">{viewingRecord.recordType}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Maintenance Status</span>
                  <span className="font-bold text-emerald-400">{viewingRecord.status || viewingRecord.verificationStatus}</span>
                </div>
              </div>

              {/* Machine & Serial Information */}
              <div className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-xl grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Machine Name</span>
                  <span className="font-bold text-white text-xs">{viewingRecord.assetName}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Asset ID</span>
                  <span className="font-mono font-bold text-cyan-400">{viewingRecord.assetId}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Serial Number</span>
                  <span className="font-mono text-slate-200">{viewingRecord.serialNumber || 'N/A'}</span>
                </div>
              </div>

              {/* Personnel & Responsibilities */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 bg-slate-950/50 border border-slate-800 rounded-xl">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Assigned Technician</span>
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-cyan-600/30 text-cyan-400 border border-cyan-500/40 flex items-center justify-center font-bold text-xs">
                      {viewingRecord.technician ? viewingRecord.technician.charAt(0).toUpperCase() : 'T'}
                    </div>
                    <div>
                      <span className="font-bold text-slate-200 block text-xs">{viewingRecord.technician}</span>
                      <span className="text-[10px] text-slate-500 block">Maintenance Technician</span>
                    </div>
                  </div>
                </div>

                <div className="p-3.5 bg-slate-950/50 border border-slate-800 rounded-xl">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Supervisor Verification</span>
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-emerald-600/30 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-bold text-xs">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-bold text-slate-200 block text-xs">{viewingRecord.supervisor || 'Verified by Supervisor'}</span>
                      <span className="text-[10px] text-emerald-400 font-medium block">
                        Verified {viewingRecord.verificationDate ? viewingRecord.verificationDate.split('T')[0] : 'on completion'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Technical Description, Findings & Actions */}
              <div className="space-y-3">
                {viewingRecord.maintenanceDescription && (
                  <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl">
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-1 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-indigo-400" />
                      Maintenance Description / Scope
                    </span>
                    <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">
                      {viewingRecord.maintenanceDescription}
                    </p>
                  </div>
                )}

                <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-1 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                    Inspection Findings / Diagnosed Issues
                  </span>
                  <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">
                    {viewingRecord.findings || 'No specific findings logged.'}
                  </p>
                </div>

                <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-1 flex items-center gap-1.5">
                    <Wrench className="w-3.5 h-3.5 text-cyan-400" />
                    Action Taken / Maintenance Execution
                  </span>
                  <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">
                    {viewingRecord.actionTaken || 'No action summary recorded.'}
                  </p>
                </div>
              </div>

              {/* Parts & Downtime */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 bg-slate-950/50 border border-slate-800 rounded-xl">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Spare Parts / Materials Used</span>
                  <span className="font-semibold text-slate-300 block">
                    {viewingRecord.partsUsed || 'No replacement parts logged.'}
                  </span>
                </div>

                <div className="p-3.5 bg-slate-950/50 border border-slate-800 rounded-xl">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Total Downtime Duration</span>
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span className="font-mono font-bold text-amber-300 text-sm">
                      {viewingRecord.downtimeHours ? `${viewingRecord.downtimeHours} Hours` : '0 Hours'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Checklist Results (if available) */}
              {viewingRecord.checklist && viewingRecord.checklist.length > 0 && (
                <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    Checklist Verification Items
                  </span>
                  <div className="border border-slate-800 rounded-lg overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-900 text-[10px] uppercase text-slate-400 border-b border-slate-800">
                        <tr>
                          <th className="py-2 px-3">No.</th>
                          <th className="py-2 px-3">Checklist Item</th>
                          <th className="py-2 px-3 text-center">Status</th>
                          <th className="py-2 px-3">Remarks</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60">
                        {viewingRecord.checklist.map((item, idx) => (
                          <tr key={idx} className="hover:bg-slate-900/40">
                            <td className="py-2 px-3 text-slate-500 font-mono">{idx + 1}</td>
                            <td className="py-2 px-3 text-slate-200">{item.task}</td>
                            <td className="py-2 px-3 text-center">
                              <span className="font-bold text-emerald-400">
                                {item.status || (item.completed ? 'OK' : 'OK')}
                              </span>
                            </td>
                            <td className="py-2 px-3 text-slate-400">{item.remarks || 'Standard'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Photos & Attachments */}
              {viewingRecord.photos && viewingRecord.photos.length > 0 && (
                <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block flex items-center gap-1.5">
                    <ImageIcon className="w-3.5 h-3.5 text-cyan-400" />
                    Maintenance Photographs
                  </span>
                  <div className="flex flex-wrap gap-3">
                    {viewingRecord.photos.map((photoUrl, i) => (
                      <a
                        key={i}
                        href={photoUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="w-36 h-28 rounded-lg overflow-hidden border border-slate-800 hover:border-cyan-500 transition-all block relative group"
                      >
                        <img src={photoUrl} alt="Maintenance" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                          <ExternalLink className="w-4 h-4 text-white" />
                        </div>
                      </a>
                    ))}
                  </div>
                </div>
              )}

              {/* Linked Safety Document (JSA / PTW) */}
              {(viewingRecord.workOrderId || viewingRecord.rawRecord?.safetyDocumentId || viewingRecord.rawRecord?.safetyDocumentStatus) && (
                <div className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                      Linked Safety Documentation & Compliance (JSA / PTW)
                    </span>
                    {viewingRecord.rawRecord?.safetyDocumentStatus && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-950 text-emerald-300 border border-emerald-800">
                        {viewingRecord.rawRecord.safetyDocumentType || 'PTW'}: {viewingRecord.rawRecord.safetyDocumentStatus}
                      </span>
                    )}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    <div className="text-slate-300">
                      <span className="text-slate-500 block text-[10px]">Associated Work Order</span>
                      <span className="font-mono text-cyan-400 font-bold">{viewingRecord.workOrderId || 'N/A'}</span>
                    </div>
                    <div className="text-slate-300">
                      <span className="text-slate-500 block text-[10px]">Statutory EHS Status</span>
                      <span className="text-emerald-400 font-semibold">
                        {viewingRecord.rawRecord?.safetyDocumentStatus === 'Approved' || viewingRecord.rawRecord?.safetyDocumentStatus === 'Active'
                          ? 'Safety Permit Approved & Closed'
                          : 'General Workshop Protocol Applied'}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Supervisor Remarks */}
              <div className="p-3.5 bg-slate-950/40 border border-slate-800/80 rounded-xl">
                <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Supervisor Remarks</span>
                <p className="text-slate-400 italic">
                  "{viewingRecord.supervisorRemarks || 'Maintenance verified according to safety regulations and operational readiness standards.'}"
                </p>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-800 bg-slate-950/90 flex items-center justify-between shrink-0">
              <div className="text-[11px] text-slate-500 flex items-center gap-1">
                <Lock className="w-3 h-3 text-cyan-400" />
                <span>Read-Only Archive • Changes are restricted across all roles.</span>
              </div>

              <button
                onClick={() => setViewingRecord(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs rounded-lg transition-colors cursor-pointer"
              >
                Close Record
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Machine Maintenance Report Generator Modal */}
      <MachineReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        assets={assets}
        initialAssetId={selectedAssetId}
        rawPms={rawPms}
        rawBreakdowns={rawBreakdowns}
        rawWorkOrders={rawWorkOrders}
        currentRole={currentRole}
        authorizedUser={authorizedUser}
      />
    </div>
  );
};
