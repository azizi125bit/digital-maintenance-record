import React, { useState, useEffect, useMemo, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { 
  SafetyDocument, 
  SafetyDocumentType, 
  SafetyDocumentStatus, 
  PTWPermitType, 
  JSAJobStep, 
  PTWIsolationRequirement,
  WorkOrder, 
  Asset, 
  UserRole,
  Personnel 
} from '../types';
import { generateSafetyDocumentPDF } from '../utils/safetyDocumentPdfExport';
import { syncSafetyDocumentToDb } from '../utils/safetyValidation';
import { 
  ShieldCheck, 
  FileText, 
  AlertTriangle, 
  Plus, 
  Search, 
  Filter, 
  RotateCcw, 
  CheckCircle, 
  Clock, 
  XCircle, 
  Printer, 
  Download, 
  Eye, 
  Edit3, 
  Trash2, 
  ShieldAlert, 
  HardHat, 
  Flame, 
  Zap, 
  Lock, 
  Unlock, 
  AlertOctagon, 
  CheckSquare, 
  Square, 
  Calendar, 
  User, 
  Wrench, 
  ChevronRight, 
  Activity, 
  FileCheck,
  RefreshCw,
  ExternalLink,
  Info,
  ArrowLeft,
  ChevronDown,
  Layers,
  ClipboardList
} from 'lucide-react';

interface RequireDocumentViewProps {
  currentRole: UserRole;
  authorizedUser: string;
  staffList?: Personnel[];
  workOrders?: WorkOrder[];
  initialWorkOrderId?: string | null;
  initialDocumentType?: 'JSA' | 'PTW' | 'JSA + PTW';
  onNavigateToWorkOrder?: (workOrderId: string) => void;
  onBackToDashboard?: () => void;
  onClearInitialWorkOrder?: () => void;
  onWorkOrderUpdated?: (workOrderId: string, doc: Partial<SafetyDocument>) => void;
}

const COMMON_PPE_LIST = [
  'Safety Helmet / Hard Hat',
  'Safety Boots (Steel Toe)',
  'Safety Glasses / Goggles',
  'Protective Gloves (Mechanical)',
  'Chemical Resistant Gloves',
  'High-Visibility Vest',
  'Ear Plugs / Ear Muffs',
  'Dust Mask / Respirator',
  'Full Face Shield',
  'Fall Arrest Harness & Lanyard',
  'Welding Apron / Leather Jacket'
];

const COMMON_HAZARDS = [
  'Pinch Points / Rotating Machinery',
  'High Voltage / Electrical Arc',
  'Pressurized Hydraulic / Pneumatic Lines',
  'Working at Height / Fall Hazard',
  'Hot Surfaces / Thermal Burn',
  'Toxic Fumes / Dust / Chemical Vapor',
  'Confined Space / Oxygen Depletion',
  'Sharp Metal Edges / Flying Debris',
  'Heavy Lifting / Ergonomic Strain',
  'Slip, Trip, and Uneven Floors'
];

const DEFAULT_SAFETY_CHECKLIST = [
  'Area Barricaded & Warning Signboards Posted',
  'Multi-gas Detector Tested & Zeroed (Norm: 20.9% O2, 0% LEL)',
  'ABC Dry Powder Fire Extinguisher on Standby (Min 9kg)',
  'Combustible Materials Cleared within 10m Radius',
  'Spark Containment / Fire Blanket Deployed',
  'Ventilation Fan / Exhaust Duct Operating Safely',
  'Dedicated Standby Person (Sentry) Stationed at Entry / Work Zone',
  'Emergency Evacuation Route Verified Clear & Unobstructed',
  'Emergency Stop Buttons Tested and Tagged',
  'Hand & Power Tools Inspected, Tagged, and Tested Safe',
  'All Crew Members Briefed on JSA Risk Assessment & Controls',
  'Correct PPE Worn and Verified by Supervisor',
  'First Aid Kit and Emergency Eye Wash Station Accessible',
  'Communication Radios / Mobile Phones Verified Functional'
];

export const RequireDocumentView: React.FC<RequireDocumentViewProps> = ({
  currentRole,
  authorizedUser,
  staffList = [],
  workOrders: propWorkOrders = [],
  initialWorkOrderId,
  initialDocumentType = 'JSA + PTW',
  onNavigateToWorkOrder,
  onBackToDashboard,
  onClearInitialWorkOrder,
  onWorkOrderUpdated
}) => {
  // Navigation / Category selection for listing: ALL vs JSA + PTW vs JSA vs PTW
  const [activeCategory, setActiveCategory] = useState<'ALL' | 'JSA + PTW' | 'JSA' | 'PTW'>('ALL');

  // Documents state
  const [documents, setDocuments] = useState<SafetyDocument[]>([]);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | 'warning' | 'info'; message: string } | null>(null);

  // Track initial auto-open to avoid repeated loops
  const initialHandledRef = useRef<string | null>(null);

  // Search & Filters
  const [searchRef, setSearchRef] = useState<string>('');
  const [filterWorkOrderId, setFilterWorkOrderId] = useState<string>('');
  const [filterMachineName, setFilterMachineName] = useState<string>('');
  const [filterPermitType, setFilterPermitType] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<string>('');
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');

  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);
  const [selectedDocForView, setSelectedDocForView] = useState<SafetyDocument | null>(null);
  const [selectedDocForEdit, setSelectedDocForEdit] = useState<SafetyDocument | null>(null);
  const [rejectionModalDoc, setRejectionModalDoc] = useState<SafetyDocument | null>(null);
  const [rejectionReasonInput, setRejectionReasonInput] = useState<string>('');
  const [reopeningModalDoc, setReopeningModalDoc] = useState<SafetyDocument | null>(null);
  const [reopenReasonInput, setReopenReasonInput] = useState<string>('');
  const [extendingDoc, setExtendingDoc] = useState<SafetyDocument | null>(null);
  const [extendValidityEnd, setExtendValidityEnd] = useState<string>('');
  const [extendReason, setExtendReason] = useState<string>('');

  // Form Section Navigation
  const [activeFormSection, setActiveFormSection] = useState<'A' | 'B' | 'C' | 'D' | 'E'>('A');
  const [expandAllSections, setExpandAllSections] = useState<boolean>(false);

  // =========================================================================
  // INTEGRATED FORM STATE: SECTION A (Shared General Information)
  // =========================================================================
  const [formDocType, setFormDocType] = useState<SafetyDocumentType>('JSA + PTW');
  const [formDocNumber, setFormDocNumber] = useState<string>('');
  const [formWorkOrderId, setFormWorkOrderId] = useState<string>('');
  const [formMachineName, setFormMachineName] = useState<string>('');
  const [formAssetId, setFormAssetId] = useState<string>('');
  const [formMachineSerialNumber, setFormMachineSerialNumber] = useState<string>('');
  const [formMachineLocation, setFormMachineLocation] = useState<string>('');
  const [formDepartment, setFormDepartment] = useState<string>('Mechanical & Electrical');
  const [formMaintenanceType, setFormMaintenanceType] = useState<string>('Corrective Maintenance');
  const [formJobTitle, setFormJobTitle] = useState<string>('');
  const [formJobDescription, setFormJobDescription] = useState<string>('');
  const [formWorkDate, setFormWorkDate] = useState<string>('');
  const [formValidityStart, setFormValidityStart] = useState<string>('');
  const [formValidityEnd, setFormValidityEnd] = useState<string>('');
  const [formRequestedBy, setFormRequestedBy] = useState<string>('');
  const [formAssignedTechName, setFormAssignedTechName] = useState<string>('');
  const [formPersonInCharge, setFormPersonInCharge] = useState<string>('');

  // =========================================================================
  // INTEGRATED FORM STATE: SECTION B (Job Safety Analysis - JSA)
  // =========================================================================
  const [formRequiredPPE, setFormRequiredPPE] = useState<string[]>([]);
  const [customPpeInput, setCustomPpeInput] = useState<string>('');
  const [formIdentifiedHazards, setFormIdentifiedHazards] = useState<string[]>([]);
  const [customHazardInput, setCustomHazardInput] = useState<string>('');
  const [formControlMeasures, setFormControlMeasures] = useState<string>('');
  const [formEmergencyProcedures, setFormEmergencyProcedures] = useState<string>('');
  const [formJobSteps, setFormJobSteps] = useState<JSAJobStep[]>([
    { stepNumber: 1, stepDescription: 'Inspect workspace and de-energize machine controls', hazards: 'Electrical discharge, moving parts', controlMeasures: 'Disconnect power, place LOTO tags, notify area lead' }
  ]);

  // =========================================================================
  // INTEGRATED FORM STATE: SECTION C (Permit to Work - PTW)
  // =========================================================================
  const [formPermitType, setFormPermitType] = useState<PTWPermitType>('Hot Work');
  const [formWorkLocationDetail, setFormWorkLocationDetail] = useState<string>('');
  const [formIsolationRequired, setFormIsolationRequired] = useState<boolean>(true);
  const [formIsolations, setFormIsolations] = useState<PTWIsolationRequirement[]>([
    { type: 'Electrical LOTO', applied: false, isolationPoint: 'Main Feeder Breaker', tagOrLockNumber: '', verifiedBy: '' },
    { type: 'Mechanical Lock', applied: false, isolationPoint: 'Primary Valve / Actuator', tagOrLockNumber: '', verifiedBy: '' },
    { type: 'Pressure Bleed', applied: false, isolationPoint: 'Hydraulic Bleed Manifold', tagOrLockNumber: '', verifiedBy: '' }
  ]);
  const [formGasTestingRequired, setFormGasTestingRequired] = useState<boolean>(false);
  const [formGasOxygen, setFormGasOxygen] = useState<string>('20.9%');
  const [formGasLel, setFormGasLel] = useState<string>('0%');
  const [formGasToxic, setFormGasToxic] = useState<string>('0 ppm');
  const [formGasTestedBy, setFormGasTestedBy] = useState<string>('');
  const [formGasTestPassed, setFormGasTestPassed] = useState<boolean>(true);
  const [formStandbyPerson, setFormStandbyPerson] = useState<string>('');
  const [formFireWatchAssigned, setFormFireWatchAssigned] = useState<boolean>(false);
  const [formEmergencyRescuePlan, setFormEmergencyRescuePlan] = useState<string>('');

  // =========================================================================
  // INTEGRATED FORM STATE: SECTION D (Safety Checklist)
  // =========================================================================
  const [formSafetyChecklist, setFormSafetyChecklist] = useState<string[]>(DEFAULT_SAFETY_CHECKLIST.slice(0, 8));
  const [customChecklistItem, setCustomChecklistItem] = useState<string>('');

  // =========================================================================
  // INTEGRATED FORM STATE: SECTION E (Review & Approval)
  // =========================================================================
  const [formTechnicianDeclaration, setFormTechnicianDeclaration] = useState<boolean>(true);
  const [formPicEndorsementRemarks, setFormPicEndorsementRemarks] = useState<string>('');

  const showFeedback = (type: 'success' | 'error' | 'warning' | 'info', message: string) => {
    setFeedback({ type, message });
    setTimeout(() => setFeedback(null), 6000);
  };

  // Fetch initial data with comprehensive local and remote fallbacks
  const loadData = async () => {
    setLoading(true);
    try {
      // 1. Fetch Safety Documents
      let loadedDocs: SafetyDocument[] = [];
      try {
        const { data: docData, error: docErr } = await supabase.from('safety_documents').select('*');
        if (!docErr && docData && Array.isArray(docData) && docData.length > 0) {
          loadedDocs = docData as SafetyDocument[];
        }
      } catch (_) {}

      // Fallback to local storage for safety documents
      if (loadedDocs.length === 0) {
        try {
          const stored = localStorage.getItem('dmr_safety_documents');
          if (stored) {
            const parsed = JSON.parse(stored);
            if (Array.isArray(parsed)) {
              loadedDocs = parsed;
            }
          }
        } catch (_) {}
      }
      setDocuments(loadedDocs);

      // 2. Fetch Work Orders for linking
      const loadedWos: WorkOrder[] = [...propWorkOrders];
      try {
        const { data: woData, error: woErr } = await supabase.from('work_orders').select('*');
        if (!woErr && woData && Array.isArray(woData)) {
          loadedWos.push(...(woData as WorkOrder[]));
        }
      } catch (_) {}

      try {
        const stored = localStorage.getItem('dmr_work_orders');
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed)) {
            loadedWos.push(...parsed);
          }
        }
      } catch (_) {}

      const seenWo = new Set<string>();
      const uniqueWos = loadedWos.filter(w => {
        if (!w.id || seenWo.has(w.id)) return false;
        seenWo.add(w.id);
        return true;
      });
      setWorkOrders(uniqueWos);

      // 3. Fetch Assets for details
      const loadedAssets: Asset[] = [];
      try {
        const { data: assetData, error: assetErr } = await supabase.from('assets').select('*');
        if (!assetErr && assetData && Array.isArray(assetData)) {
          loadedAssets.push(...(assetData as Asset[]));
        }
      } catch (_) {}

      try {
        const storedAssets = localStorage.getItem('dmr_assets_list') || localStorage.getItem('dmr_assets');
        if (storedAssets) {
          const parsed = JSON.parse(storedAssets);
          if (Array.isArray(parsed)) {
            loadedAssets.push(...parsed);
          }
        }
      } catch (_) {}

      const seenAsset = new Set<string>();
      const uniqueAssets = loadedAssets.filter(a => {
        if (!a.id || seenAsset.has(a.id)) return false;
        seenAsset.add(a.id);
        return true;
      });
      setAssets(uniqueAssets);

    } catch (err) {
      console.error('Error loading documents:', err);
      showFeedback('error', 'Failed loading safety documents from database.');
    } finally {
      setLoading(false);
      setIsRefreshing(false);
    }
  };

  // Robust unified lists of work orders and assets
  const allAvailableWorkOrders = useMemo(() => {
    const list: WorkOrder[] = [...propWorkOrders, ...workOrders];
    try {
      const stored = localStorage.getItem('dmr_work_orders');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          list.push(...parsed);
        }
      }
    } catch (_) {}
    const seen = new Set<string>();
    return list.filter(w => {
      if (!w.id || seen.has(w.id)) return false;
      seen.add(w.id);
      return true;
    });
  }, [propWorkOrders, workOrders]);

  const allAvailableAssets = useMemo(() => {
    const list: Asset[] = [...assets];
    try {
      const stored = localStorage.getItem('dmr_assets_list') || localStorage.getItem('dmr_assets');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          list.push(...parsed);
        }
      }
    } catch (_) {}
    const seen = new Set<string>();
    return list.filter(a => {
      if (!a.id || seen.has(a.id)) return false;
      seen.add(a.id);
      return true;
    });
  }, [assets]);

  useEffect(() => {
    loadData();
  }, []);

  // If opened with initialWorkOrderId, pre-open create modal or show existing document
  useEffect(() => {
    if (!initialWorkOrderId) {
      initialHandledRef.current = null;
      return;
    }

    const targetType: SafetyDocumentType = (initialDocumentType as SafetyDocumentType) || 'JSA + PTW';
    const key = `${initialWorkOrderId}-${targetType}`;

    if (initialHandledRef.current === key) {
      return;
    }

    setFilterWorkOrderId(initialWorkOrderId);

    // 1. Check if existing document matches
    const existing = documents.find(d => 
      (d.workOrderId === initialWorkOrderId || d.id === initialWorkOrderId)
    );

    if (existing) {
      initialHandledRef.current = key;
      if (existing.status === 'Draft' || existing.status === 'Rejected') {
        handleOpenEditModal(existing);
      } else {
        setSelectedDocForView(existing);
      }
    } else {
      // 2. Lookup work order from props, internal state, or localStorage
      let matchedWo: WorkOrder | undefined = 
        propWorkOrders.find(w => w.id === initialWorkOrderId) ||
        workOrders.find(w => w.id === initialWorkOrderId);

      if (!matchedWo) {
        try {
          const stored = localStorage.getItem('dmr_work_orders');
          if (stored) {
            const list: WorkOrder[] = JSON.parse(stored);
            matchedWo = list.find(w => w.id === initialWorkOrderId);
          }
        } catch (e) {}
      }

      // If still not found, construct a minimal work order object so the modal opens seamlessly
      if (!matchedWo) {
        matchedWo = {
          id: initialWorkOrderId,
          assetId: '',
          assetName: `Ticket ${initialWorkOrderId}`,
          category: 'Mechanical',
          issue: 'Job Safety Risk Assessment & Permit to Work',
          priority: 'High',
          status: 'Pending',
          timestamp: new Date().toISOString()
        } as WorkOrder;
      }

      initialHandledRef.current = key;
      handleOpenCreateModal('JSA + PTW', matchedWo);
    }
  }, [initialWorkOrderId, initialDocumentType, documents, workOrders, propWorkOrders]);

  // Open Create Modal & reset fields for Unified Safety Document (JSA + PTW)
  const handleOpenCreateModal = (type: SafetyDocumentType = 'JSA + PTW', preselectedWO?: WorkOrder) => {
    setSelectedDocForEdit(null);
    setFormDocType(type);
    setActiveFormSection('A');
    setExpandAllSections(false);
    
    const count = documents.length + 1;
    const year = new Date().getFullYear();
    const prefix = type === 'JSA + PTW' ? 'SAF' : type;
    const formattedNum = `${prefix}-${year}-${String(count).padStart(4, '0')}`;
    setFormDocNumber(formattedNum);

    const now = new Date();
    const startStr = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
    const endStr = new Date(now.getTime() + 8 * 3600 * 1000 - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
    setFormValidityStart(startStr);
    setFormValidityEnd(endStr);
    setFormWorkDate(now.toISOString().split('T')[0]);

    if (preselectedWO) {
      setFormWorkOrderId(preselectedWO.id);
      setFormAssetId(preselectedWO.assetId || '');
      setFormMachineName(preselectedWO.assetName || '');
      setFormMachineSerialNumber(preselectedWO.serialNumber || '');
      setFormMachineLocation(preselectedWO.location || '');
      setFormWorkLocationDetail(preselectedWO.location || '');
      setFormDepartment('Mechanical & Electrical');
      setFormMaintenanceType(preselectedWO.maintenanceType || (preselectedWO.category ? `${preselectedWO.category} Maintenance` : 'Corrective Maintenance'));
      setFormJobTitle(preselectedWO.issue || `${preselectedWO.category || 'Maintenance'} Job`);
      setFormJobDescription(preselectedWO.issue || '');
      setFormRequestedBy(preselectedWO.loggedBy || 'Plant Engineering Management');
      setFormAssignedTechName(preselectedWO.assignedToName || authorizedUser || 'Lead Technician');
      setFormPersonInCharge(authorizedUser || 'Site Safety Supervisor');

      // Lookup asset details if exists
      const matchedAsset = assets.find(a => a.id === preselectedWO.assetId);
      if (matchedAsset) {
        if (matchedAsset.serialNumber) setFormMachineSerialNumber(matchedAsset.serialNumber);
        if (matchedAsset.location) {
          setFormMachineLocation(matchedAsset.location);
          setFormWorkLocationDetail(matchedAsset.location);
        }
        if (matchedAsset.department) setFormDepartment(matchedAsset.department);
      }
    } else {
      setFormWorkOrderId('');
      setFormAssetId('');
      setFormMachineName('');
      setFormMachineSerialNumber('');
      setFormMachineLocation('');
      setFormWorkLocationDetail('');
      setFormDepartment('Mechanical & Electrical');
      setFormMaintenanceType('Corrective Maintenance');
      setFormJobTitle('');
      setFormJobDescription('');
      setFormRequestedBy('Plant Engineering Management');
      setFormAssignedTechName(authorizedUser || 'Lead Technician');
      setFormPersonInCharge('Site Safety Supervisor');
    }

    // Default Section B: JSA Fields
    setFormRequiredPPE(['Safety Helmet / Hard Hat', 'Safety Boots (Steel Toe)', 'Safety Glasses / Goggles', 'Protective Gloves (Mechanical)', 'High-Visibility Vest']);
    setFormIdentifiedHazards(['Pinch Points / Rotating Machinery', 'High Voltage / Electrical Arc', 'Pressurized Hydraulic / Pneumatic Lines']);
    setFormControlMeasures('De-energize machinery prior to inspection. Ensure LOTO is applied on the primary breaker and verified for zero stored energy.');
    setFormEmergencyProcedures('In case of unexpected startup, push local E-Stop button, evacuate work perimeter, and notify engineering control desk.');
    setFormJobSteps([
      { stepNumber: 1, stepDescription: 'Initial safety briefing & work perimeter cordoning', hazards: 'Unauthorized personnel entry', controlMeasures: 'Erect warning tapes and safety signboards' },
      { stepNumber: 2, stepDescription: 'Execute lockout-tagout (LOTO) & verify zero stored energy', hazards: 'Sudden electrical or hydraulic discharge', controlMeasures: 'Apply padlocks, bleed pressure gauges, test zero voltage' },
      { stepNumber: 3, stepDescription: 'Perform scheduled mechanical repair / overhaul task', hazards: 'Pinch hazards, sharp burrs, dropped tools', controlMeasures: 'Use Kevlar gloves and tethered tool lanyards' },
      { stepNumber: 4, stepDescription: 'Post-maintenance test run, 5S cleanup, and LOTO de-isolation', hazards: 'Unguarded moving parts during testing', controlMeasures: 'Reinstall all guards, ensure all tools removed before power restore' }
    ]);

    // Default Section C: PTW Fields
    setFormPermitType('Hot Work');
    setFormIsolationRequired(true);
    setFormIsolations([
      { type: 'Electrical LOTO', applied: false, isolationPoint: 'Main Distribution Breaker Q1', tagOrLockNumber: 'TAG-EL-01', verifiedBy: authorizedUser || 'Lead Electrician' },
      { type: 'Mechanical Lock', applied: false, isolationPoint: 'Machine Drive Locking Pin', tagOrLockNumber: 'TAG-MC-01', verifiedBy: authorizedUser || 'Mechanical Tech' },
      { type: 'Pressure Bleed', applied: false, isolationPoint: 'Pneumatic / Hydraulic Dump Valve', tagOrLockNumber: 'TAG-PR-01', verifiedBy: authorizedUser || 'Technician' }
    ]);
    setFormGasTestingRequired(false);
    setFormGasOxygen('20.9%');
    setFormGasLel('0%');
    setFormGasToxic('0 ppm');
    setFormGasTestedBy(authorizedUser || 'Safety Inspector');
    setFormGasTestPassed(true);
    setFormStandbyPerson(authorizedUser || 'Workshop Supervisor');
    setFormFireWatchAssigned(true);
    setFormEmergencyRescuePlan('Emergency eyewash station 15m away at bay 3. First aid kit and 9kg ABC fire extinguisher on standby at work perimeter.');

    // Default Section D: Safety Checklist
    setFormSafetyChecklist([...DEFAULT_SAFETY_CHECKLIST]);

    // Default Section E: Signatures
    setFormTechnicianDeclaration(true);
    setFormPicEndorsementRemarks('All mandatory risk controls and isolation verifications reviewed and confirmed ready for execution.');

    setIsCreateModalOpen(true);
  };

  // Open Edit Modal for Draft or Rejected document
  const handleOpenEditModal = (docItem: SafetyDocument) => {
    setSelectedDocForEdit(docItem);
    setFormDocType(docItem.documentType || 'JSA + PTW');
    setActiveFormSection('A');
    setExpandAllSections(false);

    setFormDocNumber(docItem.documentNumber || docItem.id);
    setFormWorkOrderId(docItem.workOrderId || '');
    setFormAssetId(docItem.assetId || '');
    setFormMachineName(docItem.machineName || '');
    setFormMachineSerialNumber(docItem.machineSerialNumber || '');
    setFormMachineLocation(docItem.machineLocation || '');
    setFormDepartment(docItem.department || 'Mechanical & Electrical');
    setFormMaintenanceType(docItem.maintenanceType || 'Corrective Maintenance');
    setFormJobTitle(docItem.jobTitle || '');
    setFormJobDescription(docItem.jobDescription || '');
    setFormWorkDate(docItem.workDate || docItem.scheduledWorkDate || '');
    setFormValidityStart(docItem.plannedStartTime || docItem.validityStart ? (docItem.plannedStartTime || docItem.validityStart)!.slice(0, 16) : '');
    setFormValidityEnd(docItem.plannedEndTime || docItem.validityEnd ? (docItem.plannedEndTime || docItem.validityEnd)!.slice(0, 16) : '');
    setFormRequestedBy(docItem.requestedBy || docItem.createdBy || 'Plant Engineering Management');
    setFormAssignedTechName(docItem.assignedTechnicianName || authorizedUser || '');
    setFormPersonInCharge(docItem.personInCharge || 'Site Safety Supervisor');

    // Section B: JSA
    setFormRequiredPPE(docItem.requiredPPE || ['Safety Helmet / Hard Hat', 'Safety Boots (Steel Toe)', 'Safety Glasses / Goggles']);
    setFormIdentifiedHazards(docItem.identifiedHazards || ['Pinch Points / Rotating Machinery']);
    setFormControlMeasures(docItem.overallControlMeasures || '');
    setFormEmergencyProcedures(docItem.emergencyProcedures || '');
    setFormJobSteps(docItem.jobSteps && docItem.jobSteps.length > 0 ? docItem.jobSteps : [
      { stepNumber: 1, stepDescription: 'Inspect workspace and verify surroundings', hazards: 'Slip / trip hazards', controlMeasures: 'Clean area and post signs' }
    ]);

    // Section C: PTW
    setFormPermitType(docItem.permitType || 'Hot Work');
    setFormWorkLocationDetail(docItem.workLocationDetail || docItem.machineLocation || '');
    setFormIsolationRequired(docItem.isolationRequired !== undefined ? docItem.isolationRequired : true);
    setFormIsolations(docItem.isolations && docItem.isolations.length > 0 ? docItem.isolations : [
      { type: 'Electrical LOTO', applied: false, isolationPoint: 'Main Breaker', tagOrLockNumber: 'TAG-01', verifiedBy: '' }
    ]);
    setFormGasTestingRequired(!!docItem.gasTestingRequired);
    setFormGasOxygen(docItem.gasTesting?.oxygenPercent || '20.9%');
    setFormGasLel(docItem.gasTesting?.flammableLEL || '0%');
    setFormGasToxic(docItem.gasTesting?.toxicPPM || '0 ppm');
    setFormGasTestedBy(docItem.gasTesting?.testedBy || '');
    setFormGasTestPassed(docItem.gasTesting?.testPassed !== undefined ? docItem.gasTesting.testPassed : true);
    setFormStandbyPerson(docItem.standbyPersonName || '');
    setFormFireWatchAssigned(!!docItem.fireWatchAssigned);
    setFormEmergencyRescuePlan(docItem.emergencyRescuePlan || '');

    // Section D: Safety Checklist
    if (docItem.safetyPrecautions && docItem.safetyPrecautions.length > 0) {
      setFormSafetyChecklist(docItem.safetyPrecautions);
    } else {
      setFormSafetyChecklist([...DEFAULT_SAFETY_CHECKLIST]);
    }

    // Section E: Declaration
    setFormTechnicianDeclaration(true);
    setFormPicEndorsementRemarks('');

    setIsCreateModalOpen(true);
  };

  // Handle Work Order selection in Create/Edit modal with comprehensive autofill
  const handleSelectWorkOrder = (woId: string) => {
    setFormWorkOrderId(woId);
    if (!woId) return;

    const foundWO = allAvailableWorkOrders.find(w => w.id === woId);
    if (foundWO) {
      setFormAssetId(foundWO.assetId || '');
      setFormMachineName(foundWO.assetName || '');
      setFormMaintenanceType(foundWO.maintenanceType || (foundWO.category ? `${foundWO.category} Maintenance` : 'Corrective Maintenance'));
      setFormJobTitle(foundWO.issue || `${foundWO.category || 'Mechanical'} Repair`);
      if (!formJobDescription || formJobDescription === '') {
        setFormJobDescription(foundWO.issue || '');
      }
      if (foundWO.assignedToName) {
        setFormAssignedTechName(foundWO.assignedToName);
      }
      if (foundWO.loggedBy) {
        setFormRequestedBy(foundWO.loggedBy);
      }
      if (foundWO.scheduledDate) {
        setFormWorkDate(foundWO.scheduledDate);
      }
      if (foundWO.serialNumber) {
        setFormMachineSerialNumber(foundWO.serialNumber);
      }
      if (foundWO.location) {
        setFormMachineLocation(foundWO.location);
        setFormWorkLocationDetail(foundWO.location);
      }
      
      const foundAsset = allAvailableAssets.find(a => a.id === foundWO.assetId);
      if (foundAsset) {
        if (foundAsset.serialNumber && !foundWO.serialNumber) {
          setFormMachineSerialNumber(foundAsset.serialNumber);
        }
        if (foundAsset.location && !foundWO.location) {
          setFormMachineLocation(foundAsset.location);
          setFormWorkLocationDetail(foundAsset.location);
        }
        if (foundAsset.department) {
          setFormDepartment(foundAsset.department);
        }
      }
    }
  };

  // Handle Asset selection if standalone
  const handleSelectAsset = (aId: string) => {
    setFormAssetId(aId);
    const foundAsset = allAvailableAssets.find(a => a.id === aId);
    if (foundAsset) {
      setFormMachineName(foundAsset.name);
      if (foundAsset.serialNumber) {
        setFormMachineSerialNumber(foundAsset.serialNumber);
      }
      if (foundAsset.location) {
        setFormMachineLocation(foundAsset.location);
        setFormWorkLocationDetail(foundAsset.location);
      }
      if (foundAsset.department) {
        setFormDepartment(foundAsset.department);
      }
    }
  };

  // Add / remove Job Step in Section B (JSA)
  const handleAddJobStep = () => {
    setFormJobSteps(prev => [
      ...prev,
      { stepNumber: prev.length + 1, stepDescription: '', hazards: '', controlMeasures: '' }
    ]);
  };

  const handleRemoveJobStep = (idx: number) => {
    if (formJobSteps.length <= 1) {
      showFeedback('warning', 'A Job Safety Analysis must contain at least one job step.');
      return;
    }
    setFormJobSteps(prev => prev.filter((_, i) => i !== idx).map((s, i) => ({ ...s, stepNumber: i + 1 })));
  };

  const handleUpdateJobStep = (idx: number, field: keyof JSAJobStep, value: string) => {
    setFormJobSteps(prev => prev.map((s, i) => i === idx ? { ...s, [field]: value } : s));
  };

  // Add / remove Isolation row in Section C (PTW)
  const handleAddIsolationRow = () => {
    setFormIsolations(prev => [
      ...prev,
      { type: 'Mechanical Lock', applied: false, isolationPoint: '', tagOrLockNumber: '', verifiedBy: authorizedUser }
    ]);
  };

  const handleRemoveIsolationRow = (idx: number) => {
    if (formIsolations.length <= 1) return;
    setFormIsolations(prev => prev.filter((_, i) => i !== idx));
  };

  const handleToggleIsolationApplied = (idx: number) => {
    setFormIsolations(prev => prev.map((iso, i) => i === idx ? { ...iso, applied: !iso.applied } : iso));
  };

  const handleUpdateIsolationField = (idx: number, field: keyof PTWIsolationRequirement, value: any) => {
    setFormIsolations(prev => prev.map((iso, i) => i === idx ? { ...iso, [field]: value } : iso));
  };

  // Add custom PPE item
  const handleAddCustomPPE = () => {
    if (!customPpeInput.trim()) return;
    if (!formRequiredPPE.includes(customPpeInput.trim())) {
      setFormRequiredPPE(prev => [...prev, customPpeInput.trim()]);
    }
    setCustomPpeInput('');
  };

  // Add custom Hazard
  const handleAddCustomHazard = () => {
    if (!customHazardInput.trim()) return;
    if (!formIdentifiedHazards.includes(customHazardInput.trim())) {
      setFormIdentifiedHazards(prev => [...prev, customHazardInput.trim()]);
    }
    setCustomHazardInput('');
  };

  // Add custom checklist item
  const handleAddCustomChecklistItem = () => {
    if (!customChecklistItem.trim()) return;
    if (!formSafetyChecklist.includes(customChecklistItem.trim())) {
      setFormSafetyChecklist(prev => [...prev, customChecklistItem.trim()]);
    }
    setCustomChecklistItem('');
  };

  // Toggle checklist item
  const handleToggleChecklistItem = (item: string) => {
    setFormSafetyChecklist(prev => 
      prev.includes(item) ? prev.filter(i => i !== item) : [...prev, item]
    );
  };

  // Form Validation before submission
  const validateDocumentForSubmission = (): { isValid: boolean; errors: string[] } => {
    const errors: string[] = [];

    // SECTION A
    if (!formMachineName || formMachineName.trim().length < 2) {
      errors.push('[Section A] Machine Name is required.');
    }
    if (!formJobDescription || formJobDescription.trim().length < 5) {
      errors.push('[Section A] Job / Work description is required (min 5 characters).');
    }
    if (!formAssignedTechName) {
      errors.push('[Section A] Assigned Technician name is required.');
    }
    if (!formValidityStart || !formValidityEnd) {
      errors.push('[Section A] Planned Start and End date/time are required.');
    } else {
      const start = new Date(formValidityStart).getTime();
      const end = new Date(formValidityEnd).getTime();
      if (end <= start) {
        errors.push('[Section A] Planned End date/time must be strictly after Start date/time.');
      }
    }

    // SECTION B: JSA
    if (formJobSteps.length === 0) {
      errors.push('[Section B] At least one JSA job step must be defined.');
    } else {
      const hasEmptyStep = formJobSteps.some(s => !s.stepDescription || !s.hazards || !s.controlMeasures);
      if (hasEmptyStep) {
        errors.push('[Section B] All job steps must contain task description, identified hazards, and control measures.');
      }
    }
    if (formRequiredPPE.length === 0) {
      errors.push('[Section B] At least one required PPE item must be selected.');
    }
    if (formIdentifiedHazards.length === 0) {
      errors.push('[Section B] At least one workplace hazard must be selected.');
    }

    // SECTION C: PTW
    if (!formPermitType) {
      errors.push('[Section C] Permit type must be selected.');
    }
    if (formIsolationRequired) {
      const appliedIsolations = formIsolations.filter(i => i.applied);
      if (appliedIsolations.length === 0) {
        errors.push('[Section C] Energy isolation is mandatory, but zero isolations are marked applied.');
      }
    }

    // SECTION D: Checklist
    if (formSafetyChecklist.length === 0) {
      errors.push('[Section D] At least one safety checklist item must be verified.');
    }

    return { isValid: errors.length === 0, errors };
  };

  // Save document (either Draft or Submit for Approval)
  const handleSaveDocument = async (isSubmitting: boolean) => {
    if (isSubmitting) {
      const { isValid, errors } = validateDocumentForSubmission();
      if (!isValid) {
        showFeedback('error', `Cannot submit: ${errors[0]}`);
        return;
      }
    }

    try {
      const now = new Date().toISOString();
      const docId = selectedDocForEdit?.id || formDocNumber || `SAF-${Date.now()}`;
      
      let nextStatus: SafetyDocumentStatus = 'Draft';
      if (isSubmitting) {
        nextStatus = 'Pending Approval';
      } else if (selectedDocForEdit) {
        nextStatus = selectedDocForEdit.status === 'Rejected' ? 'Draft' : selectedDocForEdit.status;
      }

      const payload: SafetyDocument = {
        id: docId,
        documentNumber: formDocNumber || docId,
        documentType: formDocType,
        workOrderId: formWorkOrderId || undefined,
        assetId: formAssetId || 'ASSET-GEN',
        machineName: formMachineName || 'General Machine',
        machineSerialNumber: formMachineSerialNumber || undefined,
        machineLocation: formMachineLocation || formWorkLocationDetail || 'Workshop Site',
        department: formDepartment || 'Mechanical & Electrical',
        maintenanceType: formMaintenanceType,
        jobTitle: formJobTitle || formJobDescription.slice(0, 40),
        jobDescription: formJobDescription,
        workDate: formWorkDate || (formValidityStart ? formValidityStart.split('T')[0] : now.split('T')[0]),
        scheduledWorkDate: formWorkDate || (formValidityStart ? formValidityStart.split('T')[0] : now.split('T')[0]),
        plannedStartTime: formValidityStart,
        plannedEndTime: formValidityEnd,
        requestedBy: formRequestedBy || 'Plant Engineering Management',
        assignedTechnicianName: formAssignedTechName || authorizedUser,
        personInCharge: formPersonInCharge || 'Site Safety Supervisor',
        status: nextStatus,
        createdBy: selectedDocForEdit?.createdBy || authorizedUser || 'Technician',
        createdRole: selectedDocForEdit?.createdRole || currentRole,
        createdAt: selectedDocForEdit?.createdAt || now,
        updatedAt: now,
        submittedAt: isSubmitting ? now : selectedDocForEdit?.submittedAt,
        rejectionReason: nextStatus === 'Pending Approval' ? undefined : selectedDocForEdit?.rejectionReason,
        revisionCount: selectedDocForEdit ? (selectedDocForEdit.revisionCount || 1) + 1 : 1,

        // SECTION B: JSA specifics
        jobSteps: formJobSteps,
        identifiedHazards: formIdentifiedHazards,
        overallControlMeasures: formControlMeasures,
        requiredPPE: formRequiredPPE,
        emergencyProcedures: formEmergencyProcedures,

        // SECTION C: PTW specifics
        permitType: formPermitType,
        validityStart: formValidityStart,
        validityEnd: formValidityEnd,
        workLocationDetail: formWorkLocationDetail || formMachineLocation,
        isolationRequired: formIsolationRequired,
        isolations: formIsolations,
        gasTestingRequired: formGasTestingRequired,
        gasTesting: formGasTestingRequired ? {
          oxygenPercent: formGasOxygen,
          flammableLEL: formGasLel,
          toxicPPM: formGasToxic,
          testedBy: formGasTestedBy || authorizedUser,
          testTime: now,
          testPassed: formGasTestPassed
        } : undefined,
        standbyPersonName: formStandbyPerson,
        fireWatchAssigned: formFireWatchAssigned,
        emergencyRescuePlan: formEmergencyRescuePlan,

        // SECTION D: Safety Checklist
        safetyPrecautions: formSafetyChecklist,

        // SECTION E: Signatures
        approvalRemarks: formPicEndorsementRemarks || undefined
      };

      // Preserve approval stamps if already approved and not resubmitting
      if (selectedDocForEdit?.approvedBy && !isSubmitting) {
        payload.approvedBy = selectedDocForEdit.approvedBy;
        payload.approvedAt = selectedDocForEdit.approvedAt;
        payload.approvalRole = selectedDocForEdit.approvalRole;
      }

      // Sync to database and localStorage
      await syncSafetyDocumentToDb(payload, formWorkOrderId);

      // Update linked Work Order
      if (formWorkOrderId) {
        try {
          await supabase.from('work_orders').update({
            safetyDocumentId: payload.id,
            safetyDocumentType: payload.documentType,
            safetyDocumentStatus: payload.status,
            requiresPermit: true,
            requiredPermitType: payload.permitType
          }).eq('id', formWorkOrderId);
        } catch (woUpdateErr) {
          console.warn('Could not update work order pointer in db:', woUpdateErr);
        }

        try {
          const stored = localStorage.getItem('dmr_work_orders');
          if (stored) {
            const list: WorkOrder[] = JSON.parse(stored);
            const updated = list.map(w => w.id === formWorkOrderId ? {
              ...w,
              safetyDocumentId: payload.id,
              safetyDocumentType: payload.documentType,
              safetyDocumentStatus: payload.status,
              requiresPermit: true,
              requiredPermitType: payload.permitType
            } : w);
            localStorage.setItem('dmr_work_orders', JSON.stringify(updated));
          }
        } catch (e) {}

        if (onWorkOrderUpdated) {
          onWorkOrderUpdated(formWorkOrderId, {
            id: payload.id,
            documentType: payload.documentType,
            status: payload.status,
            permitType: payload.permitType
          });
        }
      }

      showFeedback('success', `Integrated Safety Document [${payload.documentNumber}] saved successfully as [${payload.status}].`);
      setIsCreateModalOpen(false);
      setSelectedDocForEdit(null);
      onClearInitialWorkOrder?.();
      await loadData();
    } catch (err: any) {
      console.error('Error saving safety document:', err);
      showFeedback('error', `Failed saving document: ${err.message || 'Database error'}`);
    }
  };

  // APPROVAL WORKFLOW: Approve Document (Management Only)
  const handleApproveDocument = async (docItem: SafetyDocument) => {
    if (currentRole !== 'Management') {
      showFeedback('error', 'Only Management personnel can authorize and approve safety documents.');
      return;
    }

    try {
      const now = new Date().toISOString();
      const updatedStatus: SafetyDocumentStatus = 'Approved';

      const updatedDoc: SafetyDocument = {
        ...docItem,
        status: updatedStatus,
        approvedBy: authorizedUser || 'Plant Manager',
        approvalRole: currentRole,
        approvedAt: now,
        updatedAt: now,
        rejectionReason: undefined
      };

      // 1. Sync to Database, LocalStorage, and linked Work Order
      await syncSafetyDocumentToDb(updatedDoc, docItem.workOrderId);

      // 2. Notify parent if prop provided
      if (onWorkOrderUpdated && docItem.workOrderId) {
        onWorkOrderUpdated(docItem.workOrderId, updatedDoc);
      }

      showFeedback('success', `Safety Document [${docItem.documentNumber || docItem.id}] officially approved and signed.`);
      setSelectedDocForView(null);
      await loadData();
    } catch (err: any) {
      console.error('Approval failed:', err);
      showFeedback('error', 'Failed to approve document: ' + (err.message || 'Database error'));
    }
  };

  // REJECTION WORKFLOW: Reject Document (Management Only)
  const handleOpenRejectModal = (docItem: SafetyDocument) => {
    if (currentRole !== 'Management') {
      showFeedback('error', 'Only Management personnel can review and reject safety documents.');
      return;
    }
    setRejectionModalDoc(docItem);
    setRejectionReasonInput('');
  };

  const handleConfirmRejection = async () => {
    if (!rejectionModalDoc) return;
    if (!rejectionReasonInput.trim()) {
      showFeedback('warning', 'Please provide an explicit safety rejection reason for revision.');
      return;
    }

    try {
      const now = new Date().toISOString();
      const updatedDoc: SafetyDocument = {
        ...rejectionModalDoc,
        status: 'Rejected' as SafetyDocumentStatus,
        rejectionReason: rejectionReasonInput.trim(),
        updatedAt: now
      };

      await syncSafetyDocumentToDb(updatedDoc, rejectionModalDoc.workOrderId);

      if (onWorkOrderUpdated && rejectionModalDoc.workOrderId) {
        onWorkOrderUpdated(rejectionModalDoc.workOrderId, updatedDoc);
      }

      showFeedback('warning', `Document [${rejectionModalDoc.documentNumber || rejectionModalDoc.id}] rejected for revision.`);
      setRejectionModalDoc(null);
      setSelectedDocForView(null);
      await loadData();
    } catch (err: any) {
      console.error('Rejection failed:', err);
      showFeedback('error', 'Failed to reject document.');
    }
  };

  // PTW STATUS TRANSITIONS: Activate, Suspend, Close, Reopen
  const handleTransitionPTWStatus = async (docItem: SafetyDocument, targetStatus: SafetyDocumentStatus) => {
    if (targetStatus === 'Active' && docItem.validityEnd) {
      const endTime = new Date(docItem.validityEnd).getTime();
      if (Date.now() > endTime) {
        showFeedback('error', 'This permit has passed its validity period and has expired. Cannot activate an expired permit.');
        return;
      }
    }

    if (targetStatus === 'Active' || targetStatus === 'Suspended' || targetStatus === 'Closed') {
      if (currentRole !== 'Management') {
        showFeedback('error', 'Only Management/Safety Officers can alter permit operational states.');
        return;
      }
    }

    try {
      const now = new Date().toISOString();
      const updatedDoc: SafetyDocument = {
        ...docItem,
        status: targetStatus,
        updatedAt: now
      };

      if (targetStatus === 'Closed') {
        updatedDoc.closedBy = authorizedUser;
        updatedDoc.closedAt = now;
      }

      await syncSafetyDocumentToDb(updatedDoc, docItem.workOrderId);

      if (onWorkOrderUpdated && docItem.workOrderId) {
        onWorkOrderUpdated(docItem.workOrderId, updatedDoc);
      }

      showFeedback('success', `Safety Document [${docItem.documentNumber || docItem.id}] status changed to [${targetStatus}].`);
      setSelectedDocForView(null);
      await loadData();
    } catch (err: any) {
      console.error('Transition failed:', err);
      showFeedback('error', 'Failed transitioning permit status.');
    }
  };

  // REOPEN CLOSED PERMIT
  const handleConfirmReopenPermit = async () => {
    if (!reopeningModalDoc) return;
    if (currentRole !== 'Management') {
      showFeedback('error', 'Only Management can authorize reopening a closed permit.');
      return;
    }
    if (!reopenReasonInput.trim()) {
      showFeedback('warning', 'Please provide a justification for reopening this closed permit.');
      return;
    }

    try {
      const now = new Date().toISOString();
      const updatedDoc: SafetyDocument = {
        ...reopeningModalDoc,
        status: 'Pending Approval' as SafetyDocumentStatus,
        reopenedBy: authorizedUser,
        reopenedAt: now,
        reopenReason: reopenReasonInput.trim(),
        updatedAt: now
      };

      await syncSafetyDocumentToDb(updatedDoc, reopeningModalDoc.workOrderId);

      if (onWorkOrderUpdated && reopeningModalDoc.workOrderId) {
        onWorkOrderUpdated(reopeningModalDoc.workOrderId, updatedDoc);
      }

      showFeedback('success', `Permit [${reopeningModalDoc.documentNumber || reopeningModalDoc.id}] reopened and set to Pending Approval.`);
      setReopeningModalDoc(null);
      setSelectedDocForView(null);
      await loadData();
    } catch (err: any) {
      console.error('Reopen failed:', err);
      showFeedback('error', 'Failed to reopen permit.');
    }
  };

  // EXTEND PERMIT VALIDITY (PTW)
  const handleOpenExtendModal = (doc: SafetyDocument) => {
    setExtendingDoc(doc);
    const now = new Date();
    const futureDate = new Date(now.getTime() + 8 * 3600 * 1000 - now.getTimezoneOffset() * 60000);
    setExtendValidityEnd(futureDate.toISOString().slice(0, 16));
    setExtendReason('');
  };

  const handleQuickExtendHours = (hours: number) => {
    const base = new Date();
    const futureDate = new Date(base.getTime() + hours * 3600 * 1000 - base.getTimezoneOffset() * 60000);
    setExtendValidityEnd(futureDate.toISOString().slice(0, 16));
  };

  const handleConfirmExtendValidity = async () => {
    if (!extendingDoc) return;
    if (currentRole !== 'Management') {
      showFeedback('error', 'Only Management / Safety Officers can extend permit validity.');
      return;
    }
    if (!extendValidityEnd) {
      showFeedback('warning', 'Please specify a new validity end date/time.');
      return;
    }
    const newEndMs = new Date(extendValidityEnd).getTime();
    if (isNaN(newEndMs) || newEndMs <= Date.now()) {
      showFeedback('warning', 'New validity end date/time must be in the future.');
      return;
    }
    if (!extendReason.trim()) {
      showFeedback('warning', 'Please provide a brief justification for extending this permit.');
      return;
    }

    try {
      const now = new Date().toISOString();
      const updatedDoc: SafetyDocument = {
        ...extendingDoc,
        validityEnd: extendValidityEnd,
        plannedEndTime: extendValidityEnd,
        status: 'Active' as SafetyDocumentStatus,
        extendedBy: authorizedUser,
        extendedAt: now,
        extensionReason: extendReason.trim(),
        updatedAt: now
      };

      await syncSafetyDocumentToDb(updatedDoc, extendingDoc.workOrderId);

      if (onWorkOrderUpdated && extendingDoc.workOrderId) {
        onWorkOrderUpdated(extendingDoc.workOrderId, updatedDoc);
      }

      showFeedback('success', `Permit [${extendingDoc.documentNumber || extendingDoc.id}] validity extended until ${extendValidityEnd.replace('T', ' ')}.`);
      setExtendingDoc(null);
      setSelectedDocForView(null);
      await loadData();
    } catch (err: any) {
      console.error('Extension failed:', err);
      showFeedback('error', 'Failed to extend permit validity.');
    }
  };

  // Trigger PDF Generation (Never auto-approves)
  const handleExportPDF = async (docItem: SafetyDocument, printMode: boolean = false) => {
    try {
      const { data: freshDoc } = await supabase.from('safety_documents').select('*').eq('id', docItem.id);
      const target = (freshDoc && freshDoc[0]) ? (freshDoc[0] as SafetyDocument) : docItem;

      await generateSafetyDocumentPDF({
        document: target,
        printMode
      });
      showFeedback('success', `${printMode ? 'Print window launched' : 'A4 PDF generated'} for ${target.documentNumber || target.id}`);
    } catch (err) {
      console.error('PDF export failed:', err);
      showFeedback('error', 'Failed generating PDF document.');
    }
  };

  // Reset all filters
  const handleResetFilters = () => {
    setSearchRef('');
    setFilterWorkOrderId('');
    setFilterMachineName('');
    setFilterPermitType('');
    setFilterStatus('');
    setDateFrom('');
    setDateTo('');
  };

  // Check and flag expired permits
  const processedDocuments = useMemo(() => {
    const now = Date.now();
    return documents.map(d => {
      if ((d.documentType === 'PTW' || d.documentType === 'JSA + PTW') && (d.status === 'Active' || d.status === 'Approved') && (d.validityEnd || d.plannedEndTime)) {
        const endTimeStr = d.validityEnd || d.plannedEndTime;
        if (endTimeStr) {
          const end = new Date(endTimeStr).getTime();
          if (now > end) {
            return { ...d, status: 'Expired' as SafetyDocumentStatus };
          }
        }
      }
      return d;
    });
  }, [documents]);

  // Counts for KPI Badges
  const integratedCount = processedDocuments.filter(d => d.documentType === 'JSA + PTW').length;
  const jsaCount = processedDocuments.filter(d => d.documentType === 'JSA').length;
  const ptwCount = processedDocuments.filter(d => d.documentType === 'PTW').length;
  const totalSafetyDocsCount = processedDocuments.length;
  const pendingCount = processedDocuments.filter(d => d.status === 'Pending Approval').length;
  const activePtwCount = processedDocuments.filter(d => (d.documentType === 'PTW' || d.documentType === 'JSA + PTW') && d.status === 'Active').length;

  // Count matching documents for active work order filter
  const matchingWorkOrderDocsCount = useMemo(() => {
    if (!filterWorkOrderId.trim()) return 0;
    const q = filterWorkOrderId.toLowerCase().trim();
    return processedDocuments.filter(d => 
      (activeCategory === 'ALL' || d.documentType === activeCategory) && (d.workOrderId || '').toLowerCase().includes(q)
    ).length;
  }, [processedDocuments, activeCategory, filterWorkOrderId]);

  // Filtered documents by Category and Search options
  const filteredDocuments = useMemo(() => {
    return processedDocuments.filter(doc => {
      // 1. Category tab filter
      if (activeCategory !== 'ALL' && doc.documentType !== activeCategory) {
        return false;
      }

      // 2. Reference Search
      if (searchRef.trim()) {
        const q = searchRef.toLowerCase().trim();
        const refMatch = (doc.documentNumber || '').toLowerCase().includes(q) || doc.id.toLowerCase().includes(q);
        if (!refMatch) return false;
      }

      // 3. Work Order filter
      if (filterWorkOrderId.trim()) {
        const q = filterWorkOrderId.toLowerCase().trim();
        const woMatch = (doc.workOrderId || '').toLowerCase().includes(q);
        if (!woMatch && matchingWorkOrderDocsCount > 0) return false;
      }

      // 4. Machine / Asset Name filter
      if (filterMachineName.trim()) {
        const q = filterMachineName.toLowerCase().trim();
        const m = (doc.machineName || '').toLowerCase();
        const a = (doc.assetId || '').toLowerCase();
        if (!m.includes(q) && !a.includes(q)) return false;
      }

      // 5. Permit Type (for PTW & Integrated)
      if (filterPermitType.trim()) {
        if (doc.permitType !== filterPermitType) return false;
      }

      // 6. Status filter
      if (filterStatus.trim()) {
        if (doc.status !== filterStatus) return false;
      }

      // 7. Date range filter
      if (dateFrom) {
        const docDate = (doc.createdAt || doc.scheduledWorkDate || doc.workDate || '').split('T')[0];
        if (docDate && docDate < dateFrom) return false;
      }
      if (dateTo) {
        const docDate = (doc.createdAt || doc.scheduledWorkDate || doc.workDate || '').split('T')[0];
        if (docDate && docDate > dateTo) return false;
      }

      return true;
    });
  }, [processedDocuments, activeCategory, searchRef, filterWorkOrderId, matchingWorkOrderDocsCount, filterMachineName, filterPermitType, filterStatus, dateFrom, dateTo]);

  return (
    <div className="space-y-6">
      {/* Top Banner / Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 md:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 opacity-5 pointer-events-none">
          <ShieldAlert className="w-64 h-64 text-amber-500" />
        </div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              {onBackToDashboard && (
                <button
                  type="button"
                  onClick={() => {
                    onClearInitialWorkOrder?.();
                    onBackToDashboard();
                  }}
                  className="px-3 py-1 rounded-md bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 hover:text-white border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                  title="Kembali ke Dashboard Utama"
                >
                  <ArrowLeft className="w-3.5 h-3.5 text-amber-400" />
                  <span>Kembali ke Dashboard</span>
                </button>
              )}
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Integrated Safety System (JSA + PTW)
              </span>
              <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 text-[10px] font-mono">
                Role: {currentRole}
              </span>
            </div>
            <h1 className="text-xl md:text-2xl font-display font-bold text-white tracking-tight flex items-center gap-2.5">
              Require Document Section
              <span className="text-xs font-mono font-medium text-slate-400">/ Integrated JSA & PTW</span>
            </h1>
            <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
              Complete Job Safety Analysis (JSA) risk assessments and Permit to Work (PTW) within one unified safety document form linked with maintenance Work Orders.
            </p>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap shrink-0">
            <button
              onClick={() => { setIsRefreshing(true); loadData(); }}
              disabled={isRefreshing}
              className="px-3 py-2.5 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 text-xs font-semibold rounded-xl border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer"
              title="Refresh Safety Documents"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-cyan-400' : ''}`} />
              Refresh
            </button>

            {/* MAIN ACTION BUTTON: Create Safety Document (JSA + PTW) */}
            <button
              onClick={() => handleOpenCreateModal('JSA + PTW')}
              className="px-4 py-2.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 active:scale-95 text-white text-xs font-bold rounded-xl shadow-lg shadow-emerald-950/50 transition-all flex items-center gap-2 cursor-pointer border border-emerald-400/30"
              title="Create unified safety document combining JSA and PTW into one form"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-200" />
              Create Safety Document (JSA + PTW)
            </button>
          </div>
        </div>

        {/* Global KPI Counters */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-slate-800/80">
          <button
            type="button"
            onClick={() => setActiveCategory('ALL')}
            className={`text-left rounded-xl p-3 border transition-all cursor-pointer active:scale-98 ${
              activeCategory === 'ALL' 
                ? 'bg-emerald-950/30 border-emerald-500/40 shadow-xs' 
                : 'bg-slate-800/50 border-slate-800 hover:border-emerald-500/30 hover:bg-slate-800/80'
            }`}
            title="Papar semua rekod dokumen keselamatan"
          >
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Safety Records</span>
            <div className="flex items-center justify-between mt-1">
              <span className="text-xl font-display font-bold text-emerald-400">{totalSafetyDocsCount}</span>
              <FileCheck className="w-4 h-4 text-emerald-400/80" />
            </div>
            <span className="text-[9px] text-slate-500 block mt-0.5">
              {integratedCount} Integrated | {jsaCount} JSA | {ptwCount} PTW
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveCategory('JSA + PTW')}
            className={`text-left rounded-xl p-3 border transition-all cursor-pointer active:scale-98 ${
              activeCategory === 'JSA + PTW' 
                ? 'bg-teal-950/30 border-teal-500/40 shadow-xs' 
                : 'bg-slate-800/50 border-slate-800 hover:border-teal-500/30 hover:bg-slate-800/80'
            }`}
            title="Klik untuk papar dokumen bersepadu JSA + PTW"
          >
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Integrated (JSA + PTW)</span>
            <div className="flex items-center justify-between mt-1">
              <span className="text-xl font-display font-bold text-teal-300">{integratedCount}</span>
              <ShieldCheck className="w-4 h-4 text-teal-400/80" />
            </div>
            <span className="text-[9px] text-slate-500 block mt-0.5">Unified safety documents</span>
          </button>

          <button
            type="button"
            onClick={() => setFilterStatus(filterStatus === 'Pending Approval' ? '' : 'Pending Approval')}
            className={`text-left rounded-xl p-3 border transition-all cursor-pointer active:scale-98 ${
              filterStatus === 'Pending Approval'
                ? 'bg-yellow-950/40 border-yellow-500/50 shadow-xs'
                : 'bg-slate-800/50 border-slate-800 hover:border-yellow-500/30 hover:bg-slate-800/80'
            }`}
            title="Klik untuk tapis dokumen Pending Approval"
          >
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Pending Approval</span>
            <div className="flex items-center justify-between mt-1">
              <span className="text-xl font-display font-bold text-yellow-400">{pendingCount}</span>
              <Clock className="w-4 h-4 text-yellow-400/80" />
            </div>
            <span className="text-[9px] text-slate-500 block mt-0.5">Awaiting management review</span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveCategory('ALL'); setFilterStatus(filterStatus === 'Active' ? '' : 'Active'); }}
            className={`text-left rounded-xl p-3 border transition-all cursor-pointer active:scale-98 ${
              filterStatus === 'Active'
                ? 'bg-cyan-950/40 border-cyan-500/50 shadow-xs'
                : 'bg-slate-800/50 border-slate-800 hover:border-cyan-500/30 hover:bg-slate-800/80'
            }`}
            title="Klik untuk tapis permit Active"
          >
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Active Live Permits</span>
            <div className="flex items-center justify-between mt-1">
              <span className="text-xl font-display font-bold text-cyan-400">{activePtwCount}</span>
              <Activity className="w-4 h-4 text-cyan-400/80" />
            </div>
            <span className="text-[9px] text-slate-500 block mt-0.5">Currently authorized for work</span>
          </button>
        </div>
      </div>

      {/* Feedback banner */}
      {feedback && (
        <div className={`p-3.5 rounded-xl text-xs font-medium flex items-center justify-between border ${
          feedback.type === 'success' ? 'bg-emerald-950/70 border-emerald-800 text-emerald-300' :
          feedback.type === 'error' ? 'bg-rose-950/70 border-rose-800 text-rose-300' :
          feedback.type === 'warning' ? 'bg-amber-950/70 border-amber-800 text-amber-300' :
          'bg-slate-800 border-slate-700 text-slate-200'
        }`}>
          <div className="flex items-center gap-2">
            {feedback.type === 'success' && <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />}
            {feedback.type === 'error' && <XCircle className="w-4 h-4 shrink-0 text-rose-400" />}
            {feedback.type === 'warning' && <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />}
            {feedback.type === 'info' && <Info className="w-4 h-4 shrink-0 text-cyan-400" />}
            <span>{feedback.message}</span>
          </div>
          <button onClick={() => setFeedback(null)} className="text-slate-400 hover:text-white ml-2 text-xs">✕</button>
        </div>
      )}

      {/* Category Tabs: All Safety Documents vs Integrated vs JSA vs PTW */}
      <div className="flex items-center border-b border-slate-800 space-x-2 overflow-x-auto">
        <button
          onClick={() => setActiveCategory('ALL')}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 font-display font-bold text-xs uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
            activeCategory === 'ALL'
              ? 'border-emerald-500 text-emerald-400 bg-slate-900/90 rounded-t-lg shadow-inner'
              : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>All Safety Documents</span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono ${
            activeCategory === 'ALL' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-800 text-slate-500'
          }`}>
            {totalSafetyDocsCount}
          </span>
        </button>

        <button
          onClick={() => setActiveCategory('JSA + PTW')}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 font-display font-bold text-xs uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
            activeCategory === 'JSA + PTW'
              ? 'border-teal-500 text-teal-300 bg-slate-900/90 rounded-t-lg shadow-inner'
              : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
          }`}
        >
          <ShieldCheck className="w-4 h-4 text-teal-400" />
          <span>Integrated (JSA + PTW)</span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono ${
            activeCategory === 'JSA + PTW' ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30' : 'bg-slate-800 text-slate-500'
          }`}>
            {integratedCount}
          </span>
        </button>

        <button
          onClick={() => setActiveCategory('JSA')}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 font-display font-bold text-xs uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
            activeCategory === 'JSA'
              ? 'border-blue-500 text-blue-400 bg-slate-900/90 rounded-t-lg shadow-inner'
              : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
          }`}
        >
          <FileText className="w-4 h-4 text-blue-400" />
          <span>JSA Only</span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono ${
            activeCategory === 'JSA' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30' : 'bg-slate-800 text-slate-500'
          }`}>
            {jsaCount}
          </span>
        </button>

        <button
          onClick={() => setActiveCategory('PTW')}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 font-display font-bold text-xs uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
            activeCategory === 'PTW'
              ? 'border-amber-500 text-amber-400 bg-slate-900/90 rounded-t-lg shadow-inner'
              : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
          }`}
        >
          <Flame className="w-4 h-4 text-amber-400" />
          <span>PTW Permits Only</span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono ${
            activeCategory === 'PTW' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-slate-800 text-slate-500'
          }`}>
            {ptwCount}
          </span>
        </button>
      </div>

      {/* Active Work Order Context Banner */}
      {filterWorkOrderId && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-blue-950/60 border border-blue-500/40 text-blue-200 text-xs shadow-md">
          <div className="flex items-center gap-2.5">
            <FileText className="w-4 h-4 text-blue-400 shrink-0" />
            <div>
              <span>
                Fokus Work Order: <strong className="font-mono text-white bg-blue-900/80 px-1.5 py-0.5 rounded border border-blue-400/40">{filterWorkOrderId}</strong>
              </span>
              {matchingWorkOrderDocsCount === 0 ? (
                <span className="block text-[11px] text-amber-300 mt-0.5 font-medium">
                  ℹ️ Tiket {filterWorkOrderId} belum mempunyai rekod keselamatan. Klik butang di sebelah untuk cipta Dokumen Keselamatan Bersepadu (JSA + PTW).
                </span>
              ) : (
                <span className="block text-[11px] text-emerald-300 mt-0.5 font-medium">
                  ✓ Menjumpai {matchingWorkOrderDocsCount} dokumen keselamatan yang terikat dengan tiket {filterWorkOrderId}.
                </span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap shrink-0">
            <button
              type="button"
              onClick={() => {
                const wo = allAvailableWorkOrders.find(w => w.id === filterWorkOrderId) || { id: filterWorkOrderId, assetName: `Ticket ${filterWorkOrderId}` } as WorkOrder;
                handleOpenCreateModal('JSA + PTW', wo);
              }}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold rounded-lg text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-sm whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" /> + Jana Dokumen Keselamatan (JSA + PTW)
            </button>
            <button
              type="button"
              onClick={() => {
                setFilterWorkOrderId('');
                onClearInitialWorkOrder?.();
              }}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 hover:text-white rounded-lg text-xs font-semibold transition-all cursor-pointer border border-slate-700 whitespace-nowrap"
            >
              Tutup Penapis Work Order
            </button>
          </div>
        </div>
      )}

      {/* Search and Multi-Filter Controls */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-semibold text-slate-300 uppercase tracking-wider text-[11px]">
              Search & Filter Safety Records
            </span>
            <span className="text-[11px] text-slate-500">
              ({filteredDocuments.length} matching)
            </span>
          </div>

          <button
            onClick={handleResetFilters}
            className="text-[11px] text-slate-400 hover:text-amber-400 flex items-center gap-1 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
            Reset Filters
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {/* 1. Doc Ref Search */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase mb-1">
              Doc Ref Number
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="e.g. SAF-2026-0001"
                value={searchRef}
                onChange={e => setSearchRef(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500"
              />
              {searchRef && (
                <button onClick={() => setSearchRef('')} className="absolute right-2 top-2 text-slate-500 text-xs">✕</button>
              )}
            </div>
          </div>

          {/* 2. Work Order ID */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase mb-1">
              Work Order ID
            </label>
            <input
              type="text"
              placeholder="e.g. DMR-1001"
              value={filterWorkOrderId}
              onChange={e => setFilterWorkOrderId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* 3. Machine Name / Asset ID */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase mb-1">
              Machine / Asset
            </label>
            <input
              type="text"
              placeholder="e.g. Lathe, MCH-001"
              value={filterMachineName}
              onChange={e => setFilterMachineName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* 4. Permit Type */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase mb-1">
              Permit Type
            </label>
            <select
              value={filterPermitType}
              onChange={e => setFilterPermitType(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
            >
              <option value="">All Permit Types</option>
              <option value="Hot Work">Hot Work</option>
              <option value="Confined Space">Confined Space</option>
              <option value="Electrical / High Voltage">Electrical / High Voltage</option>
              <option value="Working at Height">Working at Height</option>
              <option value="Cold Work / Mechanical Isolation">Cold Work / Mechanical</option>
              <option value="Chemical / Hazardous Material">Chemical / Hazardous</option>
              <option value="General Hazardous Work">General Hazardous Work</option>
            </select>
          </div>

          {/* 5. Document Status */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase mb-1">
              Approval Status
            </label>
            <select
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
            >
              <option value="">All Statuses</option>
              <option value="Draft">Draft</option>
              <option value="Pending Approval">Pending Approval</option>
              <option value="Approved">Approved</option>
              <option value="Active">Active</option>
              <option value="Suspended">Suspended</option>
              <option value="Expired">Expired</option>
              <option value="Rejected">Rejected</option>
              <option value="Closed">Closed</option>
            </select>
          </div>

          {/* 6. Date Range */}
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase mb-1">
              Date Filter
            </label>
            <div className="grid grid-cols-2 gap-1">
              <input
                type="date"
                value={dateFrom}
                onChange={e => setDateFrom(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-1.5 py-1 text-[11px] text-slate-200 focus:outline-none"
                title="Date From"
              />
              <input
                type="date"
                value={dateTo}
                onChange={e => setDateTo(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-1.5 py-1 text-[11px] text-slate-200 focus:outline-none"
                title="Date To"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Main Document Listing Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        {loading ? (
          <div className="py-16 text-center text-slate-400">
            <RefreshCw className="w-8 h-8 mx-auto mb-2 text-emerald-400 animate-spin" />
            <p className="text-xs font-semibold">Retrieving official safety documents from database...</p>
          </div>
        ) : filteredDocuments.length === 0 ? (
          <div className="py-16 px-4 text-center">
            <ShieldAlert className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h3 className="text-sm font-bold text-slate-200">
              {filterWorkOrderId 
                ? `Tiada Dokumen Keselamatan Dijumpai Untuk Tiket ${filterWorkOrderId}` 
                : 'No Matching Safety Records Found'}
            </h3>
            <p className="text-xs text-slate-400 mt-1.5 max-w-md mx-auto leading-relaxed">
              {filterWorkOrderId 
                ? `Tiket ${filterWorkOrderId} belum mempunyai dokumen keselamatan. Klik butang di bawah untuk membuka borang bersepadu (JSA + PTW).` 
                : 'No matching records for current filters. You can create a new integrated safety document or clear your search filters.'}
            </p>
            <div className="mt-5 flex items-center justify-center gap-2.5 flex-wrap">
              <button
                type="button"
                onClick={() => {
                  const wo = allAvailableWorkOrders.find(w => w.id === filterWorkOrderId);
                  handleOpenCreateModal('JSA + PTW', wo);
                }}
                className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold rounded-lg transition-all cursor-pointer shadow-md flex items-center gap-1.5"
              >
                <ShieldCheck className="w-4 h-4" /> Create Safety Document (JSA + PTW)
              </button>
              {filterWorkOrderId && (
                <button
                  type="button"
                  onClick={() => {
                    setFilterWorkOrderId('');
                    onClearInitialWorkOrder?.();
                  }}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-all cursor-pointer border border-slate-700"
                >
                  Papar Semua Rekod ({totalSafetyDocsCount})
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider font-semibold">
                  <th className="py-3 px-4">Document Ref</th>
                  <th className="py-3 px-3">Document Type</th>
                  <th className="py-3 px-3">Linked Work Order</th>
                  <th className="py-3 px-4">Machine / Asset</th>
                  <th className="py-3 px-3">Assigned Tech</th>
                  <th className="py-3 px-3">Date</th>
                  <th className="py-3 px-3 text-center">Approval Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredDocuments.map(doc => {
                  const isPending = doc.status === 'Pending Approval';
                  const isApproved = doc.status === 'Approved' || doc.status === 'Active';
                  const isRejected = doc.status === 'Rejected';
                  const isDraft = doc.status === 'Draft';
                  const isExpired = doc.status === 'Expired';
                  const isClosed = doc.status === 'Closed';
                  const isIntegrated = doc.documentType === 'JSA + PTW';

                  return (
                    <tr 
                      key={doc.id} 
                      className="hover:bg-slate-800/40 transition-colors group"
                    >
                      {/* Document Reference */}
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-200">
                        <div className="flex items-center gap-1.5">
                          <span 
                            className="text-emerald-400 hover:underline cursor-pointer flex items-center gap-1" 
                            onClick={() => setSelectedDocForView(doc)}
                          >
                            {doc.documentNumber || doc.id}
                          </span>
                        </div>
                      </td>

                      {/* Type Badge */}
                      <td className="py-3.5 px-3">
                        {isIntegrated ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                            <ShieldCheck className="w-3 h-3 text-emerald-400" /> JSA + PTW
                          </span>
                        ) : doc.documentType === 'JSA' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-950/80 text-blue-300 border border-blue-800">
                            <FileText className="w-3 h-3 text-blue-400" /> JSA
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-950/80 text-amber-300 border border-amber-800" title={doc.permitType}>
                            <Flame className="w-3 h-3 text-amber-400" /> {doc.permitType || 'PTW'}
                          </span>
                        )}
                      </td>

                      {/* Linked Work Order */}
                      <td className="py-3.5 px-3 font-mono">
                        {doc.workOrderId ? (
                          <button
                            onClick={() => onNavigateToWorkOrder ? onNavigateToWorkOrder(doc.workOrderId!) : null}
                            className="text-cyan-400 hover:text-cyan-300 hover:underline cursor-pointer flex items-center gap-1"
                            title="Buka butiran Work Order ini"
                          >
                            <span>{doc.workOrderId}</span>
                            <ExternalLink className="w-3 h-3 text-cyan-500" />
                          </button>
                        ) : (
                          <span className="text-slate-500 text-[11px]">Standalone</span>
                        )}
                      </td>

                      {/* Machine / Asset */}
                      <td className="py-3.5 px-4 text-slate-300 font-medium">
                        <div>
                          <span>{doc.machineName}</span>
                          <span className="text-[10px] text-slate-500 block font-mono">
                            {doc.assetId} {doc.machineLocation ? `• ${doc.machineLocation}` : ''}
                          </span>
                        </div>
                      </td>

                      {/* Assigned Tech */}
                      <td className="py-3.5 px-3 text-slate-300">
                        <span>{doc.assignedTechnicianName || doc.createdBy || 'Technician'}</span>
                        {doc.personInCharge && (
                          <span className="text-[10px] text-slate-500 block">PIC: {doc.personInCharge}</span>
                        )}
                      </td>

                      {/* Date */}
                      <td className="py-3.5 px-3 text-slate-400 font-mono text-[11px]">
                        {(doc.workDate || doc.scheduledWorkDate || doc.createdAt || '').split('T')[0]}
                      </td>

                      {/* Approval Status Badge */}
                      <td className="py-3.5 px-3 text-center">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          isApproved
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/80'
                            : isPending
                            ? 'bg-yellow-950 text-yellow-300 border border-yellow-800/80 animate-pulse'
                            : isRejected
                            ? 'bg-rose-950 text-rose-300 border border-rose-800/80'
                            : isExpired
                            ? 'bg-red-950 text-red-400 border border-red-800/80'
                            : isClosed
                            ? 'bg-slate-800 text-slate-400 border border-slate-700'
                            : 'bg-slate-800/80 text-slate-300 border border-slate-700'
                        }`}>
                          {isApproved && <CheckCircle className="w-3 h-3 text-emerald-400" />}
                          {isPending && <Clock className="w-3 h-3 text-yellow-400" />}
                          {isRejected && <XCircle className="w-3 h-3 text-rose-400" />}
                          {doc.status}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setSelectedDocForView(doc)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer"
                            title="Inspect Details"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => handleExportPDF(doc, false)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 hover:text-cyan-200 transition-all cursor-pointer"
                            title="Download PDF"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => handleExportPDF(doc, true)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-300 hover:text-emerald-200 transition-all cursor-pointer"
                            title="Print Document"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>

                          {(isDraft || isRejected) && (
                            <button
                              onClick={() => handleOpenEditModal(doc)}
                              className="p-1.5 rounded-lg bg-blue-900/40 hover:bg-blue-800/60 text-blue-300 border border-blue-700/50 transition-all cursor-pointer"
                              title="Edit / Revise Document"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {currentRole === 'Management' && isPending && (
                            <button
                              onClick={() => handleApproveDocument(doc)}
                              className="px-2 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold transition-all cursor-pointer flex items-center gap-1"
                              title="Sign and Approve Document"
                            >
                              <CheckCircle className="w-3 h-3" /> Approve
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* ONE INTEGRATED SAFETY DOCUMENT MODAL (JSA + PTW UNIFIED FORM) */}
      {/* ========================================================================= */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-5xl max-h-[94vh] flex flex-col shadow-2xl overflow-hidden my-auto">
            {/* Modal Header */}
            <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-gradient-to-br from-emerald-900/60 to-teal-900/40 text-emerald-400 border border-emerald-600/40 shadow-sm">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800/60">
                      {formDocNumber || 'SAF-NEW'}
                    </span>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-teal-300 bg-teal-950/60 px-2 py-0.5 rounded border border-teal-800/40">
                      Integrated JSA + PTW Form
                    </span>
                  </div>
                  <h3 className="font-display font-bold text-white text-base mt-0.5">
                    {selectedDocForEdit ? `Edit Safety Document: ${formDocNumber}` : 'Create Safety Document (JSA + PTW)'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Single unified safety form combining General Job Info, Job Safety Analysis (JSA), Permit to Work (PTW), Checklist, and Approval.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setExpandAllSections(!expandAllSections)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                    expandAllSections 
                      ? 'bg-teal-950/80 text-teal-300 border-teal-700' 
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
                  }`}
                  title="Toggle view between step-by-step tabs and all sections expanded"
                >
                  {expandAllSections ? 'Show Tabbed Mode' : 'Expand All Sections'}
                </button>

                <button
                  onClick={() => setIsCreateModalOpen(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Close modal"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* SECTION PROGRESS NAVIGATION TABS */}
            <div className="bg-slate-950/90 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between gap-1 overflow-x-auto shrink-0">
              {[
                { key: 'A', title: 'SECTION A: General Job Info', icon: FileText, desc: 'Shared Details' },
                { key: 'B', title: 'SECTION B: JSA Risk Analysis', icon: HardHat, desc: 'Hazards & Steps' },
                { key: 'C', title: 'SECTION C: Permit to Work (PTW)', icon: Flame, desc: 'LOTO & Validity' },
                { key: 'D', title: 'SECTION D: Safety Checklist', icon: CheckSquare, desc: 'Precautions' },
                { key: 'E', title: 'SECTION E: Review & Approval', icon: ShieldCheck, desc: 'Sign-off' }
              ].map(sec => {
                const isActive = activeFormSection === sec.key;
                const IconComponent = sec.icon;

                return (
                  <button
                    key={sec.key}
                    type="button"
                    onClick={() => setActiveFormSection(sec.key as any)}
                    className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap border ${
                      isActive
                        ? 'bg-emerald-950/70 text-emerald-300 border-emerald-500/50 shadow-sm'
                        : 'bg-slate-900/60 text-slate-400 border-slate-800/80 hover:text-slate-200 hover:bg-slate-800/50'
                    }`}
                  >
                    <IconComponent className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-400' : 'text-slate-500'}`} />
                    <span className="tracking-wide">{sec.title}</span>
                  </button>
                );
              })}
            </div>

            {/* MODAL SCROLLABLE BODY */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">

              {/* ============================================================= */}
              {/* SECTION A: SHARED GENERAL JOB INFORMATION */}
              {/* ============================================================= */}
              {(expandAllSections || activeFormSection === 'A') && (
                <div className="bg-slate-950/70 p-5 rounded-2xl border border-slate-800 space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-blue-950 text-blue-400 border border-blue-800/50">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-display font-bold text-white text-sm">
                          SECTION A: General Job Information
                        </h4>
                        <p className="text-[11px] text-slate-400">
                          Shared general information entered once for both JSA and PTW. Auto-retrieved when Work Order is selected.
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/50">
                      Step 1 of 5
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                    {/* 1. Safety Document Reference Number */}
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Safety Document Ref # <span className="text-rose-400">*</span>
                      </label>
                      <input
                        type="text"
                        value={formDocNumber}
                        onChange={e => setFormDocNumber(e.target.value)}
                        placeholder="e.g. SAF-2026-0001"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 font-mono focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    {/* 2. Link Work Order ID */}
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Work Order ID <span className="text-cyan-400 font-normal">(Auto-Retrieval)</span>
                      </label>
                      <select
                        value={formWorkOrderId}
                        onChange={e => handleSelectWorkOrder(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                      >
                        <option value="">-- Standalone (No Work Order Link) --</option>
                        {allAvailableWorkOrders.map(wo => (
                          <option key={wo.id} value={wo.id}>
                            {wo.id} - {wo.assetName} ({wo.priority} Priority) - {(wo.issue || 'Work Order').slice(0, 30)}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* 3. Machine Name */}
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Machine Name <span className="text-rose-400">*</span>
                      </label>
                      <input
                        type="text"
                        value={formMachineName}
                        onChange={e => setFormMachineName(e.target.value)}
                        placeholder="e.g. Conventional Lathe Machine"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    {/* 4. Asset ID */}
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Asset ID
                      </label>
                      <select
                        value={formAssetId}
                        onChange={e => handleSelectAsset(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                      >
                        <option value="">-- Choose Registered Asset --</option>
                        {allAvailableAssets.map(a => (
                          <option key={a.id} value={a.id}>
                            {a.name} [{a.id}] - Location: {a.location || 'General'}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* 5. Machine Serial Number */}
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Machine Serial Number
                      </label>
                      <input
                        type="text"
                        value={formMachineSerialNumber}
                        onChange={e => setFormMachineSerialNumber(e.target.value)}
                        placeholder="e.g. SN-88294-MCH"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 font-mono focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    {/* 6. Machine Location */}
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Machine Location
                      </label>
                      <input
                        type="text"
                        value={formMachineLocation}
                        onChange={e => {
                          setFormMachineLocation(e.target.value);
                          if (!formWorkLocationDetail) setFormWorkLocationDetail(e.target.value);
                        }}
                        placeholder="e.g. Workshop Bay 3, Ground Floor"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    {/* 7. Department */}
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Department
                      </label>
                      <select
                        value={formDepartment}
                        onChange={e => setFormDepartment(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                      >
                        <option value="Mechanical & Electrical">Mechanical & Electrical</option>
                        <option value="Production & Assembly">Production & Assembly</option>
                        <option value="Machining & Tooling">Machining & Tooling</option>
                        <option value="Plant Facilities & Utilities">Plant Facilities & Utilities</option>
                        <option value="Quality Assurance">Quality Assurance</option>
                        <option value="Warehouse & Logistics">Warehouse & Logistics</option>
                      </select>
                    </div>

                    {/* 8. Maintenance Type */}
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Maintenance Type
                      </label>
                      <select
                        value={formMaintenanceType}
                        onChange={e => setFormMaintenanceType(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                      >
                        <option value="Corrective Maintenance">Corrective Maintenance (CM)</option>
                        <option value="Preventive Maintenance">Preventive Maintenance (PM)</option>
                        <option value="Breakdown Repair">Breakdown Repair</option>
                        <option value="Overhaul / Major Servicing">Overhaul / Major Servicing</option>
                        <option value="Safety Inspection & Testing">Safety Inspection & Testing</option>
                        <option value="Emergency Rectification">Emergency Rectification</option>
                      </select>
                    </div>

                    {/* 9. Job Title */}
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Job Title
                      </label>
                      <input
                        type="text"
                        value={formJobTitle}
                        onChange={e => setFormJobTitle(e.target.value)}
                        placeholder="e.g. Main Drive Bearing Replacement & LOTO Service"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    {/* 10. Work Date */}
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Work Date
                      </label>
                      <input
                        type="date"
                        value={formWorkDate}
                        onChange={e => setFormWorkDate(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    {/* 11. Planned Start Date and Time */}
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Planned Start Date & Time <span className="text-rose-400">*</span>
                      </label>
                      <input
                        type="datetime-local"
                        value={formValidityStart}
                        onChange={e => setFormValidityStart(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    {/* 12. Planned End Date and Time */}
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Planned End Date & Time <span className="text-rose-400">*</span>
                      </label>
                      <input
                        type="datetime-local"
                        value={formValidityEnd}
                        onChange={e => setFormValidityEnd(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    {/* 13. Requested By */}
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Requested By
                      </label>
                      <input
                        type="text"
                        value={formRequestedBy}
                        onChange={e => setFormRequestedBy(e.target.value)}
                        placeholder="e.g. Engineering Management"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    {/* 14. Assigned Technician */}
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Assigned Technician <span className="text-rose-400">*</span>
                      </label>
                      <input
                        type="text"
                        value={formAssignedTechName}
                        onChange={e => setFormAssignedTechName(e.target.value)}
                        placeholder="e.g. Ahmad (Mechanical Lead)"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    {/* 15. Person in Charge */}
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Person in Charge (PIC) / Supervisor
                      </label>
                      <input
                        type="text"
                        value={formPersonInCharge}
                        onChange={e => setFormPersonInCharge(e.target.value)}
                        placeholder="e.g. Safety Supervisor / Plant Engineer"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  </div>

                  {/* 16. Job Description */}
                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">
                      Job Description & Work Scope <span className="text-rose-400">*</span>
                    </label>
                    <textarea
                      rows={3}
                      value={formJobDescription}
                      onChange={e => setFormJobDescription(e.target.value)}
                      placeholder="Provide comprehensive details of the maintenance procedure, components to service, and tools to be used..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  {!expandAllSections && (
                    <div className="flex justify-end pt-2">
                      <button
                        type="button"
                        onClick={() => setActiveFormSection('B')}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
                      >
                        Next: Section B (JSA) <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* ============================================================= */}
              {/* SECTION B: JOB SAFETY ANALYSIS (JSA) */}
              {/* ============================================================= */}
              {(expandAllSections || activeFormSection === 'B') && (
                <div className="bg-slate-950/70 p-5 rounded-2xl border border-slate-800 space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-blue-950 text-blue-400 border border-blue-800/50">
                        <HardHat className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-display font-bold text-white text-sm">
                          SECTION B: Job Safety Analysis (JSA)
                        </h4>
                        <p className="text-[11px] text-slate-400">
                          Identify hazards, required PPE, safe work practices, and step-by-step risk mitigations.
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/50">
                      Step 2 of 5
                    </span>
                  </div>

                  {/* Required PPE */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="font-semibold text-slate-200 text-xs flex items-center gap-1.5">
                        <HardHat className="w-3.5 h-3.5 text-blue-400" />
                        Required Personal Protective Equipment (PPE) <span className="text-rose-400">*</span>
                      </label>
                      <span className="text-[10px] text-slate-400">
                        {formRequiredPPE.length} items selected
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                      {COMMON_PPE_LIST.map(ppe => {
                        const isChecked = formRequiredPPE.includes(ppe);
                        return (
                          <label
                            key={ppe}
                            onClick={() => {
                              if (isChecked) {
                                setFormRequiredPPE(prev => prev.filter(p => p !== ppe));
                              } else {
                                setFormRequiredPPE(prev => [...prev, ppe]);
                              }
                            }}
                            className={`p-2 rounded-lg border transition-all flex items-center gap-2 cursor-pointer ${
                              isChecked
                                ? 'bg-blue-950/70 border-blue-600 text-blue-200 font-semibold'
                                : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => {}}
                              className="w-3.5 h-3.5 text-blue-600 rounded"
                            />
                            <span className="truncate text-[11px]">{ppe}</span>
                          </label>
                        );
                      })}
                    </div>

                    {/* Add Custom PPE */}
                    <div className="flex items-center gap-2 pt-1">
                      <input
                        type="text"
                        placeholder="Add other required PPE..."
                        value={customPpeInput}
                        onChange={e => setCustomPpeInput(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), handleAddCustomPPE())}
                        className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 flex-1 focus:outline-none focus:border-blue-500"
                      />
                      <button
                        type="button"
                        onClick={handleAddCustomPPE}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold cursor-pointer border border-slate-700"
                      >
                        + Add Custom PPE
                      </button>
                    </div>
                  </div>

                  {/* Identified Hazards */}
                  <div className="space-y-2 pt-2 border-t border-slate-800/80">
                    <div className="flex items-center justify-between">
                      <label className="font-semibold text-slate-200 text-xs flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                        Identified Workplace Hazards <span className="text-rose-400">*</span>
                      </label>
                      <span className="text-[10px] text-slate-400">
                        {formIdentifiedHazards.length} hazards identified
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                      {COMMON_HAZARDS.map(hz => {
                        const isChecked = formIdentifiedHazards.includes(hz);
                        return (
                          <label
                            key={hz}
                            onClick={() => {
                              if (isChecked) {
                                setFormIdentifiedHazards(prev => prev.filter(h => h !== hz));
                              } else {
                                setFormIdentifiedHazards(prev => [...prev, hz]);
                              }
                            }}
                            className={`p-2 rounded-lg border transition-all flex items-center gap-2 cursor-pointer ${
                              isChecked
                                ? 'bg-amber-950/70 border-amber-600 text-amber-200 font-semibold'
                                : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => {}}
                              className="w-3.5 h-3.5 text-amber-600 rounded"
                            />
                            <span className="truncate text-[11px]">{hz}</span>
                          </label>
                        );
                      })}
                    </div>

                    {/* Add Custom Hazard */}
                    <div className="flex items-center gap-2 pt-1">
                      <input
                        type="text"
                        placeholder="Add other identified hazard..."
                        value={customHazardInput}
                        onChange={e => setCustomHazardInput(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), handleAddCustomHazard())}
                        className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 flex-1 focus:outline-none focus:border-amber-500"
                      />
                      <button
                        type="button"
                        onClick={handleAddCustomHazard}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold cursor-pointer border border-slate-700"
                      >
                        + Add Custom Hazard
                      </button>
                    </div>
                  </div>

                  {/* Step-by-Step JSA Table */}
                  <div className="space-y-3 pt-2 border-t border-slate-800/80">
                    <div className="flex items-center justify-between">
                      <div>
                        <h5 className="font-semibold text-slate-200 text-xs flex items-center gap-1.5">
                          <CheckSquare className="w-3.5 h-3.5 text-blue-400" />
                          Step-by-Step Risk Assessment & Safe Work Practices <span className="text-rose-400">*</span>
                        </h5>
                        <p className="text-[10px] text-slate-400">Break the job sequence into steps with dedicated hazards and control measures.</p>
                      </div>
                      <button
                        type="button"
                        onClick={handleAddJobStep}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-all shadow-sm"
                      >
                        <Plus className="w-3 h-3" /> + Add Job Step
                      </button>
                    </div>

                    <div className="space-y-2.5">
                      {formJobSteps.map((step, idx) => (
                        <div key={idx} className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-2">
                          <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                            <span className="flex items-center gap-1.5">
                              <span className="w-5 h-5 rounded-full bg-blue-900/60 text-blue-300 flex items-center justify-center text-[10px]">
                                {step.stepNumber || idx + 1}
                              </span>
                              Step #{step.stepNumber || idx + 1}
                            </span>
                            {formJobSteps.length > 1 && (
                              <button
                                type="button"
                                onClick={() => handleRemoveJobStep(idx)}
                                className="text-rose-400 hover:text-rose-300 cursor-pointer text-[11px]"
                              >
                                Remove Step
                              </button>
                            )}
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
                            <div>
                              <label className="block text-[10px] font-semibold text-slate-400 mb-0.5">Job Sequence / Step Description</label>
                              <input
                                type="text"
                                value={step.stepDescription}
                                onChange={e => handleUpdateJobStep(idx, 'stepDescription', e.target.value)}
                                placeholder="e.g. Disconnect pneumatic supply and bleed lines"
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 text-xs focus:outline-none focus:border-blue-500"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] font-semibold text-rose-400 mb-0.5">Potential Hazards</label>
                              <input
                                type="text"
                                value={step.hazards}
                                onChange={e => handleUpdateJobStep(idx, 'hazards', e.target.value)}
                                placeholder="e.g. Trapped pneumatic pressure discharge"
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-rose-300 text-xs focus:outline-none focus:border-rose-500"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] font-semibold text-emerald-400 mb-0.5">Control Measures / Safe Practice</label>
                              <input
                                type="text"
                                value={step.controlMeasures}
                                onChange={e => handleUpdateJobStep(idx, 'controlMeasures', e.target.value)}
                                placeholder="e.g. Bleed via dump valve, verify gauge zero, wear goggles"
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-emerald-300 text-xs focus:outline-none focus:border-emerald-500"
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Overall Controls & Emergency Procedures */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-slate-800/80">
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Overall Control Measures / Safe Work Method Statement
                      </label>
                      <textarea
                        rows={2}
                        value={formControlMeasures}
                        onChange={e => setFormControlMeasures(e.target.value)}
                        placeholder="Summary of general engineering controls, permits, or supervisor verifications..."
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-200 text-xs focus:outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Emergency Procedures & Actions
                      </label>
                      <textarea
                        rows={2}
                        value={formEmergencyProcedures}
                        onChange={e => setFormEmergencyProcedures(e.target.value)}
                        placeholder="Emergency shutoff locations, nearest eyewash, first-aider phone..."
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-200 text-xs focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  {!expandAllSections && (
                    <div className="flex justify-between pt-2">
                      <button
                        type="button"
                        onClick={() => setActiveFormSection('A')}
                        className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <ArrowLeft className="w-4 h-4" /> Back to Section A
                      </button>
                      <button
                        type="button"
                        onClick={() => setActiveFormSection('C')}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
                      >
                        Next: Section C (PTW) <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* ============================================================= */}
              {/* SECTION C: PERMIT TO WORK (PTW) */}
              {/* ============================================================= */}
              {(expandAllSections || activeFormSection === 'C') && (
                <div className="bg-slate-950/70 p-5 rounded-2xl border border-slate-800 space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-amber-950 text-amber-400 border border-amber-800/50">
                        <Flame className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-display font-bold text-white text-sm">
                          SECTION C: Permit to Work (PTW)
                        </h4>
                        <p className="text-[11px] text-slate-400">
                          Authorize high-risk work, energy isolation (LOTO), atmospheric testing, and dedicated fire watch/sentry.
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/50">
                      Step 3 of 5
                    </span>
                  </div>

                  {/* Permit Type & Location */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Permit Authorization Category <span className="text-rose-400">*</span>
                      </label>
                      <select
                        value={formPermitType}
                        onChange={e => setFormPermitType(e.target.value as PTWPermitType)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 font-semibold focus:outline-none focus:border-amber-500"
                      >
                        <option value="Hot Work">Hot Work (Welding, Cutting, Grinding, Open Torch)</option>
                        <option value="Confined Space">Confined Space Entry</option>
                        <option value="Electrical / High Voltage">Electrical / High Voltage Work</option>
                        <option value="Working at Height">Working at Height (&gt; 2 meters, Scaffold, MEWP)</option>
                        <option value="Cold Work / Mechanical Isolation">Cold Work / Mechanical Energy Lockout</option>
                        <option value="Chemical / Hazardous Material">Chemical / Hazardous Material Handling</option>
                        <option value="General Hazardous Work">General Hazardous Work</option>
                      </select>
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Specific Work Location Detail
                      </label>
                      <input
                        type="text"
                        value={formWorkLocationDetail}
                        onChange={e => setFormWorkLocationDetail(e.target.value)}
                        placeholder="e.g. Inside Lathe Enclosure, Bay 3"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  {/* Energy Isolation & LOTO Table */}
                  <div className="space-y-3 pt-2 border-t border-slate-800/80">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Lock className="w-4 h-4 text-rose-400" />
                        <div>
                          <h5 className="font-semibold text-slate-200 text-xs">
                            Energy Isolation & Lockout-Tagout (LOTO) Table
                          </h5>
                          <p className="text-[10px] text-slate-400">Verify all sources of electrical, mechanical, and pneumatic energy are locked out.</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <label className="flex items-center gap-1.5 cursor-pointer text-xs font-semibold text-slate-300">
                          <input
                            type="checkbox"
                            checked={formIsolationRequired}
                            onChange={e => setFormIsolationRequired(e.target.checked)}
                            className="w-4 h-4 text-rose-600 rounded"
                          />
                          <span>Isolation Mandatory</span>
                        </label>
                        <button
                          type="button"
                          onClick={handleAddIsolationRow}
                          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-bold border border-slate-700 cursor-pointer"
                        >
                          + Add Isolation Point
                        </button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      {formIsolations.map((iso, idx) => (
                        <div key={idx} className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 flex flex-col md:flex-row md:items-center gap-2.5">
                          <label className="flex items-center gap-2 cursor-pointer min-w-[200px]">
                            <input
                              type="checkbox"
                              checked={iso.applied}
                              onChange={() => handleToggleIsolationApplied(idx)}
                              className="w-4 h-4 text-emerald-600 rounded"
                            />
                            <span className={`font-semibold text-xs ${iso.applied ? 'text-emerald-300' : 'text-slate-400'}`}>
                              {iso.type}
                            </span>
                          </label>

                          <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-2">
                            <input
                              type="text"
                              value={iso.isolationPoint || ''}
                              onChange={e => handleUpdateIsolationField(idx, 'isolationPoint', e.target.value)}
                              placeholder="Isolation point (e.g. Q1 Main Breaker)"
                              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none"
                            />
                            <input
                              type="text"
                              value={iso.tagOrLockNumber || ''}
                              onChange={e => handleUpdateIsolationField(idx, 'tagOrLockNumber', e.target.value)}
                              placeholder="Padlock / Tag #"
                              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono focus:outline-none"
                            />
                            <div className="flex items-center gap-1.5">
                              <input
                                type="text"
                                value={iso.verifiedBy || ''}
                                onChange={e => handleUpdateIsolationField(idx, 'verifiedBy', e.target.value)}
                                placeholder="Verified by Name"
                                className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none"
                              />
                              {formIsolations.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => handleRemoveIsolationRow(idx)}
                                  className="text-rose-400 hover:text-rose-300 p-1 cursor-pointer"
                                  title="Remove isolation row"
                                >
                                  ✕
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Atmospheric Gas Testing & Safety Sentry */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-2 border-t border-slate-800/80">
                    {/* Gas Testing */}
                    <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <label className="font-semibold text-slate-200 flex items-center gap-2">
                          <Activity className="w-4 h-4 text-cyan-400" />
                          Atmospheric Gas Testing
                        </label>
                        <input
                          type="checkbox"
                          checked={formGasTestingRequired}
                          onChange={e => setFormGasTestingRequired(e.target.checked)}
                          className="w-4 h-4 text-cyan-600 rounded cursor-pointer"
                        />
                      </div>

                      {formGasTestingRequired ? (
                        <div className="grid grid-cols-3 gap-2 pt-1">
                          <div>
                            <span className="block text-[10px] text-slate-400 mb-0.5">Oxygen (O2)</span>
                            <input
                              type="text"
                              value={formGasOxygen}
                              onChange={e => setFormGasOxygen(e.target.value)}
                              placeholder="20.9%"
                              className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-xs font-mono text-slate-200"
                            />
                          </div>
                          <div>
                            <span className="block text-[10px] text-slate-400 mb-0.5">Flammable (LEL)</span>
                            <input
                              type="text"
                              value={formGasLel}
                              onChange={e => setFormGasLel(e.target.value)}
                              placeholder="<1%"
                              className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-xs font-mono text-slate-200"
                            />
                          </div>
                          <div>
                            <span className="block text-[10px] text-slate-400 mb-0.5">Toxic (H2S/CO)</span>
                            <input
                              type="text"
                              value={formGasToxic}
                              onChange={e => setFormGasToxic(e.target.value)}
                              placeholder="0 ppm"
                              className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-xs font-mono text-slate-200"
                            />
                          </div>
                        </div>
                      ) : (
                        <p className="text-[11px] text-slate-500">
                          Gas testing not required for current maintenance environment. Check box above if entering confined space or hot-work area.
                        </p>
                      )}
                    </div>

                    {/* Standby Person / Fire Watch */}
                    <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <label className="font-semibold text-slate-200 flex items-center gap-2">
                          <User className="w-4 h-4 text-amber-400" />
                          Standby Person (Sentry) / Fire Watch
                        </label>
                        <label className="flex items-center gap-1.5 text-[11px] text-slate-300 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={formFireWatchAssigned}
                            onChange={e => setFormFireWatchAssigned(e.target.checked)}
                            className="w-3.5 h-3.5 text-amber-600 rounded"
                          />
                          <span>Fire Watch Assigned</span>
                        </label>
                      </div>

                      <div>
                        <input
                          type="text"
                          value={formStandbyPerson}
                          onChange={e => setFormStandbyPerson(e.target.value)}
                          placeholder="Full Name of appointed safety sentry / standby observer..."
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Emergency Rescue Plan */}
                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">
                      Emergency Rescue Plan & Fire Extinguisher Station
                    </label>
                    <textarea
                      rows={2}
                      value={formEmergencyRescuePlan}
                      onChange={e => setFormEmergencyRescuePlan(e.target.value)}
                      placeholder="Specify emergency rescue gear, standby fire extinguisher location, evacuation route..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  {!expandAllSections && (
                    <div className="flex justify-between pt-2">
                      <button
                        type="button"
                        onClick={() => setActiveFormSection('B')}
                        className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <ArrowLeft className="w-4 h-4" /> Back to Section B
                      </button>
                      <button
                        type="button"
                        onClick={() => setActiveFormSection('D')}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
                      >
                        Next: Section D (Checklist) <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* ============================================================= */}
              {/* SECTION D: SAFETY CHECKLIST */}
              {/* ============================================================= */}
              {(expandAllSections || activeFormSection === 'D') && (
                <div className="bg-slate-950/70 p-5 rounded-2xl border border-slate-800 space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-teal-950 text-teal-400 border border-teal-800/50">
                        <CheckSquare className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-display font-bold text-white text-sm">
                          SECTION D: Pre-Work Safety Checklist & Precautions
                        </h4>
                        <p className="text-[11px] text-slate-400">
                          Mandatory physical verification checklist to ensure all safety controls are in place before work commences.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setFormSafetyChecklist([...DEFAULT_SAFETY_CHECKLIST])}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-emerald-300 rounded text-[11px] font-bold border border-slate-700 cursor-pointer"
                      >
                        ✓ Select All Standard
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormSafetyChecklist([])}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded text-[11px] font-semibold border border-slate-700 cursor-pointer"
                      >
                        Clear All
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {DEFAULT_SAFETY_CHECKLIST.map((item, idx) => {
                      const isChecked = formSafetyChecklist.includes(item);
                      return (
                        <label
                          key={idx}
                          onClick={() => handleToggleChecklistItem(item)}
                          className={`p-3 rounded-xl border transition-all flex items-start gap-2.5 cursor-pointer ${
                            isChecked
                              ? 'bg-emerald-950/60 border-emerald-600/70 text-emerald-200'
                              : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}}
                            className="w-4 h-4 mt-0.5 text-emerald-600 rounded shrink-0"
                          />
                          <span className="text-[11px] font-medium leading-relaxed">{item}</span>
                        </label>
                      );
                    })}
                  </div>

                  {/* Add Custom Safety Checklist Item */}
                  <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
                    <input
                      type="text"
                      placeholder="Add custom pre-work safety precaution..."
                      value={customChecklistItem}
                      onChange={e => setCustomChecklistItem(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), handleAddCustomChecklistItem())}
                      className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 flex-1 focus:outline-none focus:border-teal-500"
                    />
                    <button
                      type="button"
                      onClick={handleAddCustomChecklistItem}
                      className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold cursor-pointer border border-slate-700"
                    >
                      + Add Item
                    </button>
                  </div>

                  {!expandAllSections && (
                    <div className="flex justify-between pt-2">
                      <button
                        type="button"
                        onClick={() => setActiveFormSection('C')}
                        className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <ArrowLeft className="w-4 h-4" /> Back to Section C
                      </button>
                      <button
                        type="button"
                        onClick={() => setActiveFormSection('E')}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
                      >
                        Next: Section E (Review & Approval) <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* ============================================================= */}
              {/* SECTION E: REVIEW AND APPROVAL */}
              {/* ============================================================= */}
              {(expandAllSections || activeFormSection === 'E') && (
                <div className="bg-slate-950/70 p-5 rounded-2xl border border-slate-800 space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800/50">
                        <ShieldCheck className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-display font-bold text-white text-sm">
                          SECTION E: Review and Approval
                        </h4>
                        <p className="text-[11px] text-slate-400">
                          Review summary of all sections, technician certification, person in charge endorsement, and official management sign-off.
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/50">
                      Step 5 of 5
                    </span>
                  </div>

                  {/* Summary Overview Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-900 p-4 rounded-xl border border-slate-800">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Document Ref</span>
                      <span className="font-mono font-bold text-emerald-400 text-sm">{formDocNumber || 'SAF-NEW'}</span>
                      <span className="text-[10px] text-slate-500 block">WO: {formWorkOrderId || 'Standalone'}</span>
                    </div>

                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Target Equipment</span>
                      <span className="font-semibold text-slate-200 text-xs truncate block">{formMachineName || 'General Machine'}</span>
                      <span className="text-[10px] text-slate-500 block">{formMachineLocation || 'Workshop Site'}</span>
                    </div>

                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">JSA Compliance</span>
                      <span className="font-semibold text-blue-400 text-xs block">{formJobSteps.length} Job Steps Defined</span>
                      <span className="text-[10px] text-slate-500 block">{formRequiredPPE.length} PPE • {formIdentifiedHazards.length} Hazards</span>
                    </div>

                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">PTW & Checklist</span>
                      <span className="font-semibold text-amber-400 text-xs block">{formPermitType} Permit</span>
                      <span className="text-[10px] text-slate-500 block">{formSafetyChecklist.length} Precautions Verified</span>
                    </div>
                  </div>

                  {/* Sign-off Boxes */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Box 1: Prepared / Submitted By */}
                    <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3">
                      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                        <span className="font-semibold text-slate-200 flex items-center gap-1.5 text-xs">
                          <User className="w-3.5 h-3.5 text-blue-400" />
                          Prepared & Submitted By (Technician)
                        </span>
                        <span className="text-[10px] text-slate-500">{new Date().toISOString().split('T')[0]}</span>
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Technician Name:</span>
                          <span className="font-bold text-slate-200">{formAssignedTechName || authorizedUser || 'Technician'}</span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Person in Charge (PIC):</span>
                          <span className="font-medium text-slate-300">{formPersonInCharge || 'Supervisor'}</span>
                        </div>
                      </div>

                      <label className="flex items-start gap-2 pt-2 border-t border-slate-800 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formTechnicianDeclaration}
                          onChange={e => setFormTechnicianDeclaration(e.target.checked)}
                          className="w-4 h-4 mt-0.5 text-emerald-600 rounded shrink-0"
                        />
                        <span className="text-[11px] text-slate-300 leading-tight">
                          I declare that I have surveyed the job site, identified all hazards, verified energy isolations, and briefed the work crew on risk controls.
                        </span>
                      </label>
                    </div>

                    {/* Box 2: Management / Safety Officer Authorization */}
                    <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3">
                      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                        <span className="font-semibold text-slate-200 flex items-center gap-1.5 text-xs">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                          Management / Safety Approval
                        </span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                          selectedDocForEdit?.approvedBy ? 'bg-emerald-950 text-emerald-300' : 'bg-yellow-950 text-yellow-300'
                        }`}>
                          {selectedDocForEdit?.approvedBy ? 'OFFICIAL APPROVED' : 'PENDING APPROVAL'}
                        </span>
                      </div>

                      {selectedDocForEdit?.approvedBy ? (
                        <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-lg text-xs space-y-1">
                          <div className="flex items-center justify-between text-emerald-300 font-bold">
                            <span>Approved By: {selectedDocForEdit.approvedBy}</span>
                            <span>{selectedDocForEdit.approvalRole || 'Management'}</span>
                          </div>
                          <p className="text-[11px] text-slate-400 font-mono">Date: {(selectedDocForEdit.approvedAt || '').replace('T', ' ').slice(0, 16)}</p>
                          <div className="text-[11px] text-emerald-400 font-semibold mt-1">✓ Statutory Safe Work Permit Authorized</div>
                        </div>
                      ) : (
                        <div className="space-y-2 text-xs">
                          <label className="block text-slate-400 text-[11px]">Supervisor / Safety Endorsement Notes:</label>
                          <input
                            type="text"
                            value={formPicEndorsementRemarks}
                            onChange={e => setFormPicEndorsementRemarks(e.target.value)}
                            placeholder="Add safety endorsement remarks..."
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 text-xs focus:outline-none focus:border-emerald-500"
                          />
                          <p className="text-[11px] text-slate-400">
                            {currentRole === 'Management' 
                              ? 'As Management, you can directly sign and approve this document or save as draft.' 
                              : 'Upon submission, this document will be queued for formal Management authorization.'}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  {!expandAllSections && (
                    <div className="flex justify-between pt-2">
                      <button
                        type="button"
                        onClick={() => setActiveFormSection('D')}
                        className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <ArrowLeft className="w-4 h-4" /> Back to Section D
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* MODAL ACTION BUTTONS FOOTER */}
            <div className="px-6 py-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer transition-all"
              >
                Cancel
              </button>

              <div className="flex items-center gap-2.5 flex-wrap">
                {/* Save Draft Button */}
                <button
                  type="button"
                  onClick={() => handleSaveDocument(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-700/40 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <FileText className="w-3.5 h-3.5" />
                  Save as Draft
                </button>

                {/* Validate & Submit for Approval Button */}
                <button
                  type="button"
                  onClick={() => handleSaveDocument(true)}
                  className="px-5 py-2 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-950/60 transition-all cursor-pointer flex items-center gap-1.5 border border-emerald-400/40"
                >
                  <ShieldCheck className="w-4 h-4" />
                  Validate & Submit for Approval
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: VIEW DOCUMENT DETAILS & INSPECTION MODAL */}
      {/* ========================================================================= */}
      {selectedDocForView && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden my-auto">
            {/* Header */}
            <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between shrink-0">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-sm font-bold text-emerald-400">
                    {selectedDocForView.documentNumber || selectedDocForView.id}
                  </span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                    selectedDocForView.status === 'Approved' || selectedDocForView.status === 'Active'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : selectedDocForView.status === 'Pending Approval'
                      ? 'bg-yellow-950 text-yellow-300 border border-yellow-800'
                      : selectedDocForView.status === 'Rejected'
                      ? 'bg-rose-950 text-rose-300 border border-rose-800'
                      : 'bg-slate-800 text-slate-400'
                  }`}>
                    {selectedDocForView.status}
                  </span>
                  {selectedDocForView.documentType === 'JSA + PTW' && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-950 text-teal-300 border border-teal-800">
                      Integrated Document
                    </span>
                  )}
                </div>
                <h3 className="text-white font-display font-bold text-base mt-0.5">
                  {selectedDocForView.jobTitle || selectedDocForView.jobDescription?.slice(0, 50) || 'Safety Document Record'}
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleExportPDF(selectedDocForView, false)}
                  className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer"
                  title="Export PDF"
                >
                  <Download className="w-3.5 h-3.5" /> PDF
                </button>
                <button
                  onClick={() => handleExportPDF(selectedDocForView, true)}
                  className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer"
                  title="Print A4"
                >
                  <Printer className="w-3.5 h-3.5" /> Print
                </button>
                <button
                  onClick={() => setSelectedDocForView(null)}
                  className="p-1.5 text-slate-400 hover:text-white"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Content Body */}
            <div className="p-6 overflow-y-auto space-y-5 text-xs">
              {/* SECTION A SUMMARY: Shared Job Details */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2.5">
                <h4 className="font-bold text-slate-300 text-xs flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-blue-400" />
                  SECTION A: General Job Information
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-slate-300">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">Linked Work Order</span>
                    <span className="font-mono font-semibold text-cyan-300">{selectedDocForView.workOrderId || 'Standalone'}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">Machine / Asset</span>
                    <span className="font-semibold text-slate-200">{selectedDocForView.machineName} ({selectedDocForView.assetId})</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">Location</span>
                    <span className="text-slate-200">{selectedDocForView.machineLocation || 'Workshop Site'}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">Department / Type</span>
                    <span className="text-slate-200">{selectedDocForView.department || selectedDocForView.maintenanceType}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800/80">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Job Description:</span>
                  <p className="text-slate-200 leading-relaxed bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                    {selectedDocForView.jobDescription}
                  </p>
                </div>
              </div>

              {/* SECTION B: JSA Details */}
              {(selectedDocForView.jobSteps || selectedDocForView.requiredPPE) && (
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                  <h4 className="font-bold text-slate-300 text-xs flex items-center gap-1.5">
                    <HardHat className="w-3.5 h-3.5 text-blue-400" />
                    SECTION B: Job Safety Analysis (JSA)
                  </h4>

                  {/* PPE */}
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Required PPE:</span>
                    <div className="flex flex-wrap gap-1.5">
                      {(selectedDocForView.requiredPPE || []).map((ppe, i) => (
                        <span key={i} className="px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800 text-[11px]">
                          {ppe}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Hazards */}
                  {selectedDocForView.identifiedHazards && selectedDocForView.identifiedHazards.length > 0 && (
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Identified Hazards:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedDocForView.identifiedHazards.map((h, i) => (
                          <span key={i} className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 text-[11px]">
                            {h}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Steps Table */}
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Risk Assessment Steps:</span>
                    <div className="border border-slate-800 rounded-xl overflow-hidden">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-900 text-[10px] uppercase text-slate-400 font-bold border-b border-slate-800">
                          <tr>
                            <th className="p-2 w-10 text-center">#</th>
                            <th className="p-2">Task Sequence</th>
                            <th className="p-2">Potential Hazards</th>
                            <th className="p-2">Control Measures</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60 bg-slate-950">
                          {(selectedDocForView.jobSteps || []).map((s, idx) => (
                            <tr key={idx}>
                              <td className="p-2 text-center font-bold text-slate-400">{s.stepNumber || idx + 1}</td>
                              <td className="p-2 text-slate-200">{s.stepDescription}</td>
                              <td className="p-2 text-rose-300">{s.hazards}</td>
                              <td className="p-2 text-emerald-300">{s.controlMeasures}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* SECTION C: PTW Details */}
              {(selectedDocForView.permitType || selectedDocForView.isolations) && (
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                  <h4 className="font-bold text-slate-300 text-xs flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-amber-400" />
                    SECTION C: Permit to Work (PTW) Details
                  </h4>

                  <div className="grid grid-cols-2 gap-3 bg-slate-900 p-3 rounded-lg border border-slate-800">
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-bold block">Permit Type</span>
                      <span className="font-semibold text-amber-300">{selectedDocForView.permitType || 'Hot Work'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-bold block">Validity Window</span>
                      <span className="font-mono text-emerald-400 font-semibold">
                        {(selectedDocForView.validityStart || selectedDocForView.plannedStartTime || '').replace('T', ' ')} to {(selectedDocForView.validityEnd || selectedDocForView.plannedEndTime || '').replace('T', ' ')}
                      </span>
                    </div>
                  </div>

                  {/* LOTO Isolations */}
                  {selectedDocForView.isolations && selectedDocForView.isolations.length > 0 && (
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Energy Isolations (LOTO):</span>
                      <div className="border border-slate-800 rounded-xl overflow-hidden">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-slate-900 text-[10px] uppercase text-slate-400 font-bold border-b border-slate-800">
                            <tr>
                              <th className="p-2">Isolation Type</th>
                              <th className="p-2 text-center">Applied</th>
                              <th className="p-2">Point</th>
                              <th className="p-2">Tag/Lock #</th>
                              <th className="p-2">Verified By</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-800/60 bg-slate-950">
                            {selectedDocForView.isolations.map((iso, idx) => (
                              <tr key={idx}>
                                <td className="p-2 font-medium text-slate-200">{iso.type}</td>
                                <td className="p-2 text-center">
                                  {iso.applied ? (
                                    <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[10px] font-bold">YES</span>
                                  ) : (
                                    <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-500 text-[10px]">NO</span>
                                  )}
                                </td>
                                <td className="p-2 text-slate-300">{iso.isolationPoint || 'N/A'}</td>
                                <td className="p-2 font-mono text-cyan-300">{iso.tagOrLockNumber || 'N/A'}</td>
                                <td className="p-2 text-slate-300">{iso.verifiedBy || 'N/A'}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* SECTION D: Safety Checklist */}
              {selectedDocForView.safetyPrecautions && selectedDocForView.safetyPrecautions.length > 0 && (
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                  <h4 className="font-bold text-slate-300 text-xs flex items-center gap-1.5">
                    <CheckSquare className="w-3.5 h-3.5 text-teal-400" />
                    SECTION D: Verified Safety Precautions Checklist
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                    {selectedDocForView.safetyPrecautions.map((p, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-slate-300 bg-slate-900/60 p-2 rounded-lg border border-slate-800/80">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span className="text-[11px]">{p}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* SECTION E: Review and Official Approval */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <h4 className="font-bold text-slate-300 text-xs flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  SECTION E: Official Authorisation & Sign-off Status
                </h4>
                {selectedDocForView.approvedBy ? (
                  <div className="flex items-center justify-between text-xs text-emerald-400 bg-emerald-950/40 p-3 rounded-lg border border-emerald-800/60">
                    <div>
                      <span className="font-bold">Approved By: </span>
                      <span>{selectedDocForView.approvedBy} ({selectedDocForView.approvalRole || 'Management'})</span>
                      <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                        Date: {(selectedDocForView.approvedAt || '').replace('T', ' ').slice(0, 16)}
                      </p>
                    </div>
                    <span className="px-2.5 py-1 rounded-full bg-emerald-900/60 text-emerald-300 border border-emerald-700 text-xs font-bold">
                      ✓ OFFICIAL APPROVED
                    </span>
                  </div>
                ) : (
                  <div className="flex items-center justify-between text-xs text-yellow-400 bg-yellow-950/30 p-3 rounded-lg border border-yellow-800/50">
                    <div>
                      <span className="font-bold">Status: Pending Management Approval</span>
                      <p className="text-[10px] text-slate-400 mt-0.5">Work execution must not commence until signed by authorized Management.</p>
                    </div>
                    {currentRole === 'Management' && (
                      <button
                        onClick={() => handleApproveDocument(selectedDocForView)}
                        className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs transition-all cursor-pointer shadow-sm flex items-center gap-1"
                      >
                        <CheckCircle className="w-3.5 h-3.5" /> Approve Now
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-3 shrink-0">
              <button
                onClick={() => setSelectedDocForView(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
              >
                Close View
              </button>

              <div className="flex items-center gap-2">
                {(selectedDocForView.status === 'Draft' || selectedDocForView.status === 'Rejected') && (
                  <button
                    onClick={() => {
                      const doc = selectedDocForView;
                      setSelectedDocForView(null);
                      handleOpenEditModal(doc);
                    }}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    Edit / Revise Document
                  </button>
                )}

                {currentRole === 'Management' && selectedDocForView.status === 'Pending Approval' && (
                  <>
                    <button
                      onClick={() => handleOpenRejectModal(selectedDocForView)}
                      className="px-4 py-2 bg-rose-600/30 hover:bg-rose-600/50 text-rose-300 border border-rose-600/50 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      Reject for Revision
                    </button>
                    <button
                      onClick={() => handleApproveDocument(selectedDocForView)}
                      className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-lg shadow-emerald-950/50"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Sign & Approve Safety Document
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* REJECTION REASON MODAL */}
      {rejectionModalDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-rose-800/80 rounded-2xl w-full max-w-md p-5 space-y-4 shadow-2xl">
            <div className="flex items-center gap-2.5 text-rose-400">
              <AlertOctagon className="w-5 h-5 shrink-0" />
              <h3 className="font-display font-bold text-base text-white">
                Reject Safety Document for Revision
              </h3>
            </div>
            <p className="text-xs text-slate-300">
              Please specify the precise safety deficiency or hazard mitigation required before this document can be re-submitted.
            </p>
            <div>
              <textarea
                rows={3}
                value={rejectionReasonInput}
                onChange={e => setRejectionReasonInput(e.target.value)}
                placeholder="e.g. Isolation point breaker Q1 must also include mechanical lockout tag and secondary padlock..."
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-slate-100 focus:outline-none focus:border-rose-500"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setRejectionModalDoc(null)}
                className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRejection}
                className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold cursor-pointer"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
