import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { 
  Package, 
  Plus, 
  Trash2, 
  Search, 
  Settings2, 
  Info, 
  X, 
  Upload, 
  Camera, 
  Image as ImageIcon, 
  RefreshCw, 
  Edit3, 
  AlertCircle, 
  CheckCircle2,
  SlidersHorizontal
} from 'lucide-react';
import { Asset, MachineBreakdown, CustomSpecification } from '../types';
import { SEED_ASSETS, SEED_BREAKDOWNS } from '../data';
import { 
  syncAssetBreakdownStatus, 
  getEffectiveMachineStatus, 
  checkAssetHasActiveBreakdown, 
  isBreakdownActive,
  healAndSyncAllAssets
} from '../utils/machineSync';

interface AssetListViewProps {
  currentRole: string;
}

const STORAGE_BUCKET = 'asset-images';
const MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024; // 5MB
const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

export const resolveMachinePhoto = (a: any): string => {
  if (!a) return '';
  const candidates = [a.photoUrl, a.photo_url, a.machine_photo, a.machinePhoto];
  for (const candidate of candidates) {
    if (typeof candidate === 'string' && candidate.trim()) {
      const trimmed = candidate.trim();
      // Strictly exclude any AI/SVG vector data
      if (trimmed.startsWith('data:image/svg') || trimmed.includes('%3Csvg') || trimmed.includes('<svg')) {
        continue;
      }
      return trimmed;
    }
  }
  return '';
};

export const AssetListView: React.FC<AssetListViewProps> = ({ currentRole }) => {
  // Breakdowns state for equipment history (empty by default)
  const [machineBreakdowns, setMachineBreakdowns] = useState<MachineBreakdown[]>(() => {
    try {
      const saved = localStorage.getItem('dmr_machine_breakdowns');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const demoBrkIds = ['BRK-001', 'BRK-002', 'BRK-2026-001', 'BRK-2026-002'];
          return parsed.filter((b: any) => !demoBrkIds.includes(b.id) && !demoBrkIds.includes(b.breakdown_id));
        }
      }
    } catch (e) {
      console.error('Failed reading dmr_machine_breakdowns from localStorage:', e);
    }
    return [];
  });

  // Initialize assets from localStorage (empty by default)
  const [assets, setAssets] = useState<Asset[]>(() => {
    try {
      const saved = localStorage.getItem('dmr_assets_list');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const demoAssetIds = [
            'LATHE-01', 'LATHE-02', 'MILL-03', 'CNC-01', 'PUMP-01', 
            'COMP-02', 'WELD-05', 'DRILL-04', 'SHAPER-01', 'PLC-08', 
            'MCH-001', 'MCH-002', 'MCH-003', 'A-03', 'H-01', 'P-02'
          ];
          return parsed.filter((a: any) => !demoAssetIds.includes(a.id)).map((a: any) => {
            const photo = resolveMachinePhoto(a);
            return {
              ...a,
              photoUrl: photo,
              machine_photo: photo,
              photo_url: photo,
              customSpecifications: Array.isArray(a.customSpecifications)
                ? a.customSpecifications
                : Array.isArray(a.custom_specifications)
                ? a.custom_specifications
                : []
            };
          });
        }
      }
    } catch (e) {
      // Graceful fallback if reading fails
    }
    return [];
  });

  const sanitizeAssetsForStorage = (list: Asset[]): Asset[] => {
    return list.map(a => {
      let cleanPhoto = resolveMachinePhoto(a);
      // Retain URLs and reasonably sized image strings up to 500KB
      if (typeof cleanPhoto === 'string' && cleanPhoto.length > 500000) {
        cleanPhoto = '';
      }
      return {
        ...a,
        photoUrl: cleanPhoto,
        machine_photo: cleanPhoto,
        photo_url: cleanPhoto
      };
    });
  };

  const saveAssetsState = (newAssets: Asset[]) => {
    setAssets(newAssets);
    try {
      const sanitized = sanitizeAssetsForStorage(newAssets);
      localStorage.setItem('dmr_assets_list', JSON.stringify(sanitized));
    } catch (e) {
      try {
        // Quota exceeded: aggressively remove obsolete dmr_storage_ and dmr_cache_ keys
        for (let i = localStorage.length - 1; i >= 0; i--) {
          const key = localStorage.key(i);
          if (key && (key.startsWith('dmr_storage_') || key.startsWith('dmr_cache_') || key.startsWith('dmr_assets_backup'))) {
            localStorage.removeItem(key);
          }
        }
        // Retry saving minimal assets without bloat
        const minimal = newAssets.map(a => {
          const cleanPhoto = resolveMachinePhoto(a);
          return {
            id: a.id,
            name: a.name,
            category: a.category,
            status: a.status,
            location: a.location,
            criticality: a.criticality,
            department: a.department,
            description: (a.description || '').slice(0, 100),
            manufacturer: a.manufacturer,
            model: a.model,
            serialNumber: a.serialNumber,
            installationDate: a.installationDate,
            photoUrl: cleanPhoto && cleanPhoto.length < 500000 ? cleanPhoto : '',
            machine_photo: cleanPhoto && cleanPhoto.length < 500000 ? cleanPhoto : ''
          };
        });
        localStorage.setItem('dmr_assets_list', JSON.stringify(minimal));
      } catch (innerErr) {
        // Safely retain in-memory assets state without emitting uncaught errors
      }
    }
  };

  // Clear legacy bloated dmr_storage_ items on boot to free browser storage quota
  useEffect(() => {
    try {
      for (let i = localStorage.length - 1; i >= 0; i--) {
        const key = localStorage.key(i);
        if (key && key.startsWith('dmr_storage_')) {
          localStorage.removeItem(key);
        }
      }
    } catch (e) {}
  }, []);

  useEffect(() => {
    const fetchAssets = async () => {
      try {
        const { data, error } = await supabase.from('assets').select('*');
        if (!error && data) {
          const formatted: Asset[] = data.map((a: any) => {
            const resolvedPhoto = resolveMachinePhoto(a);
            return {
              id: a.id,
              name: a.name,
              category: a.category,
              status: a.status,
              location: a.location,
              criticality: a.criticality,
              department: a.department,
              description: a.description,
              manufacturer: a.manufacturer,
              model: a.model,
              serialNumber: a.serial_number || a.serialNumber,
              installationDate: a.installation_date || a.installationDate,
              nextMaintenanceDate: a.next_maintenance_date || a.nextMaintenanceDate,
              photoUrl: resolvedPhoto,
              machine_photo: resolvedPhoto,
              customSpecifications: Array.isArray(a.customSpecifications)
                ? a.customSpecifications
                : Array.isArray(a.custom_specifications)
                ? a.custom_specifications
                : []
            };
          });
          saveAssetsState(formatted);
        }
      } catch (err) {
        console.error('Error fetching assets from Firestore:', err);
      }
    };

    const fetchBreakdowns = async () => {
      try {
        const { data, error } = await supabase.from('machine_breakdowns').select('*');
        if (!error && Array.isArray(data)) {
          setMachineBreakdowns(data);
          try {
            localStorage.setItem('dmr_machine_breakdowns', JSON.stringify(data));
          } catch {}
        }
      } catch (err) {
        console.error('Error fetching machine breakdowns in AssetListView:', err);
      }
    };

    const loadAndReconcile = async () => {
      await fetchAssets();
      await fetchBreakdowns();
      await healAndSyncAllAssets();
    };

    loadAndReconcile();

    const handleSync = () => {
      loadAndReconcile();
    };

    window.addEventListener('dmr_machine_sync', handleSync);
    window.addEventListener('storage', handleSync);

    return () => {
      window.removeEventListener('dmr_machine_sync', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, []);

  const [searchTerm, setSearchTerm] = useState('');
  
  // Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [viewingAsset, setViewingAsset] = useState<Asset | null>(null);
  const [editingAsset, setEditingAsset] = useState<Asset | null>(null);
  const [statusDropdown, setStatusDropdown] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [imageLoadErrors, setImageLoadErrors] = useState<Record<string, boolean>>({});
  
  // Custom Specifications State for Register Modal
  const [customSpecs, setCustomSpecs] = useState<CustomSpecification[]>([]);

  // Custom Specifications State for Edit Asset Modal
  const [editCustomSpecs, setEditCustomSpecs] = useState<CustomSpecification[]>([]);

  const handleAddSpecification = () => {
    setCustomSpecs(prev => [...prev, { name: '', value: '' }]);
  };

  const handleUpdateSpecification = (index: number, field: 'name' | 'value', val: string) => {
    setCustomSpecs(prev => prev.map((item, i) => i === index ? { ...item, [field]: val } : item));
  };

  const handleRemoveSpecification = (index: number) => {
    setCustomSpecs(prev => prev.filter((_, i) => i !== index));
  };

  const handleAddEditSpecification = () => {
    setEditCustomSpecs(prev => [...prev, { name: '', value: '' }]);
  };

  const handleUpdateEditSpecification = (index: number, field: 'name' | 'value', val: string) => {
    setEditCustomSpecs(prev => prev.map((item, i) => i === index ? { ...item, [field]: val } : item));
  };

  const handleRemoveEditSpecification = (index: number) => {
    setEditCustomSpecs(prev => prev.filter((_, i) => i !== index));
  };
  
  // Image Upload State for Register Modal
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string>('');
  const [uploadError, setUploadError] = useState<string>('');
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Image Upload State for Edit Asset
  const [editImageFile, setEditImageFile] = useState<File | null>(null);
  const [editImagePreview, setEditImagePreview] = useState<string>('');
  const [editUploadError, setEditUploadError] = useState<string>('');
  const [isEditUploading, setIsEditUploading] = useState<boolean>(false);
  const editFileInputRef = useRef<HTMLInputElement>(null);
  
  // Confirmation state for deleting machine information
  const [assetToDelete, setAssetToDelete] = useState<Asset | null>(null);
  
  // Form State
  const [formData, setFormData] = useState({
    name: '',
    machineType: '',
    manufacturer: '',
    model: '',
    serialNumber: '',
    department: '',
    location: '',
    installationDate: '',
    status: 'Operational' as 'Operational' | 'Under Maintenance' | 'Faulty' | 'Decommissioned',
    criticality: '' as '' | 'Low' | 'Medium' | 'High' | 'Critical',
    photoUrl: '',
    description: '',
    category: 'General' as any
  });

  const isManagement = currentRole === 'Management';

  const filteredAssets = assets.filter(a => 
    (a.name || '').toLowerCase().includes(searchTerm.toLowerCase()) || 
    (a.id || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (a.category || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (a.location || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // Image selection validation helper
  const validateAndSetImage = (
    file: File, 
    setFile: (f: File | null) => void, 
    setPreview: (url: string) => void, 
    setError: (err: string) => void
  ) => {
    setError('');
    
    // Check file size (5MB max)
    if (file.size > MAX_FILE_SIZE_BYTES) {
      setError(`File size exceeds 5MB limit (${(file.size / (1024 * 1024)).toFixed(1)}MB). Please choose a smaller image.`);
      return false;
    }

    // Check supported MIME types (JPG, JPEG, PNG, WEBP)
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    const extension = file.name.split('.').pop()?.toLowerCase();
    const isExtensionValid = ['jpg', 'jpeg', 'png', 'webp'].includes(extension || '');

    if (!validTypes.includes(file.type.toLowerCase()) && !isExtensionValid) {
      setError('Unsupported file format. Please upload JPG, JPEG, PNG, or WEBP.');
      return false;
    }

    setFile(file);
    const objectUrl = URL.createObjectURL(file);
    setPreview(objectUrl);
    return true;
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      validateAndSetImage(file, setSelectedImageFile, setImagePreviewUrl, setUploadError);
    }
  };

  const handleRemoveImage = () => {
    setSelectedImageFile(null);
    setImagePreviewUrl('');
    setUploadError('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleEditFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      validateAndSetImage(file, setEditImageFile, setEditImagePreview, setEditUploadError);
    }
  };

  const handleRemoveEditImage = () => {
    setEditImageFile(null);
    setEditImagePreview('');
    setEditUploadError('');
    if (editFileInputRef.current) {
      editFileInputRef.current.value = '';
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setUploadError('');
    setIsUploading(true);

    try {
      let finalPhotoUrl = formData.photoUrl || '';

      // Upload file to Supabase Storage bucket 'asset-images' if selected
      if (selectedImageFile) {
        const fileExt = selectedImageFile.name.split('.').pop() || 'jpg';
        const fileName = `machine_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${fileExt}`;
        const filePath = `${fileName}`;

        const { data: uploadData, error: uploadErr } = await supabase.storage
          .from(STORAGE_BUCKET)
          .upload(filePath, selectedImageFile, {
            contentType: selectedImageFile.type,
            upsert: true
          });

        if (uploadErr || !uploadData) {
          throw new Error(uploadErr?.message || 'Failed to upload machine image to Supabase Storage.');
        }

        // Get public URL
        const { data: publicUrlData } = supabase.storage
          .from(STORAGE_BUCKET)
          .getPublicUrl(uploadData.path || filePath);

        finalPhotoUrl = publicUrlData?.publicUrl || `/storage/v1/object/public/${STORAGE_BUCKET}/${fileName}`;
      }

      // Process & validate custom specifications
      const cleanedSpecs: CustomSpecification[] = [];
      const seenSpecNames = new Set<string>();

      for (let i = 0; i < customSpecs.length; i++) {
        const s = customSpecs[i];
        const nameTrim = (s.name || '').trim();
        const valTrim = (s.value || '').trim();

        // If completely blank row, skip it
        if (!nameTrim && !valTrim) {
          continue;
        }

        if (!nameTrim) {
          setUploadError(`Custom specification #${i + 1} is missing a name.`);
          setIsUploading(false);
          return;
        }

        if (!valTrim) {
          setUploadError(`Custom specification "${nameTrim}" is missing a value.`);
          setIsUploading(false);
          return;
        }

        const lowerName = nameTrim.toLowerCase();
        if (seenSpecNames.has(lowerName)) {
          setUploadError(`Duplicate specification name "${nameTrim}". Each custom specification must have a unique name.`);
          setIsUploading(false);
          return;
        }
        seenSpecNames.add(lowerName);

        cleanedSpecs.push({
          name: nameTrim,
          value: valTrim
        });
      }

      const newAssetId = `EQ-${Math.floor(Math.random() * 9000) + 1000}`;
      const newAsset: Asset = {
        id: newAssetId,
        name: formData.name,
        machineType: formData.machineType || 'General Machinery',
        manufacturer: formData.manufacturer || 'Standard',
        model: formData.model || 'Standard',
        serialNumber: formData.serialNumber || `SN-${newAssetId}`,
        department: formData.department || 'Workshop',
        location: formData.location || 'Main Floor',
        installationDate: formData.installationDate || new Date().toISOString().split('T')[0],
        status: formData.status || 'Operational',
        criticality: (formData.criticality || 'Medium') as any,
        photoUrl: finalPhotoUrl || '',
        machine_photo: finalPhotoUrl || '',
        description: formData.description || '',
        category: formData.category || 'General',
        customSpecifications: cleanedSpecs
      };

      // Insert record to assets table with machine_photo, photo_url, photoUrl, and customSpecifications
      await supabase.from('assets').insert({
        id: newAsset.id,
        name: newAsset.name,
        category: newAsset.category,
        status: newAsset.status,
        location: newAsset.location,
        criticality: newAsset.criticality || 'Medium',
        department: newAsset.department,
        description: newAsset.description,
        manufacturer: newAsset.manufacturer,
        model: newAsset.model,
        serial_number: newAsset.serialNumber,
        installation_date: newAsset.installationDate,
        next_maintenance_date: null,
        photoUrl: finalPhotoUrl || '',
        photo_url: finalPhotoUrl || '',
        machine_photo: finalPhotoUrl || '',
        custom_specifications: cleanedSpecs,
        customSpecifications: cleanedSpecs
      });

      const updatedList = [newAsset, ...assets];
      saveAssetsState(updatedList);
      setIsAddModalOpen(false);

      // Reset form & state
      setFormData({
        name: '', machineType: '', manufacturer: '', model: '', serialNumber: '',
        department: '', location: '', installationDate: '', status: 'Operational',
        criticality: '', photoUrl: '', description: '', category: 'General'
      });
      setCustomSpecs([]);
      setSelectedImageFile(null);
      setImagePreviewUrl('');
      setUploadError('');

      setFeedback({ type: 'success', message: `Machine "${newAsset.name}" registered successfully with image.` });
      setTimeout(() => setFeedback(null), 4000);
    } catch (err: any) {
      console.error('Registration failed:', err);
      setUploadError(err.message || 'Image upload or registration failed. Please retry.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleUpdateStatus = async (id: string, newStatus: Asset['status']) => {
    // Check if there is an active breakdown
    const activeBreakdown = machineBreakdowns.find(
      b => (b.asset_id === id || (b as any).assetId === id) && isBreakdownActive(b.status)
    );
    if (activeBreakdown && newStatus === 'Operational') {
      setFeedback({ 
        type: 'error', 
        message: `Mesin tidak boleh diubah ke Operational kerana masih mempunyai laporan breakdown aktif (${activeBreakdown.breakdown_id || activeBreakdown.id})! Sila selesaikan pembaikan kerosakan terlebih dahulu.` 
      });
      setTimeout(() => setFeedback(null), 4000);
      setStatusDropdown(null);
      return;
    }

    try {
      await syncAssetBreakdownStatus(id, newStatus === 'Breakdown', `Manual status changed to ${newStatus}`);
      const updated = assets.map(a => a.id === id ? { ...a, status: newStatus } : a);
      saveAssetsState(updated);
      setFeedback({ type: 'success', message: `Status mesin ${id} berjaya dikemaskini ke ${newStatus}.` });
      setTimeout(() => setFeedback(null), 3000);
    } catch (err) {
      console.error('Error updating asset status:', err);
    }
    setStatusDropdown(null);
  };

  const confirmDeleteAsset = async (id: string) => {
    const targetAsset = assets.find(a => a.id === id);
    
    // Remove image from storage bucket if it belongs to local/supabase storage
    if (targetAsset?.photoUrl && targetAsset.photoUrl.includes(STORAGE_BUCKET)) {
      const fileName = targetAsset.photoUrl.split('/').pop();
      if (fileName) {
        await supabase.storage.from(STORAGE_BUCKET).remove([fileName]);
      }
    }

    await supabase.from('assets').delete().eq('id', id);
    const updated = assets.filter(a => a.id !== id);
    saveAssetsState(updated);
    setFeedback({ type: 'success', message: `Machine asset ${id} deleted successfully.` });
    setTimeout(() => setFeedback(null), 3000);
  };

  const handleRemoveAsset = (id: string) => {
    const target = assets.find(a => a.id === id);
    if (target) {
      setAssetToDelete(target);
    } else {
      confirmDeleteAsset(id);
    }
  };

  // Open Edit Modal for an asset
  const handleOpenEditModal = (asset: Asset) => {
    setEditingAsset(asset);
    setEditImagePreview(asset.photoUrl || asset.machine_photo || '');
    setEditImageFile(null);
    setEditUploadError('');
    const existingSpecs = Array.isArray(asset.customSpecifications)
      ? asset.customSpecifications
      : Array.isArray((asset as any).custom_specifications)
      ? (asset as any).custom_specifications
      : [];
    setEditCustomSpecs(existingSpecs.map((s: any) => ({ name: s.name || '', value: s.value || '' })));
  };

  // Save changes to edited asset
  const handleSaveEditAsset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAsset) return;
    setIsEditUploading(true);
    setEditUploadError('');

    try {
      let finalPhotoUrl = editImagePreview;

      // Process & validate custom specifications for edit
      const cleanedEditSpecs: CustomSpecification[] = [];
      const seenEditSpecNames = new Set<string>();

      for (let i = 0; i < editCustomSpecs.length; i++) {
        const s = editCustomSpecs[i];
        const nameTrim = (s.name || '').trim();
        const valTrim = (s.value || '').trim();

        if (!nameTrim && !valTrim) {
          continue;
        }

        if (!nameTrim) {
          setEditUploadError(`Custom specification #${i + 1} is missing a name.`);
          setIsEditUploading(false);
          return;
        }

        if (!valTrim) {
          setEditUploadError(`Custom specification "${nameTrim}" is missing a value.`);
          setIsEditUploading(false);
          return;
        }

        const lowerName = nameTrim.toLowerCase();
        if (seenEditSpecNames.has(lowerName)) {
          setEditUploadError(`Duplicate specification name "${nameTrim}". Each custom specification must have a unique name.`);
          setIsEditUploading(false);
          return;
        }
        seenEditSpecNames.add(lowerName);

        cleanedEditSpecs.push({
          name: nameTrim,
          value: valTrim
        });
      }

      // If user uploaded a new image file
      if (editImageFile) {
        const fileExt = editImageFile.name.split('.').pop() || 'jpg';
        const fileName = `machine_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${fileExt}`;
        const filePath = `${fileName}`;

        const { data: uploadData, error: uploadErr } = await supabase.storage
          .from(STORAGE_BUCKET)
          .upload(filePath, editImageFile, {
            contentType: editImageFile.type,
            upsert: true
          });

        if (uploadErr || !uploadData) {
          throw new Error(uploadErr?.message || 'Failed to upload replacement image.');
        }

        const { data: publicUrlData } = supabase.storage
          .from(STORAGE_BUCKET)
          .getPublicUrl(uploadData.path || filePath);

        finalPhotoUrl = publicUrlData?.publicUrl || `/storage/v1/object/public/${STORAGE_BUCKET}/${fileName}`;

        // Clean up old image from storage if it was stored in the bucket
        const oldPhoto = editingAsset.photoUrl || editingAsset.machine_photo;
        if (oldPhoto && oldPhoto.includes(STORAGE_BUCKET)) {
          const oldName = oldPhoto.split('/').pop();
          if (oldName && oldName !== fileName) {
            await supabase.storage.from(STORAGE_BUCKET).remove([oldName]);
          }
        }
      } else if (!editImagePreview && (editingAsset.photoUrl || editingAsset.machine_photo)) {
        // User removed the image
        const oldPhoto = editingAsset.photoUrl || editingAsset.machine_photo;
        if (oldPhoto && oldPhoto.includes(STORAGE_BUCKET)) {
          const oldName = oldPhoto.split('/').pop();
          if (oldName) {
            await supabase.storage.from(STORAGE_BUCKET).remove([oldName]);
          }
        }
        finalPhotoUrl = '';
      }

      const updatedAsset: Asset = {
        ...editingAsset,
        photoUrl: finalPhotoUrl,
        machine_photo: finalPhotoUrl,
        customSpecifications: cleanedEditSpecs
      };

      await supabase.from('assets').update({
        name: updatedAsset.name,
        machineType: updatedAsset.machineType || '',
        manufacturer: updatedAsset.manufacturer || '',
        model: updatedAsset.model || '',
        serial_number: updatedAsset.serialNumber || '',
        department: updatedAsset.department || '',
        location: updatedAsset.location || '',
        installation_date: updatedAsset.installationDate || '',
        status: updatedAsset.status || 'Operational',
        criticality: updatedAsset.criticality || 'Medium',
        photoUrl: finalPhotoUrl || '',
        photo_url: finalPhotoUrl || '',
        machine_photo: finalPhotoUrl || '',
        description: updatedAsset.description || '',
        category: updatedAsset.category || 'General',
        custom_specifications: cleanedEditSpecs,
        customSpecifications: cleanedEditSpecs
      }).eq('id', updatedAsset.id);

      const updatedList = assets.map(a => a.id === updatedAsset.id ? updatedAsset : a);
      saveAssetsState(updatedList);
      if (viewingAsset && viewingAsset.id === updatedAsset.id) {
        setViewingAsset(updatedAsset);
      }
      setEditingAsset(null);
      setFeedback({ type: 'success', message: `Machine ${updatedAsset.name} updated successfully.` });
      setTimeout(() => setFeedback(null), 3500);
    } catch (err: any) {
      console.error('Update failed:', err);
      setEditUploadError(err.message || 'Failed to update machine information.');
    } finally {
      setIsEditUploading(false);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm overflow-hidden flex flex-col min-h-[500px] relative">
      {/* Toast Feedback */}
      {feedback && (
        <div className={`p-3 px-4 text-xs font-semibold flex items-center justify-between transition-all ${
          feedback.type === 'success' 
            ? 'bg-emerald-50 text-emerald-800 border-b border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800' 
            : 'bg-rose-50 text-rose-800 border-b border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800'
        }`}>
          <div className="flex items-center gap-2">
            {feedback.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" /> : <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400" />}
            <span>{feedback.message}</span>
          </div>
          <button onClick={() => setFeedback(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Header */}
      <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-50 dark:bg-slate-900/50">
        <div>
          <h2 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2 font-display">
            <Package className="w-5 h-5 text-sky-500" />
            Asset Directory & Specifications
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Browse registered equipment, machine imagery, specifications, and operational status.
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto mt-2 sm:mt-0">
          <div className="relative w-full sm:w-auto">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder="Search assets or machines..." 
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full sm:w-64 pl-9 pr-4 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-sm focus:outline-none focus:border-sky-500 dark:text-slate-200"
            />
          </div>
          {isManagement && (
            <button 
              onClick={() => {
                setSelectedImageFile(null);
                setImagePreviewUrl('');
                setUploadError('');
                setCustomSpecs([]);
                setIsAddModalOpen(true);
              }}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-900 dark:bg-sky-500 dark:hover:bg-sky-600 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-all shadow-md hover:shadow-lg cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4" /> Register New Machine
            </button>
          )}
        </div>
      </div>

      {/* Asset Table */}
      <div className="flex-1 overflow-x-auto">
        <table className="w-full text-left border-collapse min-w-max sm:min-w-0">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              <th className="p-3 sm:p-4 w-14 text-center">Photo</th>
              <th className="p-3 sm:p-4">Asset ID & Name</th>
              <th className="p-3 sm:p-4 hidden md:table-cell">Location</th>
              <th className="p-3 sm:p-4 hidden sm:table-cell">Category</th>
              <th className="p-3 sm:p-4">Status</th>
              <th className="p-3 sm:p-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
            {filteredAssets.length === 0 ? (
              <tr>
                <td colSpan={6} className="p-12 text-center text-slate-500">
                  <div className="flex flex-col items-center justify-center space-y-2">
                    <Package className="w-10 h-10 text-slate-300 dark:text-slate-600 mb-1" />
                    <p className="font-semibold text-slate-700 dark:text-slate-300 text-sm">
                      {assets.length === 0 ? "No assets registered yet." : "No assets found matching your criteria."}
                    </p>
                    {assets.length === 0 && (
                      <p className="text-xs text-slate-400">
                        Use 'Register New Machine' to add your first asset.
                      </p>
                    )}
                  </div>
                </td>
              </tr>
            ) : (
              filteredAssets.map((asset, index) => {
                const photo = resolveMachinePhoto(asset);
                return (
                  <tr key={`${asset.id}-${index}`} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    {/* Machine Photo thumbnail */}
                    <td className="p-3 sm:p-4 text-center">
                      <div 
                        onClick={() => setViewingAsset(asset)}
                        className="w-10 h-10 rounded-lg overflow-hidden bg-slate-900 border border-slate-700/80 flex items-center justify-center cursor-pointer mx-auto transition-transform hover:scale-105 shadow-2xs relative"
                        title={photo ? `View ${asset.name} photo` : 'No image available'}
                      >
                        {photo && !imageLoadErrors[asset.id] ? (
                          <img 
                            src={photo} 
                            alt={asset.name} 
                            className="w-full h-full object-cover" 
                            onError={() => {
                              setImageLoadErrors(prev => ({ ...prev, [asset.id]: true }));
                            }}
                          />
                        ) : (
                          <div className="w-full h-full bg-slate-800/80 flex items-center justify-center text-slate-400">
                            <ImageIcon className="w-4 h-4 text-slate-400" />
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="p-3 sm:p-4">
                      <div className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                        {asset.name}
                        {asset.criticality === 'Critical' && (
                          <span className="text-[9px] bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">
                            Critical
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-500 font-mono mt-0.5">{asset.id}</div>
                    </td>
                    <td className="p-3 sm:p-4 text-slate-600 dark:text-slate-300 hidden md:table-cell">{asset.location}</td>
                    <td className="p-3 sm:p-4 text-slate-600 dark:text-slate-300 hidden sm:table-cell">{asset.category}</td>
                    <td className="p-3 sm:p-4">
                      {(() => {
                        const currentDisplayStatus = getEffectiveMachineStatus(asset, machineBreakdowns);
                        return (
                          <span 
                            className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase ${
                              currentDisplayStatus === 'Breakdown' ? 'bg-rose-600 text-white font-extrabold flex items-center gap-1 shadow-xs animate-pulse' :
                              currentDisplayStatus === 'Operational' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 font-bold' :
                              currentDisplayStatus === 'Under Maintenance' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' :
                              currentDisplayStatus === 'Decommissioned' ? 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-400' :
                              'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400'
                            }`}
                          >
                            {currentDisplayStatus === 'Breakdown' ? '🔴 BREAKDOWN' : currentDisplayStatus === 'Operational' ? '🟢 OPERATIONAL' : currentDisplayStatus === 'Decommissioned' ? 'Scrapped' : currentDisplayStatus}
                          </span>
                        );
                      })()}
                    </td>
                    <td className="p-3 sm:p-4 text-right flex items-center justify-end gap-1 sm:gap-2">
                      <button 
                        onClick={() => setViewingAsset(asset)}
                        className="p-1.5 text-slate-400 hover:text-sky-600 hover:bg-sky-50 dark:hover:bg-sky-900/20 rounded transition-colors cursor-pointer"
                        title="View Specifications & Image"
                      >
                        <Info className="w-4 h-4" />
                      </button>

                      {isManagement && (
                        <button 
                          onClick={() => handleOpenEditModal(asset)}
                          className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-900/20 rounded transition-colors cursor-pointer"
                          title="Edit Asset & Image"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                      )}

                      {(currentRole === 'Management' || currentRole === 'Technician' || currentRole === 'Supervisor') && (
                        <div className="relative inline-block text-left">
                          <button 
                            onClick={() => setStatusDropdown(statusDropdown === asset.id ? null : asset.id)}
                            className="p-1.5 text-slate-400 hover:text-sky-600 hover:bg-sky-50 dark:hover:bg-sky-900/20 rounded transition-colors cursor-pointer"
                            title="Change Status"
                          >
                            <Settings2 className="w-4 h-4" />
                          </button>
                          {statusDropdown === asset.id && (
                            <div className="absolute right-8 top-0 mt-0 w-48 rounded-md shadow-lg bg-white dark:bg-slate-800 ring-1 ring-black ring-opacity-5 z-50 border border-slate-200 dark:border-slate-700 overflow-hidden">
                              <div className="py-1" role="menu">
                                {(['Operational', 'Faulty', 'Under Maintenance', 'Decommissioned'] as const).map((status) => (
                                  <button
                                    key={status}
                                    onClick={() => handleUpdateStatus(asset.id, status)}
                                    className={`block w-full text-left px-4 py-2 text-xs ${asset.status === status ? 'bg-sky-50 text-sky-700 dark:bg-sky-900/30 dark:text-sky-400 font-bold' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'}`}
                                    role="menuitem"
                                  >
                                    {status === 'Decommissioned' ? 'Scrapped' : status}
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                      
                      {isManagement && (
                        <button 
                          onClick={() => handleRemoveAsset(asset.id)}
                          className="p-1.5 text-rose-600 dark:text-rose-400 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/60 border border-rose-200 dark:border-rose-900/50 hover:border-rose-300 dark:hover:border-rose-700 rounded-md transition-all shadow-2xs hover:scale-105 active:scale-95 cursor-pointer focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                          title="Delete Machine Information"
                          aria-label={`Delete machine info for ${asset.name}`}
                        >
                          <Trash2 className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* ======================================================== */}
      {/* REGISTER NEW MACHINE MODAL WITH MACHINE IMAGE UPLOAD */}
      {/* ======================================================== */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 md:p-6">
          <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh] sm:max-h-[90vh]">
            <div className="px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900/50 shrink-0">
              <h3 className="font-display font-bold text-base sm:text-lg text-slate-800 dark:text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-sky-500 shrink-0" />
                <span>Register New Machine</span>
              </h3>
              <button 
                onClick={() => setIsAddModalOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full transition-colors cursor-pointer min-h-[36px] min-w-[36px] flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-4 sm:p-6 overflow-y-auto flex-1">
              <form id="registerMachineForm" onSubmit={handleRegisterSubmit} className="space-y-5 sm:space-y-6">
                
                {uploadError && (
                  <div className="p-3 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 rounded-xl text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2.5 shadow-2xs">
                    <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                    <span className="font-medium">{uploadError}</span>
                  </div>
                )}

                {/* Basic Info */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 sm:mb-4 pb-2 border-b border-slate-100 dark:border-slate-800">
                    Basic Information
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Machine Name <span className="text-rose-500">*</span>
                      </label>
                      <input required type="text" name="name" value={formData.name} onChange={handleInputChange} className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm focus:outline-none focus:border-sky-500 dark:text-white" placeholder="e.g. CNC Milling Machine" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Machine Type <span className="text-rose-500">*</span>
                      </label>
                      <input required type="text" name="machineType" value={formData.machineType} onChange={handleInputChange} className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm focus:outline-none focus:border-sky-500 dark:text-white" placeholder="e.g. Vertical Mill" />
                    </div>
                  </div>
                </div>

                {/* Manufacturer Details */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 sm:mb-4 pb-2 border-b border-slate-100 dark:border-slate-800">
                    Manufacturer Details
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Manufacturer <span className="text-rose-500">*</span>
                      </label>
                      <input required type="text" name="manufacturer" value={formData.manufacturer} onChange={handleInputChange} className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm focus:outline-none focus:border-sky-500 dark:text-white" placeholder="e.g. Haas" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Model <span className="text-rose-500">*</span>
                      </label>
                      <input required type="text" name="model" value={formData.model} onChange={handleInputChange} className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm focus:outline-none focus:border-sky-500 dark:text-white" placeholder="e.g. VF-2" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Serial Number <span className="text-rose-500">*</span>
                      </label>
                      <input required type="text" name="serialNumber" value={formData.serialNumber} onChange={handleInputChange} className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm focus:outline-none focus:border-sky-500 dark:text-white" placeholder="SN-XXXX" />
                    </div>
                  </div>
                </div>

                {/* Deployment */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 sm:mb-4 pb-2 border-b border-slate-100 dark:border-slate-800">
                    Deployment
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Department <span className="text-rose-500">*</span>
                      </label>
                      <input required type="text" name="department" value={formData.department} onChange={handleInputChange} className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm focus:outline-none focus:border-sky-500 dark:text-white" placeholder="e.g. Machining" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Location <span className="text-rose-500">*</span>
                      </label>
                      <input required type="text" name="location" value={formData.location} onChange={handleInputChange} className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm focus:outline-none focus:border-sky-500 dark:text-white" placeholder="e.g. Zone A" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Installation Date <span className="text-rose-500">*</span>
                      </label>
                      <input required type="date" name="installationDate" value={formData.installationDate} onChange={handleInputChange} className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm focus:outline-none focus:border-sky-500 dark:text-white" />
                    </div>
                  </div>
                </div>

                {/* Operational Parameters */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4 pb-2 border-b border-slate-100 dark:border-slate-800">
                    Operational Parameters
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Operating Status <span className="text-rose-500">*</span>
                      </label>
                      <select required name="status" value={formData.status} onChange={handleInputChange} className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm focus:outline-none focus:border-sky-500 dark:text-white">
                        <option value="Operational">Operational</option>
                        <option value="Under Maintenance">Under Maintenance</option>
                        <option value="Faulty">Faulty</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Criticality <span className="text-slate-400 font-normal lowercase">(Optional)</span>
                      </label>
                      <select name="criticality" value={formData.criticality} onChange={handleInputChange} className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm focus:outline-none focus:border-sky-500 dark:text-white">
                        <option value="">Select Criticality (Optional)</option>
                        <option value="Low">Low</option>
                        <option value="Medium">Medium</option>
                        <option value="High">High</option>
                        <option value="Critical">Critical</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* ========================================= */}
                {/* CUSTOM SPECIFICATIONS SECTION */}
                {/* ========================================= */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50/60 dark:bg-slate-950/40">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3 pb-2 border-b border-slate-200/80 dark:border-slate-800">
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                        <SlidersHorizontal className="w-4 h-4 text-sky-500" />
                        Custom Specifications
                      </h4>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        Add flexible specifications not included in standard fields (e.g. Refrigerant, Voltage, Cooling Capacity).
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={handleAddSpecification}
                      className="self-start sm:self-auto px-3 py-1.5 bg-sky-600 hover:bg-sky-700 active:bg-sky-800 text-white rounded-lg text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>+ Add Specification</span>
                    </button>
                  </div>

                  {customSpecs.length === 0 ? (
                    <div className="p-4 border border-dashed border-slate-200 dark:border-slate-800 rounded-lg text-center bg-white/60 dark:bg-slate-900/60">
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        No custom specifications added yet.
                      </p>
                      <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">
                        Click <strong className="text-sky-600 dark:text-sky-400 font-medium">+ Add Specification</strong> if this machine requires specific parameters (e.g., Refrigerant: R32, Voltage: 240V).
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {customSpecs.map((spec, index) => (
                        <div 
                          key={`reg-spec-${index}`}
                          className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xs space-y-2 sm:space-y-0 sm:flex sm:items-end sm:gap-3"
                        >
                          <div className="flex-1">
                            <label className="block text-[11px] font-medium text-slate-700 dark:text-slate-300 mb-1">
                              Specification Name <span className="text-rose-500">*</span>
                            </label>
                            <input
                              type="text"
                              value={spec.name}
                              onChange={(e) => handleUpdateSpecification(index, 'name', e.target.value)}
                              placeholder="e.g. Refrigerant, Cooling Capacity, Voltage"
                              className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-xs sm:text-sm focus:outline-none focus:border-sky-500 dark:text-white"
                            />
                          </div>

                          <div className="flex-1">
                            <label className="block text-[11px] font-medium text-slate-700 dark:text-slate-300 mb-1">
                              Specification Value <span className="text-rose-500">*</span>
                            </label>
                            <input
                              type="text"
                              value={spec.value}
                              onChange={(e) => handleUpdateSpecification(index, 'value', e.target.value)}
                              placeholder="e.g. R32, 2.5 HP, 240 V"
                              className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-xs sm:text-sm focus:outline-none focus:border-sky-500 dark:text-white"
                            />
                          </div>

                          <div className="flex items-center justify-end sm:justify-start">
                            <button
                              type="button"
                              onClick={() => handleRemoveSpecification(index)}
                              className="w-full sm:w-auto px-3 py-2 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/60 text-rose-600 dark:text-rose-400 border border-rose-200/80 dark:border-rose-900/50 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer min-h-[38px]"
                              title="Remove specification"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Remove</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* ========================================= */}
                {/* NEW: MACHINE IMAGE UPLOAD SECTION */}
                {/* ========================================= */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50/60 dark:bg-slate-950/40">
                  <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-200/80 dark:border-slate-800">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                      <Camera className="w-4 h-4 text-sky-500" />
                      MACHINE IMAGE
                    </h4>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400">
                      Supabase Storage • Max 5MB
                    </span>
                  </div>

                  {/* Hidden standard file input supporting Camera & Gallery on Mobile */}
                  <input 
                    ref={fileInputRef}
                    type="file" 
                    id="machineImageInput"
                    accept="image/jpeg,image/jpg,image/png,image/webp"
                    capture="environment" // Mobile camera shortcut
                    onChange={handleFileSelect}
                    className="hidden"
                  />

                  {/* Secondary input without capture for standard photo library / files */}
                  <input 
                    type="file" 
                    id="machineImageLibraryInput"
                    accept="image/jpeg,image/jpg,image/png,image/webp"
                    onChange={handleFileSelect}
                    className="hidden"
                  />

                  {uploadError && (
                    <div className="mb-3 p-2.5 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 rounded-lg text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                      <span>{uploadError}</span>
                    </div>
                  )}

                  {imagePreviewUrl ? (
                    /* Image Preview Card */
                    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 sm:p-4 shadow-xs">
                      <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center justify-between">
                        <span>MACHINE PHOTO</span>
                        <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">Ready for upload</span>
                      </div>
                      
                      <div className="w-full h-48 sm:h-56 bg-slate-100 dark:bg-slate-950 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-800 flex items-center justify-center relative group">
                        <img 
                          src={imagePreviewUrl} 
                          alt="Machine Preview" 
                          className="w-full h-full object-cover" 
                        />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            className="px-3 py-1.5 bg-white text-slate-800 text-xs font-bold rounded-lg shadow-md hover:bg-slate-100 cursor-pointer flex items-center gap-1.5"
                          >
                            <RefreshCw className="w-3.5 h-3.5" /> Replace
                          </button>
                          <button
                            type="button"
                            onClick={handleRemoveImage}
                            className="px-3 py-1.5 bg-rose-600 text-white text-xs font-bold rounded-lg shadow-md hover:bg-rose-700 cursor-pointer flex items-center gap-1.5"
                          >
                            <Trash2 className="w-3.5 h-3.5" /> Remove
                          </button>
                        </div>
                      </div>

                      {/* Explicit Action Buttons */}
                      <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                        <span className="text-xs text-slate-500 dark:text-slate-400 truncate max-w-[200px]">
                          {selectedImageFile?.name || 'Selected image'}
                        </span>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <RefreshCw className="w-3 h-3" /> Replace
                          </button>
                          <button
                            type="button"
                            onClick={handleRemoveImage}
                            className="px-3 py-1.5 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/40 text-rose-600 dark:text-rose-400 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <Trash2 className="w-3 h-3" /> Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    /* No image selected state & Upload Buttons */
                    <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-6 text-center bg-white dark:bg-slate-900">
                      <div className="w-12 h-12 mx-auto rounded-full bg-sky-50 dark:bg-sky-950/50 flex items-center justify-center text-sky-600 dark:text-sky-400 mb-3">
                        <Upload className="w-6 h-6" />
                      </div>
                      <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">
                        No machine image selected
                      </p>
                      <p className="text-xs text-slate-400 mt-1 mb-4">
                        Supported formats: JPG, JPEG, PNG, WEBP (Max 5MB)
                      </p>

                      <div className="flex flex-wrap items-center justify-center gap-2">
                        <label 
                          htmlFor="machineImageInput"
                          className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-2 shadow-xs"
                        >
                          <Upload className="w-4 h-4" /> [ Upload Machine Image ]
                        </label>
                        <label 
                          htmlFor="machineImageLibraryInput"
                          className="px-3.5 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5"
                        >
                          <Camera className="w-4 h-4 text-slate-500" /> Camera / Files
                        </label>
                      </div>
                    </div>
                  )}
                </div>

              </form>
            </div>
            
            <div className="p-3 sm:p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex flex-wrap justify-end gap-2 sm:gap-3 shrink-0">
              <button 
                type="button" 
                onClick={() => setIsAddModalOpen(false)}
                disabled={isUploading}
                className="flex-1 sm:flex-initial px-4 py-2 text-xs sm:text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer min-h-[38px] disabled:opacity-50"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                form="registerMachineForm"
                disabled={isUploading}
                className="flex-1 sm:flex-initial px-6 py-2 text-xs sm:text-sm font-bold uppercase tracking-wider text-white bg-sky-600 hover:bg-sky-700 rounded-lg shadow-md transition-all cursor-pointer min-h-[38px] flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isUploading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Uploading & Registering...</span>
                  </>
                ) : (
                  <span>Register Machine</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* EDIT ASSET MODAL WITH IMAGE REPLACE & REMOVE */}
      {/* ======================================================== */}
      {editingAsset && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 md:p-6">
          <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh] sm:max-h-[90vh]">
            <div className="px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900/50 shrink-0">
              <h3 className="font-display font-bold text-base sm:text-lg text-slate-800 dark:text-white flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-amber-500 shrink-0" />
                <span>Edit Asset: {editingAsset.name}</span>
              </h3>
              <button 
                onClick={() => setEditingAsset(null)}
                className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full transition-colors cursor-pointer min-h-[36px] min-w-[36px] flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 sm:p-6 overflow-y-auto flex-1">
              <form id="editMachineForm" onSubmit={handleSaveEditAsset} className="space-y-5">
                
                {editUploadError && (
                  <div className="p-3 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 rounded-xl text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2.5 shadow-2xs">
                    <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                    <span className="font-medium">{editUploadError}</span>
                  </div>
                )}
                
                {/* Machine Image Management Card */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50/70 dark:bg-slate-950/40">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                    <Camera className="w-4 h-4 text-sky-500" />
                    Machine Image
                  </h4>

                  <input 
                    ref={editFileInputRef}
                    type="file" 
                    id="editMachineFileInput"
                    accept="image/jpeg,image/jpg,image/png,image/webp"
                    onChange={handleEditFileSelect}
                    className="hidden"
                  />

                  {editUploadError && (
                    <div className="mb-3 p-2.5 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 rounded-lg text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
                      <span>{editUploadError}</span>
                    </div>
                  )}

                  {editImagePreview ? (
                    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3">
                      <div className="w-full h-44 sm:h-52 bg-slate-100 dark:bg-slate-950 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-800">
                        <img 
                          src={editImagePreview} 
                          alt="Machine" 
                          className="w-full h-full object-cover" 
                          onError={(e) => {
                            (e.target as HTMLElement).style.display = 'none';
                          }}
                        />
                      </div>
                      <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                        <span className="text-xs text-slate-500">Current machine photo</span>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => editFileInputRef.current?.click()}
                            className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <RefreshCw className="w-3 h-3" /> Replace Image
                          </button>
                          <button
                            type="button"
                            onClick={handleRemoveEditImage}
                            className="px-3 py-1.5 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/40 text-rose-600 dark:text-rose-400 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <Trash2 className="w-3 h-3" /> Remove Image
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="border border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-5 text-center bg-white dark:bg-slate-900">
                      <p className="text-xs font-medium text-slate-500 mb-2">No machine image available</p>
                      <button
                        type="button"
                        onClick={() => editFileInputRef.current?.click()}
                        className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer inline-flex items-center gap-1.5"
                      >
                        <Upload className="w-3.5 h-3.5" /> Upload New Photo
                      </button>
                    </div>
                  )}
                </div>

                {/* Edit Form Fields */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Machine Name</label>
                    <input 
                      type="text" 
                      value={editingAsset.name} 
                      onChange={e => setEditingAsset({ ...editingAsset, name: e.target.value })} 
                      className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm dark:text-white" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Machine Type</label>
                    <input 
                      type="text" 
                      value={editingAsset.machineType || ''} 
                      onChange={e => setEditingAsset({ ...editingAsset, machineType: e.target.value })} 
                      className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm dark:text-white" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Manufacturer</label>
                    <input 
                      type="text" 
                      value={editingAsset.manufacturer || ''} 
                      onChange={e => setEditingAsset({ ...editingAsset, manufacturer: e.target.value })} 
                      className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm dark:text-white" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Model</label>
                    <input 
                      type="text" 
                      value={editingAsset.model || ''} 
                      onChange={e => setEditingAsset({ ...editingAsset, model: e.target.value })} 
                      className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm dark:text-white" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Serial Number</label>
                    <input 
                      type="text" 
                      value={editingAsset.serialNumber || ''} 
                      onChange={e => setEditingAsset({ ...editingAsset, serialNumber: e.target.value })} 
                      className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm dark:text-white" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Department</label>
                    <input 
                      type="text" 
                      value={editingAsset.department || ''} 
                      onChange={e => setEditingAsset({ ...editingAsset, department: e.target.value })} 
                      className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm dark:text-white" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Location</label>
                    <input 
                      type="text" 
                      value={editingAsset.location || ''} 
                      onChange={e => setEditingAsset({ ...editingAsset, location: e.target.value })} 
                      className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm dark:text-white" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Operating Status</label>
                    <select 
                      value={editingAsset.status} 
                      onChange={e => setEditingAsset({ ...editingAsset, status: e.target.value as any })}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm dark:text-white"
                    >
                      <option value="Operational">Operational</option>
                      <option value="Under Maintenance">Under Maintenance</option>
                      <option value="Faulty">Faulty</option>
                      <option value="Decommissioned">Decommissioned</option>
                    </select>
                  </div>
                </div>

                {/* ========================================= */}
                {/* EDIT CUSTOM SPECIFICATIONS SECTION */}
                {/* ========================================= */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50/60 dark:bg-slate-950/40">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3 pb-2 border-b border-slate-200/80 dark:border-slate-800">
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                        <SlidersHorizontal className="w-4 h-4 text-sky-500" />
                        Custom Specifications
                      </h4>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        Additional technical parameters for this equipment.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={handleAddEditSpecification}
                      className="self-start sm:self-auto px-3 py-1.5 bg-sky-600 hover:bg-sky-700 active:bg-sky-800 text-white rounded-lg text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>+ Add Specification</span>
                    </button>
                  </div>

                  {editCustomSpecs.length === 0 ? (
                    <div className="p-4 border border-dashed border-slate-200 dark:border-slate-800 rounded-lg text-center bg-white/60 dark:bg-slate-900/60">
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        No custom specifications added for this machine.
                      </p>
                      <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">
                        Click <strong className="text-sky-600 dark:text-sky-400 font-medium">+ Add Specification</strong> to add custom parameters.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {editCustomSpecs.map((spec, index) => (
                        <div 
                          key={`edit-spec-${index}`}
                          className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xs space-y-2 sm:space-y-0 sm:flex sm:items-end sm:gap-3"
                        >
                          <div className="flex-1">
                            <label className="block text-[11px] font-medium text-slate-700 dark:text-slate-300 mb-1">
                              Specification Name <span className="text-rose-500">*</span>
                            </label>
                            <input
                              type="text"
                              value={spec.name}
                              onChange={(e) => handleUpdateEditSpecification(index, 'name', e.target.value)}
                              placeholder="e.g. Refrigerant, Voltage"
                              className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-xs sm:text-sm focus:outline-none focus:border-sky-500 dark:text-white"
                            />
                          </div>

                          <div className="flex-1">
                            <label className="block text-[11px] font-medium text-slate-700 dark:text-slate-300 mb-1">
                              Specification Value <span className="text-rose-500">*</span>
                            </label>
                            <input
                              type="text"
                              value={spec.value}
                              onChange={(e) => handleUpdateEditSpecification(index, 'value', e.target.value)}
                              placeholder="e.g. R32, 240 V"
                              className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-xs sm:text-sm focus:outline-none focus:border-sky-500 dark:text-white"
                            />
                          </div>

                          <div className="flex items-center justify-end sm:justify-start">
                            <button
                              type="button"
                              onClick={() => handleRemoveEditSpecification(index)}
                              className="w-full sm:w-auto px-3 py-2 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/60 text-rose-600 dark:text-rose-400 border border-rose-200/80 dark:border-rose-900/50 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer min-h-[38px]"
                              title="Remove specification"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Remove</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Description / Remarks</label>
                  <textarea 
                    rows={2} 
                    value={editingAsset.description || ''} 
                    onChange={e => setEditingAsset({ ...editingAsset, description: e.target.value })} 
                    className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-sm dark:text-white resize-none" 
                  />
                </div>
              </form>
            </div>

            <div className="p-3 sm:p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex justify-end gap-2 shrink-0">
              <button 
                type="button" 
                onClick={() => setEditingAsset(null)}
                className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                form="editMachineForm"
                disabled={isEditUploading}
                className="px-5 py-2 text-xs font-bold uppercase tracking-wider text-white bg-sky-600 hover:bg-sky-700 rounded-lg shadow-sm flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isEditUploading ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Saving...
                  </>
                ) : (
                  'Save Changes'
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* VIEW MACHINE SPECIFICATIONS & DETAILS MODAL */}
      {/* ======================================================== */}
      {viewingAsset && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 md:p-6">
          <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh] sm:max-h-[90vh]">
            <div className="px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900/50 shrink-0">
              <h3 className="font-display font-bold text-base sm:text-lg text-slate-800 dark:text-white flex items-center gap-2">
                <Info className="w-5 h-5 text-sky-500 shrink-0" />
                <span>Asset Specifications</span>
              </h3>
              <button 
                onClick={() => setViewingAsset(null)}
                className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full transition-colors cursor-pointer min-h-[36px] min-w-[36px] flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-4 sm:p-6 overflow-y-auto flex-1">
              <div className="space-y-5 sm:space-y-6">
                
                {/* PROMINENT MACHINE IMAGE SECTION */}
                <div>
                  <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center justify-between">
                    <span>Machine Image</span>
                    {isManagement && (
                      <button 
                        onClick={() => {
                          const assetToEdit = viewingAsset;
                          setViewingAsset(null);
                          handleOpenEditModal(assetToEdit);
                        }}
                        className="text-xs text-sky-600 dark:text-sky-400 hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" /> Manage Image
                      </button>
                    )}
                  </div>
                  
                  {resolveMachinePhoto(viewingAsset) ? (
                    <div className="w-full h-48 sm:h-64 bg-slate-900 rounded-xl overflow-hidden border border-slate-700 shadow-sm relative group flex items-center justify-center">
                      <img 
                        src={resolveMachinePhoto(viewingAsset)} 
                        alt={viewingAsset.name} 
                        className="w-full h-full object-cover" 
                        onError={(e) => {
                          const target = e.target as HTMLElement;
                          target.style.display = 'none';
                          const fallback = target.nextElementSibling as HTMLElement;
                          if (fallback) fallback.style.display = 'flex';
                        }}
                      />
                      <div className="hidden flex-col items-center justify-center w-full h-full bg-slate-900 text-slate-400 p-4 text-center">
                        <ImageIcon className="w-10 h-10 mb-2 opacity-50 text-sky-400" />
                        <span className="text-sm font-semibold text-slate-300">{viewingAsset.name}</span>
                        <span className="text-xs text-slate-500 font-mono mt-0.5">{viewingAsset.id}</span>
                      </div>
                    </div>
                  ) : (
                    <div className="w-full h-36 bg-slate-100/70 dark:bg-slate-800/40 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 flex flex-col items-center justify-center text-slate-400">
                      <ImageIcon className="w-8 h-8 mb-2 opacity-50" />
                      <p className="text-xs font-semibold">No machine image available</p>
                    </div>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div>
                    <h4 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white break-words">{viewingAsset.name}</h4>
                    <p className="text-xs sm:text-sm font-mono text-slate-500">{viewingAsset.id}</p>
                  </div>
                  {(() => {
                    const effectiveStatus = getEffectiveMachineStatus(viewingAsset, machineBreakdowns);
                    const isBreakdown = effectiveStatus === 'Breakdown';
                    const activeBreakdownInfo = isBreakdown ? machineBreakdowns.find(
                      b => (b.asset_id === viewingAsset.id || (b as any).assetId === viewingAsset.id) && isBreakdownActive(b.status)
                    ) : null;
                    return (
                      <div className="flex flex-col items-end gap-1.5 self-start sm:self-auto shrink-0">
                        <span className={`px-2.5 py-1 rounded-lg text-[10px] sm:text-xs font-bold uppercase tracking-wider shrink-0 ${
                            effectiveStatus === 'Breakdown' ? 'bg-rose-600 text-white font-extrabold shadow-xs animate-pulse flex items-center gap-1' :
                            effectiveStatus === 'Operational' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 font-bold' :
                            effectiveStatus === 'Under Maintenance' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' :
                            effectiveStatus === 'Decommissioned' ? 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-400' :
                            'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400'
                          }`}>
                          {effectiveStatus === 'Breakdown' ? '🔴 BREAKDOWN' : effectiveStatus === 'Operational' ? '🟢 OPERATIONAL' : effectiveStatus === 'Decommissioned' ? 'Scrapped' : effectiveStatus}
                        </span>
                        {isBreakdown && activeBreakdownInfo && (
                          <span className="text-[10px] text-rose-600 dark:text-rose-400 font-mono font-bold">
                            {activeBreakdownInfo.breakdown_id || activeBreakdownInfo.id} ({activeBreakdownInfo.status})
                          </span>
                        )}
                      </div>
                    );
                  })()}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                  {/* General Info */}
                  <div className="space-y-3 sm:space-y-4">
                    <h5 className="text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-100 dark:border-slate-800 pb-2">General</h5>
                    
                    <div className="grid grid-cols-2 gap-2 text-xs sm:text-sm">
                      <div className="text-slate-500">Machine Type</div>
                      <div className="font-medium text-slate-800 dark:text-slate-200">{viewingAsset.machineType || '-'}</div>
                      
                      <div className="text-slate-500">Category</div>
                      <div className="font-medium text-slate-800 dark:text-slate-200">{viewingAsset.category || '-'}</div>
                      
                      <div className="text-slate-500">Criticality</div>
                      <div className="font-medium text-slate-800 dark:text-slate-200">{viewingAsset.criticality || '-'}</div>
                    </div>
                  </div>

                  {/* Manufacturer Details */}
                  <div className="space-y-3 sm:space-y-4">
                    <h5 className="text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-100 dark:border-slate-800 pb-2">Manufacturer Details</h5>
                    
                    <div className="grid grid-cols-2 gap-2 text-xs sm:text-sm">
                      <div className="text-slate-500">Manufacturer</div>
                      <div className="font-medium text-slate-800 dark:text-slate-200">{viewingAsset.manufacturer || '-'}</div>
                      
                      <div className="text-slate-500">Model</div>
                      <div className="font-medium text-slate-800 dark:text-slate-200">{viewingAsset.model || '-'}</div>
                      
                      <div className="text-slate-500">Serial Number</div>
                      <div className="font-medium text-slate-800 dark:text-slate-200">{viewingAsset.serialNumber || '-'}</div>
                    </div>
                  </div>

                  {/* Deployment Info */}
                  <div className="space-y-3 sm:space-y-4">
                    <h5 className="text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-100 dark:border-slate-800 pb-2">Deployment</h5>
                    
                    <div className="grid grid-cols-2 gap-2 text-xs sm:text-sm">
                      <div className="text-slate-500">Department</div>
                      <div className="font-medium text-slate-800 dark:text-slate-200">{viewingAsset.department || '-'}</div>
                      
                      <div className="text-slate-500">Location</div>
                      <div className="font-medium text-slate-800 dark:text-slate-200">{viewingAsset.location || '-'}</div>
                      
                      <div className="text-slate-500">Installation Date</div>
                      <div className="font-medium text-slate-800 dark:text-slate-200">{viewingAsset.installationDate || '-'}</div>
                    </div>
                  </div>
                </div>

                {viewingAsset.description && (
                  <div className="space-y-2 mt-4 sm:mt-6">
                    <h5 className="text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-100 dark:border-slate-800 pb-2">Description / Remarks</h5>
                    <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap">{viewingAsset.description}</p>
                  </div>
                )}

                {/* CUSTOM SPECIFICATIONS DISPLAY */}
                {viewingAsset.customSpecifications && viewingAsset.customSpecifications.length > 0 && (
                  <div className="space-y-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                    <div className="flex items-center justify-between">
                      <h5 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                        <SlidersHorizontal className="w-3.5 h-3.5 text-sky-500" />
                        Custom Specifications
                      </h5>
                      <span className="text-[11px] font-mono text-slate-400">
                        {viewingAsset.customSpecifications.length} parameter{viewingAsset.customSpecifications.length === 1 ? '' : 's'}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {viewingAsset.customSpecifications.map((spec, sIdx) => (
                        <div 
                          key={`view-spec-${sIdx}`}
                          className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 shadow-2xs"
                        >
                          <span className="text-xs font-medium text-slate-600 dark:text-slate-400">
                            {spec.name}
                          </span>
                          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 font-mono bg-white dark:bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 shrink-0">
                            {spec.value}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* BREAKDOWN HISTORY SECTION */}
                {(() => {
                  const assetBreakdowns = machineBreakdowns.filter(b => b.asset_id === viewingAsset.id);
                  const activeBreakdown = assetBreakdowns.find(b => b.status !== 'Completed' && b.status !== 'Closed');
                  const totalBreakdowns = assetBreakdowns.length;
                  const lastBreakdown = assetBreakdowns.length > 0 ? assetBreakdowns[0] : null;
                  const totalDowntime = assetBreakdowns.reduce((acc, b) => acc + (b.total_downtime || 2.0), 0);

                  return (
                    <div className="space-y-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                      {activeBreakdown && (
                        <div className="p-3.5 bg-rose-500/15 border-2 border-rose-500/50 rounded-xl text-rose-700 dark:text-rose-300 flex items-center justify-between animate-pulse">
                          <div className="flex items-center gap-2.5">
                            <span className="w-3 h-3 rounded-full bg-rose-600 animate-ping"></span>
                            <div>
                              <span className="font-extrabold text-sm block">🔴 MACHINE BREAKDOWN ACTIVE</span>
                              <span className="text-[11px] opacity-90">{activeBreakdown.problem_description}</span>
                            </div>
                          </div>
                          <span className="text-xs font-mono font-bold bg-rose-600 text-white px-2.5 py-1 rounded-lg">
                            {activeBreakdown.status}
                          </span>
                        </div>
                      )}

                      <div className="flex items-center justify-between">
                        <h5 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                          BREAKDOWN HISTORY
                        </h5>
                        <span className="text-[11px] font-mono text-slate-400">
                          {totalBreakdowns} record{totalBreakdowns === 1 ? '' : 's'}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                        <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                          <span className="text-[10px] uppercase font-bold text-slate-400">Total Breakdowns</span>
                          <p className="text-base font-bold font-display text-slate-900 dark:text-white mt-0.5">{totalBreakdowns}</p>
                        </div>

                        <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                          <span className="text-[10px] uppercase font-bold text-slate-400">Current Status</span>
                          <p className={`text-xs font-bold mt-1 ${activeBreakdown ? 'text-rose-600' : 'text-emerald-600'}`}>
                            {activeBreakdown ? `🔴 ${activeBreakdown.status}` : 'Normal'}
                          </p>
                        </div>

                        <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                          <span className="text-[10px] uppercase font-bold text-slate-400">Total Downtime</span>
                          <p className="text-base font-bold font-mono text-amber-500 mt-0.5">{totalDowntime.toFixed(1)} hrs</p>
                        </div>

                        <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                          <span className="text-[10px] uppercase font-bold text-slate-400">Breakdown Freq</span>
                          <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mt-1">
                            {totalBreakdowns >= 3 ? '⚠️ Frequent' : totalBreakdowns >= 1 ? 'Moderate' : 'Low / Reliable'}
                          </p>
                        </div>
                      </div>

                      {lastBreakdown && (
                        <div className="p-3 bg-slate-50/80 dark:bg-slate-950/80 rounded-xl border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                          <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
                            <span>Last Incident: {lastBreakdown.breakdown_id}</span>
                            <span>{lastBreakdown.reported_date} {lastBreakdown.reported_time}</span>
                          </div>
                          <p className="text-slate-700 dark:text-slate-300 font-medium line-clamp-2">
                            {lastBreakdown.problem_description}
                          </p>
                        </div>
                      )}
                    </div>
                  );
                })()}
                
              </div>
            </div>
            
            <div className="p-3 sm:p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex justify-end items-center shrink-0">
              <button 
                onClick={() => setViewingAsset(null)}
                className="w-full sm:w-auto px-6 py-2 text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg shadow-sm transition-all cursor-pointer min-h-[38px]"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE MACHINE INFORMATION MODAL */}
      {assetToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mb-4 mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-center text-slate-900 dark:text-white font-display">
              Delete Machine Information?
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 text-center mt-2 leading-relaxed">
              Are you sure you want to permanently delete machine records for <strong className="text-slate-700 dark:text-slate-200">{assetToDelete.name}</strong> ({assetToDelete.id})? This will remove all associated machine specifications.
            </p>
            <div className="mt-6 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setAssetToDelete(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  const id = assetToDelete.id;
                  setAssetToDelete(null);
                  confirmDeleteAsset(id);
                }}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 active:bg-rose-700 rounded-lg shadow-sm transition-all cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" /> Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
