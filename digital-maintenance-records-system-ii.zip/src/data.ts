/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Asset, Technician, WorkOrder, ActivityLog, Personnel, MachineBreakdown } from './types';

export const SEED_ASSETS: Asset[] = [];

export const SEED_TECHNICIANS: Technician[] = [];

export const SEED_WORK_ORDERS: WorkOrder[] = [];

export const SEED_ACTIVITY_LOGS: ActivityLog[] = [];

export const SEED_BREAKDOWNS: MachineBreakdown[] = [];

export const SEED_PERSONNEL: Personnel[] = [
  {
    userId: 'USR-001',
    employeeId: 'EMP-1001',
    fullName: 'Ahmad',
    username: 'Ahmad',
    email: 'ahmad@dmr.com',
    phone: '',
    department: 'Management',
    position: 'Manager',
    role: 'Management',
    accountStatus: 'Active',
    dateJoined: '2026-01-01T00:00:00Z',
    lastLogin: new Date().toISOString(),
    pin: '1111',
    primarySkill: 'General',
    skills: ['General'],
    maxWorkload: 5
  },
  {
    userId: 'USR-002',
    employeeId: 'EMP-1002',
    fullName: 'Encik Aziz',
    username: 'Aziz',
    email: 'aziz@dmr.company.com',
    phone: '',
    department: 'Plant Maintenance',
    position: 'Workshop Supervisor & Custodian',
    role: 'Supervisor',
    accountStatus: 'Active',
    dateJoined: '2026-01-01T00:00:00Z',
    lastLogin: new Date().toISOString(),
    pin: '6666',
    primarySkill: 'General',
    skills: ['General', 'Supervision', 'Safety'],
    maxWorkload: 10
  },
  {
    userId: 'USR-46246',
    employeeId: 'EMP-7534',
    fullName: 'Amir Azizi',
    username: 'Amir',
    email: 'amir@dmr.company.com',
    phone: '',
    department: 'Plant Maintenance',
    position: 'General Technician',
    role: 'Technician',
    accountStatus: 'Active',
    dateJoined: '2026-10-02T06:47:49.570Z',
    lastLogin: new Date().toISOString(),
    pin: '2222',
    primarySkill: 'General',
    skills: ['Mechanical', 'Pump', 'Motor', 'Lubrication'],
    maxWorkload: 5
  },
  {
    userId: 'USR-31265',
    employeeId: 'EMP-3031',
    fullName: 'Lee',
    username: 'Lee',
    email: 'lee@dmr.company.com',
    phone: '',
    department: 'Plant Maintenance',
    position: 'Auditor',
    role: 'Auditor',
    accountStatus: 'Active',
    dateJoined: '2026-10-18T13:46:50.995Z',
    lastLogin: new Date().toISOString(),
    pin: '5555',
    primarySkill: 'Mechanical',
    skills: ['Mechanical', 'Pump', 'Motor', 'Lubrication'],
    maxWorkload: 5
  }
];

export const GAS_CODE_SNIPPET = `
// Production Google Apps Script Web App Endpoint Handler
function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    var postData = JSON.parse(e.postData.contents);
    return ContentService.createTextOutput(JSON.stringify({ status: "success" }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ status: "error", error: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
`;
