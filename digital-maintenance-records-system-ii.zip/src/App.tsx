/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from './lib/supabase';
import { WorkOrder, Asset, Technician, UserRole, DatabaseConfig, PriorityLevel, ActivityLog, MaintenanceCategory, Personnel } from './types';
import { SEED_WORK_ORDERS, SEED_ACTIVITY_LOGS, SEED_TECHNICIANS, SEED_ASSETS } from './data';
import ManagerView from './components/ManagerView';
import TechnicianView from './components/TechnicianView';
import AuditorView from './components/AuditorView';
import { PreventiveMaintenanceView } from './components/PreventiveMaintenanceView';
import { ProfileSettingsView } from './components/ProfileSettingsView';
import { AssetListView } from './components/AssetListView';
import { PersonnelManagementView } from './components/PersonnelManagementView';
import { MachineBreakdownView } from './components/MachineBreakdownView';
import { MaintenanceRecordsView } from './components/MaintenanceRecordsView';
import { RequireDocumentView } from './components/RequireDocumentView';
import { IncompleteJobsModal } from './components/IncompleteJobsModal';
import { syncAssetBreakdownStatus, healAndSyncAllAssets, checkAssetHasActiveBreakdown, broadcastMachineSync } from './utils/machineSync';
import { fetchLatestSafetyDocuments, validateWorkOrderSafety, normalizeDocId } from './utils/safetyValidation';
import { 
  Users,
  ShieldCheck, 
  Settings, 
  Database, 
  HelpCircle, 
  RefreshCw, 
  Wrench, 
  Clock, 
  CheckCircle, 
  Briefcase,
  AlertCircle,
  AlertTriangle,
  FileText,
  Sun,
  Moon,
  UserX,
  Lock,
  Menu,
  X,
  History,
  ChevronRight,
  ClipboardList
} from 'lucide-react';

import { SEED_PERSONNEL } from './data';
import { autoAssignTechnician } from './lib/technicianAssignment';
import { 
  getAuthorizedDashboardForRole, 
  isRoleAuthorizedForDashboard, 
  isRoleAuthorizedForModule, 
  getAccessDeniedMessage, 
  parseRouteFromUrl, 
  syncUrlForRoute, 
  saveAuthenticatedSession, 
  getStoredSession, 
  clearAuthenticatedSession 
} from './utils/rbac';
import { DashboardRouteGuard } from './components/DashboardRouteGuard';


// Helper to deduplicate Work Orders to ensure React keys and state remain completely unique
const deduplicateWorkOrders = (orders: WorkOrder[]): WorkOrder[] => {
  const seen = new Set<string>();
  return orders.filter(o => {
    if (!o || !o.id) return false;
    if (seen.has(o.id)) return false;
    seen.add(o.id);
    return true;
  });
};

export default function App() {
  // Dynamic staff and technicians
  const [staffList, setStaffList] = useState<Personnel[]>(() => {
    const saved = localStorage.getItem('dmr_staff_list');
    const demoUsernames = ['aziz_sup', 'syahmi_tech', 'sarah_aud', 'raju_tech', 'ali_tech', 'khairul_tech', 'hafizul_tech', 'sarah'];
    
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          // Remove all demo accounts
          const cleaned = parsed.filter((p: any) => !demoUsernames.includes((p.username || '').toLowerCase()));
          const hasAhmad = cleaned.some((p: any) => (p.username || '').toLowerCase() === 'ahmad');
          
          const result = hasAhmad ? cleaned : [...SEED_PERSONNEL, ...cleaned];
          const seen = new Set<string>();
          const deduped: any[] = [];
          for (const item of result) {
            const key = item.userId || item.username;
            if (!key || !seen.has(key)) {
              if (key) seen.add(key);
              deduped.push(item);
            }
          }
          return deduped.map((p: any) => {
            if ((p.username || '').toLowerCase() === 'ahmad') {
              return {
                ...p,
                fullName: 'Ahmad',
                username: 'Ahmad',
                role: 'Management' as UserRole,
                position: 'Manager',
                accountStatus: 'Active' as const,
                pin: '1111'
              };
            }
            return p;
          });
        }
      } catch (e) {
        console.error("Failed to parse local personnel list", e);
      }
    }
    
    return SEED_PERSONNEL;
  });

  const [technicians, setTechnicians] = useState<Technician[]>(() => {
    const saved = localStorage.getItem('dmr_technicians_list');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const demoNames = ['Raju Raman', 'Ali Bin Abu', 'M. Syahmi Bin Razak', 'Khairul Jamil Bin Ariffin', 'Hafizul Bin Mohd Zul'];
          return parsed.filter((t: any) => !demoNames.includes(t.name));
        }
      } catch (e) {}
    }
    return [];
  });

  // Global Theme State
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    return (localStorage.getItem('dmr_theme') as 'light' | 'dark') || 'light';
  });

  // Session initialization from secure stored session
  const [session, setSession] = useState<{
    userId: string;
    username: string;
    fullName: string;
    role: UserRole;
  } | null>(() => {
    const stored = getStoredSession();
    if (stored) {
      return {
        userId: stored.userId,
        username: stored.username,
        fullName: stored.fullName,
        role: stored.role
      };
    }
    return null;
  });

  const [isAuthorized, setIsAuthorized] = useState<boolean>(() => !!session);
  const [authorizedUser, setAuthorizedUser] = useState<string>(() => session?.fullName || '');
  const [isVerifyingAuth, setIsVerifyingAuth] = useState<boolean>(() => !!session);

  const [loginUsername, setLoginUsername] = useState<string>('');
  const [loginPassword, setLoginPassword] = useState<string>('');
  const [loginError, setLoginError] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);

  // Load initial state from LocalStorage (empty defaults, zero demo orders)
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(() => {
    const saved = localStorage.getItem('dmr_work_orders');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const demoIds = ['DMR-1001', 'DMR-1002', 'DMR-1003', 'DMR-1004', 'DMR-1005'];
          return parsed.filter((o: any) => !demoIds.includes(o.id));
        }
      } catch (e) {}
    }
    return [];
  });

  const [pmTasks, setPmTasks] = useState<any[]>(() => {
    const saved = localStorage.getItem('dmr_pm_tasks');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const demoPmIds = ['PM-1001', 'PM-1002', 'PM-1003', 'PM-1004'];
          return parsed.filter((p: any) => !demoPmIds.includes(p.id));
        }
      } catch (e) {}
    }
    return [];
  });

  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>(() => {
    const saved = localStorage.getItem('dmr_activity_logs');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const demoTicketIds = ['DMR-1001', 'DMR-1002', 'DMR-1003', 'DMR-1004', 'DMR-1005', 'PLC-08', 'LATHE-02'];
          return parsed.filter((l: any) => !demoTicketIds.includes(l.ticketId) && !String(l.id || '').startsWith('LOG-00'));
        }
      } catch (e) {}
    }
    return [];
  });

  const [currentModule, setCurrentModule] = useState<'Dashboard' | 'PreventiveMaintenance' | 'ProfileSettings' | 'AssetList' | 'PersonnelManagement' | 'MachineBreakdown' | 'MaintenanceRecords' | 'RequireDocument'>('Dashboard');
  const [selectedRequireDocWorkOrderId, setSelectedRequireDocWorkOrderId] = useState<string | null>(null);
  const [selectedRequireDocType, setSelectedRequireDocType] = useState<'JSA' | 'PTW' | 'JSA + PTW'>('JSA + PTW');

  // Strictly resolve user's trusted role from database records (never from unvalidated input)
  const userActualRole: UserRole = useMemo(() => {
    if (!isAuthorized || !authorizedUser) return 'Technician';

    const cleanAuth = (authorizedUser || '').trim().toLowerCase();
    const matched = staffList.find(s => 
      (s.fullName || '').trim().toLowerCase() === cleanAuth ||
      (s.username || '').trim().toLowerCase() === cleanAuth ||
      (s.userId || '').trim().toLowerCase() === cleanAuth ||
      (s.employeeId || '').trim().toLowerCase() === cleanAuth
    ) || SEED_PERSONNEL.find(s => 
      (s.fullName || '').trim().toLowerCase() === cleanAuth ||
      (s.username || '').trim().toLowerCase() === cleanAuth ||
      (s.userId || '').trim().toLowerCase() === cleanAuth ||
      (s.employeeId || '').trim().toLowerCase() === cleanAuth
    );

    if (matched?.role) return matched.role;
    if (session?.role) return session.role;
    return 'Technician';
  }, [staffList, authorizedUser, isAuthorized, session]);

  // Current role is strictly locked to verified userActualRole
  const currentRole: UserRole = userActualRole;

  const isManagementAllowed = userActualRole === 'Management';
  const isTechnicianAllowed = userActualRole === 'Technician';
  const isSupervisorAllowed = userActualRole === 'Supervisor';
  const isAuditorAllowed = userActualRole === 'Auditor';

  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error' | 'info', text: string } | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isIncompleteModalOpen, setIsIncompleteModalOpen] = useState(false);

  // Auto-close mobile menu when changing modules
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [currentModule, currentRole]);

  // Handle Access Denied redirection and notification
  const handleAccessDenied = (attemptedTarget: string) => {
    const targetDashboard = getAuthorizedDashboardForRole(userActualRole);
    setCurrentModule('Dashboard');
    syncUrlForRoute('Dashboard', targetDashboard);
    showFeedback('error', getAccessDeniedMessage(attemptedTarget));
  };

  // Active Route Guard: inspects URL parameters, hash, and pathname on navigation
  useEffect(() => {
    if (!isAuthorized || isVerifyingAuth) return;

    const enforceRouteGuard = () => {
      const { requestedDashboard, requestedModule } = parseRouteFromUrl();

      // Check requested dashboard
      if (requestedDashboard) {
        if (!isRoleAuthorizedForDashboard(userActualRole, requestedDashboard)) {
          console.warn(`[RBAC Guard] Blocked unauthorized dashboard: ${userActualRole} cannot access ${requestedDashboard}`);
          handleAccessDenied(requestedDashboard);
          return;
        } else {
          setCurrentModule('Dashboard');
          syncUrlForRoute('Dashboard', requestedDashboard);
          return;
        }
      }

      // Check requested module
      if (requestedModule) {
        if (!isRoleAuthorizedForModule(userActualRole, requestedModule)) {
          console.warn(`[RBAC Guard] Blocked unauthorized module: ${userActualRole} cannot access ${requestedModule}`);
          handleAccessDenied(requestedModule);
          return;
        } else {
          setCurrentModule(requestedModule as any);
          syncUrlForRoute(requestedModule);
          return;
        }
      }
    };

    enforceRouteGuard();

    window.addEventListener('popstate', enforceRouteGuard);
    window.addEventListener('hashchange', enforceRouteGuard);
    return () => {
      window.removeEventListener('popstate', enforceRouteGuard);
      window.removeEventListener('hashchange', enforceRouteGuard);
    };
  }, [isAuthorized, isVerifyingAuth, userActualRole]);

  // Load data from Supabase / local backend
  const fetchData = async () => {
    try {
      const { data: woData, error: woError } = await supabase.from('work_orders').select('*').order('timestamp', { ascending: false });
      if (!woError && woData) {
        const formattedWo = woData
          .map(w => ({
            id: w.id,
            timestamp: w.timestamp,
            assetId: w.asset_id || w.assetId,
            assetName: w.asset_name || w.assetName,
            category: w.category,
            issue: w.issue,
            priority: w.priority,
            assignedToId: w.assigned_to_id || w.assignedToId,
            assignedToName: w.assigned_to_name || w.assignedToName,
            status: w.status,
            loggedBy: w.logged_by || w.loggedBy,
            actionsTaken: w.actions_taken || w.actionsTaken,
            materialsUsed: w.materials_used || w.materialsUsed,
            completedTime: w.completed_time || w.completedTime,
            downtimeHours: w.downtime_hours !== undefined ? w.downtime_hours : w.downtimeHours,
            scheduledDate: w.scheduled_date || w.scheduledDate,
            dueDate: w.due_date || w.dueDate,
            assignmentReason: w.assignment_reason || w.assignmentReason,
            pmScheduleId: w.pm_schedule_id || w.pmScheduleId,
            maintenanceType: w.maintenance_type || w.maintenanceType,
            serialNumber: w.serial_number || w.serialNumber,
            location: w.location || w.machine_location,
            checklist: w.checklist,
            toolsRequired: w.tools_and_materials || w.tools_required || w.toolsRequired,
            materialsRequired: w.materials_required || w.materialsRequired,
            autoGenerated: w.auto_generated !== undefined ? w.auto_generated : w.autoGenerated,
            generatedAt: w.generated_at || w.generatedAt
          }));
        setWorkOrders(formattedWo);
      }

      const { data: logData, error: logError } = await supabase.from('activity_logs').select('*').order('timestamp', { ascending: false });
      if (!logError && logData) {
        const formattedLogs = logData
          .map(l => ({
            id: l.id,
            timestamp: l.timestamp,
            ticketId: l.ticket_id || l.ticketId,
            user: l.user_name || l.user,
            action: l.action,
            details: l.details
          }));
        setActivityLogs(formattedLogs);
      }

      const { data: pmData, error: pmError } = await supabase.from('preventive_maintenance').select('*');
      if (!pmError && pmData) {
        setPmTasks(pmData);
      }

      const { data: profileData, error: profileError } = await supabase.from('profiles').select('*');
      if (!profileError && profileData) {
        const formattedStaff = profileData.map(p => ({
          userId: p.id || p.userId,
          employeeId: p.employeeId || `EMP-${(p.id || '').slice(0, 4)}`,
          fullName: p.full_name || p.fullName || p.username,
          username: p.username,
          email: p.email || `${p.username}@dmr.com`,
          phone: p.phone || '',
          department: p.department || 'Operations',
          position: p.position || p.role,
          role: (p.role as UserRole) || 'Technician',
          accountStatus: p.account_status || p.accountStatus || 'Active',
          dateJoined: p.created_at || p.dateJoined || '2026-01-01T00:00:00Z',
          lastLogin: p.lastLogin || p.created_at,
          pin: p.pin || '1111',
          primarySkill: p.primarySkill || p.primary_skill || 'General',
          skills: p.skills || ['General'],
          maxWorkload: p.maxWorkload || p.max_workload || 5
        }));

        const mergedStaff = [...formattedStaff, ...SEED_PERSONNEL];
        const seen = new Set<string>();
        const finalStaff: any[] = [];
        for (const s of mergedStaff) {
          const key = s.userId || (s.username ? s.username.toLowerCase() : null);
          if (!key || !seen.has(key)) {
            if (key) seen.add(key);
            finalStaff.push(s);
          }
        }
        setStaffList(finalStaff);

        // Strictly validate active session against authentic database records
        if (session) {
          const matched = finalStaff.find(s => 
            s.userId === session.userId || 
            (s.username && s.username.toLowerCase() === session.username.toLowerCase()) ||
            (s.fullName && s.fullName.toLowerCase() === session.fullName.toLowerCase())
          );

          if (!matched || matched.accountStatus !== 'Active') {
            console.warn('[RBAC] Active session invalid or account inactive. De-authorizing terminal.');
            clearAuthenticatedSession();
            setIsAuthorized(false);
            setSession(null);
            setAuthorizedUser('');
          } else if (matched.role !== session.role) {
            console.log('[RBAC] User role updated from database:', matched.role);
            saveAuthenticatedSession({
              userId: matched.userId,
              username: matched.username,
              fullName: matched.fullName,
              role: matched.role
            });
            setSession({
              userId: matched.userId,
              username: matched.username,
              fullName: matched.fullName,
              role: matched.role
            });
          }
        }

        const seenTech = new Set<string>();
        const loadedTechs = finalStaff
          .filter(s => s.role === 'Technician')
          .filter(s => {
            const k = s.userId || s.fullName;
            if (seenTech.has(k)) return false;
            seenTech.add(k);
            return true;
          })
          .map(s => ({
            id: `TECH-${(s.userId || 'USR').slice(0, 4)}`,
            name: s.fullName,
            specialty: s.primarySkill || 'General',
            activeTicketsCount: 0
          }));
        setTechnicians(loadedTechs);
      }
    } catch (err) {
      console.error('Error fetching data from local backend:', err);
    } finally {
      setIsVerifyingAuth(false);
    }
  };

  useEffect(() => {
    fetchData();
    if (isAuthorized) {
      healAndSyncAllAssets();

      const channel = supabase
        .channel('public-db-changes')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'work_orders' }, () => {
          fetchData();
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'preventive_maintenance' }, () => {
          fetchData();
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'activity_logs' }, () => {
          fetchData();
        })
        .subscribe();

      const handleMachineSync = () => {
        fetchData();
      };
      const handleSafetySync = () => {
        fetchData();
      };
      window.addEventListener('dmr_machine_sync', handleMachineSync);
      window.addEventListener('dmr_safety_updated', handleSafetySync);
      window.addEventListener('storage', handleSafetySync);

      return () => {
        supabase.removeChannel(channel);
        window.removeEventListener('dmr_machine_sync', handleMachineSync);
        window.removeEventListener('dmr_safety_updated', handleSafetySync);
        window.removeEventListener('storage', handleSafetySync);
      };
    }
  }, [isAuthorized]);


  // Persist states to LocalStorage
  useEffect(() => {
    localStorage.setItem('dmr_work_orders', JSON.stringify(workOrders));
  }, [workOrders]);

  useEffect(() => {
    if (pmTasks.length > 0) {
      localStorage.setItem('dmr_pm_tasks', JSON.stringify(pmTasks));
    }
  }, [pmTasks]);

  useEffect(() => {
    localStorage.setItem('dmr_activity_logs', JSON.stringify(activityLogs));
  }, [activityLogs]);

    useEffect(() => {
    localStorage.setItem('dmr_current_role', currentRole);
  }, [currentRole]);

  useEffect(() => {
    localStorage.setItem('dmr_staff_list', JSON.stringify(staffList));
  }, [staffList]);

  useEffect(() => {
    localStorage.setItem('dmr_technicians_list', JSON.stringify(technicians));
  }, [technicians]);

  useEffect(() => {
    localStorage.setItem('dmr_theme', theme);
  }, [theme]);

  // Trigger feedback banner
  const showFeedback = (type: 'success' | 'error' | 'info', text: string) => {
    setFeedbackMsg({ type, text });
    setTimeout(() => setFeedbackMsg(null), 5000);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanInput = loginUsername.trim().toLowerCase();
    const cleanPassword = loginPassword.trim();

    // Match by username, employeeId, userId, email, or full name
    const user = staffList.find(s => 
      (s.username || '').trim().toLowerCase() === cleanInput ||
      (s.employeeId || '').trim().toLowerCase() === cleanInput ||
      (s.userId || '').trim().toLowerCase() === cleanInput ||
      (s.email || '').trim().toLowerCase() === cleanInput ||
      (s.fullName || '').trim().toLowerCase() === cleanInput
    ) || SEED_PERSONNEL.find(s => 
      (s.username || '').trim().toLowerCase() === cleanInput ||
      (s.employeeId || '').trim().toLowerCase() === cleanInput ||
      (s.userId || '').trim().toLowerCase() === cleanInput ||
      (s.email || '').trim().toLowerCase() === cleanInput ||
      (s.fullName || '').trim().toLowerCase() === cleanInput
    );

    // Get expected PIN (support seed fallback for accounts if PIN was altered)
    const expectedPin = (user?.pin && user.pin !== '****') 
      ? user.pin 
      : (SEED_PERSONNEL.find(s => s.username === user?.username || s.userId === user?.userId)?.pin || '1111');

    if (user && cleanPassword === expectedPin) {
      if (user.accountStatus !== 'Active') {
        setLoginError('Account is inactive. Please contact your system administrator.');
        showFeedback('error', 'Authentication failed: Account inactive.');
        return;
      }

      // Save authenticated session with strict role binding
      saveAuthenticatedSession({
        userId: user.userId,
        username: user.username,
        fullName: user.fullName,
        role: user.role
      });

      setSession({
        userId: user.userId,
        username: user.username,
        fullName: user.fullName,
        role: user.role
      });

      setIsAuthorized(true);
      setAuthorizedUser(user.fullName);
      setCurrentModule('Dashboard');

      // Automatic Redirection to user's authorized dashboard
      const authorizedDashboard = getAuthorizedDashboardForRole(user.role);
      syncUrlForRoute('Dashboard', authorizedDashboard);

      setLoginError('');
      setLoginPassword('');
      showFeedback('success', `Welcome back, ${user.fullName} (${user.role})! Redirected to ${authorizedDashboard} Console.`);
    } else {
      setLoginError('Invalid username or password.');
      showFeedback('error', 'Authentication failed. Please verify your username and PIN.');
    }
  };

  const handleLogout = () => {
    clearAuthenticatedSession();
    setIsAuthorized(false);
    setAuthorizedUser('');
    setSession(null);
    setCurrentModule('Dashboard');
    setLoginUsername('');
    setLoginPassword('');
    setLoginError('');
    showFeedback('info', 'Session ended. Securely locked terminal.');
  };

  const handleRemoveStaff = (nameToRemove: string) => {
    if (nameToRemove === authorizedUser) {
      showFeedback('error', 'Security Policy: You cannot remove your own active session profile.');
      return;
    }

    setStaffList(prev => prev.filter(s => s.fullName !== nameToRemove));
    setTechnicians(prev => prev.filter(t => t.name !== nameToRemove));

    // Log the staff resignation
    const logId = `LOG-${Math.floor(Math.random() * 90000 + 10000)}`;
    const newLog: ActivityLog = {
      id: logId,
      timestamp: new Date().toISOString(),
      ticketId: 'N/A',
      user: authorizedUser || 'System Administrator',
      action: 'Personnel Resignation',
      details: `Credentials revoked and user profile deleted for ${nameToRemove}.`
    };
    setActivityLogs(prev => [newLog, ...prev]);

    showFeedback('success', `Safety credentials and PIN access for "${nameToRemove}" have been deleted.`);
  };

  // Bidirectional Sync: Fetch rows from live Google Sheet
  ;

  // Helper to generate sequential Ticket IDs (e.g. DMR-1006)
  const generateNextTicketId = () => {
    if (workOrders.length === 0) return 'DMR-1001';
    const ids = workOrders.map(o => {
      const match = o.id.match(/DMR-(\d+)/);
      return match ? parseInt(match[1], 10) : 1000;
    });
    const maxId = Math.max(...ids, 1000);
    return `DMR-${maxId + 1}`;
  };

  // ACTION: Create new Work Order (Management)
  const handleAddWorkOrder = async (newOrder: Omit<WorkOrder, 'id' | 'timestamp' | 'status'> & { status?: any }) => {
    if (currentRole !== 'Management') {
      showFeedback('error', 'Access Restricted: Only Management personnel can generate or create work orders.');
      return;
    }
    const nextId = generateNextTicketId();
    const timestamp = new Date().toISOString();
    
    const status = (newOrder as any).status || 'Pending';

    const completedOrderObj: WorkOrder = {
      ...newOrder,
      id: nextId,
      timestamp,
      status
    };

    const isPendingAssignment = status === 'Pending Technician Assignment';

    const newLog: ActivityLog = {
      id: `LOG-${Math.floor(Math.random() * 90000) + 10000}`,
      timestamp,
      ticketId: nextId,
      user: authorizedUser || 'Management',
      action: 'Created Ticket',
      details: isPendingAssignment
        ? `Logged fault for ${newOrder.assetName} (${newOrder.assetId}). Status set to Pending Technician Assignment (No suitable technician available).`
        : `Logged fault for ${newOrder.assetName} (${newOrder.assetId}). Auto-assigned to ${newOrder.assignedToName}.`
    };

    try {
      await supabase.from('work_orders').insert({
        id: completedOrderObj.id,
        timestamp: completedOrderObj.timestamp,
        asset_id: completedOrderObj.assetId,
        asset_name: completedOrderObj.assetName,
        category: completedOrderObj.category,
        issue: completedOrderObj.issue,
        priority: completedOrderObj.priority,
        assigned_to_id: completedOrderObj.assignedToId,
        assigned_to_name: completedOrderObj.assignedToName,
        status: completedOrderObj.status,
        logged_by: authorizedUser || completedOrderObj.loggedBy
      });
      await supabase.from('activity_logs').insert({
        id: newLog.id,
        timestamp: newLog.timestamp,
        ticket_id: newLog.ticketId,
        user_name: newLog.user,
        action: newLog.action,
        details: newLog.details
      });
    } catch (err) {
      console.error('Failed to save work order / activity log to Firestore:', err);
    }

    setWorkOrders(prev => [completedOrderObj, ...prev]);
    setActivityLogs(prev => [newLog, ...prev]);

    // If linked to a breakdown report, update the breakdown report
    if (newOrder.breakdownId) {
      try {
        await supabase.from('machine_breakdowns').update({
          linked_work_order_id: nextId
        }).eq('breakdown_id', newOrder.breakdownId);

        const saved = localStorage.getItem('dmr_machine_breakdowns');
        if (saved) {
          const parsed = JSON.parse(saved);
          const updated = parsed.map((b: any) => 
            b.breakdown_id === newOrder.breakdownId ? { ...b, linked_work_order_id: nextId } : b
          );
          localStorage.setItem('dmr_machine_breakdowns', JSON.stringify(updated));
        }
      } catch (err) {
        console.error('Failed to link breakdown to work order:', err);
      }
    }
  };


  
  // ACTION: Pause Work
  const handlePauseWork = async (id: string) => {
    try {
      if (id.startsWith('PM-')) {
        await supabase.from('preventive_maintenance').update({ status: 'Paused' }).eq('id', id);
      } else {
        await supabase.from('work_orders').update({ status: 'Paused' }).eq('id', id);
      }
    } catch (e) {
      console.error('Error pausing work order / PM in db:', e);
    }
    
    setWorkOrders(prev => prev.map(o => {
      if (o.id === id) {
        return { ...o, status: 'Paused' };
      }
      return o;
    }));

    setPmTasks(prev => prev.map(p => {
      if (p.id === id) {
        return { ...p, status: 'Paused' };
      }
      return p;
    }));

    const newLog = {
      id: `LOG-${Math.floor(Math.random() * 90000) + 10000}`,
      timestamp: new Date().toISOString(),
      ticketId: id,
      user: authorizedUser || 'Technician',
      action: 'Paused Work',
      details: `Status updated to Paused for ${id}.`
    };
    
    try {
      await supabase.from('activity_logs').insert({
        id: newLog.id,
        timestamp: newLog.timestamp,
        ticket_id: newLog.ticketId,
        user_name: newLog.user,
        action: newLog.action,
        details: newLog.details
      });
    } catch (e) {}
    
    // @ts-ignore
    setActivityLogs(prev => [newLog, ...prev]);
  };

  // ACTION: Start Work (Technician transition Pending -> In Progress)
  const handleStartWork = async (id: string) => {
    const cleanId = normalizeDocId(id);
    const isPM = id.startsWith('PM-') || pmTasks.some(p => normalizeDocId(p.id) === cleanId);

    if (!isPM) {
      // 1. Fetch latest safety documents from DB
      const latestDocs = await fetchLatestSafetyDocuments(id);

      // 2. Locate ticket
      const ticket = workOrders.find(o => normalizeDocId(o.id) === cleanId);
      if (ticket) {
        const validation = validateWorkOrderSafety(ticket, latestDocs);
        if (!validation.canStart) {
          showFeedback('error', validation.specificMessage || `SAFETY HOLD: Work start blocked for ticket #${ticket.id}. Required safety documents must be approved.`);
          return;
        }
      }
    }

    try {
      if (isPM) {
        await supabase.from('preventive_maintenance').update({ status: 'In Progress' }).eq('id', id);
      } else {
        await supabase.from('work_orders').update({ 
          status: 'In Progress',
          workAuthorized: true,
          workAuthorizedAt: new Date().toISOString(),
          workAuthorizedBy: authorizedUser || 'Authorized Technician'
        }).eq('id', id);
      }
    } catch (e) {
      console.error('Error starting work order / PM in db:', e);
    }
    
    setWorkOrders(prev => {
      const updated = prev.map(o => {
        if (normalizeDocId(o.id) === cleanId) {
          return { ...o, status: 'In Progress', workAuthorized: true };
        }
        return o;
      });
      try {
        localStorage.setItem('dmr_work_orders', JSON.stringify(updated));
      } catch (_) {}
      return updated;
    });

    setPmTasks(prev => prev.map(p => {
      if (normalizeDocId(p.id) === cleanId) {
        return { ...p, status: 'In Progress' };
      }
      return p;
    }));

    const newLog = {
      id: `LOG-${Math.floor(Math.random() * 90000) + 10000}`,
      timestamp: new Date().toISOString(),
      ticketId: id,
      user: authorizedUser || 'Technician',
      action: 'Started Work',
      details: `Status updated to In Progress for ${id}.`
    };
    
    try {
      await supabase.from('activity_logs').insert({
        id: newLog.id,
        timestamp: newLog.timestamp,
        ticket_id: newLog.ticketId,
        user_name: newLog.user,
        action: newLog.action,
        details: newLog.details
      });
    } catch (e) {}

    // @ts-ignore
    setActivityLogs(prev => [newLog, ...prev]);
  };

  // ACTION: Complete Work (Technician transition In Progress -> Completed)
  const handleCompleteWork = async (id: string, actions: string, materials: string, downtime: number) => {
    const completedTime = new Date().toISOString();

    setWorkOrders(prev => prev.map(o => {
      if (o.id === id) {
        return {
          ...o,
          status: 'Completed',
          actionsTaken: actions,
          materialsUsed: materials,
          completedTime,
          downtimeHours: downtime
        };
      }
      return o;
    }));

    setPmTasks(prev => prev.map(p => {
      if (p.id === id) {
        return {
          ...p,
          status: 'Completed',
          remarks: actions,
          completed_at: completedTime,
          actual_duration: downtime,
          downtime_hours: downtime
        };
      }
      return p;
    }));

    try {
      if (id.startsWith('PM-')) {
        await supabase.from('preventive_maintenance').update({
          status: 'Completed',
          remarks: actions,
          downtime_hours: downtime
        }).eq('id', id);
      } else {
        await supabase.from('work_orders').update({
          status: 'Completed',
          actions_taken: actions,
          materials_used: materials,
          completed_time: completedTime,
          downtime_hours: downtime
        }).eq('id', id);
      }
    } catch (e) {}

    // Audit logs
    const ticket = [...workOrders, ...pmTasks].find(o => o.id === id);
    const techName = ticket ? (ticket.assignedToName || ticket.assigned_to_name) : 'Technician';

    const newLog: ActivityLog = {
      id: `LOG-${Math.floor(Math.random() * 90000) + 10000}`,
      timestamp: completedTime,
      ticketId: id,
      user: techName || authorizedUser || 'Technician',
      action: 'Completed Repairs',
      details: `Resolved breakdown. Action: ${actions}. Spare parts: ${materials || 'None'}. Downtime: ${downtime} hrs.`
    };

    try {
      await supabase.from('activity_logs').insert({
        id: newLog.id,
        timestamp: newLog.timestamp,
        ticket_id: newLog.ticketId,
        user_name: newLog.user,
        action: newLog.action,
        details: newLog.details
      });
    } catch (e) {}

    // If work order is linked to a machine breakdown report, automatically mark that breakdown as Completed
    let linkedBreakdownId = ticket?.breakdownId;
    try {
      const savedBrk = localStorage.getItem('dmr_machine_breakdowns');
      if (savedBrk) {
        const parsed = JSON.parse(savedBrk);
        if (Array.isArray(parsed)) {
          if (!linkedBreakdownId && ticket?.id) {
            const found = parsed.find((b: any) => b.linked_work_order_id === ticket.id);
            if (found) linkedBreakdownId = found.breakdown_id || found.id;
          }

          if (linkedBreakdownId) {
            const updated = parsed.map((b: any) => 
              (b.breakdown_id === linkedBreakdownId || b.id === linkedBreakdownId) 
                ? { 
                    ...b, 
                    status: 'Completed', 
                    downtime_end: completedTime, 
                    total_downtime: downtime, 
                    remarks: actions, 
                    updated_at: completedTime 
                  } 
                : b
            );
            localStorage.setItem('dmr_machine_breakdowns', JSON.stringify(updated));
          }
        }
      }
    } catch (_) {}

    if (linkedBreakdownId) {
      try {
        await supabase.from('machine_breakdowns').update({
          status: 'Completed',
          downtime_end: completedTime,
          total_downtime: downtime,
          remarks: actions,
          updated_at: completedTime
        }).eq('breakdown_id', linkedBreakdownId);

        await supabase.from('machine_breakdowns').update({
          status: 'Completed',
          downtime_end: completedTime,
          total_downtime: downtime,
          remarks: actions,
          updated_at: completedTime
        }).eq('id', linkedBreakdownId);
      } catch (err) {
        console.warn('Failed to update linked breakdown on WO completion in Supabase:', err);
      }
    }

    // Always check if the asset has active breakdowns remaining or can return to Operational
    if (ticket && ticket.assetId) {
      try {
        const hasActive = checkAssetHasActiveBreakdown(ticket.assetId);
        if (!hasActive) {
          await syncAssetBreakdownStatus(ticket.assetId, false, `Work order ${id} completed`);
        }
        await healAndSyncAllAssets();
      } catch (err) {
        console.warn('Failed to sync asset to Operational on completion:', err);
      }
      broadcastMachineSync(ticket.assetId, 'Completed', { workOrderId: id, breakdownId: linkedBreakdownId });
    }

    setActivityLogs(prev => [newLog, ...prev]);

    showFeedback('success', `Ticket ${id} marked completed.`);
  };

  // ACTION: Update priority level (Management)
  const handleUpdatePriority = async (id: string, priority: PriorityLevel) => {
    try {
      await supabase.from('work_orders').update({ priority }).eq('id', id);
    } catch (err) {
      console.error('Failed to update priority in Firestore:', err);
    }

    setWorkOrders(prev => prev.map(o => {
      if (o.id === id) {
        return { ...o, priority };
      }
      return o;
    }));

    const newLog: ActivityLog = {
      id: `LOG-${Math.floor(Math.random() * 90000) + 10000}`,
      timestamp: new Date().toISOString(),
      ticketId: id,
      user: authorizedUser || 'Management',
      action: 'Modified Priority',
      details: `Set priority of ${id} to ${priority}.`
    };
    
    try {
      await supabase.from('activity_logs').insert({
        id: newLog.id,
        timestamp: newLog.timestamp,
        ticket_id: newLog.ticketId,
        user_name: newLog.user,
        action: newLog.action,
        details: newLog.details
      });
    } catch (err) {
      console.error('Failed to insert activity log in Firestore:', err);
    }
    
    setActivityLogs(prev => [newLog, ...prev]);
  };

  // ACTION: Reassign Technician (Management)
  const handleReassignTechnician = async (id: string, techId: string, techName: string) => {
    try {
      await supabase.from('work_orders').update({ 
        assigned_to_id: techId, 
        assigned_to_name: techName 
      }).eq('id', id);
    } catch (err) {
      console.error('Failed to reassign technician in Firestore:', err);
    }

    setWorkOrders(prev => prev.map(o => {
      if (o.id === id) {
        return { ...o, assignedToId: techId, assignedToName: techName };
      }
      return o;
    }));

    const newLog: ActivityLog = {
      id: `LOG-${Math.floor(Math.random() * 90000) + 10000}`,
      timestamp: new Date().toISOString(),
      ticketId: id,
      user: authorizedUser || 'Management',
      action: 'Reassigned Technician',
      details: `Reassigned ${id} to ${techName}.`
    };
    
    try {
      await supabase.from('activity_logs').insert({
        id: newLog.id,
        timestamp: newLog.timestamp,
        ticket_id: newLog.ticketId,
        user_name: newLog.user,
        action: newLog.action,
        details: newLog.details
      });
    } catch (err) {
      console.error('Failed to insert activity log in Firestore:', err);
    }
    
    setActivityLogs(prev => [newLog, ...prev]);
  };

  // ACTION: Update Status of work order or PM task
  const handleUpdateStatus = async (id: string, newStatus: string) => {
    try {
      if (id.startsWith('PM-')) {
        await supabase.from('preventive_maintenance').update({ status: newStatus }).eq('id', id);
        setPmTasks(prev => prev.map(p => p.id === id ? { ...p, status: newStatus } : p));
      } else {
        await supabase.from('work_orders').update({ status: newStatus }).eq('id', id);
        setWorkOrders(prev => prev.map(o => o.id === id ? { ...o, status: newStatus as any } : o));
      }
    } catch (err) {
      console.error('Failed to update status in database:', err);
    }
    showFeedback('success', `Status of ${id} updated to ${newStatus}.`);
  };

  const normalizedPMTasks = pmTasks.map(pm => ({
    id: pm.id,
    timestamp: pm.scheduled_date,
    scheduledDate: pm.scheduled_date || pm.scheduledDate,
    dueDate: pm.due_date || pm.dueDate || pm.scheduled_date || pm.scheduledDate,
    assetId: pm.asset_id,
    assetName: pm.asset_name,
    category: pm.category || 'General',
    issue: `[${pm.maintenance_type || 'PM'}] ${pm.maintenance_task}`,
    priority: pm.priority,
    assignedToId: pm.assigned_to_id || 'unassigned',
    assignedToName: pm.assigned_to_name || pm.assigned_technician || pm.assignedToName,
    status: pm.status,
    loggedBy: pm.supervisor || pm.logged_by || 'System',
    isPM: true,
    downtimeHours: pm.estimated_duration || 2
  }));

  // Shared Work Orders calculation: single source of truth for both "Pending Work" and "Incomplete Jobs" cards
  // Evaluates actual Work Orders records from database (work_orders) with deduplication to prevent double counting
  const uniqueWorkOrders = useMemo(() => {
    if (!Array.isArray(workOrders)) return [];
    const seen = new Set<string>();
    return workOrders.filter(order => {
      if (!order || !order.id) return false;
      const cleanId = String(order.id).trim();
      if (!cleanId || seen.has(cleanId)) return false;
      seen.add(cleanId);
      return true;
    });
  }, [workOrders]);

  // Shared Work Order count for both "Pending Work" and "Incomplete Jobs" dashboard cards
  const sharedWorkOrdersCount = uniqueWorkOrders.length;
  const pendingCount = sharedWorkOrdersCount;
  const incompleteJobsCount = sharedWorkOrdersCount;

  const allTickets = [...workOrders, ...normalizedPMTasks];
  const inProgressCount = allTickets.filter(o => o.status === 'In Progress').length;
  const completedCount = allTickets.filter(o => o.status === 'Completed').length;
  const totalCount = allTickets.length;
  
  // Calculate average downtime using formula:
  // Average Downtime (hours) = Total Downtime (hours) / Number of Downtime Events
  const downtimeEvents = allTickets.filter(
    o => o.status === 'Completed' && o.downtimeHours !== undefined && Number(o.downtimeHours) > 0
  );
  const totalDowntimeHours = downtimeEvents.reduce(
    (acc, curr) => acc + (Number(curr.downtimeHours) || 0),
    0
  );
  const numberOfDowntimeEvents = downtimeEvents.length;
  const avgDowntimeHours = numberOfDowntimeEvents > 0 
    ? (totalDowntimeHours / numberOfDowntimeEvents).toFixed(1)
    : "0.0";
  const mttrAvg = avgDowntimeHours;

  const uptimeScore = totalCount > 0 
    ? (95 + Math.min(3.2, (completedCount / totalCount) * 3.2)).toFixed(1)
    : "98.2";

  if (isVerifyingAuth) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center p-4 font-sans select-none">
        <div className="w-16 h-16 sm:w-20 sm:h-20 bg-slate-900 border-2 border-amber-500 rounded-2xl flex items-center justify-center shadow-2xl shadow-amber-500/20 mb-6 p-2 animate-pulse">
          <Wrench className="w-9 h-9 text-amber-500 animate-spin" style={{ animationDuration: '3s' }} />
        </div>
        <div className="text-center max-w-sm space-y-2">
          <h2 className="text-base sm:text-lg font-bold font-display tracking-tight text-white uppercase">
            Verifying Terminal Authorization
          </h2>
          <p className="text-xs text-slate-400 font-mono">
            Validating security role permissions and database authentication records...
          </p>
          <div className="w-48 h-1 bg-slate-900 rounded-full mx-auto mt-4 overflow-hidden">
            <div className="h-full bg-amber-500 rounded-full animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  if (!isAuthorized) {
    return (
      <div className="min-h-screen bg-industrial-grid flex flex-col justify-center items-center p-3 sm:p-4 font-sans selection:bg-amber-500/30 relative overflow-x-hidden overflow-y-auto">
        
        <div className="w-full max-w-sm z-10 px-2 sm:px-0 my-auto py-8">
          <div className="mb-6 sm:mb-8 text-center flex flex-col items-center">
            <div className="w-14 h-14 sm:w-16 sm:h-16 bg-hazard-stripes-sm rounded-lg flex items-center justify-center shadow-lg shadow-amber-500/20 mb-3 sm:mb-4 border-2 border-amber-500 p-1">
              <div className="w-full h-full bg-slate-900 rounded flex items-center justify-center">
                <Wrench className="w-7 h-7 sm:w-8 sm:h-8 text-amber-500" />
              </div>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tighter text-white block font-display uppercase">DMR System</h1>
            <p className="text-[11px] sm:text-xs text-amber-500 font-bold uppercase tracking-[0.3em] block mt-1 bg-amber-500/10 px-3 py-1 rounded border border-amber-500/20">TVET Workshop</p>
          </div>

          <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl relative industrial-panel">
            <div className="p-4 sm:p-6">
              <form onSubmit={handleLogin} className="space-y-4 sm:space-y-5">
                {loginError && (
                  <div className="p-2.5 sm:p-3 bg-rose-950/60 border border-rose-800 text-rose-300 rounded-sm text-xs font-medium text-center flex items-center justify-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse shrink-0"></span> <span>{loginError}</span>
                  </div>
                )}

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                    Username
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Enter operator ID"
                    className="block w-full rounded-sm border-b-2 border-slate-700 bg-slate-950 text-slate-200 px-3 py-2.5 text-sm focus:border-amber-500 focus:ring-0 outline-none placeholder:text-slate-600 transition-all font-mono"
                    value={loginUsername}
                    onChange={(e) => {
                      setLoginUsername(e.target.value);
                      setLoginError('');
                    }}
                  />
                </div>

                <div className="space-y-1.5 relative">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                    Password
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      placeholder="••••••••"
                      className="block w-full text-center rounded-sm border-b-2 border-slate-700 bg-slate-950 text-slate-200 px-3 py-2.5 text-sm tracking-[0.2em] font-mono focus:border-amber-500 focus:ring-0 outline-none placeholder:text-slate-700 placeholder:tracking-normal transition-all"
                      value={loginPassword}
                      onChange={(e) => {
                        setLoginPassword(e.target.value);
                        setLoginError('');
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-amber-500 text-xs font-bold uppercase tracking-wider focus:outline-none bg-slate-950 pl-2 transition-colors py-1 cursor-pointer"
                    >
                      {showPassword ? "Hide" : "Show"}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <label className="flex items-center gap-1.5 cursor-pointer text-slate-400 hover:text-slate-300 select-none text-[11px] font-mono">
                    <input
                      type="checkbox"
                      className="rounded border-slate-700 bg-slate-950 text-amber-500 focus:ring-0 focus:ring-offset-0 cursor-pointer w-3.5 h-3.5"
                    />
                    <span>Remember ID</span>
                  </label>
                  <button type="button" className="text-[10px] text-slate-500 hover:text-amber-400 transition-colors font-bold cursor-pointer uppercase tracking-widest">
                    Forgot Key?
                  </button>
                </div>

                <button
                  type="submit"
                  className="w-full flex justify-center items-center gap-2 px-4 py-3 text-xs font-black uppercase tracking-[0.2em] text-slate-950 bg-amber-500 hover:bg-amber-400 rounded-sm cursor-pointer transition-all shadow-md hover:shadow-amber-500/20 active:translate-y-px mt-2 sm:mt-4 min-h-[44px]"
                >
                  <ShieldCheck className="w-4 h-4 shrink-0" /> Initialize Access
                </button>
              </form>
            </div>
          </div>
        </div>

        <div className="w-full flex justify-between px-4 sm:px-8 text-[9px] sm:text-[10px] text-slate-600 font-mono tracking-widest select-none z-10 uppercase font-bold opacity-50 mt-4 sm:mt-0 sm:absolute sm:bottom-4 left-0">
          <span>SYS.VER.1.0.0</span>
          <span>RESTRICTED AREA</span>
        </div>
      </div>
    );
  }
  return (
    <div className={`flex flex-col md:flex-row min-h-screen font-sans overflow-x-hidden antialiased transition-colors duration-200 ${
      theme === 'dark' ? 'dark text-slate-100 futuristic-bg' : 'bg-[#f8fafc] text-slate-900'
    }`}>
      
      {/* Dynamic Toast Feedback Overlay */}
      {feedbackMsg && (
        <div className="fixed bottom-4 right-4 sm:bottom-5 sm:right-5 z-50 max-w-[calc(100vw-2rem)] sm:max-w-sm">
          <div className={`p-3.5 sm:p-4 rounded-xl border shadow-xl flex items-start gap-3 animate-bounce ${
            feedbackMsg.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-900' :
            feedbackMsg.type === 'error' ? 'bg-rose-50 border-rose-200 text-rose-900' :
            'bg-slate-900 border-slate-800 text-slate-100 shadow-slate-950/20'
          }`}>
            <AlertCircle className={`w-5 h-5 shrink-0 ${
              feedbackMsg.type === 'success' ? 'text-emerald-600' :
              feedbackMsg.type === 'error' ? 'text-rose-600' : 'text-amber-400'
            }`} />
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider mb-0.5">Database Status Notification</p>
              <p className="text-xs leading-relaxed opacity-90">{feedbackMsg.text}</p>
            </div>
          </div>
        </div>
      )}

      {/* Sidebar Navigation */}
      {/* Mobile Drawer Backdrop */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-40 md:hidden transition-opacity" 
          onClick={() => setIsMobileMenuOpen(false)}
          aria-hidden="true"
        />
      )}

      <aside className={`
        ${isMobileMenuOpen ? 'fixed inset-y-0 left-0 z-50 flex translate-x-0' : 'hidden -translate-x-full'} 
        md:translate-x-0 md:relative md:flex w-[280px] max-w-[85vw] md:w-64 bg-[#050b14]/95 md:bg-[#050b14]/90 backdrop-blur-xl text-slate-300 flex-col shrink-0 border-r border-slate-800/80 shadow-2xl md:shadow-[4px_0_24px_-12px_rgba(14,165,233,0.3)] md:z-10 transition-transform duration-300 ease-in-out h-full min-h-screen
      `}>
        <div className="relative z-10 flex flex-col h-full bg-[#050b14] w-full overflow-y-auto">
          {/* Brand Block */}
          <div className="p-4 sm:p-5 flex items-center justify-between border-b border-slate-800 shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-amber-500 rounded flex items-center justify-center text-white shadow-lg shadow-amber-500/20 shrink-0">
                <Wrench className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="font-bold tracking-tight text-white block text-sm sm:text-base font-display truncate">DMR System</span>
                <span className="text-[10px] text-amber-400 font-semibold uppercase tracking-widest block -mt-1 truncate">TVET Workshop</span>
              </div>
            </div>
            <button 
              className="md:hidden p-2 -mr-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer min-h-[40px] min-w-[40px] flex items-center justify-center" 
              onClick={() => setIsMobileMenuOpen(false)}
              aria-label="Close Navigation Menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

        {/* Navigation / Role Selector Items */}
        <nav className="flex-1 p-3 sm:p-4 space-y-1 text-sm overflow-y-auto">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider px-2.5 mb-2">
            Authorized Dashboard
          </p>

          {/* 1. Management Role Dashboard Entry */}
          {userActualRole === 'Management' && (
            <>
              <button
                onClick={() => { 
                  setCurrentModule('Dashboard'); 
                  syncUrlForRoute('Dashboard', 'Management');
                  setIsMobileMenuOpen(false); 
                }}
                className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all text-left min-h-[44px] cursor-pointer ${
                  currentModule === 'Dashboard'
                    ? 'bg-slate-800 text-white font-semibold border-l-4 border-amber-500 pl-1.5'
                    : 'hover:bg-slate-800/60 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Briefcase className={`w-4 h-4 shrink-0 ${currentModule === 'Dashboard' ? 'text-amber-400' : 'text-slate-500'}`} />
                <div className="flex-1 min-w-0">
                  <span className="block text-xs font-medium truncate">Management Console</span>
                  <span className="block text-[9px] text-slate-500 -mt-0.5 truncate">Dispatches & Priorities</span>
                </div>
              </button>
              
              <button
                onClick={() => { 
                  setCurrentModule('PreventiveMaintenance'); 
                  syncUrlForRoute('PreventiveMaintenance');
                  setIsMobileMenuOpen(false); 
                }}
                className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all text-left ml-2 cursor-pointer min-h-[44px] ${
                  currentModule === 'PreventiveMaintenance'
                    ? 'bg-slate-800/80 text-white font-semibold border-l-2 border-indigo-500'
                    : 'hover:bg-slate-800/40 text-slate-400 hover:text-slate-200'
                }`}
              >
                <ShieldCheck className={`w-3.5 h-3.5 shrink-0 ${currentModule === 'PreventiveMaintenance' ? 'text-indigo-400' : 'text-slate-500'}`} />
                <span className="block text-[11px] font-medium truncate">PM Dashboard</span>
              </button>
            </>
          )}

          {/* 2. Technician Role Dashboard Entry */}
          {userActualRole === 'Technician' && (
            <button
              onClick={() => { 
                setCurrentModule('Dashboard'); 
                syncUrlForRoute('Dashboard', 'Technician');
                setIsMobileMenuOpen(false); 
              }}
              className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all text-left min-h-[44px] cursor-pointer ${
                currentModule === 'Dashboard'
                  ? 'bg-slate-800 text-white font-semibold border-l-4 border-amber-500 pl-1.5'
                  : 'hover:bg-slate-800/60 text-slate-400 hover:text-slate-200'
              }`}
            >
              <Wrench className={`w-4 h-4 shrink-0 ${currentModule === 'Dashboard' ? 'text-amber-400' : 'text-slate-500'}`} />
              <div className="flex-1 min-w-0">
                <span className="block text-xs font-medium truncate">Technician Console</span>
                <span className="block text-[9px] text-slate-500 -mt-0.5 truncate">Assigned Work & Execution</span>
              </div>
            </button>
          )}

          {/* 3. Supervisor Role Dashboard Entry */}
          {userActualRole === 'Supervisor' && (
            <button
              onClick={() => { 
                setCurrentModule('Dashboard'); 
                syncUrlForRoute('Dashboard', 'Supervisor');
                setIsMobileMenuOpen(false); 
              }}
              className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all text-left min-h-[44px] cursor-pointer ${
                currentModule === 'Dashboard'
                  ? 'bg-slate-800 text-white font-semibold border-l-4 border-amber-500 pl-1.5'
                  : 'hover:bg-slate-800/60 text-slate-400 hover:text-slate-200'
              }`}
            >
              <ClipboardList className={`w-4 h-4 shrink-0 ${currentModule === 'Dashboard' ? 'text-amber-400' : 'text-slate-500'}`} />
              <div className="flex-1 min-w-0">
                <span className="block text-xs font-medium truncate">Supervisor Console</span>
                <span className="block text-[9px] text-slate-500 -mt-0.5 truncate">Dispatch & Oversight</span>
              </div>
            </button>
          )}

          {/* 4. Auditor Role Dashboard Entry */}
          {userActualRole === 'Auditor' && (
            <button
              onClick={() => { 
                setCurrentModule('Dashboard'); 
                syncUrlForRoute('Dashboard', 'Auditor');
                setIsMobileMenuOpen(false); 
              }}
              className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all text-left min-h-[44px] cursor-pointer ${
                currentModule === 'Dashboard'
                  ? 'bg-slate-800 text-white font-semibold border-l-4 border-amber-500 pl-1.5'
                  : 'hover:bg-slate-800/60 text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileText className={`w-4 h-4 shrink-0 ${currentModule === 'Dashboard' ? 'text-amber-400' : 'text-slate-500'}`} />
              <div className="flex-1 min-w-0">
                <span className="block text-xs font-medium truncate">Compliance Auditor Panel</span>
                <span className="block text-[9px] text-slate-500 -mt-0.5 truncate">Read-Only Logs & KPIs</span>
              </div>
            </button>
          )}
          
          <button
            onClick={() => { setCurrentModule('AssetList'); setIsMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all text-left cursor-pointer min-h-[44px] ${
              currentModule === 'AssetList'
                ? 'bg-slate-800 text-white font-semibold border-l-4 border-indigo-500 pl-1.5'
                : 'hover:bg-slate-800/60 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className={`w-4 h-4 shrink-0 ${currentModule === 'AssetList' ? 'text-indigo-400' : 'text-slate-500'}`} />
            <div className="flex-1 min-w-0">
              <span className="block text-xs font-medium truncate">Asset Directory</span>
              <span className="block text-[9px] text-slate-500 -mt-0.5 truncate">View & Manage Equipment</span>
            </div>
          </button>

          {/* Machine Breakdown Navigation Button */}
          <button
            onClick={() => { setCurrentModule('MachineBreakdown'); setIsMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all text-left cursor-pointer min-h-[44px] ${
              currentModule === 'MachineBreakdown'
                ? 'bg-slate-800 text-white font-semibold border-l-4 border-rose-500 pl-1.5'
                : 'hover:bg-slate-800/60 text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="relative shrink-0">
              <AlertTriangle className={`w-4 h-4 ${currentModule === 'MachineBreakdown' ? 'text-rose-400' : 'text-slate-500'}`} />
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 absolute -top-0.5 -right-0.5 animate-ping"></span>
            </div>
            <div className="flex-1 min-w-0">
              <span className="block text-xs font-medium truncate flex items-center gap-1.5">
                Machine Breakdown
                <span className="px-1.5 py-0.2 bg-rose-600/30 text-rose-400 border border-rose-600/40 text-[9px] rounded font-mono font-bold">
                  LIVE
                </span>
              </span>
              <span className="block text-[9px] text-slate-500 -mt-0.5 truncate">Reports & Telemetry</span>
            </div>
          </button>

          {/* Maintenance Records Navigation Button (Read-Only for ALL Roles) */}
          <button
            onClick={() => { setCurrentModule('MaintenanceRecords'); setIsMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all text-left cursor-pointer min-h-[44px] ${
              currentModule === 'MaintenanceRecords'
                ? 'bg-slate-800 text-white font-semibold border-l-4 border-cyan-500 pl-1.5'
                : 'hover:bg-slate-800/60 text-slate-400 hover:text-slate-200'
            }`}
          >
            <History className={`w-4 h-4 shrink-0 ${currentModule === 'MaintenanceRecords' ? 'text-cyan-400' : 'text-slate-500'}`} />
            <div className="flex-1 min-w-0">
              <span className="block text-xs font-medium truncate flex items-center gap-1.5">
                Maintenance Records
                <span className="px-1.5 py-0.2 bg-cyan-600/30 text-cyan-400 border border-cyan-600/40 text-[9px] rounded font-mono font-bold">
                  READ ONLY
                </span>
              </span>
              <span className="block text-[9px] text-slate-500 -mt-0.5 truncate">Machine History & Logs</span>
            </div>
          </button>
          
          {/* Require Document Navigation Button (JSA & PTW) */}
          <button
            onClick={() => { setSelectedRequireDocWorkOrderId(null); setCurrentModule('RequireDocument'); setIsMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all text-left cursor-pointer min-h-[44px] ${
              currentModule === 'RequireDocument'
                ? 'bg-slate-800 text-white font-semibold border-l-4 border-amber-500 pl-1.5'
                : 'hover:bg-slate-800/60 text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className={`w-4 h-4 shrink-0 ${currentModule === 'RequireDocument' ? 'text-amber-400' : 'text-slate-500'}`} />
            <div className="flex-1 min-w-0">
              <span className="block text-xs font-medium truncate flex items-center gap-1.5">
                Require Document
                <span className="px-1.5 py-0.2 bg-amber-600/30 text-amber-400 border border-amber-600/40 text-[9px] rounded font-mono font-bold">
                  JSA & PTW
                </span>
              </span>
              <span className="block text-[9px] text-slate-500 -mt-0.5 truncate">Permits & Risk Assessments</span>
            </div>
          </button>
          
          {currentRole === 'Management' && (
            <button
              onClick={() => { setCurrentModule('PersonnelManagement'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all text-left cursor-pointer mt-1 min-h-[44px] ${
                currentModule === 'PersonnelManagement'
                  ? 'bg-slate-800 text-white font-semibold border-l-4 border-indigo-500 pl-1.5'
                  : 'hover:bg-slate-800/60 text-slate-400 hover:text-slate-200'
              }`}
            >
              <Users className={`w-4 h-4 shrink-0 ${currentModule === 'PersonnelManagement' ? 'text-indigo-400' : 'text-slate-500'}`} />
              <div className="flex-1 min-w-0">
                <span className="block text-xs font-medium truncate">Personnel Mgmt</span>
                <span className="block text-[9px] text-slate-500 -mt-0.5 truncate">Staff & Access Control</span>
              </div>
            </button>
          )}
        </nav>

        {/* Connection box at bottom */}
        <div className="p-3 sm:p-4 border-t border-slate-800 space-y-3 shrink-0">
          <div className="bg-slate-800/40 p-3 rounded-lg border border-slate-800">
            <p className="text-[9px] uppercase font-bold text-slate-500 tracking-wider">Operator Profile</p>
            <p className="text-xs text-amber-400 font-bold truncate mt-0.5" title={authorizedUser}>
              {authorizedUser}
            </p>
            <div className="flex items-center justify-between mt-2">
              <span className="inline-block px-1.5 py-0.5 bg-emerald-950/80 text-emerald-400 text-[8px] font-bold rounded border border-emerald-900 uppercase">
                {currentRole}
              </span>
              <button
                onClick={handleLogout}
                className="text-[9px] text-rose-400 hover:text-rose-300 font-bold uppercase tracking-wider hover:underline transition-all cursor-pointer py-1 px-1"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className={`flex-1 flex flex-col min-w-0 transition-colors duration-200 ${
        theme === 'dark' ? 'bg-transparent text-slate-100 relative' : 'bg-[#f8fafc] text-slate-900'
      }`}>
        {theme === 'dark' && (
          <>
            <div className="absolute top-[10%] right-[5%] w-[30%] h-[30%] bg-amber-500/5 blur-[100px] rounded-full pointer-events-none"></div>
            <div className="absolute bottom-[10%] left-[20%] w-[40%] h-[40%] bg-indigo-500/5 blur-[120px] rounded-full pointer-events-none"></div>
          </>
        )}
        
        {/* Header Bar */}
        <header className={`h-14 sm:h-16 border-b flex items-center justify-between px-3 sm:px-6 md:px-8 shrink-0 transition-colors duration-200 z-10 relative ${
          theme === 'dark' ? 'bg-slate-950/60 backdrop-blur-md border-slate-800/60 text-white shadow-sm' : 'bg-white border-slate-200 text-slate-800'
        }`}>
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <button 
              className="md:hidden p-2 -ml-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer min-h-[40px] min-w-[40px] flex items-center justify-center shrink-0"
              onClick={() => setIsMobileMenuOpen(true)}
              aria-label="Open Navigation Menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className={`text-xs sm:text-sm md:text-base font-bold font-display uppercase tracking-tight truncate ${
              theme === 'dark' ? 'text-white' : 'text-slate-800'
            }`}>
              {currentModule === 'MachineBreakdown' && 'Machine Breakdown Reports & Telemetry'}
              {userActualRole === 'Management' && currentModule === 'Dashboard' && 'Management Dashboard'}
              {userActualRole === 'Supervisor' && currentModule === 'Dashboard' && 'Supervisor Dispatch & Oversight Dashboard'}
              {userActualRole === 'Management' && currentModule === 'PreventiveMaintenance' && 'Preventive Maintenance Module'}
              {currentModule === 'ProfileSettings' && 'User Profile & Settings'}
              {currentModule === 'AssetList' && 'Asset Directory & Specifications'}
              {currentModule === 'PersonnelManagement' && 'Personnel Management'}
              {currentModule === 'RequireDocument' && 'Require Document — Safety Permits & JSA'}
              {userActualRole === 'Technician' && currentModule === 'Dashboard' && 'Technician Repair Workspace'}
              {userActualRole === 'Auditor' && currentModule === 'Dashboard' && 'Compliance Audit Console'}
            </h1>
            <span className={`hidden sm:flex px-2 py-0.5 text-[10px] font-bold rounded-full border items-center gap-1 shrink-0 ${
              theme === 'dark' 
                ? 'bg-emerald-950/60 text-emerald-400 border-emerald-900' 
                : 'bg-emerald-100 text-emerald-700 border-emerald-200'
            }`}>
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
              SYSTEM LIVE
            </span>
          </div>

          <div className="flex items-center gap-2 sm:gap-4 shrink-0">
            <div className={`hidden lg:flex items-center gap-2 text-xs font-medium ${
              theme === 'dark' ? 'text-slate-400' : 'text-slate-500'
            }`}>
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
              Firebase Connected
            </div>
            
            {/* Global Theme Toggle */}
            <button
              onClick={() => setTheme(prev => prev === 'light' ? 'dark' : 'light')}
              className={`p-2 rounded-lg transition-colors cursor-pointer flex items-center justify-center min-h-[40px] min-w-[40px] ${
                theme === 'dark' 
                  ? 'text-amber-400 hover:text-amber-300 hover:bg-slate-800' 
                  : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100'
              }`}
              title={`Switch to ${theme === 'light' ? 'Dark' : 'Light'} Mode`}
              aria-label="Toggle Theme Mode"
            >
              {theme === 'light' ? <Moon className="w-4.5 h-4.5" /> : <Sun className="w-4.5 h-4.5" />}
            </button>

            {/* User Profile avatar */}
            <button onClick={() => setCurrentModule('ProfileSettings')} className="flex items-center gap-1.5 sm:gap-2 border-l pl-2 sm:pl-4 border-slate-200 dark:border-slate-800 hover:opacity-80 transition-opacity cursor-pointer group">
              <span className={`text-xs font-bold font-sans hidden sm:inline truncate max-w-[120px] ${
                theme === 'dark' ? 'text-slate-300' : 'text-slate-700'
              }`}>
                {authorizedUser}
              </span>
              <div className="w-8 h-8 rounded-full bg-amber-500 text-white border border-amber-400 flex items-center justify-center font-bold text-xs shadow-sm font-display select-none group-hover:ring-2 ring-amber-300 ring-offset-1 dark:ring-offset-slate-900 transition-all shrink-0">
                {authorizedUser ? authorizedUser.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'AA'}
              </div>
            </button>
          </div>
        </header>

        {/* Content Container */}
        <div className="p-3 sm:p-5 md:p-6 space-y-4 sm:space-y-6 flex-1 overflow-y-auto">
          
          {currentModule === 'Dashboard' && (
            <>
              {/* Metric Tiles - High Density design */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {/* Tile 1 */}
            <div className="bg-white p-4 border border-slate-200 rounded-xl shadow-xs">
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Pending Work</p>
              <div className="flex items-baseline gap-1 mt-1">
                <p className="text-2xl font-bold text-slate-800 tracking-tight font-display">{pendingCount}</p>
                <span className="text-[11px] text-slate-400 font-medium">tickets</span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 mt-3 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-amber-400 rounded-full transition-all duration-500" 
                  style={{ width: `${totalCount ? (pendingCount / totalCount * 100) : 0}%` }}
                />
              </div>
            </div>

            {/* Tile 2 */}
            <button
              type="button"
              onClick={() => setIsIncompleteModalOpen(true)}
              className="bg-white p-4 border border-slate-200 rounded-xl shadow-xs hover:border-amber-400 hover:shadow-md transition-all duration-200 cursor-pointer text-left w-full group relative focus:outline-none focus:ring-2 focus:ring-amber-400/30"
              title="Click to view all Incomplete Maintenance Jobs"
              aria-label="View Incomplete Maintenance Jobs"
            >
              <div className="flex items-center justify-between">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider group-hover:text-amber-600 transition-colors">
                  Incomplete Jobs
                </p>
                <span className="text-[9px] font-bold text-amber-700 bg-amber-50 group-hover:bg-amber-100 border border-amber-200/80 px-1.5 py-0.5 rounded transition-colors flex items-center gap-0.5">
                  View <ChevronRight className="w-2.5 h-2.5 group-hover:translate-x-0.5 transition-transform" />
                </span>
              </div>
              <div className="flex items-baseline gap-1 mt-1">
                <p className="text-2xl font-bold text-slate-800 tracking-tight font-display group-hover:text-amber-600 transition-colors">
                  {incompleteJobsCount}
                </p>
                <span className="text-[11px] text-slate-400 font-medium">active</span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 mt-3 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-amber-400 group-hover:bg-amber-500 rounded-full transition-all duration-500" 
                  style={{ width: `${totalCount ? (incompleteJobsCount / totalCount * 100) : 0}%` }}
                />
              </div>
            </button>

            {/* Tile 3 */}
            <div className="bg-white p-4 border border-slate-200 rounded-xl shadow-xs" title={`Average Downtime = Total Downtime (${totalDowntimeHours.toFixed(1)} hrs) / Number of Downtime Events (${numberOfDowntimeEvents}) = ${avgDowntimeHours} hrs`}>
              <div className="flex items-center justify-between">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Avg Downtime</p>
                <span className="text-[9px] font-semibold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">Total / Events</span>
              </div>
              <div className="flex items-baseline gap-1 mt-1">
                <p className="text-2xl font-bold text-slate-800 tracking-tight font-display">{avgDowntimeHours}</p>
                <span className="text-[11px] text-slate-400 font-medium">hours</span>
              </div>
              <p className="text-[10px] text-slate-500 mt-2 font-medium flex items-center justify-between">
                <span>{totalDowntimeHours.toFixed(1)} hrs total</span>
                <span className="text-slate-300">•</span>
                <span>{numberOfDowntimeEvents} {numberOfDowntimeEvents === 1 ? 'event' : 'events'}</span>
              </p>
            </div>

            {/* Tile 4 */}
            <div className="bg-white p-4 border border-slate-200 rounded-xl shadow-xs">
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Uptime Score</p>
              <div className="flex items-baseline gap-1 mt-1">
                <p className="text-2xl font-bold text-slate-800 tracking-tight font-display">{uptimeScore}%</p>
              </div>
              <p className="text-[10px] text-slate-400 mt-2 font-medium">
                {completedCount} of {totalCount} tickets resolved
              </p>
            </div>
          </div>

            </>
          )}
          {/* Dynamic Workspace Container strictly guarded by Role-Based Access Control */}
          <div className="min-h-96">
            {userActualRole === 'Management' && currentModule === 'Dashboard' && (
              <DashboardRouteGuard
                requiredDashboard="Management"
                userRole={userActualRole}
                onRedirect={handleAccessDenied}
              >
                <div className="space-y-4">
                  <ManagerView
                    staffList={staffList}
                    workOrders={workOrders}
                    activityLogs={activityLogs}
                    pmTasks={pmTasks}
                    onAddWorkOrder={handleAddWorkOrder}
                    onUpdatePriority={handleUpdatePriority}
                    onReassignTechnician={handleReassignTechnician}
                    onOpenRequireDocument={(woId, docType) => {
                      setSelectedRequireDocWorkOrderId(woId || null);
                      setSelectedRequireDocType(docType || 'JSA');
                      setCurrentModule('RequireDocument');
                      syncUrlForRoute('RequireDocument');
                    }}
                    technicians={technicians.filter(tech => {
                      const personnel = staffList.find(p => p.fullName === tech.name);
                      return personnel ? personnel.accountStatus === 'Active' : true;
                    })}
                    theme={theme}
                    authorizedUser={authorizedUser}
                    authorizedUserRole="Management"
                  />
                </div>
              </DashboardRouteGuard>
            )}

            {userActualRole === 'Supervisor' && currentModule === 'Dashboard' && (
              <DashboardRouteGuard
                requiredDashboard="Supervisor"
                userRole={userActualRole}
                onRedirect={handleAccessDenied}
              >
                <div className="space-y-4">
                  <ManagerView
                    staffList={staffList}
                    workOrders={workOrders}
                    activityLogs={activityLogs}
                    pmTasks={pmTasks}
                    onAddWorkOrder={handleAddWorkOrder}
                    onUpdatePriority={handleUpdatePriority}
                    onReassignTechnician={handleReassignTechnician}
                    onOpenRequireDocument={(woId, docType) => {
                      setSelectedRequireDocWorkOrderId(woId || null);
                      setSelectedRequireDocType(docType || 'JSA');
                      setCurrentModule('RequireDocument');
                      syncUrlForRoute('RequireDocument');
                    }}
                    technicians={technicians.filter(tech => {
                      const personnel = staffList.find(p => p.fullName === tech.name);
                      return personnel ? personnel.accountStatus === 'Active' : true;
                    })}
                    theme={theme}
                    authorizedUser={authorizedUser}
                    authorizedUserRole="Supervisor"
                  />
                </div>
              </DashboardRouteGuard>
            )}

            {currentModule === 'PreventiveMaintenance' && (
              userActualRole === 'Management' ? (
                <PreventiveMaintenanceView 
                  staffList={staffList}
                  pmTasks={pmTasks}
                  onAddPMTask={(newPM) => setPmTasks(prev => [newPM, ...prev])}
                  onAddWorkOrder={handleAddWorkOrder}
                  technicians={technicians.filter(tech => {
                    const personnel = staffList.find(p => p.fullName === tech.name);
                    return personnel ? personnel.accountStatus === 'Active' : true;
                  })}
                  authorizedUser={authorizedUser}
                />
              ) : (
                <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-xl">
                  <p className="text-sm font-bold text-rose-400">Access Restricted: Only Management can configure Preventive Maintenance.</p>
                </div>
              )
            )}

            {currentModule === 'ProfileSettings' && (
              <ProfileSettingsView authorizedUser={authorizedUser} theme={theme} currentRole={userActualRole} />
            )}

            {currentModule === 'AssetList' && (
              <AssetListView currentRole={userActualRole} />
            )}
            {currentModule === 'PersonnelManagement' && (
              <PersonnelManagementView 
                personnelList={staffList}
                currentRole={currentRole}
                onUpdatePersonnel={async (updated) => {
                  try {
                    await supabase.from('profiles').update({
                      fullName: updated.fullName,
                      full_name: updated.fullName,
                      username: updated.username,
                      department: updated.department,
                      role: updated.role,
                      position: updated.position,
                      accountStatus: updated.accountStatus,
                      account_status: updated.accountStatus,
                      primarySkill: updated.primarySkill,
                      primary_skill: updated.primarySkill,
                      skills: updated.skills,
                      maxWorkload: updated.maxWorkload,
                      max_workload: updated.maxWorkload,
                      pin: updated.pin
                    }).eq('id', updated.userId);
                    setStaffList(prev => prev.map(p => p.userId === updated.userId ? updated : p));
                  } catch (err) {
                    console.error('Failed to update personnel in Firestore:', err);
                  }
                }}
                onAddPersonnel={async (newUser) => {
                  try {
                    await supabase.from('profiles').insert([newUser]);
                    setStaffList(prev => {
                      const exists = prev.some(p => p.userId === newUser.userId || (p.username && newUser.username && p.username.toLowerCase() === newUser.username.toLowerCase()));
                      if (exists) {
                        return prev.map(p => (p.userId === newUser.userId || p.username.toLowerCase() === newUser.username.toLowerCase()) ? newUser : p);
                      }
                      return [...prev, newUser];
                    });
                    if (newUser.role === 'Technician') {
                      setTechnicians(prev => {
                        if (prev.some(t => t.id === newUser.userId || t.name === newUser.fullName)) {
                          return prev;
                        }
                        return [...prev, {
                          id: newUser.userId,
                          name: newUser.fullName,
                          specialty: newUser.primarySkill || newUser.department as any || 'General',
                          activeTicketsCount: 0
                        }];
                      });
                    }
                  } catch (err) {
                    console.error('Failed to save new personnel to Firestore:', err);
                  }
                }}
                onRemovePersonnel={async (userId) => {
                  try {
                    await supabase.from('profiles').delete().eq('id', userId);
                    setStaffList(prev => prev.filter(p => p.userId !== userId));
                  } catch (err) {
                    console.error('Failed to delete personnel from Firestore:', err);
                  }
                }}
              />
            )}

            {currentModule === 'MachineBreakdown' && (
              <MachineBreakdownView
                currentRole={currentRole}
                authorizedUser={authorizedUser}
                onUpdateAssetStatus={async (assetId, status) => {
                  await syncAssetBreakdownStatus(assetId, status === 'Breakdown');
                }}
                onNavigateToWorkOrder={(assetId, issue, priority, breakdownId) => {
                  if (currentRole !== 'Management') {
                    showFeedback('error', 'Access Restricted: Only Management personnel can generate or dispatch work orders.');
                    return;
                  }
                  setCurrentModule('Dashboard');
                  // Find asset
                  const asset = SEED_ASSETS.find(a => a.id === assetId);
                  
                  // Automatic Technician Assignment engine with priority handling
                  const assignment = autoAssignTechnician(
                    {
                      asset: asset || null,
                      maintenanceType: (asset?.category as any) || 'Mechanical',
                      priority: priority || 'Critical',
                      issueDescription: issue,
                      scheduledDate: new Date().toISOString().split('T')[0],
                    },
                    staffList,
                    workOrders,
                    pmTasks
                  );

                  if (assignment.success && assignment.technician) {
                    handleAddWorkOrder({
                      assetId,
                      assetName: asset?.name || assetId,
                      category: asset?.category || 'Mechanical',
                      issue,
                      priority: priority || 'Critical',
                      assignedToId: assignment.technicianId,
                      assignedToName: assignment.technicianName,
                      assignmentReason: assignment.assignmentReason,
                      loggedBy: authorizedUser || 'Supervisor',
                      breakdownId,
                      status: 'Pending'
                    });
                    showFeedback('success', `Work Order automatically assigned to ${assignment.technicianName} (${assignment.department}) for breakdown ${breakdownId}`);
                  } else {
                    handleAddWorkOrder({
                      assetId,
                      assetName: asset?.name || assetId,
                      category: asset?.category || 'Mechanical',
                      issue,
                      priority: priority || 'Critical',
                      assignedToId: 'UNASSIGNED',
                      assignedToName: 'Unassigned (Pending Auto-Assignment)',
                      assignmentReason: assignment.rejectionSummary.join(', ') || 'No suitable technician available',
                      loggedBy: authorizedUser || 'Supervisor',
                      breakdownId,
                      status: 'Pending Technician Assignment'
                    });
                    showFeedback('info', `No suitable technician available. Work Order status set to Pending Technician Assignment for breakdown ${breakdownId}`);
                  }
                }}
              />
            )}

            {currentModule === 'MaintenanceRecords' && (
              <MaintenanceRecordsView
                currentRole={currentRole}
                authorizedUser={authorizedUser}
                theme={theme}
              />
            )}

            {currentModule === 'RequireDocument' && (
              <RequireDocumentView
                currentRole={currentRole}
                authorizedUser={authorizedUser || 'Staff'}
                staffList={staffList}
                workOrders={workOrders}
                initialWorkOrderId={selectedRequireDocWorkOrderId}
                initialDocumentType={selectedRequireDocType}
                onNavigateToWorkOrder={(woId) => {
                  setSelectedRequireDocWorkOrderId(null);
                  setCurrentModule('Dashboard');
                }}
                onBackToDashboard={() => {
                  setSelectedRequireDocWorkOrderId(null);
                  setCurrentModule('Dashboard');
                }}
                onClearInitialWorkOrder={() => {
                  setSelectedRequireDocWorkOrderId(null);
                }}
                onWorkOrderUpdated={(woId, docPayload) => {
                  const cleanWoId = normalizeDocId(woId);
                  setWorkOrders(prev => {
                    const updated = prev.map(wo => {
                      if (normalizeDocId(wo.id) === cleanWoId) {
                        return {
                          ...wo,
                          safetyDocumentId: docPayload.id || wo.safetyDocumentId,
                          safetyDocumentType: docPayload.documentType || wo.safetyDocumentType,
                          safetyDocumentStatus: docPayload.status || wo.safetyDocumentStatus,
                          requiresPermit: docPayload.documentType === 'PTW' || wo.requiresPermit,
                          requiredPermitType: docPayload.permitType || wo.requiredPermitType
                        };
                      }
                      return wo;
                    });
                    try {
                      localStorage.setItem('dmr_work_orders', JSON.stringify(updated));
                    } catch (_) {}
                    return updated;
                  });
                }}
              />
            )}

            {currentRole === 'Technician' && currentModule === 'Dashboard' && (
              <div className="space-y-4">
                <TechnicianView
                  workOrders={workOrders}
                  pmTasks={pmTasks}
                  onStartWork={handleStartWork}
                  onPauseWork={handlePauseWork}
                  onCompleteWork={handleCompleteWork}
                  onOpenRequireDocument={(woId, docType) => {
                    setSelectedRequireDocWorkOrderId(woId || null);
                    setSelectedRequireDocType(docType || 'JSA');
                    setCurrentModule('RequireDocument');
                  }}
                  technicians={technicians}
                  staffList={staffList}
                  authorizedUser={authorizedUser}
                />
              </div>
            )}

            {currentRole === 'Auditor' && currentModule === 'Dashboard' && (
              <div className="space-y-4">
                <AuditorView workOrders={workOrders} auditorName={authorizedUser} />
              </div>
            )}
          </div>

        </div>
      </main>

      {/* Incomplete Maintenance Jobs Modal */}
      {isIncompleteModalOpen && (
        <IncompleteJobsModal
          isOpen={isIncompleteModalOpen}
          onClose={() => setIsIncompleteModalOpen(false)}
          workOrders={workOrders}
          pmTasks={pmTasks}
          staffList={staffList}
          technicians={technicians}
          currentRole={currentRole}
          authorizedUser={authorizedUser}
          theme={theme}
          onUpdatePriority={handleUpdatePriority}
          onReassignTechnician={handleReassignTechnician}
          onStartWork={handleStartWork}
          onPauseWork={handlePauseWork}
          onCompleteWork={handleCompleteWork}
          onUpdateStatus={handleUpdateStatus}
          onRefresh={fetchData}
        />
      )}

    </div>
  );
}

// Simple embedded Info component since it is used repeatedly
function Info({ className, ...props }: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      strokeWidth="2"
      stroke="currentColor"
      className={className}
      {...props}
    >
      <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 111.085 1.086L12.5 12.83l-.041.02a.75.75 0 11-1.085-1.086l.041-.022zM12 18.75h.008v.008H12v-.008zM12 3a9 9 0 100 18 9 9 0 000-18z" />
    </svg>
  );
}
