const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle0' });
  await new Promise(r => setTimeout(r, 1000));
  
  // Try to login as John Doe
  await page.evaluate(() => {
     const inputs = Array.from(document.querySelectorAll('input'));
     if (inputs[0]) inputs[0].value = 'john.d';
     if (inputs[1]) inputs[1].value = '1234';
     const btn = document.querySelector('button[type="submit"]');
     if (btn) btn.click();
  });

  await new Promise(r => setTimeout(r, 2000));
  
  // click "Start Repair"
  await page.evaluate(() => {
     const btns = Array.from(document.querySelectorAll('button'));
     const startBtn = btns.find(b => b.textContent.includes('Start Repair'));
     if (startBtn) startBtn.click();
  });
  
  await new Promise(r => setTimeout(r, 2000));

  // Check the checkboxes
  const res = await page.evaluate(() => {
     const inputs = Array.from(document.querySelectorAll('input[type="checkbox"]'));
     if (inputs.length > 0) {
       inputs.forEach(i => i.click());
     }
     
     const completeBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Complete Job'));
     return {
       checkboxes: inputs.length,
       completeDisabled: completeBtn ? completeBtn.disabled : null
     };
  });
  
  console.log("Result:", res);
  await browser.close();
})();
