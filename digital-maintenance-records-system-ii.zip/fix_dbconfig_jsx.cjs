const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf-8');
content = content.replace(/\{dbConfig\.appsScriptUrl && \([\s\S]*?<\/p>\s*\)\}/g, '');
content = content.replace(/\{dbConfig\.isRealSyncEnabled \? 'Connected: GAS_Master_Sheet_V2' : 'Local Cache Active'\}/g, "'Local Cache Active'");
fs.writeFileSync('src/App.tsx', content);
