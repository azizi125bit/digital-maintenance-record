const jspdf = require('jspdf');
console.log(jspdf);
