const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

const targetProps = `                <TechnicianView
                  workOrders={workOrders}
                  pmTasks={pmTasks}
                  onStartWork={handleStartWork}
                  onCompleteWork={handleCompleteWork}
                  technicians={technicians}
                  staffList={staffList}
                  authorizedUser={authorizedUser}
                />`;

const newProps = `                <TechnicianView
                  workOrders={workOrders}
                  pmTasks={pmTasks}
                  onStartWork={handleStartWork}
                  onPauseWork={handlePauseWork}
                  onCompleteWork={handleCompleteWork}
                  technicians={technicians}
                  staffList={staffList}
                  authorizedUser={authorizedUser}
                />`;

if (code.includes('onPauseWork={handlePauseWork}')) {
  console.log("Already has onPauseWork prop");
} else {
  code = code.replace(targetProps, newProps);
  fs.writeFileSync('src/App.tsx', code);
  console.log("Patched App.tsx props for TechnicianView");
}
