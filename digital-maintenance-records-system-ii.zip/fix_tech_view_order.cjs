const fs = require('fs');
let code = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

const str = `  const [pmTasks, setPmTasks] = useState<any[]>([]);

  useEffect(() => {
    if (import.meta.env.VITE_SUPABASE_URL && currentTech) {
      const fetchPMTasks = async () => {
        const { data, error } = await supabase.from('preventive_maintenance').select('*');
        if (data) {
          // Find tasks assigned to this tech's name
          setPmTasks(data.filter(t => t.assigned_to_name === currentTech.fullName));
        }
      };
      fetchPMTasks();
    }
  }, [currentTech]);

  // Active technician data
  const currentTech = activeStaff.find(t => t.userId === activeTechId);`;

const fixStr = `  // Active technician data
  const currentTech = activeStaff.find(t => t.userId === activeTechId);

  const [pmTasks, setPmTasks] = useState<any[]>([]);

  useEffect(() => {
    if (import.meta.env.VITE_SUPABASE_URL && currentTech) {
      const fetchPMTasks = async () => {
        const { data, error } = await supabase.from('preventive_maintenance').select('*');
        if (data) {
          // Find tasks assigned to this tech's name
          setPmTasks(data.filter(t => t.assigned_to_name === currentTech.fullName));
        }
      };
      fetchPMTasks();
    }
  }, [currentTech]);`;

code = code.replace(str, fixStr);
fs.writeFileSync('src/components/TechnicianView.tsx', code);
