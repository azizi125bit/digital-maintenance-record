# Implementation Plan: Automate Return to OPERATIONAL (Green) when Repairs Completed

Penyelesaian menyeluruh untuk membetulkan punca status mesin (seperti *welding machine*, *Daikin*, dan *BENDSAW MACHINE*) masih kekal bertanda merah (🔴 BREAKDOWN) walaupun pembaikan telah diselesaikan atau tiada kerosakan aktif.

---

## 1. Punca Masalah (Root Cause Analysis)

1. **Fallback Tersangkut pada `asset.status === 'Breakdown'`**:
   - Dalam `MaintenanceRecordsView.tsx` dan `AssetListView.tsx`, logik sebelumnya menyemak:
     ```ts
     const isAssetInBreakdown = rawBreakdowns.some(...) || asset.status === 'Breakdown';
     ```
   - Apabila status kerosakan telah ditandakan *Completed*, nilai lama `asset.status = 'Breakdown'` dalam pangkalan data Firestore/localStorage menyebabkan mesin kekal merah (🔴) tanpa henti.
2. **Ketiadaan Pemulihan Automatik (Self-Healing Sync)**:
   - Jika laporan kerosakan untuk mesin tersebut sudah tiada yang aktif (semua *Completed/Resolved* atau tiada laporan kerosakan aktif), status mesin sepatutnya pulih kembali secara automatik ke **🟢 OPERATIONAL (Hijau)** dan disimpan terus ke Firestore.
3. **Semakan Status Kerosakan Aktif yang Tepat**:
   - Hanya mesin yang mempunyai laporan kerosakan aktif (*Reported*, *Acknowledged*, *Under Repair*, *In Progress*, *Waiting for Spare Parts*, *Overdue*) patut bertukar merah.
   - Mesin yang tiada laporan kerosakan aktif (atau kerosakan telah berstatus *Completed / Resolved / Closed*) wajib bertukar ke **🟢 Hijau (Operational)**.
4. **Butang Pantas Selesaikan Kerosakan di Kad Rekod**:
   - Menambah butang *"Tandakan Selesai / Mark Completed"* terus pada kad kerosakan/rekod di `MaintenanceRecordsView` supaya juruteknik/pengurus boleh menyelesaikan kerosakan dengan satu klik dan serta-merta menukar status mesin ke hijau.

---

## 2. Pelan Pelaksanaan Terperinci

### Langkah 1: Baiki Logik Penentuan Status Mesin (`src/utils/machineSync.ts`)
- Kemaskini fungsi `checkAssetHasActiveBreakdown` dan `getEffectiveMachineStatus`:
  - Periksa sama ada wujud sebarang laporan dalam `machine_breakdowns` untuk aset tersebut yang statusnya **bukan** `Completed`, `Resolved`, `Closed`, atau `Repaired`.
  - Jika tiada laporan aktif: Status mesin **wajib** dikembalikan ke `'Operational'` (Hijau).
  - Lakukan *self-healing*: Jika dalam database aset masih berstatus `'Breakdown'` tetapi tiada laporan kerosakan aktif, kemaskini status aset tersebut di Firestore & localStorage terus ke `'Operational'`.

### Langkah 2: Kemaskini Paparan di `MaintenanceRecordsView.tsx`
- Buang semakan tegar `|| asset.status === 'Breakdown'` pada senarai butang mesin dan kad mesin.
- Gunakan `checkAssetHasActiveBreakdown(asset.id, rawBreakdowns)`:
  - Mesin hanya bertanda merah 🔴 jika benar-benar ada laporan kerosakan aktif.
  - Jika semua kerosakan selesai, butang mesin dan lencana kad mesin kembali ke **🟢 OPERATIONAL (Hijau)**.
- Tambah butang tindakan pantas **"Selesaikan Kerosakan (Resolve / Complete Breakdown)"** pada butiran rekod kerosakan dan kad mesin apabila mesin sedang dalam kerosakan aktif.

### Langkah 3: Kemaskini di `AssetListView.tsx` & `MachineBreakdownView.tsx`
- Pastikan lajur status mesin dan modal spesifikasi di *Asset Directory* menyelaraskan status hijau/merah berdasarkan laporan aktif sebenar.
- Apabila butang status kerosakan ditukar ke `Completed`, kemaskini serta-merta status mesin ke `Operational` dan siarkan acara `dmr_machine_sync`.

### Langkah 4: Pemulihan Data Semasa (Data Reset / Healing)
- Jalankan pemeriksaan automatik semasa komponen dimuatkan:
  - Bagi mesin yang tiada laporan kerosakan aktif (atau jika semua laporan kerosakan telah diselesaikan), pulihkan status aset ke `Operational` dalam Firestore (`assets` collection) dan `dmr_assets_list`.
  - Daikin dan Bendsaw Machine (serta Welding Machine yang selesai) akan serta-merta bertukar hijau.

---

## 3. Verifikasi & Pengujian

1. **Ujian Status Selesai**:
   - Buka mesin *welding machine* -> Pastikan jika laporan kerosakannya telah *Completed*, butang dan lencana mesin serta-merta bertukar hijau (**🟢 OPERATIONAL**).
2. **Ujian Mesin Tanpa Kerosakan**:
   - Pastikan *Daikin* dan *BENDSAW MACHINE* yang tiada kerosakan aktif kembali berwarna normal/hijau tanpa ikon merah.
3. **Ujian Kerosakan Baru**:
   - Daftarkan kerosakan baru -> Mesin bertukar merah (**🔴 BREAKDOWN**).
   - Tukar status kerosakan ke *Completed* -> Mesin kembali automatik ke hijau (**🟢 OPERATIONAL**).
