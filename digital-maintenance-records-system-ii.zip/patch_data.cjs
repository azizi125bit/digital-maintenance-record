const fs = require('fs');
let content = fs.readFileSync('src/data.ts', 'utf-8');

// Replace TECH-101 with USR-002
content = content.replace(/'TECH-101'/g, "'USR-002'");
// Replace TECH-102 (Ahmad Farhan Bin Isa) with USR-003 or whatever Ahmad's ID is. Wait, what is Ahmad's ID?
// Let's check SEED_PERSONNEL.
