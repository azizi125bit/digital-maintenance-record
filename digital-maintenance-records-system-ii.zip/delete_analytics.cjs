const fs = require('fs');
let content = fs.readFileSync('src/components/ManagerView.tsx', 'utf-8');

const startIdx = content.indexOf('<div className={`rounded-xl border p-5 space-y-6 transition-all relative overflow-hidden ${');
if (startIdx === -1) throw new Error("Could not find start");

const endMarker = '</div>\n      </div>\n\n      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">';
const endIdx = content.indexOf(endMarker, startIdx);
if (endIdx === -1) throw new Error("Could not find end");

const toRemove = content.substring(startIdx, endIdx);
content = content.replace(toRemove, '');

fs.writeFileSync('src/components/ManagerView.tsx', content);
console.log('Deleted section successfully');
