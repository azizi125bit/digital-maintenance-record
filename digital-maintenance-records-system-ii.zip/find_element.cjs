const fs = require('fs');

// We don't have jsdom easily, but we can look at the code.
// Let's print out ManagerView and TechnicianView structure.
