const SEED_PERSONNEL = [
  { username: 'ahmad', role: 'Management', accountStatus: 'Active', pin: '1111' },
];

let saved = JSON.stringify([...SEED_PERSONNEL, {
  userId: 'USR-12345',
  fullName: 'Kumar Technician',
  username: 'kumar',
  email: 'kumar@dmr.company.com',
  pin: '1234',
  role: 'Technician',
  accountStatus: 'Active'
}]);

const parsed = JSON.parse(saved);
const ahmad = parsed.find(p => p.username === 'ahmad');
if (!ahmad || ahmad.role !== 'Management') {
  console.log('RESET TO SEED');
} else {
  const final = parsed.map(p => ({
    ...p,
    userId: p.userId || p.id || `USR-${Math.floor(Math.random() * 90000) + 10000}`,
    fullName: p.fullName || p.name || 'Unknown User',
    employeeId: p.employeeId || 'OLD-' + Math.floor(Math.random() * 9000 + 1000),
    username: p.username || (p.fullName || p.name || 'user').toLowerCase().replace(/\s+/g, '.'),
    email: p.email || (p.fullName || p.name || 'user').toLowerCase().replace(/\s+/g, '.') + '@dmr.company.com',
    accountStatus: p.accountStatus || 'Active'
  }));
  console.log(final);
}
