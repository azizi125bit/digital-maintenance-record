const fs = require('fs');
let code = fs.readFileSync('src/components/ManagerView.tsx', 'utf-8');

// Replace logic
code = code.replace(
    /const overduePMs = assets\.filter.*?\.getTime\(\)\);/s,
    `const overduePMs = activeOrders.filter(o => o.timestamp && new Date(o.timestamp) < now).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());`
);

code = code.replace(
    /const upcomingPMs = assets\.filter.*?\.slice\(0, 3\);/s,
    `const upcomingPMs = activeOrders.filter(o => o.timestamp && new Date(o.timestamp) >= now).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()).slice(0, 3);`
);

// Replace JSX references
// Instead of asset.asset_name, it should be asset.assetName
code = code.replace(/asset\.asset_name/g, 'asset.assetName');

// Instead of asset.scheduled_date, it should be asset.timestamp
code = code.replace(/asset\.scheduled_date/g, 'asset.timestamp');

fs.writeFileSync('src/components/ManagerView.tsx', code);
console.log("Updated ManagerView.tsx PMs list");
