const fs = require('fs');
let content = fs.readFileSync('src/data.ts', 'utf-8');

content = content.replace(/'TECH-101'/g, "'USR-002'");
content = content.replace(/'TECH-102'/g, "'USR-004'");
content = content.replace(/'TECH-103'/g, "'USR-005'");
content = content.replace(/'TECH-104'/g, "'USR-006'");

fs.writeFileSync('src/data.ts', content);
