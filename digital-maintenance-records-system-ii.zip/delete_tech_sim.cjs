const fs = require('fs');
let content = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

const startIdx = content.indexOf('{/* Simulation Identity Panel */}');
if (startIdx === -1) throw new Error("Could not find start");

const endMarker = '</div>\n\n      {/* Tech Stats Overview */}';
const endIdx = content.indexOf(endMarker, startIdx);
if (endIdx === -1) throw new Error("Could not find end");

const toRemove = content.substring(startIdx, endIdx + '</div>\n\n'.length);
content = content.replace(toRemove, '');

fs.writeFileSync('src/components/TechnicianView.tsx', content);
console.log('Deleted Simulation Identity Panel successfully');
