const fs = require('fs');
let code = fs.readFileSync('src/components/PMCalendar.tsx', 'utf-8');

// Add PM Details Modal
const viewModalCode = `
      {/* View PM Details Modal */}
      {viewingPM && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col animate-in zoom-in-95 duration-200 border border-slate-200">
            <div className="flex justify-between items-center p-5 border-b border-slate-200 bg-slate-50 rounded-t-2xl shrink-0">
              <h3 className="text-xl font-bold font-display text-slate-800 flex items-center gap-2">
                <Wrench className="w-5 h-5 text-sky-500" />
                PM Schedule Details
              </h3>
              <button onClick={() => setViewingPM(null)} className="p-2 text-slate-400 hover:text-slate-700 bg-white border border-slate-200 rounded-lg shadow-sm">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto flex-1 bg-white space-y-6">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-2xl font-bold text-slate-900">{viewingPM.machine_name}</h4>
                  <p className="font-mono text-slate-500 text-sm">{viewingPM.asset_id}</p>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <span className="font-mono font-bold text-sky-600 bg-sky-50 px-3 py-1 rounded-lg border border-sky-100">{viewingPM.id}</span>
                  <span className={\`px-3 py-1 text-xs font-bold uppercase tracking-wider rounded-lg border \${
                    viewingPM.status === 'Completed' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                    viewingPM.status === 'In Progress' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                    viewingPM.status === 'Overdue' ? 'bg-rose-50 text-rose-700 border-rose-200' :
                    'bg-slate-50 text-slate-700 border-slate-200'
                  }\`}>
                    {viewingPM.status}
                  </span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <p className="text-xs font-bold text-slate-400 uppercase mb-1">Maintenance Task</p>
                  <p className="text-sm font-medium text-slate-800">{viewingPM.maintenance_task}</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <p className="text-xs font-bold text-slate-400 uppercase mb-1">Maintenance Type</p>
                  <p className="text-sm font-medium text-slate-800">{viewingPM.maintenance_type}</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <p className="text-xs font-bold text-slate-400 uppercase mb-1">Scheduled Date & Time</p>
                  <p className="text-sm font-medium text-slate-800">{viewingPM.scheduled_date} at {viewingPM.scheduled_time || '09:00 AM'}</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <p className="text-xs font-bold text-slate-400 uppercase mb-1">Estimated Duration</p>
                  <p className="text-sm font-medium text-slate-800">{viewingPM.estimated_duration} Hours</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <p className="text-xs font-bold text-slate-400 uppercase mb-1">Frequency</p>
                  <p className="text-sm font-medium text-slate-800">{viewingPM.frequency}</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <p className="text-xs font-bold text-slate-400 uppercase mb-1">Priority</p>
                  <p className="text-sm font-medium text-slate-800">{viewingPM.priority}</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <p className="text-xs font-bold text-slate-400 uppercase mb-1">Assigned Technician</p>
                  <p className="text-sm font-medium text-slate-800">{viewingPM.assigned_technician}</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <p className="text-xs font-bold text-slate-400 uppercase mb-1">Supervisor</p>
                  <p className="text-sm font-medium text-slate-800">{viewingPM.supervisor}</p>
                </div>
              </div>
              
              {viewingPM.safety_requirements && viewingPM.safety_requirements.length > 0 && (
                <div>
                  <h5 className="text-sm font-bold text-slate-800 border-b border-slate-100 pb-2 mb-3">Safety Requirements</h5>
                  <ul className="space-y-2">
                    {viewingPM.safety_requirements.map((req, i) => (
                      <li key={i} className="flex items-center gap-2 text-sm text-slate-600">
                        <CheckCircle className="w-4 h-4 text-emerald-500" /> {req}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              
              {viewingPM.remarks && (
                <div>
                  <h5 className="text-sm font-bold text-slate-800 border-b border-slate-100 pb-2 mb-3">Remarks</h5>
                  <p className="text-sm text-slate-600 whitespace-pre-wrap">{viewingPM.remarks}</p>
                </div>
              )}
            </div>
            
            <div className="p-5 border-t border-slate-200 bg-slate-50 rounded-b-2xl flex flex-wrap justify-end gap-3 shrink-0">
               {/* Note: In a real app we would check permissions here. As requested, we provide actions where authorized. */}
               <button className="px-4 py-2 text-xs font-bold uppercase tracking-wider bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 rounded-lg transition-colors">Edit</button>
               <button className="px-4 py-2 text-xs font-bold uppercase tracking-wider bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 rounded-lg transition-colors">Export PDF</button>
               <button className="px-4 py-2 text-xs font-bold uppercase tracking-wider bg-amber-500 hover:bg-amber-400 text-white shadow-lg shadow-amber-500/20 rounded-lg transition-colors">Generate Work Order</button>
               <button className="px-4 py-2 text-xs font-bold uppercase tracking-wider bg-emerald-500 hover:bg-emerald-400 text-white shadow-lg shadow-emerald-500/20 rounded-lg transition-colors">Complete</button>
            </div>
          </div>
        </div>
      )}
`;

code = code.replace(
  "const [selectedDate, setSelectedDate] = useState<string | null>(null);",
  "const [selectedDate, setSelectedDate] = useState<string | null>(null);\n  const [viewingPM, setViewingPM] = useState<PMSchedule | null>(null);"
);

code = code.replace(
  "onClick={() => { setSelectedDate(null); onViewPMClick(pm); }}",
  "onClick={() => { setViewingPM(pm); }}"
);

code = code.replace(
  "    </div>\n  );\n};",
  viewModalCode + "\n    </div>\n  );\n};"
);

fs.writeFileSync('src/components/PMCalendar.tsx', code);
