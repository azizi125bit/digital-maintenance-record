const fs = require('fs');
let code = fs.readFileSync('src/components/ManagerView.tsx', 'utf-8');

if (!code.includes("import { supabase }")) {
  code = code.replace(
    "import { motion, AnimatePresence } from 'motion/react';",
    "import { motion, AnimatePresence } from 'motion/react';\nimport { supabase } from '../lib/supabase';"
  );
}

fs.writeFileSync('src/components/ManagerView.tsx', code);
