<?php
/**
 * Digital Maintenance Records (DMR) - Main API Gateway
 * Designed specifically for InfinityFree Shared Hosting (Apache + PHP + MySQL)
 * 
 * Always guarantees JSON responses. Never outputs raw HTML or unhandled fatal errors.
 */

// 1. Strict JSON Headers
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// 2. Handle HTTP OPTIONS Preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(['success' => true]);
    exit;
}

// 3. Prevent PHP from printing HTML error pages
ini_set('display_errors', '0');
error_reporting(E_ALL);

// 4. Catch Fatal Errors on Shutdown and render as JSON
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=UTF-8');
        }
        echo json_encode([
            'success' => false,
            'error'   => 'PHP Server Error: ' . $error['message'],
            'file'    => basename($error['file']),
            'line'    => $error['line'],
            'code'    => 'FATAL_ERROR'
        ]);
    }
});

// 5. Require Controller
try {
    require_once __DIR__ . '/control.php';
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error'   => 'Initialization failure: ' . $e->getMessage()
    ]);
    exit;
}

// 6. Main Request Router
try {
    $method = $_SERVER['REQUEST_METHOD'];

    // Handle GET Requests (Read operations)
    if ($method === 'GET') {
        $resource = $_GET['resource'] ?? $_GET['table'] ?? '';
        $action   = $_GET['action'] ?? 'list';

        if (empty($resource)) {
            // Health check / API status
            echo json_encode([
                'success' => true,
                'status'  => 'online',
                'service' => 'DMR PHP-MySQL Backend API',
                'timestamp' => date('c')
            ]);
            exit;
        }

        $table = resolveTableName($resource);
        if (!$table) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'error'   => "Unknown resource: '{$resource}'"
            ]);
            exit;
        }

        $params = [
            'id'          => $_GET['id'] ?? null,
            'filterField' => $_GET['filterField'] ?? $_GET['filter_field'] ?? null,
            'filterValue' => $_GET['filterValue'] ?? $_GET['filter_value'] ?? null,
            'orderField'  => $_GET['orderField'] ?? $_GET['order_field'] ?? null,
            'ascending'   => $_GET['ascending'] ?? 'true'
        ];

        $data = handleListRecords($table, $params);
        echo json_encode([
            'success' => true,
            'data'    => $data,
            'count'   => count($data)
        ]);
        exit;
    }

    // Handle POST Requests (Create, Update, Delete, Upload, Login)
    if ($method === 'POST') {
        $rawInput = file_get_contents('php://input');
        $payload = json_decode($rawInput, true);

        if (!is_array($payload)) {
            // Fallback to standard $_POST if not JSON body
            $payload = $_POST;
        }

        $action   = $payload['action'] ?? $_GET['action'] ?? 'create';
        $resource = $payload['resource'] ?? $payload['table'] ?? $_GET['resource'] ?? $_GET['table'] ?? '';
        $data     = $payload['data'] ?? $payload['item'] ?? $payload;

        // Route: Image Upload
        if ($action === 'upload_image' || $action === 'upload') {
            $uploadResult = handleImageUpload($data);
            echo json_encode($uploadResult);
            exit;
        }

        // Route: User Login
        if ($action === 'login') {
            $loginResult = handleLogin($data);
            echo json_encode($loginResult);
            exit;
        }

        // Database CRUD Operations
        $table = resolveTableName($resource);
        if (!$table) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'error'   => "Unknown or missing resource '{$resource}'"
            ]);
            exit;
        }

        switch ($action) {
            case 'create':
            case 'insert':
                $createResult = handleCreateRecord($table, $data);
                echo json_encode([
                    'success' => true,
                    'data'    => $createResult,
                    'error'   => null
                ]);
                break;

            case 'update':
                $idField = $payload['idField'] ?? $payload['id_field'] ?? 'id';
                $idValue = $payload['idValue'] ?? $payload['id_value'] ?? ($data['id'] ?? $data['userId'] ?? null);
                if ($idValue === null) {
                    throw new Exception("Missing idValue for update operation on '{$table}'");
                }
                $updateResult = handleUpdateRecord($table, $idField, $idValue, $data);
                echo json_encode([
                    'success' => true,
                    'data'    => $updateResult,
                    'error'   => null
                ]);
                break;

            case 'delete':
                $idField = $payload['idField'] ?? $payload['id_field'] ?? 'id';
                $idValue = $payload['idValue'] ?? $payload['id_value'] ?? ($data['id'] ?? $data['userId'] ?? null);
                if ($idValue === null) {
                    throw new Exception("Missing idValue for delete operation on '{$table}'");
                }
                $deleteResult = handleDeleteRecord($table, $idField, $idValue);
                echo json_encode([
                    'success' => true,
                    'data'    => $deleteResult,
                    'error'   => null
                ]);
                break;

            case 'list':
            case 'read':
                $params = [
                    'id'          => $payload['id'] ?? null,
                    'filterField' => $payload['filterField'] ?? null,
                    'filterValue' => $payload['filterValue'] ?? null,
                    'orderField'  => $payload['orderField'] ?? null,
                    'ascending'   => $payload['ascending'] ?? true
                ];
                $data = handleListRecords($table, $params);
                echo json_encode([
                    'success' => true,
                    'data'    => $data,
                    'count'   => count($data)
                ]);
                break;

            default:
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error'   => "Unsupported action '{$action}'"
                ]);
                break;
        }
        exit;
    }

    // Any other method
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error'   => "Method '{$method}' not allowed. Use GET or POST for InfinityFree compatibility."
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error'   => $e->getMessage()
    ]);
}
