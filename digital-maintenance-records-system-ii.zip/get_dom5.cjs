const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle0' });
  
  // click technician view if there is a nav button
  await page.evaluate(() => {
     const navButtons = Array.from(document.querySelectorAll('button'));
     const techBtn = navButtons.find(b => b.textContent && b.textContent.includes('Technician'));
     if (techBtn) techBtn.click();
  });
  
  await new Promise(r => setTimeout(r, 1000));

  const htmls = await page.evaluate(() => {
     const s1 = document.querySelector('div#root:nth-of-type(1) > div:nth-of-type(1) > main:nth-of-type(1) > div:nth-of-type(3) > div:nth-of-type(2) > div:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(2) > div:nth-of-type(2) > div:nth-of-type(2) > button:nth-of-type(1)');
     const s2 = document.querySelector('div#root:nth-of-type(1) > div:nth-of-type(1) > main:nth-of-type(1) > div:nth-of-type(3) > div:nth-of-type(2) > div:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(2) > div:nth-of-type(2) > div:nth-of-type(2) > button:nth-of-type(2)');
     return {
        btn1: s1 ? s1.outerHTML : 'Not found',
        btn2: s2 ? s2.outerHTML : 'Not found'
     };
  });

  console.log("Found Elements in Technician View:", htmls);
  await browser.close();
})();
