const fs = require('fs');
let content = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

// 1. Add authorizedUser to props
content = content.replace(
  "staffList?: import('../types').Personnel[];",
  "staffList?: import('../types').Personnel[];\n  authorizedUser?: string;"
);

content = content.replace(
  "export default function TechnicianView({ workOrders, onStartWork, onCompleteWork, technicians, staffList }: TechnicianViewProps) {",
  "export default function TechnicianView({ workOrders, onStartWork, onCompleteWork, technicians, staffList, authorizedUser }: TechnicianViewProps) {"
);

// 2. Change activeTechId logic
const oldState = "const [activeTechId, setActiveTechId] = useState<string>(activeStaff[0]?.userId || 'USR-001');";
const newState = `const loggedInStaff = activeStaff.find(s => s.fullName === authorizedUser);
  const [activeTechId, setActiveTechId] = useState<string>(loggedInStaff?.userId || activeStaff[0]?.userId || 'USR-001');
  
  useEffect(() => {
    if (loggedInStaff) {
      setActiveTechId(loggedInStaff.userId);
    }
  }, [loggedInStaff]);`;

content = content.replace(oldState, newState);

fs.writeFileSync('src/components/TechnicianView.tsx', content);
