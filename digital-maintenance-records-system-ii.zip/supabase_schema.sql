-- Run this in your Supabase SQL Editor

-- 1. Create Profiles Table
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('Management', 'Technician', 'Auditor')),
  account_status TEXT NOT NULL DEFAULT 'Active' CHECK (account_status IN ('Active', 'Inactive', 'Suspended')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. Create Assets Table
CREATE TABLE assets (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  status TEXT NOT NULL,
  location TEXT,
  criticality TEXT,
  department TEXT,
  description TEXT,
  manufacturer TEXT,
  model TEXT,
  serial_number TEXT,
  installation_date TEXT,
  next_maintenance_date TEXT,
  photo_url TEXT,
  custom_specifications JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. Create Preventive Maintenance Table
CREATE TABLE preventive_maintenance (
  id TEXT PRIMARY KEY,
  asset_id TEXT REFERENCES assets(id) ON DELETE CASCADE,
  asset_name TEXT,
  issue TEXT,
  priority TEXT,
  category TEXT,
  frequency TEXT,
  assigned_to_id TEXT,
  assigned_to_name TEXT,
  status TEXT,
  logged_by TEXT,
  scheduled_date TEXT,
  next_due_date TEXT,
  downtime_hours NUMERIC,
  checklist JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. Create Work Orders Table
CREATE TABLE work_orders (
  id TEXT PRIMARY KEY,
  timestamp TEXT NOT NULL,
  asset_id TEXT REFERENCES assets(id) ON DELETE CASCADE,
  asset_name TEXT,
  category TEXT,
  issue TEXT,
  priority TEXT,
  assigned_to_id TEXT,
  assigned_to_name TEXT,
  status TEXT,
  logged_by TEXT,
  actions_taken TEXT,
  materials_used TEXT,
  completed_time TEXT,
  downtime_hours NUMERIC,
  checklist JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 5. Create Activity Logs Table
CREATE TABLE activity_logs (
  id TEXT PRIMARY KEY,
  timestamp TEXT NOT NULL,
  ticket_id TEXT,
  user_name TEXT,
  action TEXT,
  details TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 6. Create Machine Breakdowns Table
CREATE TABLE machine_breakdowns (
  id TEXT PRIMARY KEY,
  breakdown_id TEXT NOT NULL,
  asset_id TEXT REFERENCES assets(id) ON DELETE SET NULL,
  machine_name TEXT,
  department TEXT,
  location TEXT,
  reported_by TEXT,
  reported_date TEXT,
  reported_time TEXT,
  problem_description TEXT NOT NULL,
  breakdown_category TEXT,
  priority TEXT NOT NULL,
  status TEXT NOT NULL,
  machine_condition TEXT,
  downtime_start TEXT,
  downtime_end TEXT,
  total_downtime NUMERIC,
  immediate_action TEXT,
  machine_isolated BOOLEAN DEFAULT true,
  safety_risk TEXT,
  temporary_solution TEXT,
  remarks TEXT,
  photo_url TEXT,
  linked_work_order_id TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE preventive_maintenance ENABLE ROW LEVEL SECURITY;
ALTER TABLE work_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE machine_breakdowns ENABLE ROW LEVEL SECURITY;

-- Simple Policies (Customize as needed for tighter security)
-- For this app, we will allow authenticated users to read everything
CREATE POLICY "Allow authenticated read" ON profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated read" ON assets FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated read" ON preventive_maintenance FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated read" ON work_orders FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated read" ON activity_logs FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated read" ON machine_breakdowns FOR SELECT TO authenticated USING (true);

-- Allow all authenticated to insert/update (You can restrict to specific roles later)
CREATE POLICY "Allow authenticated insert/update" ON assets FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow authenticated insert/update" ON preventive_maintenance FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow authenticated insert/update" ON work_orders FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow authenticated insert/update" ON activity_logs FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow authenticated insert/update" ON machine_breakdowns FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow Management to manage profiles" ON profiles FOR ALL TO authenticated USING (true);

-- Insert default demo users (You will still need to create them in Supabase Auth via the dashboard or API)
-- Example: 
-- INSERT INTO profiles (id, username, full_name, role, account_status) VALUES ('some-uuid-from-auth', 'lim', 'Sarah Lim', 'Auditor', 'Active');
