/**
 * DMR System - Google Apps Script Backend (Code.gs)
 * 
 * Instructions:
 * 1. Create a new Google Sheet.
 * 2. Rename the first sheet tab to "WorkOrders".
 * 3. Add the exact headers from A1 to O1.
 * 4. Go to Extensions > Apps Script and paste this code.
 * 5. Deploy > New deployment > Select type: Web app.
 *    - Execute as: Me
 *    - Who has access: Anyone
 * 6. Copy the resulting Web App URL and paste it into the DMR Web App settings.
 */

const SPREADSHEET_ID = "YOUR_SPREADSHEET_ID_HERE"; // Optional if script is bound to the sheet
const SHEET_NAME = "WorkOrders";

// Handle GET requests (Fetching Data)
function doGet(e) {
  try {
    const sheet = getSheet();
    const data = sheet.getDataRange().getValues();
    
    // Convert 2D array to array of objects
    const headers = data[0];
    const rows = data.slice(1);
    
    const jsonArray = rows.map(row => {
      let obj = {};
      headers.forEach((header, index) => {
        obj[header] = row[index];
      });
      return obj;
    });
    
    return ContentService.createTextOutput(JSON.stringify({
      status: "success",
      data: jsonArray
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      status: "error",
      message: error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

// Handle POST requests (Adding/Updating Data)
function doPost(e) {
  try {
    const sheet = getSheet();
    const requestBody = JSON.parse(e.postData.contents);
    const action = requestBody.action; // 'create' or 'update'
    const payload = requestBody.payload;
    
    if (action === 'create') {
      const newRow = [
        payload.id,
        payload.timestamp,
        payload.assetId,
        payload.assetName,
        payload.category,
        payload.issue,
        payload.priority,
        payload.assignedToId,
        payload.assignedToName,
        payload.status,
        payload.loggedBy,
        payload.actionsTaken || "",
        payload.materialsUsed || "",
        payload.completedTime || "",
        payload.downtimeHours || ""
      ];
      sheet.appendRow(newRow);
      
    } else if (action === 'update') {
      // Find the row with the matching ID and update it
      const data = sheet.getDataRange().getValues();
      const headers = data[0];
      const idIndex = headers.indexOf('id');
      
      let rowIndexToUpdate = -1;
      for (let i = 1; i < data.length; i++) {
        if (data[i][idIndex] === payload.id) {
          rowIndexToUpdate = i + 1; // Apps Script rows are 1-indexed
          break;
        }
      }
      
      if (rowIndexToUpdate > -1) {
        // Update specific columns (e.g., status, actionsTaken, etc.)
        const statusCol = headers.indexOf('status') + 1;
        const actionsCol = headers.indexOf('actionsTaken') + 1;
        const materialsCol = headers.indexOf('materialsUsed') + 1;
        const completedTimeCol = headers.indexOf('completedTime') + 1;
        const downtimeCol = headers.indexOf('downtimeHours') + 1;
        
        if (payload.status) sheet.getRange(rowIndexToUpdate, statusCol).setValue(payload.status);
        if (payload.actionsTaken) sheet.getRange(rowIndexToUpdate, actionsCol).setValue(payload.actionsTaken);
        if (payload.materialsUsed) sheet.getRange(rowIndexToUpdate, materialsCol).setValue(payload.materialsUsed);
        if (payload.completedTime) sheet.getRange(rowIndexToUpdate, completedTimeCol).setValue(payload.completedTime);
        if (payload.downtimeHours) sheet.getRange(rowIndexToUpdate, downtimeCol).setValue(payload.downtimeHours);
      } else {
        throw new Error("Ticket ID not found for update.");
      }
    }
    
    return ContentService.createTextOutput(JSON.stringify({
      status: "success",
      message: `Successfully processed action: ${action}`
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      status: "error",
      message: error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

// Helper function to get the sheet
function getSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet(); // Assumes script is bound to the sheet
  return ss.getSheetByName(SHEET_NAME);
}

// OPTIONS request for CORS preflight
function doOptions(e) {
  var headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Max-Age": "86400"
  };
  
  var response = ContentService.createTextOutput("");
  for (var key in headers) {
    response.setHeader(key, headers[key]);
  }
  return response;
}
