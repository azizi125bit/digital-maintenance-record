const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

code = code.replace(
    "<PreventiveMaintenanceView \n                staffList={staffList}\n                onAddWorkOrder={handleAddWorkOrder}",
    "<PreventiveMaintenanceView \n                staffList={staffList}\n                onAddPMTask={(newPM) => setPmTasks(prev => [newPM, ...prev])}\n                onAddWorkOrder={handleAddWorkOrder}"
);

fs.writeFileSync('src/App.tsx', code);
console.log("App.tsx updated to pass onAddPMTask");
