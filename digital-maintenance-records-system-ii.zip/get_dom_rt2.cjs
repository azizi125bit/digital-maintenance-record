const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle0' });

  // Wait a bit
  await new Promise(r => setTimeout(r, 2000));

  const htmls = await page.evaluate(() => {
     // Manager view is default when logged in as Management. Wait, the app starts at login screen!
     // We need to bypass login or simulate it to get to the elements.
     return { html: document.body.innerHTML.substring(0, 500) };
  });

  console.log("Found:", htmls);
  await browser.close();
})();
