const fs = require('fs');
let code = fs.readFileSync('src/components/AssetListView.tsx', 'utf-8');

const target2 = `                    <span 
                      className={\`px-2.5 py-1 rounded text-[10px] font-bold uppercase \${
                        asset.status === 'Operational' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' :
                        asset.status === 'Under Maintenance' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' :
                        asset.status === 'Decommissioned' ? 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-400' :
                        'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400'
                      } \${index === 1 ? '!text-[#ff0000]' : ''}\`}
                      style={index === 1 ? { color: '#ff0000' } : undefined}
                    >`;

const new2 = `                    <span 
                      className={\`px-2.5 py-1 rounded text-[10px] font-bold uppercase \${
                        asset.status === 'Operational' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' :
                        asset.status === 'Under Maintenance' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' :
                        asset.status === 'Decommissioned' ? 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-400' :
                        'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400'
                      }\`}
                    >`;

code = code.replace(target2, new2);

fs.writeFileSync('src/components/AssetListView.tsx', code);
console.log("Patched style in AssetListView.tsx");
