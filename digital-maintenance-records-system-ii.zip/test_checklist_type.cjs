const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.VITE_SUPABASE_URL || 'http://localhost:54321', process.env.VITE_SUPABASE_ANON_KEY || 'dummy');

(async () => {
  const { data, error } = await supabase.from('work_orders').select('id, checklist').limit(2);
  console.log("Work orders:", data);
  const { data: pm, error: e2 } = await supabase.from('preventive_maintenance').select('id, checklist').limit(2);
  console.log("PMs:", pm);
})();
