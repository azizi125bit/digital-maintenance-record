const fs = require('fs');
let code = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

const issueStr = `<span className="font-semibold text-slate-800 block mb-0.5">Diagnosed Problem:</span>
                  {workOrders.find(o => o.id === completingOrderId)?.issue}`;

const newIssueStr = `  <span className="font-semibold text-slate-800 block mb-0.5">
                    {completingOrderId?.startsWith('PM-') ? 'Maintenance Task:' : 'Diagnosed Problem:'}
                  </span>
                  {allTickets.find(o => o.id === completingOrderId)?.issue}`;

code = code.replace(issueStr, newIssueStr);

fs.writeFileSync('src/components/TechnicianView.tsx', code);
