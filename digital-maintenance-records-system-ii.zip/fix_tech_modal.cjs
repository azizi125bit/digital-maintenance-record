const fs = require('fs');
let code = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

const OLD_MODAL_START = `<AnimatePresence>
        {completingOrderId && (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-xl border border-slate-200 max-w-md w-full overflow-hidden shadow-2xl"
            >
              <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
                <h3 className="font-display font-bold text-sm md:text-base flex items-center gap-1.5">
                  <Wrench className="w-4 h-4 text-sky-400" /> Submit Maintenance Record
                </h3>`;

const NEW_MODAL_START = `<AnimatePresence>
        {completingOrderId && (() => {
          const isCompleted = allTickets.find(o => o.id === completingOrderId)?.status === 'Completed';
          return (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-xl border border-slate-200 max-w-md w-full overflow-hidden shadow-2xl"
            >
              <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
                <h3 className="font-display font-bold text-sm md:text-base flex items-center gap-1.5">
                  <Wrench className="w-4 h-4 text-sky-400" /> {isCompleted ? 'Review Maintenance Record' : 'Submit Maintenance Record'}
                </h3>`;

code = code.replace(OLD_MODAL_START, NEW_MODAL_START);

const OLD_ACTIONS = `<textarea
                    required
                    rows={3}
                    className="block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:border-brand-500 focus:ring-1 focus:ring-brand-500 outline-none resize-none"
                    placeholder="e.g. Cleared debris, replaced timing belt, adjusted motor drive alignment..."
                    value={actionsTaken}
                    onChange={(e) => setActionsTaken(e.target.value)}
                  />`;
const NEW_ACTIONS = `<textarea
                    required
                    readOnly={isCompleted}
                    rows={3}
                    className={\`block w-full rounded-lg border px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:outline-none resize-none \${isCompleted ? 'bg-slate-50 border-slate-200 cursor-default' : 'border-slate-300 focus:border-brand-500 focus:ring-1 focus:ring-brand-500'}\`}
                    placeholder="e.g. Cleared debris, replaced timing belt, adjusted motor drive alignment..."
                    value={actionsTaken}
                    onChange={(e) => setActionsTaken(e.target.value)}
                  />`;

code = code.replace(OLD_ACTIONS, NEW_ACTIONS);

const OLD_MATERIALS = `<input
                    type="text"
                    className="block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:border-brand-500 focus:ring-1 focus:ring-brand-500 outline-none"
                    placeholder="e.g. 1x V-Belt A-42, 2L Hydraulic Oil"
                    value={materialsUsed}
                    onChange={(e) => setMaterialsUsed(e.target.value)}
                  />`;
const NEW_MATERIALS = `<input
                    type="text"
                    readOnly={isCompleted}
                    className={\`block w-full rounded-lg border px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:outline-none \${isCompleted ? 'bg-slate-50 border-slate-200 cursor-default' : 'border-slate-300 focus:border-brand-500 focus:ring-1 focus:ring-brand-500'}\`}
                    placeholder="e.g. 1x V-Belt A-42, 2L Hydraulic Oil"
                    value={materialsUsed}
                    onChange={(e) => setMaterialsUsed(e.target.value)}
                  />`;
code = code.replace(OLD_MATERIALS, NEW_MATERIALS);

const OLD_BUTTONS = `<div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setCompletingOrderId(null)}
                    className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-bold uppercase tracking-wider text-white bg-emerald-600 hover:bg-emerald-700 border border-emerald-500 rounded-lg cursor-pointer shadow"
                  >
                    Submit Record
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}`;

const NEW_BUTTONS = `<div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setCompletingOrderId(null)}
                    className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
                  >
                    {isCompleted ? 'Close' : 'Cancel'}
                  </button>
                  {!isCompleted && (
                    <button
                      type="submit"
                      className="px-4 py-2 text-xs font-bold uppercase tracking-wider text-white bg-emerald-600 hover:bg-emerald-700 border border-emerald-500 rounded-lg cursor-pointer shadow"
                    >
                      Submit Record
                    </button>
                  )}
                </div>
              </form>
            </motion.div>
          </div>
          );
        })()}`;
code = code.replace(OLD_BUTTONS, NEW_BUTTONS);

fs.writeFileSync('src/components/TechnicianView.tsx', code);
