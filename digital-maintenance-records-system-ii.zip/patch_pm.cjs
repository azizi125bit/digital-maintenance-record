const fs = require('fs');
let content = fs.readFileSync('src/components/PreventiveMaintenanceView.tsx', 'utf-8');

const target = `        const tech = technicians && technicians.length > 0 ? technicians[0] : { id: 'TECH-101', name: 'AI Assigned' };
        
        onAddWorkOrder({
          assetId: 'P-101',
          assetName: 'Pump P-101',
          category: data.category || 'Mechanical',
          issue: data.issue || 'Preventive Maintenance Routine',
          priority: data.priority || 'Medium',
          assignedToId: tech.userId,
          assignedToName: tech.fullName,
          loggedBy: authorizedUser || 'AI System',`;

const replacement = `        // Find an active technician from staffList
        const activeTechs = staffList ? staffList.filter(s => s.role === 'Technician' && s.accountStatus === 'Active') : [];
        const tech = activeTechs.length > 0 ? activeTechs[0] : { userId: 'USR-002', fullName: 'M. Syahmi Bin Razak (Technician)' };
        
        onAddWorkOrder({
          assetId: 'P-101',
          assetName: 'Pump P-101',
          category: data.category || 'Mechanical',
          issue: data.issue || 'Preventive Maintenance Routine',
          priority: data.priority || 'Medium',
          assignedToId: tech.userId,
          assignedToName: tech.fullName,
          loggedBy: authorizedUser || 'AI System',`;

content = content.replace(target, replacement);

fs.writeFileSync('src/components/PreventiveMaintenanceView.tsx', content);
console.log('patched');
