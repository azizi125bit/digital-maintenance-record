-- ============================================================================
-- Digital Maintenance Records (DMR) - MySQL Database Schema
-- InfinityFree Shared Hosting (phpMyAdmin Import Script)
-- Database Engine: InnoDB, Charset: utf8mb4_unicode_ci
-- ============================================================================

SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4;

-- ----------------------------------------------------------------------------
-- 1. Table: staff (Personnel, Profiles, Users)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `staff` (
  `user_id` VARCHAR(100) NOT NULL,
  `employee_id` VARCHAR(50) NOT NULL,
  `full_name` VARCHAR(150) NOT NULL,
  `username` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `phone` VARCHAR(50) DEFAULT '',
  `department` VARCHAR(100) DEFAULT 'Plant Maintenance',
  `position` VARCHAR(100) DEFAULT 'Technician',
  `role` ENUM('Management', 'Technician', 'Supervisor', 'Auditor') NOT NULL DEFAULT 'Technician',
  `account_status` ENUM('Active', 'Inactive', 'Suspended') NOT NULL DEFAULT 'Active',
  `date_joined` VARCHAR(50) DEFAULT NULL,
  `last_login` VARCHAR(50) DEFAULT NULL,
  `pin` VARCHAR(50) NOT NULL,
  `primary_skill` VARCHAR(100) DEFAULT 'General',
  `skills` TEXT DEFAULT NULL COMMENT 'JSON array of skills',
  `max_workload` INT DEFAULT 5,
  `profile_picture` LONGTEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `idx_username` (`username`),
  KEY `idx_role` (`role`),
  KEY `idx_account_status` (`account_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 2. Table: assets (Machinery & Plant Equipment)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `assets` (
  `id` VARCHAR(100) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `machine_type` VARCHAR(100) DEFAULT NULL,
  `manufacturer` VARCHAR(100) DEFAULT NULL,
  `model` VARCHAR(100) DEFAULT NULL,
  `serial_number` VARCHAR(100) DEFAULT NULL,
  `department` VARCHAR(100) DEFAULT NULL,
  `location` VARCHAR(100) NOT NULL,
  `installation_date` VARCHAR(50) DEFAULT NULL,
  `criticality` ENUM('Low', 'Medium', 'High', 'Critical') DEFAULT 'Medium',
  `photo_url` LONGTEXT DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `category` ENUM('Mechanical', 'Electrical', 'Pneumatic', 'General') DEFAULT 'General',
  `status` ENUM('Operational', 'Under Maintenance', 'Faulty', 'Decommissioned', 'Breakdown') DEFAULT 'Operational',
  `next_maintenance_date` VARCHAR(50) DEFAULT NULL,
  `custom_specifications` LONGTEXT DEFAULT NULL COMMENT 'JSON array of custom key-value specifications',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_category` (`category`),
  KEY `idx_location` (`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 3. Table: custom_specifications (Relational Machine Specs)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `custom_specifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `asset_id` VARCHAR(100) NOT NULL,
  `spec_name` VARCHAR(150) NOT NULL,
  `spec_value` TEXT NOT NULL,
  KEY `idx_asset_id` (`asset_id`),
  CONSTRAINT `fk_specs_asset_pub` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 4. Table: work_orders (Maintenance Work Orders & Tasks)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `work_orders` (
  `id` VARCHAR(100) NOT NULL,
  `timestamp` VARCHAR(50) NOT NULL,
  `asset_id` VARCHAR(100) NOT NULL,
  `asset_name` VARCHAR(255) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `issue` TEXT NOT NULL,
  `priority` ENUM('Low', 'Medium', 'High', 'Critical') DEFAULT 'Medium',
  `assigned_to_id` VARCHAR(100) DEFAULT NULL,
  `assigned_to_name` VARCHAR(150) DEFAULT NULL,
  `status` VARCHAR(50) DEFAULT 'Pending',
  `logged_by` VARCHAR(150) NOT NULL,
  `checklist` LONGTEXT DEFAULT NULL COMMENT 'JSON array of checklist items',
  `actions_taken` TEXT DEFAULT NULL,
  `materials_used` TEXT DEFAULT NULL,
  `completed_time` VARCHAR(50) DEFAULT NULL,
  `downtime_hours` DECIMAL(10,2) DEFAULT 0.00,
  `breakdown_id` VARCHAR(100) DEFAULT NULL,
  `scheduled_date` VARCHAR(50) DEFAULT NULL,
  `due_date` VARCHAR(50) DEFAULT NULL,
  `estimated_duration` DECIMAL(10,2) DEFAULT 1.00,
  `assignment_reason` TEXT DEFAULT NULL,
  `safety_document_id` VARCHAR(100) DEFAULT NULL,
  `safety_document_type` VARCHAR(50) DEFAULT NULL,
  `safety_document_status` VARCHAR(50) DEFAULT NULL,
  `requires_permit` TINYINT(1) DEFAULT 0,
  `required_permit_type` VARCHAR(100) DEFAULT NULL,
  `pm_schedule_id` VARCHAR(100) DEFAULT NULL,
  `maintenance_type` VARCHAR(100) DEFAULT NULL,
  `serial_number` VARCHAR(100) DEFAULT NULL,
  `location` VARCHAR(100) DEFAULT NULL,
  `tools_required` TEXT DEFAULT NULL,
  `materials_required` TEXT DEFAULT NULL,
  `auto_generated` TINYINT(1) DEFAULT 0,
  `generated_at` VARCHAR(50) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_asset_id` (`asset_id`),
  KEY `idx_assigned_to_id` (`assigned_to_id`),
  KEY `idx_status` (`status`),
  KEY `idx_breakdown_id` (`breakdown_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 5. Table: pm_schedules (Preventive Maintenance Schedules)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `pm_schedules` (
  `id` VARCHAR(100) NOT NULL,
  `asset_id` VARCHAR(100) NOT NULL,
  `machine_name` VARCHAR(255) DEFAULT NULL,
  `maintenance_task` TEXT NOT NULL,
  `maintenance_type` VARCHAR(100) DEFAULT 'Preventive Maintenance',
  `frequency` VARCHAR(50) DEFAULT 'Monthly',
  `scheduled_date` VARCHAR(50) NOT NULL,
  `scheduled_time` VARCHAR(20) DEFAULT '09:00',
  `estimated_duration` DECIMAL(10,2) DEFAULT 2.00,
  `assigned_technician` VARCHAR(150) DEFAULT NULL,
  `supervisor` VARCHAR(150) DEFAULT NULL,
  `priority` ENUM('Low', 'Medium', 'High', 'Critical') DEFAULT 'Medium',
  `status` VARCHAR(50) DEFAULT 'Scheduled',
  `safety_requirements` TEXT DEFAULT NULL COMMENT 'JSON array of safety requirements',
  `remarks` TEXT DEFAULT NULL,
  `linked_work_order_id` VARCHAR(100) DEFAULT NULL,
  `last_work_order_generated_at` VARCHAR(50) DEFAULT NULL,
  `last_generated_occurrence_date` VARCHAR(50) DEFAULT NULL,
  `location` VARCHAR(100) DEFAULT NULL,
  `checklist_instructions` TEXT DEFAULT NULL,
  `tools_and_materials` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_pm_asset` (`asset_id`),
  KEY `idx_scheduled_date` (`scheduled_date`),
  KEY `idx_pm_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 6. Table: machine_breakdowns (Active Breakdowns & Downtime History)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `machine_breakdowns` (
  `id` VARCHAR(100) NOT NULL,
  `breakdown_id` VARCHAR(100) NOT NULL,
  `asset_id` VARCHAR(100) NOT NULL,
  `machine_name` VARCHAR(255) NOT NULL,
  `department` VARCHAR(100) DEFAULT NULL,
  `location` VARCHAR(100) DEFAULT NULL,
  `reported_by` VARCHAR(150) NOT NULL,
  `reported_date` VARCHAR(50) NOT NULL,
  `reported_time` VARCHAR(20) NOT NULL,
  `problem_description` TEXT NOT NULL,
  `breakdown_category` VARCHAR(50) DEFAULT 'Mechanical',
  `priority` ENUM('Low', 'Medium', 'High', 'Critical') DEFAULT 'Medium',
  `status` VARCHAR(50) DEFAULT 'Reported',
  `machine_condition` TEXT DEFAULT NULL,
  `downtime_start` VARCHAR(50) NOT NULL,
  `downtime_end` VARCHAR(50) DEFAULT NULL,
  `total_downtime` DECIMAL(10,2) DEFAULT 0.00,
  `immediate_action` TEXT DEFAULT NULL,
  `machine_isolated` TINYINT(1) DEFAULT 0,
  `safety_risk` TEXT DEFAULT NULL,
  `temporary_solution` TEXT DEFAULT NULL,
  `remarks` TEXT DEFAULT NULL,
  `photo_url` LONGTEXT DEFAULT NULL,
  `linked_work_order_id` VARCHAR(100) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_brk_asset` (`asset_id`),
  KEY `idx_brk_status` (`status`),
  KEY `idx_breakdown_id_key` (`breakdown_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 7. Table: safety_documents (Integrated JSA & PTW Documents)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `safety_documents` (
  `id` VARCHAR(100) NOT NULL,
  `document_number` VARCHAR(100) NOT NULL,
  `document_type` ENUM('JSA', 'PTW', 'JSA + PTW') NOT NULL DEFAULT 'JSA + PTW',
  `work_order_id` VARCHAR(100) DEFAULT NULL,
  `work_order_title` VARCHAR(255) DEFAULT NULL,
  `asset_id` VARCHAR(100) NOT NULL,
  `machine_name` VARCHAR(255) NOT NULL,
  `machine_serial_number` VARCHAR(100) DEFAULT NULL,
  `machine_location` VARCHAR(100) DEFAULT NULL,
  `department` VARCHAR(100) DEFAULT NULL,
  `maintenance_type` VARCHAR(100) DEFAULT NULL,
  `job_title` VARCHAR(255) DEFAULT NULL,
  `scheduled_work_date` VARCHAR(50) DEFAULT NULL,
  `work_date` VARCHAR(50) DEFAULT NULL,
  `job_description` TEXT NOT NULL,
  `planned_start_time` VARCHAR(50) DEFAULT NULL,
  `planned_end_time` VARCHAR(50) DEFAULT NULL,
  `requested_by` VARCHAR(150) DEFAULT NULL,
  `assigned_technician_id` VARCHAR(100) DEFAULT NULL,
  `assigned_technician_name` VARCHAR(150) DEFAULT NULL,
  `person_in_charge` VARCHAR(150) DEFAULT NULL,
  `status` VARCHAR(50) NOT NULL DEFAULT 'Draft',
  `rejection_reason` TEXT DEFAULT NULL,
  `revision_count` INT DEFAULT 0,
  `created_by` VARCHAR(150) NOT NULL,
  `created_role` VARCHAR(50) DEFAULT NULL,
  `created_at` VARCHAR(50) NOT NULL,
  `updated_at` VARCHAR(50) NOT NULL,
  `submitted_at` VARCHAR(50) DEFAULT NULL,
  `approved_by` VARCHAR(150) DEFAULT NULL,
  `approval_role` VARCHAR(50) DEFAULT NULL,
  `approved_at` VARCHAR(50) DEFAULT NULL,
  `approval_remarks` TEXT DEFAULT NULL,
  `closed_by` VARCHAR(150) DEFAULT NULL,
  `closed_at` VARCHAR(50) DEFAULT NULL,
  `closure_remarks` TEXT DEFAULT NULL,
  `reopened_by` VARCHAR(150) DEFAULT NULL,
  `reopened_at` VARCHAR(50) DEFAULT NULL,
  `reopen_reason` TEXT DEFAULT NULL,
  `extended_by` VARCHAR(150) DEFAULT NULL,
  `extended_at` VARCHAR(50) DEFAULT NULL,
  `extension_reason` TEXT DEFAULT NULL,
  `job_steps` LONGTEXT DEFAULT NULL COMMENT 'JSON array of JSA steps',
  `identified_hazards` LONGTEXT DEFAULT NULL COMMENT 'JSON array of hazards',
  `overall_control_measures` TEXT DEFAULT NULL,
  `required_ppe` LONGTEXT DEFAULT NULL COMMENT 'JSON array of PPE',
  `emergency_procedures` TEXT DEFAULT NULL,
  `permit_type` VARCHAR(100) DEFAULT NULL,
  `validity_start` VARCHAR(50) DEFAULT NULL,
  `validity_end` VARCHAR(50) DEFAULT NULL,
  `work_location_detail` TEXT DEFAULT NULL,
  `safety_precautions` LONGTEXT DEFAULT NULL COMMENT 'JSON array of precautions',
  `isolation_required` TINYINT(1) DEFAULT 0,
  `isolations` LONGTEXT DEFAULT NULL COMMENT 'JSON array of isolation points',
  `gas_testing_required` TINYINT(1) DEFAULT 0,
  `gas_testing` LONGTEXT DEFAULT NULL COMMENT 'JSON object of gas test results',
  `standby_person_name` VARCHAR(150) DEFAULT NULL,
  `fire_watch_assigned` TINYINT(1) DEFAULT 0,
  `emergency_rescue_plan` TEXT DEFAULT NULL,
  `safety_checklist` LONGTEXT DEFAULT NULL COMMENT 'JSON array of safety checklist items',
  `handback_housekeeping_done` TINYINT(1) DEFAULT 0,
  `handback_isolations_restored` TINYINT(1) DEFAULT 0,
  `handback_technician_name` VARCHAR(150) DEFAULT NULL,
  `handback_time` VARCHAR(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_safe_asset` (`asset_id`),
  KEY `idx_safe_wo` (`work_order_id`),
  KEY `idx_safe_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 8. Table: activity_logs (Audit Trail & Activity Log)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id` VARCHAR(100) NOT NULL,
  `timestamp` VARCHAR(50) NOT NULL,
  `ticket_id` VARCHAR(100) DEFAULT NULL,
  `user` VARCHAR(150) NOT NULL,
  `action` VARCHAR(100) NOT NULL,
  `details` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_log_ticket` (`ticket_id`),
  KEY `idx_log_user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 9. Table: inventory (Spare Parts & Inventory)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `inventory` (
  `id` VARCHAR(100) NOT NULL,
  `item_code` VARCHAR(100) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `quantity` INT DEFAULT 0,
  `min_threshold` INT DEFAULT 5,
  `unit` VARCHAR(50) DEFAULT 'pcs',
  `unit_cost` DECIMAL(10,2) DEFAULT 0.00,
  `location` VARCHAR(100) DEFAULT NULL,
  `compatible_assets` TEXT DEFAULT NULL COMMENT 'JSON array of compatible asset IDs',
  `supplier` VARCHAR(150) DEFAULT NULL,
  `last_restocked` VARCHAR(50) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_item_code` (`item_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- INITIAL SEED DATA: Staff Accounts (Management, Supervisor, Technician, Auditor)
-- ----------------------------------------------------------------------------
INSERT INTO `staff` (`user_id`, `employee_id`, `full_name`, `username`, `email`, `phone`, `department`, `position`, `role`, `account_status`, `date_joined`, `last_login`, `pin`, `primary_skill`, `skills`, `max_workload`)
VALUES
('USR-001', 'EMP-1001', 'Ahmad', 'Ahmad', 'ahmad@dmr.com', '', 'Management', 'Manager', 'Management', 'Active', '2026-01-01T00:00:00Z', '2026-10-28T00:00:00Z', '1111', 'General', '[\"General\"]', 5),
('USR-002', 'EMP-1002', 'Encik Aziz', 'Aziz', 'aziz@dmr.company.com', '', 'Plant Maintenance', 'Workshop Supervisor & Custodian', 'Supervisor', 'Active', '2026-01-01T00:00:00Z', '2026-10-28T00:00:00Z', '6666', 'General', '[\"General\", \"Supervision\", \"Safety\"]', 10),
('USR-46246', 'EMP-7534', 'Amir Azizi', 'Amir', 'amir@dmr.company.com', '', 'Plant Maintenance', 'General Technician', 'Technician', 'Active', '2026-10-02T06:47:49.570Z', '2026-10-28T00:00:00Z', '2222', 'General', '[\"Mechanical\", \"Pump\", \"Motor\", \"Lubrication\"]', 5),
('USR-31265', 'EMP-3031', 'Lee', 'Lee', 'lee@dmr.company.com', '', 'Plant Maintenance', 'Auditor', 'Auditor', 'Active', '2026-10-18T13:46:50.995Z', '2026-10-28T00:00:00Z', '5555', 'Mechanical', '[\"Mechanical\", \"Pump\", \"Motor\", \"Lubrication\"]', 5)
ON DUPLICATE KEY UPDATE `full_name` = VALUES(`full_name`), `pin` = VALUES(`pin`);

SET FOREIGN_KEY_CHECKS = 1;
