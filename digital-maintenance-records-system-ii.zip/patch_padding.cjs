const fs = require('fs');
let code = fs.readFileSync('src/components/AssetListView.tsx', 'utf-8');

code = code.replace(/className="p-4"/g, 'className="p-3 sm:p-4"');
code = code.replace(/className="p-4 hidden md:table-cell"/g, 'className="p-3 sm:p-4 hidden md:table-cell"');
code = code.replace(/className="p-4 hidden sm:table-cell"/g, 'className="p-3 sm:p-4 hidden sm:table-cell"');
code = code.replace(/className="p-4 text-right"/g, 'className="p-3 sm:p-4 text-right"');
code = code.replace(/className="p-4 text-slate-600 dark:text-slate-300 hidden md:table-cell"/g, 'className="p-3 sm:p-4 text-slate-600 dark:text-slate-300 hidden md:table-cell"');
code = code.replace(/className="p-4 text-slate-600 dark:text-slate-300 hidden sm:table-cell"/g, 'className="p-3 sm:p-4 text-slate-600 dark:text-slate-300 hidden sm:table-cell"');
code = code.replace(/className="p-4 text-right flex items-center justify-end gap-2"/g, 'className="p-3 sm:p-4 text-right flex items-center justify-end gap-1 sm:gap-2"');

code = code.replace(/className="w-full text-left border-collapse"/g, 'className="w-full text-left border-collapse min-w-max sm:min-w-0"');

fs.writeFileSync('src/components/AssetListView.tsx', code);
console.log("Patched padding");
