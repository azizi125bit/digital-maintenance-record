const fs = require('fs');
let content = fs.readFileSync('src/lib/supabase.ts', 'utf-8');

content = content.replace(
  "const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co';",
  "const supabaseUrl = import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_URL.trim() !== '' ? import.meta.env.VITE_SUPABASE_URL : 'https://placeholder.supabase.co';"
);

content = content.replace(
  "const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'placeholder';",
  "const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY && import.meta.env.VITE_SUPABASE_ANON_KEY.trim() !== '' ? import.meta.env.VITE_SUPABASE_ANON_KEY : 'placeholder';"
);

fs.writeFileSync('src/lib/supabase.ts', content);
