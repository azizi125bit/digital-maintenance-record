const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf-8');

const replacement = `          </div>

        </div>
      </aside>`;

// We will replace lines 625 to 632 with our fixed closing tags.
// Let's use string split and splice to be exact.
let lines = content.split('\n');
lines.splice(625, 7, '        </div>', '      </aside>');

fs.writeFileSync('src/App.tsx', lines.join('\n'));
