const fs = require('fs');
let code = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

// Replace the currentTech and localPmTasks logic
const oldStateLogic = /const \[localPmTasks, setPmTasks\] = useState<any\[\]>\(pmTasks\);.*?fetchPMTasks\(\);\n    \}\n  \}, \[currentTech\]\);/s;

const newStateLogic = `const [localPmTasks, setPmTasks] = useState<any[]>([]);

  useEffect(() => {
    if (currentTech) {
      setPmTasks(pmTasks.filter(pm => pm.assigned_to_id === currentTech.userId || pm.assigned_to_name === currentTech.fullName));
    } else {
      setPmTasks([]);
    }
  }, [pmTasks, currentTech]);`;

code = code.replace(oldStateLogic, newStateLogic);

fs.writeFileSync('src/components/TechnicianView.tsx', code);
console.log("TechnicianView synced with App's pmTasks");
