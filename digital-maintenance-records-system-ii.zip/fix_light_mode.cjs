const fs = require('fs');

let code = fs.readFileSync('src/components/PreventiveMaintenanceView.tsx', 'utf8');

// Container / Cards
code = code.replace(/bg-slate-900\/60/g, 'bg-white');
code = code.replace(/bg-slate-900\/40/g, 'bg-white');
code = code.replace(/bg-slate-900\/50/g, 'bg-white/90');
code = code.replace(/bg-slate-900\/95/g, 'bg-white/95');
code = code.replace(/bg-slate-900/g, 'bg-white');
code = code.replace(/bg-slate-950\/80/g, 'bg-slate-900/40'); // Backdrop for modal
code = code.replace(/bg-slate-950\/50/g, 'bg-slate-50');
code = code.replace(/bg-slate-950/g, 'bg-white');

// Background elements like buttons and icons
code = code.replace(/bg-slate-800\/80/g, 'bg-slate-100');
code = code.replace(/bg-slate-800\/40/g, 'bg-slate-50');
code = code.replace(/bg-slate-800/g, 'bg-slate-100');
code = code.replace(/bg-slate-700/g, 'bg-slate-200');

// Text Colors
code = code.replace(/text-white/g, 'text-slate-800');
code = code.replace(/text-slate-200/g, 'text-slate-700');
code = code.replace(/text-slate-300/g, 'text-slate-600');
code = code.replace(/text-slate-400/g, 'text-slate-500');

// Borders
code = code.replace(/border-slate-800/g, 'border-slate-200');
code = code.replace(/border-slate-700\/50/g, 'border-slate-200');
code = code.replace(/border-slate-700/g, 'border-slate-200');
code = code.replace(/border-slate-600/g, 'border-slate-300');

// Hovers
code = code.replace(/hover:bg-slate-700/g, 'hover:bg-slate-200');
code = code.replace(/hover:bg-slate-800/g, 'hover:bg-slate-100');
code = code.replace(/hover:text-white/g, 'hover:text-slate-800');
code = code.replace(/hover:text-slate-300/g, 'hover:text-slate-600');

// Fix explicit text-white on primary colored buttons/badges (which should remain white)
code = code.replace(/className="flex items-center gap-2 px-4 py-2 bg-sky-500 hover:bg-sky-400 text-slate-800/g, 'className="flex items-center gap-2 px-4 py-2 bg-sky-500 hover:bg-sky-400 text-white');
code = code.replace(/className="px-6 py-2 rounded-lg text-sm font-bold text-slate-800 bg-sky-500/g, 'className="px-6 py-2 rounded-lg text-sm font-bold text-white bg-sky-500');
code = code.replace(/text-slate-800 text-xs font-bold bg-sky-500/g, 'text-white text-xs font-bold bg-sky-500');
code = code.replace(/text-slate-800 text-xs font-bold bg-emerald-500/g, 'text-white text-xs font-bold bg-emerald-500');
code = code.replace(/text-slate-800 text-xs font-bold bg-amber-500/g, 'text-white text-xs font-bold bg-amber-500');
code = code.replace(/text-slate-800 text-xs font-bold bg-rose-500/g, 'text-white text-xs font-bold bg-rose-500');

// Badges text
code = code.replace(/text-emerald-400/g, 'text-emerald-600');
code = code.replace(/bg-emerald-500\/20/g, 'bg-emerald-100');
code = code.replace(/text-emerald-300/g, 'text-emerald-700');

code = code.replace(/text-amber-400/g, 'text-amber-600');
code = code.replace(/bg-amber-500\/20/g, 'bg-amber-100');
code = code.replace(/text-amber-300/g, 'text-amber-700');

code = code.replace(/text-rose-400/g, 'text-rose-600');
code = code.replace(/bg-rose-500\/20/g, 'bg-rose-100');
code = code.replace(/text-rose-300/g, 'text-rose-700');

code = code.replace(/text-sky-400/g, 'text-sky-600');
code = code.replace(/bg-sky-500\/20/g, 'bg-sky-100');
code = code.replace(/text-sky-300/g, 'text-sky-700');

fs.writeFileSync('src/components/PreventiveMaintenanceView.tsx', code);
