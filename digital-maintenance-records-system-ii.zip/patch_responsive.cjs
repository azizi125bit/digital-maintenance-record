const fs = require('fs');
let code = fs.readFileSync('src/components/AssetListView.tsx', 'utf-8');

const thLocationTarget = '<th className="p-4">Location</th>';
const thLocationNew = '<th className="p-4 hidden md:table-cell">Location</th>';

const thCategoryTarget = '<th className="p-4">Category</th>';
const thCategoryNew = '<th className="p-4 hidden sm:table-cell">Category</th>';

const tdLocationTarget = '<td className="p-4 text-slate-600 dark:text-slate-300">{asset.location}</td>';
const tdLocationNew = '<td className="p-4 text-slate-600 dark:text-slate-300 hidden md:table-cell">{asset.location}</td>';

const tdCategoryTarget = '<td className="p-4 text-slate-600 dark:text-slate-300">{asset.category}</td>';
const tdCategoryNew = '<td className="p-4 text-slate-600 dark:text-slate-300 hidden sm:table-cell">{asset.category}</td>';

code = code.replace(thLocationTarget, thLocationNew);
code = code.replace(thCategoryTarget, thCategoryNew);
code = code.replace(tdLocationTarget, tdLocationNew);
code = code.replace(tdCategoryTarget, tdCategoryNew);

fs.writeFileSync('src/components/AssetListView.tsx', code);
console.log("Patched responsiveness");
