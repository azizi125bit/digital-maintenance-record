const fs = require('fs');
let content = fs.readFileSync('src/components/ManagerView.tsx', 'utf-8');

content = content.replace(
`  return (
    <div className="space-y-6">
      
            </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">`,
`  return (
    <div className="space-y-6">

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">`
);

fs.writeFileSync('src/components/ManagerView.tsx', content);
