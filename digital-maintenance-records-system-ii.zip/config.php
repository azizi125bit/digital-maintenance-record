<?php
/**
 * Digital Maintenance Records (DMR) - Database Configuration
 * InfinityFree Shared Hosting MySQL Configuration
 * 
 * Replace the placeholder values below with your MySQL database credentials
 * found in your InfinityFree Control Panel (cPanel) under "MySQL Databases".
 */

// Prevent direct execution error output from leaking sensitive paths
error_reporting(E_ALL);
ini_set('display_errors', '0');

// Database Credentials - Update with your InfinityFree details
define('DB_HOST', getenv('DMR_DB_HOST') ?: 'sql208.infinityfree.com'); // e.g. sql100.infinityfree.com or localhost
define('DB_NAME', getenv('DMR_DB_NAME') ?: 'if0_38000001_dmr');        // e.g. if0_12345678_dmr
define('DB_USER', getenv('DMR_DB_USER') ?: 'if0_38000001');            // e.g. if0_12345678
define('DB_PASS', getenv('DMR_DB_PASS') ?: 'YourMySQLPasswordHere');   // Your vPanel/MySQL account password
define('DB_PORT', getenv('DMR_DB_PORT') ?: '3306');

/**
 * Establish a secure PDO connection to InfinityFree MySQL database.
 * Returns PDO instance or outputs structured JSON error.
 */
function getDbConnection() {
    static $pdo = null;

    if ($pdo !== null) {
        return $pdo;
    }

    $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
    ];

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
    } catch (PDOException $e) {
        // Safe JSON response if database is unreachable or credentials invalid
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=UTF-8');
            http_response_code(500);
        }
        echo json_encode([
            'success' => false,
            'error'   => 'Database connection failed. Please verify DB_HOST, DB_NAME, DB_USER, and DB_PASS in config.php.',
            'code'    => 'DB_CONNECTION_ERROR',
            'detail'  => (defined('DEBUG_MODE') && DEBUG_MODE) ? $e->getMessage() : null
        ]);
        exit;
    }
}
