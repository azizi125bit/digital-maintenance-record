const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const startStr = '{/* Admin Access Section: Personnel Directory & Resignations */}';
const endStr = '                </div>\n\n              </div>\n            )}';

const startIdx = code.indexOf(startStr);
// We need a more robust end condition. The div ending is at the end of the Dashboard logic.
// Let's just find the startStr and the end of that specific div.
if (startIdx !== -1) {
  // Find the exact ending. Let's use a regex or string replacement.
  const regex = /\{\/\* Admin Access Section: Personnel Directory & Resignations \*\/\}[\s\S]*?<\/table>\s*<\/div>\s*<\/div>/;
  code = code.replace(regex, '');
  fs.writeFileSync('src/App.tsx', code);
  console.log("Removed old personnel table from App.tsx");
} else {
  console.log("Could not find start index");
}

