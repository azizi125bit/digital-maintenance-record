const fs = require('fs');
let code = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

const idLabel = `<span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2.5 py-0.5 rounded border border-slate-200">
                          {order.id}
                        </span>`;

const newIdLabel = `<span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2.5 py-0.5 rounded border border-slate-200">
                          {order.id}
                        </span>
                        {(order as any).isPM && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded bg-sky-50 text-sky-800 border border-sky-200">
                            <Sparkles className="w-3.5 h-3.5 text-sky-500" /> Planned Maintenance
                          </span>
                        )}`;
                        
code = code.replace(idLabel, newIdLabel);

const diagnosisStr = `<strong className="text-slate-900 font-display block mb-0.5">Problem Diagnosis:</strong>
                        {order.issue}`;

const newDiagnosisStr = `<strong className="text-slate-900 font-display block mb-0.5">{(order as any).isPM ? 'Maintenance Task:' : 'Problem Diagnosis:'}</strong>
                        {order.issue}`;

code = code.replace(diagnosisStr, newDiagnosisStr);

fs.writeFileSync('src/components/TechnicianView.tsx', code);
