const fs = require('fs');
let code = fs.readFileSync('src/components/AssetListView.tsx', 'utf-8');

const stateTarget = `  const [viewingAsset, setViewingAsset] = useState<Asset | null>(null);`;
const stateNew = `  const [viewingAsset, setViewingAsset] = useState<Asset | null>(null);
  const [statusDropdown, setStatusDropdown] = useState<string | null>(null);`;

const funcTarget = `  const handleRemoveAsset = (id: string) => {`;
const funcNew = `  const handleUpdateStatus = async (id: string, newStatus: Asset['status']) => {
    if (import.meta.env.VITE_SUPABASE_URL) {
      await supabase.from('assets').update({ status: newStatus }).eq('id', id);
    }
    setAssets(prev => prev.map(a => a.id === id ? { ...a, status: newStatus } : a));
    setStatusDropdown(null);
  };

  const handleRemoveAsset = (id: string) => {`;

const btnTarget = `                    <button 
                      className="p-1.5 text-slate-400 hover:text-sky-600 hover:bg-sky-50 dark:hover:bg-sky-900/20 rounded transition-colors cursor-pointer"
                      title="Asset Settings"
                    >
                      <Settings2 className="w-4 h-4" />
                    </button>`;

const btnNew = `                    <div className="relative inline-block text-left">
                      <button 
                        onClick={() => setStatusDropdown(statusDropdown === asset.id ? null : asset.id)}
                        className="p-1.5 text-slate-400 hover:text-sky-600 hover:bg-sky-50 dark:hover:bg-sky-900/20 rounded transition-colors cursor-pointer"
                        title="Change Status"
                      >
                        <Settings2 className="w-4 h-4" />
                      </button>
                      {statusDropdown === asset.id && (
                        <div className="absolute right-8 top-0 mt-0 w-48 rounded-md shadow-lg bg-white dark:bg-slate-800 ring-1 ring-black ring-opacity-5 z-50 border border-slate-200 dark:border-slate-700 overflow-hidden">
                          <div className="py-1" role="menu">
                            {(['Operational', 'Faulty', 'Under Maintenance', 'Decommissioned'] as const).map((status) => (
                              <button
                                key={status}
                                onClick={() => handleUpdateStatus(asset.id, status)}
                                className={\`block w-full text-left px-4 py-2 text-xs \${asset.status === status ? 'bg-sky-50 text-sky-700 dark:bg-sky-900/30 dark:text-sky-400 font-bold' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'}\`}
                                role="menuitem"
                              >
                                {status === 'Decommissioned' ? 'Scraped' : status}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>`;

code = code.replace(stateTarget, stateNew);
code = code.replace(funcTarget, funcNew);
code = code.replace(btnTarget, btnNew);

fs.writeFileSync('src/components/AssetListView.tsx', code);
console.log("Patched AssetListView.tsx");
