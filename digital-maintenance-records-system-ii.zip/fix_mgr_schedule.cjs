const fs = require('fs');
let code = fs.readFileSync('src/components/ManagerView.tsx', 'utf-8');

// Replace the old overdue/upcoming assets calculation
const oldCalc = `
  const now = new Date();
  const overdueAssets = assets.filter(a => a.nextMaintenanceDate && new Date(a.nextMaintenanceDate) < now)
    .sort((a, b) => new Date(a.nextMaintenanceDate!).getTime() - new Date(b.nextMaintenanceDate!).getTime());
      
  const upcomingAssets = assets.filter(a => a.nextMaintenanceDate && new Date(a.nextMaintenanceDate) >= now)
    .sort((a, b) => new Date(a.nextMaintenanceDate!).getTime() - new Date(b.nextMaintenanceDate!).getTime())
    .slice(0, 3);
`;

const newCalc = `
  const now = new Date();
  const pendingPMs = pmTasks.filter(pm => pm.status !== 'Completed');
  
  const overduePMs = pendingPMs.filter(pm => pm.scheduled_date && new Date(pm.scheduled_date) < now)
    .sort((a, b) => new Date(a.scheduled_date).getTime() - new Date(b.scheduled_date).getTime());
      
  const upcomingPMs = pendingPMs.filter(pm => pm.scheduled_date && new Date(pm.scheduled_date) >= now)
    .sort((a, b) => new Date(a.scheduled_date).getTime() - new Date(b.scheduled_date).getTime())
    .slice(0, 3);
`;

if (code.includes('const overdueAssets = assets.filter')) {
    code = code.replace(oldCalc.trim(), newCalc.trim());
}

// Now replace the JSX references
code = code.replace(/overdueAssets/g, 'overduePMs');
code = code.replace(/upcomingAssets/g, 'upcomingPMs');

// The rendering inside map needs to change slightly, since it uses `asset.nextMaintenanceDate`
// We need to change `asset.name` to `asset.asset_name` or `asset.maintenance_task`, and `nextMaintenanceDate` to `scheduled_date`
code = code.replace(/{asset\.name}/g, '{asset.asset_name}');
code = code.replace(/asset\.nextMaintenanceDate!/g, 'asset.scheduled_date');

fs.writeFileSync('src/components/ManagerView.tsx', code);
console.log("ManagerView schedule updated");
