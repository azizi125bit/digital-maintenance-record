const fs = require('fs');
let content = fs.readFileSync('src/components/ManagerView.tsx', 'utf-8');

// 1. Remove Recharts imports
const rechartsImport = `import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
  Cell
} from 'recharts';`;
content = content.replace(rechartsImport, '');

// 2. Remove data calculations for the charts
const dataCalculations = `
  // Calculate completed work orders per technician to highlight high performance
  const completedOrdersPerTech = techniciansList.map(tech => {
    const totalCompleted = workOrders.filter(
      o => o.assignedToId === tech.id && o.status === 'Completed'
    ).length;
    return {
      name: tech.name.split(' ')[0],
      fullName: tech.name,
      completed: totalCompleted,
      specialty: tech.specialty,
    };
  });

  // Calculate completed work orders per asset to evaluate high performance / reliability
  const assetMaintenanceData = SEED_ASSETS.map(asset => {
    const completedCount = workOrders.filter(
      o => o.assetId === asset.id && o.status === 'Completed'
    ).length;
    const totalCount = workOrders.filter(o => o.assetId === asset.id).length;
    return {
      name: asset.name.replace("System", "").replace("Unit", "").trim(),
      fullName: asset.name,
      completed: completedCount,
      total: totalCount,
      resolutionRate: totalCount === 0 ? 0 : Math.round((completedCount / totalCount) * 100),
    };
  });

  // Calculate downtime trend per asset over the last 30 days
  const downtimeTrendData = SEED_ASSETS.map(asset => {
    // 30 days ago calculation
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const downtimeHours = workOrders
      .filter(o => o.assetId === asset.id && new Date(o.timestamp) >= thirtyDaysAgo)
      .reduce((sum, o) => sum + (o.downtimeHours || 0), 0);

    return {
      name: asset.name.replace("System", "").replace("Unit", "").trim(),
      fullName: asset.name,
      downtimeHours: parseFloat(downtimeHours.toFixed(1))
    };
  });`;
content = content.replace(dataCalculations, '');

// 3. Find the Analytics div and remove it using regex
// Because it's large, I'll use a more surgical approach.
const startStr = `<div className={\`rounded-xl border p-5 space-y-6 transition-all relative overflow-hidden`;
const endStr = `visualizes total estimated downtime hours accrued per asset over the last 30 days to pinpoint critical failure risks.
              </p>
            </div>
          </div>

        </div>
      </div>`;

// Actually we know the lines, but line numbers can be finicky.
