const fs = require('fs');
let content = fs.readFileSync('src/components/ManagerView.tsx', 'utf-8');
content = content.replace(/import\s*\{\s*BarChart[\s\S]*?from\s*'recharts';/, '');
fs.writeFileSync('src/components/ManagerView.tsx', content);
