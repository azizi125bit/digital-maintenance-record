const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(
  "  const handleRegisterTechnician = (e: React.FormEvent) => {\n    e.preventDefault();\n\n    if (!regName.trim()) {\n      setRegError('Technician name cannot be empty.');\n      return;\n    }\n\n    if (regPin.length !== 4 || !/^\\d{4}$/.test(regPin)) {\n      setRegError('Safety PIN must be exactly a 4-digit number.');\n      return;\n    }",
  "  const handleRegisterTechnician = (e: React.FormEvent) => {\n    e.preventDefault();\n\n    if (!regName.trim()) {\n      setRegError('Staff name cannot be empty.');\n      return;\n    }\n\n    if (regPin.length < 4 || !/^\\d{4,}$/.test(regPin)) {\n      setRegError('Safety PIN must be at least a 4-digit number.');\n      return;\n    }"
);

code = code.replace(
  "    const newStaff = {\n      name: regName.trim(),\n      role: 'Technician' as UserRole,\n      pin: regPin,\n      desc: `${regSpecialty} Specialty (Registered)`\n    };\n\n    setStaffList(prev => [...prev, newStaff]);\n    setTechnicians(prev => [...prev, newTech]);\n\n    // Sign in immediately\n    setIsAuthorized(true);\n    setAuthorizedUser(regName.trim());\n    setCurrentRole('Technician');\n    localStorage.setItem('dmr_authorized', 'true');\n    localStorage.setItem('dmr_authorized_user', regName.trim());\n    localStorage.setItem('dmr_current_role', 'Technician');\n\n    // Reset fields\n    setRegName('');\n    setRegPin('');\n    setRegSpecialty('Mechanical');\n    setRegError('');\n\n    showFeedback('success', `Welcome ${regName.trim()}! Dynamic profile registered & initialized successfully.`);\n  };",
  "    const newStaff = {\n      name: regName.trim(),\n      role: regRole as UserRole,\n      pin: regPin,\n      desc: `${regRole === 'Technician' ? regSpecialty : regRole} (Registered)`\n    };\n\n    setStaffList(prev => [...prev, newStaff]);\n    if (regRole === 'Technician') {\n      setTechnicians(prev => [...prev, newTech]);\n    }\n\n    // Sign in immediately\n    setIsAuthorized(true);\n    setAuthorizedUser(regName.trim());\n    setCurrentRole(regRole);\n    localStorage.setItem('dmr_authorized', 'true');\n    localStorage.setItem('dmr_authorized_user', regName.trim());\n    localStorage.setItem('dmr_current_role', regRole);\n\n    // Reset fields\n    setRegName('');\n    setRegPin('');\n    setRegRole('Technician');\n    setRegSpecialty('Mechanical');\n    setRegError('');\n\n    showFeedback('success', `Welcome ${regName.trim()}! Dynamic profile registered & initialized successfully.`);\n  };"
);

fs.writeFileSync('src/App.tsx', code);
