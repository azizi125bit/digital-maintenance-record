const fs = require('fs');
let code = fs.readFileSync('src/components/PreventiveMaintenanceView.tsx', 'utf-8');

code = code.replace(
  "onClick: () => setIsCreateModalOpen(true) },",
  "onClick: () => { setIsCreateModalOpen(true); setSelectedAssetForForm(null); } },"
);
code = code.replace(
  "setIsCreateModalOpen(true);",
  "setIsCreateModalOpen(true); setSelectedAssetForForm(null);"
);
code = code.replace(
  "setIsCreateModalOpen(false);",
  "setIsCreateModalOpen(false); setSelectedAssetForForm(null);"
);
code = code.replace(
  "onClick={() => setIsCreateModalOpen(false)}",
  "onClick={() => { setIsCreateModalOpen(false); setSelectedAssetForForm(null); }}"
);

fs.writeFileSync('src/components/PreventiveMaintenanceView.tsx', code);
