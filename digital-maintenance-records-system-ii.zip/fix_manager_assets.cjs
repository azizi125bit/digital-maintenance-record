const fs = require('fs');
let code = fs.readFileSync('src/components/ManagerView.tsx', 'utf-8');

// 1. Add Supabase import
if (!code.includes("import { supabase }")) {
  code = code.replace(
    "import { PlusCircle,",
    "import { supabase } from '../lib/supabase';\nimport { PlusCircle,"
  );
}

// 2. Add assets state
const statePattern = /const \[selectedAssetId, setSelectedAssetId\] = useState\(''\);/;
const newState = `const [selectedAssetId, setSelectedAssetId] = useState('');
  const [assets, setAssets] = useState<Asset[]>(SEED_ASSETS as any[]);
  const [assetSearchQuery, setAssetSearchQuery] = useState('');
  const [showAssetDropdown, setShowAssetDropdown] = useState(false);
  const [selectedAssetObj, setSelectedAssetObj] = useState<Asset | null>(null);

  useEffect(() => {
    if (import.meta.env.VITE_SUPABASE_URL) {
      const fetchAssets = async () => {
        const { data, error } = await supabase.from('assets').select('*');
        if (!error && data) {
          const formatted = data.map(a => ({
            id: a.id,
            name: a.name,
            category: a.category,
            status: a.status,
            location: a.location,
            criticality: a.criticality,
            department: a.department,
            description: a.description,
            manufacturer: a.manufacturer,
            model: a.model,
            serialNumber: a.serial_number,
            installationDate: a.installation_date,
            nextMaintenanceDate: a.next_maintenance_date
          }));
          setAssets(formatted as any);
        }
      };
      fetchAssets();
    }
  }, []);`;
code = code.replace(statePattern, newState);

// 3. Update useEffect for selectedAssetId
const oldAssetEffect = `const asset = SEED_ASSETS.find(a => a.id === selectedAssetId);`;
const newAssetEffect = `const asset = assets.find(a => a.id === selectedAssetId);`;
code = code.replaceAll(oldAssetEffect, newAssetEffect);

const oldAssetMap1 = `const assetMaintenanceData = SEED_ASSETS.map(asset => {`;
const newAssetMap1 = `const assetMaintenanceData = assets.map(asset => {`;
code = code.replaceAll(oldAssetMap1, newAssetMap1);

const oldAssetMap2 = `const downtimeTrendData = SEED_ASSETS.map(asset => {`;
const newAssetMap2 = `const downtimeTrendData = assets.map(asset => {`;
code = code.replaceAll(oldAssetMap2, newAssetMap2);

const oldAssetOverdue = `const overdueAssets = SEED_ASSETS.filter(a => a.nextMaintenanceDate && new Date(a.nextMaintenanceDate) < now)`;
const newAssetOverdue = `const overdueAssets = assets.filter(a => a.nextMaintenanceDate && new Date(a.nextMaintenanceDate) < now)`;
code = code.replaceAll(oldAssetOverdue, newAssetOverdue);

const oldAssetUpcoming = `const upcomingAssets = SEED_ASSETS.filter(a => a.nextMaintenanceDate && new Date(a.nextMaintenanceDate) >= now)`;
const newAssetUpcoming = `const upcomingAssets = assets.filter(a => a.nextMaintenanceDate && new Date(a.nextMaintenanceDate) >= now)`;
code = code.replaceAll(oldAssetUpcoming, newAssetUpcoming);

// 4. Update the Select dropdown UI
const selectUI = `<label className="block text-xs font-medium text-slate-700 uppercase tracking-wider mb-1">
                Select Asset / Machinery <span className="text-rose-500">*</span>
              </label>
              <select
                required
                className="block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-800 bg-white focus:border-brand-500 focus:ring-1 focus:ring-brand-500 outline-none"
                value={selectedAssetId}
                onChange={(e) => setSelectedAssetId(e.target.value)}
              >
                <option value="">-- Choose Workshop Asset --</option>
                {SEED_ASSETS.map((asset) => (
                  <option key={asset.id} value={asset.id}>
                    [{asset.id}] {asset.name} ({asset.location})
                  </option>
                ))}
              </select>`;

const newSelectUI = `<label className="block text-xs font-medium text-slate-700 uppercase tracking-wider mb-1">
                Select Asset / Machinery <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input 
                  type="text" 
                  required={!selectedAssetId}
                  value={showAssetDropdown ? assetSearchQuery : (selectedAssetObj ? \`[\${selectedAssetObj.id}] \${selectedAssetObj.name}\` : '')}
                  onChange={(e) => {
                    setAssetSearchQuery(e.target.value);
                    setShowAssetDropdown(true);
                    if (!e.target.value) {
                      setSelectedAssetObj(null);
                      setSelectedAssetId('');
                    }
                  }}
                  onFocus={() => setShowAssetDropdown(true)}
                  onBlur={() => setTimeout(() => setShowAssetDropdown(false), 200)}
                  placeholder="Search by asset name or ID..." 
                  className="w-full pl-9 bg-white border border-slate-300 rounded-lg p-2 text-sm text-slate-800 focus:border-sky-500 focus:outline-none" 
                />
                <input type="hidden" name="asset_id" value={selectedAssetId} />
              </div>
              {showAssetDropdown && (
                <div className="absolute z-10 w-full max-w-sm mt-1 bg-white border border-slate-200 rounded-lg shadow-xl max-h-56 overflow-y-auto">
                  {assets.filter(a => a.name.toLowerCase().includes(assetSearchQuery.toLowerCase()) || a.id.toLowerCase().includes(assetSearchQuery.toLowerCase())).map(asset => (
                    <div 
                      key={asset.id}
                      className="px-4 py-2 hover:bg-slate-50 cursor-pointer text-sm border-b border-slate-100 last:border-0"
                      onClick={() => {
                        setSelectedAssetObj(asset);
                        setSelectedAssetId(asset.id);
                        setAssetSearchQuery('');
                        setShowAssetDropdown(false);
                      }}
                    >
                      <div className="font-bold text-slate-700">{asset.name}</div>
                      <div className="text-[10px] text-slate-500 font-mono mt-0.5">{asset.id} &bull; {asset.location}</div>
                    </div>
                  ))}
                  {assets.length > 0 && assets.filter(a => a.name.toLowerCase().includes(assetSearchQuery.toLowerCase()) || a.id.toLowerCase().includes(assetSearchQuery.toLowerCase())).length === 0 && (
                    <div className="px-4 py-2 text-sm text-slate-500">No assets found</div>
                  )}
                </div>
              )}`;

code = code.replace(selectUI, newSelectUI);

fs.writeFileSync('src/components/ManagerView.tsx', code);
