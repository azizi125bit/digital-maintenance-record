const fs = require('fs');
let code = fs.readFileSync('src/components/TechnicianView.tsx', 'utf-8');

// Update props interface
if (!code.includes("pmTasks?: any[];")) {
    code = code.replace(
        "workOrders: WorkOrder[];",
        "workOrders: WorkOrder[];\n  pmTasks?: any[];"
    );
}

// Update function signature
code = code.replace(
    "export default function TechnicianView({ workOrders, onStartWork, onCompleteWork, technicians, staffList, authorizedUser }: TechnicianViewProps) {",
    "export default function TechnicianView({ workOrders, pmTasks = [], onStartWork, onCompleteWork, technicians, staffList, authorizedUser }: TechnicianViewProps) {"
);

// Remove local state and fetch
if (code.includes("const [pmTasks, setPmTasks]")) {
    // We just comment it out to be safe
    code = code.replace("const [pmTasks, setPmTasks] = useState<any[]>([]);", "// Local state removed");
    
    // We need to replace the useEffect that fetches pmTasks
    code = code.replace(/useEffect\(\(\) => \{\n    if \(import\.meta\.env\.VITE_SUPABASE_URL\).*?fetchPMTasks\(\);\n  \}, \[currentTech\]\);/s, "/* PM fetch moved to App.tsx */");
}

fs.writeFileSync('src/components/TechnicianView.tsx', code);
console.log("TechnicianView modified");
