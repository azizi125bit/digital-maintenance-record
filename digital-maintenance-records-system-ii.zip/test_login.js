const SEED = [
  { username: 'aziz_sup', pin: '0000', role: 'Management', accountStatus: 'Active' },
  { username: 'ahmad', pin: '1111', role: 'Management', accountStatus: 'Active' },
  { username: 'kumar', pin: '1234', role: 'Technician', accountStatus: 'Active' }
];
const loginUsername = 'kumar';
const loginPassword = '123';
const user = SEED.find(s => (s.username || '').toLowerCase() === loginUsername.trim().toLowerCase());
console.log(user);
