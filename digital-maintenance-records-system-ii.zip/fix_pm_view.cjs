const fs = require('fs');

let content = fs.readFileSync('src/components/PreventiveMaintenanceView.tsx', 'utf-8');

const pdfFunc = `
  const generatePDF = (printMode = false) => {
    if (!selectedScheduleId) {
      alert("Please select a PM Schedule from the table first.");
      return;
    }

    const schedule = schedules.find(s => s.id === selectedScheduleId);
    if (!schedule) return;

    const doc = new jsPDF();
    
    // Theme colors
    const primaryColor = [14, 165, 233]; // sky-500
    const textColor = [51, 65, 85]; // slate-700
    const lightGray = [241, 245, 249]; // slate-100

    // Header
    doc.setFontSize(22);
    doc.setTextColor(...primaryColor);
    doc.text("PREVENTIVE MAINTENANCE SCHEDULE", 14, 22);
    
    doc.setFontSize(10);
    doc.setTextColor(...textColor);
    doc.text(\`Generated: \${new Date().toLocaleDateString()}\`, 14, 30);

    // General Information Table
    autoTable(doc, {
      startY: 40,
      head: [['PM Schedule ID', 'Asset ID / Machine Name', 'Type', 'Department', 'Location']],
      body: [
        [schedule.id, schedule.machine, schedule.type, 'General', 'Zone A']
      ],
      theme: 'grid',
      headStyles: { fillColor: primaryColor, textColor: [255, 255, 255], fontStyle: 'bold' },
      styles: { fontSize: 10, cellPadding: 5 }
    });

    // Maintenance Info
    autoTable(doc, {
      startY: (doc as any).lastAutoTable.finalY + 10,
      head: [['Priority', 'Frequency', 'Last Maintenance', 'Next Due Date', 'Estimated Duration']],
      body: [
        ['High', schedule.freq, schedule.lastMaint || 'N/A', schedule.nextDue, '2 Hours']
      ],
      theme: 'grid',
      headStyles: { fillColor: primaryColor, textColor: [255, 255, 255], fontStyle: 'bold' },
      styles: { fontSize: 10, cellPadding: 5 }
    });

    // Assignment
    autoTable(doc, {
      startY: (doc as any).lastAutoTable.finalY + 10,
      head: [['Assigned Technician', 'Supervisor']],
      body: [
        [schedule.tech || 'N/A', 'Sarah Jenkins']
      ],
      theme: 'grid',
      headStyles: { fillColor: primaryColor, textColor: [255, 255, 255], fontStyle: 'bold' },
      styles: { fontSize: 10, cellPadding: 5 }
    });

    // Checklist
    autoTable(doc, {
      startY: (doc as any).lastAutoTable.finalY + 10,
      head: [['No.', 'Maintenance Task', 'Requirement']],
      body: [
        ['1', 'Check vibration', 'Required'],
        ['2', 'Check leakage', 'Required'],
        ['3', 'Inspect bearing', 'Required'],
        ['4', 'Check lubrication', 'Required'],
        ['5', 'Check coupling alignment', 'Required'],
      ],
      theme: 'grid',
      headStyles: { fillColor: primaryColor, textColor: [255, 255, 255], fontStyle: 'bold' },
      styles: { fontSize: 10, cellPadding: 5 }
    });

    // Safety
    autoTable(doc, {
      startY: (doc as any).lastAutoTable.finalY + 10,
      head: [['Safety Requirements']],
      body: [
        ['PPE Required: Safety Glasses, Gloves, Steel-toe boots\\nLOTO Required: Yes\\nPermit to Work: Required\\nSafety Notes: Ensure machine is fully powered off before inspection.']
      ],
      theme: 'grid',
      headStyles: { fillColor: [245, 158, 11] /* amber-500 */, textColor: [255, 255, 255], fontStyle: 'bold' },
      styles: { fontSize: 10, cellPadding: 5 }
    });

    // Remarks
    autoTable(doc, {
      startY: (doc as any).lastAutoTable.finalY + 10,
      head: [['Remarks / Additional Instructions']],
      body: [
        ['Please verify all alignment measurements according to manufacturer specs.']
      ],
      theme: 'grid',
      headStyles: { fillColor: lightGray, textColor: textColor, fontStyle: 'bold' },
      styles: { fontSize: 10, cellPadding: 5 }
    });

    // Document Control (Footer)
    const finalY = (doc as any).lastAutoTable.finalY + 20;
    
    // Prevent page break in the middle of signatures
    if (finalY > 250) {
      doc.addPage();
    }
    
    const yPos = finalY > 250 ? 30 : finalY;
    
    doc.setFontSize(10);
    doc.text("Prepared By: ________________________", 14, yPos);
    doc.text("Date Created: ________________________", 14, yPos + 8);
    
    doc.text("Approved By: ________________________", 110, yPos);
    doc.text("Approval Date: ________________________", 110, yPos + 8);

    doc.text("Technician Signature: ________________________", 14, yPos + 30);

    if (printMode) {
      doc.autoPrint();
      window.open(doc.output('bloburl'), '_blank');
    } else {
      doc.save(\`PM-Schedule-\${schedule.id}.pdf\`);
    }
  };
`;

content = content.replace("  const scrollToCalendar = () => {", pdfFunc + "\n  const scrollToCalendar = () => {");
fs.writeFileSync('src/components/PreventiveMaintenanceView.tsx', content);
