const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf-8');

// 1. Remove dbConfig state
content = content.replace(/const \[dbConfig, setDbConfig\] = useState<DatabaseConfig>\(\(\) => \{[\s\S]*?\}\);\n\n/g, '');
content = content.replace(/useEffect\(\(\) => \{\n    localStorage\.setItem\('dmr_db_config', JSON\.stringify\(dbConfig\)\);\n  \}, \[dbConfig\]\);\n\n/g, '');

// 2. Remove isSyncing state
content = content.replace(/const \[isSyncing, setIsSyncing\] = useState\(false\);\n/g, '');

// 3. Remove handleFetchFromSheets completely
content = content.replace(/\/\/ Bidirectional Sync: Fetch rows from live Google Sheet\n  const handleFetchFromSheets = async \(\): Promise<boolean> => \{[\s\S]*?return true;\n    \} catch \(err\) \{[\s\S]*?return false;\n    \}\n  \};\n\n/g, '');

// 4. Remove fetch logic from handleAddWorkOrder
content = content.replace(/if \(dbConfig\.isRealSyncEnabled && dbConfig\.appsScriptUrl\) \{[\s\S]*?\}\s*\}\s*\}\s*/g, '');

// 5. Remove UI block for DB connection in sidebar
content = content.replace(/<div className="bg-slate-800\/40 p-3 rounded-lg border border-slate-800 text-\[10px\] text-slate-400 space-y-1">[\s\S]*?<\/div>/g, '');

// Write back
fs.writeFileSync('src/App.tsx', content);
