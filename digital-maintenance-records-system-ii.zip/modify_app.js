const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

// 1. Add pmTasks state
if (!code.includes('const [pmTasks,')) {
    code = code.replace(
        "const [staffList, setStaffList] = useState<Personnel[]>([]);",
        "const [staffList, setStaffList] = useState<Personnel[]>([]);\n  const [pmTasks, setPmTasks] = useState<any[]>([]);"
    );
}

// 2. Fetch pmTasks inside fetchData()
if (!code.includes("from('preventive_maintenance')")) {
    const profileFetch = "const { data: profileData, error: profileError } = await supabase.from('profiles').select('*');";
    const pmFetch = `
        const { data: pmData, error: pmError } = await supabase.from('preventive_maintenance').select('*');
        if (!pmError && pmData) {
          setPmTasks(pmData);
        }
`;
    code = code.replace(profileFetch, pmFetch + '\n        ' + profileFetch);
}

// 3. Pass pmTasks to ManagerView
if (!code.includes("pmTasks={pmTasks}")) {
    code = code.replace(
        "<ManagerView\n                  staffList={staffList}",
        "<ManagerView\n                  pmTasks={pmTasks}\n                  staffList={staffList}"
    );
}

// 4. Update the dashboard metrics to include pmTasks (if not already included)
// pendingCount, inProgressCount, completedCount, totalCount, mttrAvg, uptimeScore
// We should normalize pmTasks first.
const normalizationCode = `
  const normalizedPMTasks = pmTasks.map(pm => ({
    id: pm.id,
    timestamp: pm.scheduled_date,
    assetId: pm.asset_id,
    assetName: pm.asset_name,
    category: pm.category || 'General',
    issue: \`[\${pm.maintenance_type || 'PM'}] \${pm.maintenance_task}\`,
    priority: pm.priority,
    assignedToId: pm.assigned_to_id || 'unassigned',
    assignedToName: pm.assigned_to_name,
    status: pm.status,
    loggedBy: pm.supervisor || pm.logged_by || 'System',
    isPM: true,
    downtimeHours: pm.estimated_duration || 2
  }));

  const allTickets = [...workOrders, ...normalizedPMTasks];
`;

if (!code.includes('const allTickets = [...workOrders, ...normalizedPMTasks];')) {
    code = code.replace(
        "const pendingCount = workOrders.filter(o => o.status === 'Pending').length;",
        normalizationCode + "\n  const pendingCount = allTickets.filter(o => o.status === 'Pending').length;"
    );
    code = code.replace("const inProgressCount = workOrders.filter(o => o.status === 'In Progress').length;", "const inProgressCount = allTickets.filter(o => o.status === 'In Progress').length;");
    code = code.replace("const completedCount = workOrders.filter(o => o.status === 'Completed').length;", "const completedCount = allTickets.filter(o => o.status === 'Completed').length;");
    code = code.replace("const totalCount = workOrders.length;", "const totalCount = allTickets.length;");
    
    // update completedWithDowntime
    code = code.replace(
        "const completedWithDowntime = workOrders.filter(",
        "const completedWithDowntime = allTickets.filter("
    );
}

// 5. Pass pmTasks to TechnicianView
if (!code.includes("pmTasks={pmTasks}")) {
    code = code.replace(
        "<TechnicianView\n                  workOrders={workOrders}",
        "<TechnicianView\n                  workOrders={workOrders}\n                  pmTasks={pmTasks}"
    );
}

fs.writeFileSync('src/App.tsx', code);
console.log("App.tsx modified");
