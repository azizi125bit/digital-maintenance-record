# Digital Maintenance Records (DMR) System

Sistem Pengurusan Penyelenggaraan Digital (CMMS) berasaskan web yang direka untuk bengkel, makmal latihan teknikal (TVET), dan institusi industri.

Aplikasi ini menyokong pengurusan tiket aduan kerosakan (*Work Orders*), jadual penyelenggaraan berkala (*Preventive Maintenance*), direktori aset/mesin (*Asset Directory*), serta pengurusan staf berasaskan peranan (*Management, Technician, Auditor*).

---

## 🚀 Panduan Menjalankan Aplikasi Secara Setempat (Localhost)

Aplikasi ini tidak lagi memerlukan pangkalan data luaran seperti Supabase. Semua rekod disimpan terus dalam fail tempatan **`data/db.json`** di komputer anda.

### 1. Keperluan Sistem (Prerequisites)
Pastikan komputer anda telah dipasang dengan **Node.js** (versi 18 atau ke atas):
- Muat turun percuma di: [nodejs.org](https://nodejs.org) (Pilih versi LTS).
- Semak pemasangan dalam Terminal / Command Prompt:
  ```bash
  node -v
  npm -v
  ```

---

### 2. Langkah Pemasangan (Setup)

1. **Ekstrak Fail Projek**:
   - Jika anda memuat turun fail ZIP dari Google AI Studio, ekstrak fail ZIP ke folder pilihan (contoh: `C:\dmr-app` atau `Documents/dmr-app`).

2. **Buka Terminal / Command Prompt**:
   - Buka terminal dan masuk ke folder projek tersebut:
     ```bash
     cd path/to/dmr-app
     ```

3. **Pasang Dependencies (Pakej Diperlukan)**:
   - Jalankan arahan berikut untuk memuat turun semua library yang diperlukan:
     ```bash
     npm install
     ```

4. **Konfigurasi Fail `.env` (Pilihan)**:
   - Salin fail `.env.example` dan namakan sebagai `.env`:
     ```bash
     cp .env.example .env
     ```
     *(Di Windows, anda boleh buat salinan fail `.env.example` dan namakannya `.env`)*
   - Masukkan kunci `GEMINI_API_KEY` jika anda ingin menggunakan fungsi penjanaan AI checklist automatik:
     ```env
     GEMINI_API_KEY="kunci_api_anda_dari_google_ai_studio"
     ```
     *(Jika tiada kunci API, sistem tetap berfungsi 100% untuk rekod penyelenggaraan).*

---

### 3. Menjalankan Aplikasi

Jalankan arahan pembangunan (development server):

```bash
npm run dev
```

Terminal akan memaparkan mesej:
```text
Server running on http://0.0.0.0:3000 (Localhost mode)
```

Buka pelayar web (Google Chrome, Microsoft Edge, Mozilla Firefox) dan layari:
👉 **[http://localhost:3000](http://localhost:3000)**

---

## 👥 Akaun Log Masuk Demo

Sistem ini mempunyai data pengguna contoh sedia ada:

| Peranan (Role) | Nama Pengguna (Username) | PIN / Katalaluan | Nama Kakitangan |
| :--- | :--- | :--- | :--- |
| **Management** | `ahmad` | `1111` | Ahmad Farhan Bin Isa (Manager) |
| **Management** | `aziz_sup` | `1234` | Encik Aziz (Supervisor) |
| **Technician** | `syahmi_tech` | `5678` | M. Syahmi Bin Razak |
| **Technician** | `khairul_tech` | `2222` | Khairul Jamil Bin Ariffin |
| **Auditor** | `sarah_aud` | `0000` | Sarah Lim (Compliance Auditor) |

---

## 🗄️ Penyimpanan Data Tempatan (`data/db.json`)

- Semua data tiket aduan, rekod log aktiviti, senarai mesin/aset, jadual PM, dan profil pengguna disimpan secara automatik dalam fail:
  `data/db.json`
- Anda boleh membuat salinan sandaran (*backup*) fail `data/db.json` pada bila-bila masa.

---

## 🛠️ Arahan Tambahan (Build untuk Production)

Jika anda ingin membina versi siap untuk pelayan pengeluaran (production):

```bash
# Bina fail frontend dan server
npm run build

# Jalankan server production
npm start
```
