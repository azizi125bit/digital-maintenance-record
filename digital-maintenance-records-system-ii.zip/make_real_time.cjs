const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

const oldEffect = `      };\n      fetchData();\n    }\n  }, [isAuthorized]);`;

const newEffect = `      };
      fetchData();

      const channel = supabase
        .channel('public-db-changes')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'work_orders' }, () => {
          fetchData();
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'preventive_maintenance' }, () => {
          fetchData();
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'activity_logs' }, () => {
          fetchData();
        })
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [isAuthorized]);`;

code = code.replace(oldEffect, newEffect);

fs.writeFileSync('src/App.tsx', code);
console.log("App.tsx updated for real-time");
